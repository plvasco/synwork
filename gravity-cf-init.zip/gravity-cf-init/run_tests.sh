#!/bin/bash
# source $HOME/.config/2F/credentials.sh
go test -v ./... -timeout 2h
