[TOC]

# Cosmic Dust

Welcome to Cosmic Dust.
This project serves to stand up the amis for our accounts to use.


## Prerequisites
go 1.21
2F logins for accounts
KMs key stack is up in account you want to create ami
Grant will need to be up in any account outside of ami account that will need ami use

## New AMI creation

1. Log into the account you want to create a new ami in for common ami use il2-dev

```shell
2F login -p 2F_Gov -t $(gov) -a dev && creds
```

2. Select your stack

```shell
pulumi stack select il2-dev-ami
```

3. Update the yaml ami reference for that accounts yaml file and then pulumi up the stack

```shell
pulumi up
```
4. Once the stack is done up'ing and run was successful, look up the urn reference to the ami, and Delete the state for the ami urn reference

```shell
pulumi stack --show-urns | grep AmiFromInstance
pulumi state delete urn:pulumi:il2-dev-ami::cosmic-dust::aws:ec2/amiFromInstance:AmiFromInstance::SecondFront-prd-eks-v2023October18 --target-dependents
```

5. Down the stack

```shell
pulumi down -r
```
