[TOC]

# Galactic Bridge

Welcome to Galactic Bridge
This project serves to stand up the infrastructure that is needed to connect to services in separate AWS regions


## Prerequisites
go 1.21
2F logins for accounts
Exporting vars so you can deploy to different AWS region
This expects that the pulumi configuration (state bucket) has been configured in the new region
This code also expects basic config (quarks) is configured in the region

## New Peered VPC creation in Gov West to peer to Infra in Gov East

1. Log into the account you want to connect regions in

```shell
2F login -p 2F_Gov -t $(gov) -a dev && creds
```

2. Export new pulumi vars for region you want to peer with (gov west in this example)

```shell
export AWS_DEFAULT_REGION=us-gov-west-1
export PULUMI_BACKEND_URL=s3://gamewarden-infrastructure-state-2f-dev-west
```

3. Create the new pulumi stack

```shell
pp stack init  --secrets-provider "awskms://alias/encryption-key?region=us-gov-west-1"
```

4. Configure the pulumi stacks yaml using the example to your desired configuration

The repo currently supports creation of vpcs, route tables, security groups, and peering connections
This will allow basic connection between region vpcs.

5. Up the stack

```shell
pulumi up -s stack-name
```

This should give you a vpc, private subnet, security groups defined, and routes to connect the two regions VPCs.
