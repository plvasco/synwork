Requires go 1.21

# Local Development

for local development please add the following to your settings.json (remember to replace the full path with your own)

```json
{
    "go.lintTool": "golangci-lint",
    "go.generateTestsFlags": [
        "-parallel",
        "-exported",
    ],
    "go.toolsEnvVars": {
        "GOTESTS_TEMPLATE_DIR": "/Users/jeffdavis/Projects/pulumi/gravity/.vscode/testTemplates/pulumi"
    }
}
```
