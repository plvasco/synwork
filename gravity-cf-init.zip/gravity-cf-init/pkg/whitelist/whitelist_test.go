package whitelist_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/whitelist"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestShouldCreateWhitelist(t *testing.T) {
	t.Parallel()

	err := pulumi.RunErr(func(_ *pulumi.Context) error {
		whitelistOut := whitelist.GetIPWhitelist(pulumi.String("testing"))
		assert.NotNil(t, whitelistOut)

		whitelistOut.ApplyT(func(list []string) bool {
			assert.Equal(t, "0.0.0.0/0", list[0])
			assert.Equal(t, "2.2.2.2/32", list[1])

			return true
		})

		return nil
	}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
	require.NoError(t, err)
}

func TestShouldCreateStringArrayWhitelist(t *testing.T) {
	t.Parallel()

	err := pulumi.RunErr(func(_ *pulumi.Context) error {
		whitelistOut, err := whitelist.GetStringArrayIPWhitelist("testing")
		require.NoError(t, err)
		assert.NotNil(t, whitelistOut)
		assert.Equal(t, "0.0.0.0/0", whitelistOut[0])
		assert.Equal(t, "2.2.2.2/32", whitelistOut[1])

		return nil
	}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
	require.NoError(t, err)
}

func TestShouldFailToCreateArrayWhitelist(t *testing.T) {
	t.Parallel()

	err := pulumi.RunErr(func(_ *pulumi.Context) error {
		_, err := whitelist.GetStringArrayIPWhitelist("doesntexist")
		require.Error(t, err)

		return err
	}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
	require.Error(t, err)
}

func TestShouldFailToCreateWhitelist(t *testing.T) {
	t.Parallel()

	pulumi.Run(func(_ *pulumi.Context) error {
		list := whitelist.GetIPWhitelist(pulumi.String("doesntexist"))

		list.ApplyT(func(ips []string) error {
			require.Empty(t, ips)

			return nil
		})

		return nil
	}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
}
