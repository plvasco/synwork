package whitelist

import (
	"embed"
	"fmt"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"gopkg.in/yaml.v3"
)

//go:embed lists
var whitelists embed.FS

type Config struct {
	IP   string `yaml:"ip"`
	Name string `yaml:"name"`
}
type Users struct {
	IP   string `yaml:"ip"`
	Name string `yaml:"name"`
}

type ComplianceLevel struct {
	ComplianceLevel string `yaml:"complianceLevel"`
	Users           string `yaml:"users"`
}

func GetIPWhitelist(complianceLevel pulumi.StringInput) pulumi.StringArrayOutput {
	iplist, ok := complianceLevel.ToStringOutput().ApplyT(func(level string) ([]string, error) {
		var configs []Config

		fileName := fmt.Sprintf("lists/%s_whitelist.yaml", level)

		fileContent, err := whitelists.ReadFile(fileName)
		if err != nil {
			return nil, fmt.Errorf("unable to read whitelist file %s, %w", fileName, err)
		}

		if err := yaml.Unmarshal(fileContent, &configs); err != nil {
			return nil, fmt.Errorf("unable to unmarshal whitelist %s, %w", fileName, err)
		}

		ips := make([]string, len(configs))
		for i, config := range configs {
			ips[i] = config.IP
		}

		return ips, nil
	}).(pulumi.StringArrayOutput)
	if !ok {
		panic("unable to convert ip list to output")
	}

	return iplist
}

func GetStringArrayIPWhitelist(complianceLevel string) ([]string, error) {
	var configs []Config

	fileName := fmt.Sprintf("lists/%s_whitelist.yaml", complianceLevel)

	fileContent, err := whitelists.ReadFile(fileName)
	if err != nil {
		return nil, fmt.Errorf("unable to reade whitelist file %s, %w", fileName, err)
	}

	if err := yaml.Unmarshal(fileContent, &configs); err != nil {
		return nil, fmt.Errorf("unable to unmarshal whitelist %s, %w", fileName, err)
	}

	ips := make([]string, len(configs))
	for i, config := range configs {
		ips[i] = config.IP
	}

	return ips, nil
}
