```mermaid
---
title: AWS Root
---
classDiagram
    Root o-- Organization
    Root o-- "0..n" OrganizationalUnit
    Root o-- "0..n" ServiceControlPolicy
    Root o-- RootNetwork
    class Root{
        +OrganizationRootID string
	    +OrganizationalUnits map[string]id
	    +ServiceControlPolicies map[string]id
	    +NetworkAccountID id
	    +NetworkRole string
	    +Tags map[string]string
        createOrganization()
        createOrganizationalUnits()
        createServiceControlPolicies()
        createInfrastructure()
    }

    Organization ..> OrganizationalUnit


    ServiceControlPolicy *-- Policy
    ServiceControlPolicy *-- "0..n" PolicyMapping
    class ServiceControlPolicy{
        +PolicyIDs map[string]id
        createPolicy()
        createPolicyMappings()
    }

    OrganizationalUnit ..> PolicyMapping
    Policy ..> PolicyMapping

    RootNetwork *-- Account
    RootNetwork *-- Provider
    RootNetwork *-- Network
    RootNetwork *-- TransitGateway
    class RootNetwork {
        +AccountID id
        +RoleName string
        +VpcID id
        +TransitGatewayID id
        createNetworkAccount()
        createProvider()
        createNetwork()
        createTransitGateway()
    }

    OrganizationalUnit ..> Account
    Account ..> Provider
    Provider ..> Network

    Cluster o-- ClusterNetwork
    ClusterNetwork *--Network
    Network *-- VPC
    Network *-- Subnet
    Network *-- TransitGatewayConnection
    class Network {
        +VpcID id
        +SubnetIDs map[string]id
        createVPC()
        createSubnets()
        createTransitGatewayConnection()
    }

    TransitGatewayConnection ..> TransitGateway
