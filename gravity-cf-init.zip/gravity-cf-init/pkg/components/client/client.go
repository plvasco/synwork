package client

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/service/ec2"
)

type AWSClient interface {
	DescribeTransitGatewayAttachments(ctx context.Context, input *ec2.DescribeTransitGatewayAttachmentsInput, opts ...func(*ec2.Options)) (*ec2.DescribeTransitGatewayAttachmentsOutput, error)
	AcceptTransitGatewayPeeringAttachment(ctx context.Context, input *ec2.AcceptTransitGatewayPeeringAttachmentInput, opts ...func(*ec2.Options)) (*ec2.AcceptTransitGatewayPeeringAttachmentOutput, error)
}
