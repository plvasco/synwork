package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/lb"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const lbComponentName = "gravity:aws:networking:loadbalancer"

type LoadBalancer struct {
	pulumi.ResourceState
	LoadBalancerARN pulumi.StringOutput `pulumi:"loadBalancerARN"`
	TargetGroups    []*lb.TargetGroup   `pulumi:"targetGroups"`
	Listeners       []*lb.Listener      `pulumi:"listeners"`
}

type LoadBalancerArgs struct {
	SecurityGroupID   pulumi.StringInput `pulumi:"nodeSecurityGroupID"`
	VpcID             pulumi.StringInput `pulumi:"vpcID"`
	Type              pulumi.StringInput `pulumi:"type"`
	InternalSubnetIDs pulumi.StringArray `pulumi:"internalSubnetIDs"`
	ExternalSubnetIDs pulumi.StringArray `pulumi:"externalSubnetIDs"`
	Internal          pulumi.BoolInput   `pulumi:"internal"`
	Tags              pulumi.StringMap   `pulumi:"tags"`
	Ports             []*PortConfig      `pulumi:"ports"`
}

type PortConfig struct {
	// Port on which the load balancer is listening.
	ListenerPort pulumi.Int
	// The port on which targets receive traffic.
	NodePort pulumi.Int
	// The port the load balancer uses when performing health checks on targets.
	// Valid values are either `traffic-port`, to use the same port as the target group, or a valid port number between `1` and `65536`.
	// Default is `traffic-port`.
	HealthCheck pulumi.String
}

func (a *LoadBalancerArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", a, err)
	}

	return nil
}

func NewLoadBalancer(ctx *pulumi.Context, name string, args *LoadBalancerArgs, opts ...pulumi.ResourceOption) (*LoadBalancer, error) {
	// creates a new load balancer
	component := &LoadBalancer{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(lbComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", lbComponentName, name, err)
	}

	if err := component.createLoadBalancer(ctx, name+"-elb", args); err != nil {
		return nil, err
	}

	if err := component.createLoadBalancerSecurityGroup(ctx, name+"-elb-sg", args); err != nil {
		return nil, err
	}

	if err := component.createTargetGroupAndListeners(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", lbComponentName, name, err)
	}

	return component, nil
}

func (a *LoadBalancerArgs) validate() error {
	if err := utils.ValidateStruct(a); err != nil {
		return fmt.Errorf("%T validation failed: %w", a, err)
	}

	return nil
}

func (c *LoadBalancer) createLoadBalancer(ctx *pulumi.Context, name string, args *LoadBalancerArgs) error {
	subnetIDs := pulumix.Flatten(pulumix.Apply(args.Internal.ToBoolOutput(), func(internal bool) pulumi.StringArray {
		if internal {
			return args.InternalSubnetIDs
		}

		return args.ExternalSubnetIDs
	}))

	loadBalancer, err := lb.NewLoadBalancer(ctx, name, &lb.LoadBalancerArgs{
		EnableDeletionProtection: pulumi.Bool(false),
		Internal:                 args.Internal,
		Subnets:                  pulumix.Cast[pulumi.StringArrayOutput](subnetIDs),
		IpAddressType:            pulumi.String("ipv4"),
		LoadBalancerType:         args.Type,
		Tags:                     args.Tags,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create load balancer, %w", err)
	}

	c.LoadBalancerARN = loadBalancer.Arn

	return nil
}

func (c *LoadBalancer) createTargetGroupAndListeners(ctx *pulumi.Context, name string, args *LoadBalancerArgs) error {
	targetGroups := []*lb.TargetGroup{}
	listeners := []*lb.Listener{}

	for _, port := range args.Ports {
		tgName := fmt.Sprintf("tg-%d", port.ListenerPort)
		listenerName := fmt.Sprintf("listener-%d", port.ListenerPort)

		targetGroup, err := lb.NewTargetGroup(ctx, name+"-"+tgName, &lb.TargetGroupArgs{
			Name:                  pulumi.String(name + "-" + tgName),
			ConnectionTermination: pulumi.Bool(true),
			HealthCheck: &lb.TargetGroupHealthCheckArgs{
				Port:     port.HealthCheck,
				Protocol: pulumi.String("TCP"),
			},
			Port:     port.NodePort,
			Protocol: pulumi.String("TCP"),
			Tags:     args.Tags,
			VpcId:    args.VpcID,
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create target group, %w", err)
		}

		targetGroups = append(targetGroups, targetGroup)

		listener, err := lb.NewListener(ctx, name+"-"+listenerName, &lb.ListenerArgs{
			DefaultActions: lb.ListenerDefaultActionArray{
				&lb.ListenerDefaultActionArgs{
					TargetGroupArn: targetGroup.Arn,
					Type:           pulumi.String("forward"),
				},
			},
			LoadBalancerArn: c.LoadBalancerARN,
			Port:            port.ListenerPort,
			Protocol:        pulumi.String("TCP"),
			Tags:            args.Tags,
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create listener, %w", err)
		}

		listeners = append(listeners, listener)
	}

	c.TargetGroups = targetGroups
	c.Listeners = listeners

	return nil
}

func (c *LoadBalancer) createLoadBalancerSecurityGroup(ctx *pulumi.Context, name string, args *LoadBalancerArgs) error {
	securityGroup, err := ec2.NewSecurityGroup(ctx, name, &ec2.SecurityGroupArgs{
		Tags:  args.Tags,
		VpcId: args.VpcID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create new security group, %w", err)
	}

	ingressRules := map[string]*ec2.SecurityGroupRuleArgs{}

	for _, port := range args.Ports {
		ingress := &ec2.SecurityGroupRuleArgs{
			CidrBlocks:      pulumi.ToStringArray([]string{"0.0.0.0/0"}),
			FromPort:        port.ListenerPort,
			Protocol:        pulumi.String("TCP"),
			ToPort:          port.ListenerPort,
			SecurityGroupId: args.SecurityGroupID,
			Type:            pulumi.String("ingress"),
		}
		if port.ListenerPort == 15021 {
			ingress.CidrBlocks = nil
			ingress.SourceSecurityGroupId = args.SecurityGroupID
		}

		ingressRules[fmt.Sprintf("%s-%d-ingress", name, port.ListenerPort)] = ingress

		_, err := ec2.NewSecurityGroupRule(ctx, fmt.Sprintf("%s-cluster-sec-rule-%d", name, port.NodePort), &ec2.SecurityGroupRuleArgs{
			FromPort:              port.NodePort,
			Protocol:              pulumi.String("tcp"),
			SecurityGroupId:       args.SecurityGroupID,
			SourceSecurityGroupId: securityGroup.ID(),
			ToPort:                port.NodePort,
			Type:                  pulumi.String("ingress"),
		}, pulumi.Parent(c), pulumi.DeleteBeforeReplace(true))
		if err != nil {
			return fmt.Errorf("unable to create security group rule, %w", err)
		}
	}

	_, err = ec2.NewSecurityGroupRule(ctx, name+"-egress-rule", &ec2.SecurityGroupRuleArgs{
		CidrBlocks:      pulumi.ToStringArray([]string{"0.0.0.0/0"}),
		FromPort:        pulumi.Int(0),
		Protocol:        pulumi.String("-1"),
		SecurityGroupId: securityGroup.ID(),
		ToPort:          pulumi.Int(0),
		Type:            pulumi.String("egress"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create new security group egress rule, %w", err)
	}

	for ruleName, rule := range ingressRules {
		_, err = ec2.NewSecurityGroupRule(ctx, ruleName, rule, pulumi.Parent(c), pulumi.DeleteBeforeReplace(true))
		if err != nil {
			return fmt.Errorf("unable to create security group Port ingress rule %s, %w", ruleName, err)
		}
	}

	return nil
}
