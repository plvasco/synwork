package networking

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	tgw "github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2transitgateway"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/iam"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/organizations"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ram"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const transitGatewayComponentName = "gravity:aws:transitGateway"

var ErrUnableToFindAttachment = errors.New("unable to find peering attachment id")

type TransitGateway struct {
	pulumi.ResourceState
	ID             pulumi.StringOutput `pulumi:"ID"`
	TransitGateway *tgw.TransitGateway `pulumi:"transitGateway"`
}

type TransitGatewayArgs struct {
	AmazonASN pulumi.IntInput `pulumi:"amazonASN" validate:"default=64512"`
	// overarching cloud supernet that the ipam will use to find free ranges.
	WanCidr        pulumi.StringInput   `pulumi:"wanCidr"        validate:"default=10.0.0.0/8"`
	IngressSubnets map[string]*Subnet   `pulumi:"ingreesSubnets" validate:"required"`
	EgressSubnets  map[string]*Subnet   `pulumi:"egreesSubnets"  validate:"required"`
	EgressVPC      pulumi.StringInput   `pulumi:"egressVPC"      validate:"required"`
	Peers          map[string]*PeerArgs `pulumi:"peers"          validate:"dig"`
	Tags           pulumi.StringMap     `pulumi:"tags"`
	// Internal ARGS
	organizationARN pulumi.StringInput `pulumi:"organizationARN"`
	organizationID  pulumi.StringInput `pulumi:"organizationID"`
}

type PeerArgs struct {
	RouteCIDR        pulumi.StringInput `pulumi:"routeCIDR"        validate:"required"`
	TransitGatewayID pulumi.StringInput `pulumi:"transitGatewayID" validate:"required"`
	Region           pulumi.StringInput `pulumi:"region"           validate:"required"`
	Tags             pulumi.StringMap   `pulumi:"tags"`
}

func NewTransitGateway(ctx *pulumi.Context, name string, args *TransitGatewayArgs, opts ...pulumi.ResourceOption) (*TransitGateway, error) {
	component := &TransitGateway{}

	if err := args.validate(ctx); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(transitGatewayComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", transitGatewayComponentName, name, err)
	}

	if err := component.createTransitGateway(ctx, name+"-transitGateway", args); err != nil {
		return nil, err
	}

	if err := component.createTGWResourceShare(ctx, name+"-share", args); err != nil {
		return nil, err
	}

	if err := component.createTGWOrgRoutePolicy(ctx, name+"-routeManagement", args); err != nil {
		return nil, err
	}

	if err := component.createNewTransitGatewayPeers(ctx, name+"-peer", args); err != nil {
		return nil, err
	}

	if err := component.createEgressAttachment(ctx, name+"-egress", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"transitGateway": component.TransitGateway,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", transitGatewayComponentName, name, err)
	}

	return component, nil
}

func (c *TransitGateway) createTransitGateway(ctx *pulumi.Context, name string, args *TransitGatewayArgs) error {
	// Create a Transit Gateway
	transitGateway, err := tgw.NewTransitGateway(ctx, name, &tgw.TransitGatewayArgs{
		AmazonSideAsn:                args.AmazonASN,
		AutoAcceptSharedAttachments:  pulumi.String("enable"),
		DefaultRouteTableAssociation: pulumi.String("enable"),
		DefaultRouteTablePropagation: pulumi.String("disable"),
		Tags:                         utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create transit gateway, %w", err)
	}

	c.TransitGateway = transitGateway

	return nil
}

func (c *TransitGateway) createTGWResourceShare(ctx *pulumi.Context, name string, args *TransitGatewayArgs) error {
	share, err := ram.NewResourceShare(ctx, name, &ram.ResourceShareArgs{
		AllowExternalPrincipals: pulumi.Bool(false),
		Tags:                    utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create new resource share, %w", err)
	}

	if _, err := ram.NewPrincipalAssociation(ctx, name+"-principal", &ram.PrincipalAssociationArgs{
		Principal:        args.organizationARN,
		ResourceShareArn: share.Arn,
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create Transit Gateway Resource Share Principal Association, %w", err)
	}

	if _, err := ram.NewResourceAssociation(ctx, name+"-resource", &ram.ResourceAssociationArgs{
		ResourceArn:      c.TransitGateway.Arn,
		ResourceShareArn: share.Arn,
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create Transit Gateway Resource Share Resource Association, %w", err)
	}

	return nil
}

func (c *TransitGateway) createTGWOrgRoutePolicy(ctx *pulumi.Context, name string, args *TransitGatewayArgs) error {
	// Define the policy for managing Transit Gateway routes
	routeManagementPolicy := pulumi.String(`{
		"Version": "2012-10-17",
		"Statement": [
			{
				"Effect": "Allow",
				"Action": [
					"ec2:DescribeTransitGatewayRouteTables",
					"ec2:AssociateTransitGatewayRouteTable",
					"ec2:DisassociateTransitGatewayRouteTable",
					"ec2:SearchTransitGatewayRoutes",
					"ec2:CreateTransitGatewayRoute",
					"ec2:DeleteTransitGatewayRoute"
				],
				"Resource": "*"
			}
		]
	}`)

	// Create the IAM policy for route management
	policy, err := iam.NewPolicy(ctx, name+"-policy", &iam.PolicyArgs{Policy: routeManagementPolicy}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create Transit Gateway Route Policy, %w", err)
	}

	// Define the trust policy to allow any account in your AWS Organization to assume the role
	trustPolicy := pulumi.Sprintf(`{
		"Version": "2012-10-17",
		"Statement": [
			{
				"Effect": "Allow",
				"Principal": {
                    "AWS": "*"
                },
				"Action": "sts:AssumeRole",
				"Condition": {
					"StringEquals": {
						"aws:PrincipalOrgID": "%s"
					}
				}
			}
		]
	}`, args.organizationID)

	// Create the IAM role with the trust policy
	role, err := iam.NewRole(ctx, name+"-role", &iam.RoleArgs{
		Name:             pulumi.Sprintf("%s-routeManager", c.TransitGateway.ID()),
		AssumeRolePolicy: trustPolicy,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create Transit Gateway Route Policy, %w", err)
	}

	// Attach the policy to the role
	_, err = iam.NewRolePolicyAttachment(ctx, name+"-policy-attachment", &iam.RolePolicyAttachmentArgs{
		Role:      role.Name,
		PolicyArn: policy.Arn,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to attach Transit Gateway Route Policy to Role, %w", err)
	}

	return nil
}

func (c *TransitGateway) createNewTransitGatewayPeers(ctx *pulumi.Context, name string, args *TransitGatewayArgs) error {
	for peerName, peerArgs := range args.Peers {
		args.Tags = utils.CombineTags(args.Tags, peerArgs.Tags)

		if err := c.createTransitGatewayPeer(ctx, name+"-"+peerName, peerArgs); err != nil {
			return err
		}
	}

	return nil
}

func (c *TransitGateway) createTransitGatewayPeer(ctx *pulumi.Context, name string, args *PeerArgs) error {
	transitGateway := tgw.LookupTransitGatewayOutput(ctx, tgw.LookupTransitGatewayOutputArgs{Id: args.TransitGatewayID})

	attachment, err := tgw.NewPeeringAttachment(ctx, name, &tgw.PeeringAttachmentArgs{
		PeerAccountId:        transitGateway.OwnerId(),
		PeerRegion:           args.Region,
		PeerTransitGatewayId: args.TransitGatewayID,
		Tags:                 utils.GenerateTags(args.Tags, name),
		TransitGatewayId:     c.TransitGateway.ID(),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create transit gateway attachment %s, %w", name, err)
	}

	acceptor, err := tgw.NewPeeringAttachmentAccepter(ctx, name+"-acceptor", &tgw.PeeringAttachmentAccepterArgs{
		TransitGatewayAttachmentId: c.findRemoteTGWAttachment(ctx, attachment),
		Tags:                       utils.GenerateTags(args.Tags, name+"-remote"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create transit gateway attachment acceptor %s, %w", name, err)
	}

	if _, err := tgw.NewRoute(ctx, name+"-route", &tgw.RouteArgs{
		DestinationCidrBlock:       args.RouteCIDR,
		TransitGatewayAttachmentId: attachment.ID(),
		TransitGatewayRouteTableId: c.TransitGateway.AssociationDefaultRouteTableId,
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{acceptor})); err != nil {
		return fmt.Errorf("unable to create transit gateway route %s, %w", name, err)
	}

	return nil
}

func (c *TransitGateway) createEgressAttachment(ctx *pulumi.Context, name string, args *TransitGatewayArgs) error {
	attachment, err := tgw.NewVpcAttachment(ctx, name+"-attachment", &tgw.VpcAttachmentArgs{
		SubnetIds: func() pulumi.StringArray {
			subnets := pulumi.StringArray{}

			for _, subnet := range args.EgressSubnets {
				subnets = append(subnets, subnet.ID)
			}

			return subnets
		}(),
		Tags:             utils.GenerateTags(args.Tags, name),
		TransitGatewayId: c.TransitGateway.ID(),
		VpcId:            args.EgressVPC,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create network TGW VPC attachment %s on public subnets, %w", name, err)
	}

	if _, err := tgw.NewRoute(ctx, name+"-route", &tgw.RouteArgs{
		DestinationCidrBlock:       pulumi.String("0.0.0.0/0"),
		TransitGatewayAttachmentId: attachment.ID(),
		TransitGatewayRouteTableId: c.TransitGateway.AssociationDefaultRouteTableId,
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create egress transit gateway route %s, %w", name, err)
	}

	for az, subnet := range args.IngressSubnets {
		if _, err = ec2.NewRoute(ctx, name+"-"+az, &ec2.RouteArgs{
			DestinationCidrBlock: args.WanCidr,
			RouteTableId:         subnet.RouteTableID,
			TransitGatewayId:     c.TransitGateway.ID(),
		}); err != nil {
			return fmt.Errorf("unable to create internal supernet route %s, %w", name, err)
		}
	}

	return nil
}
func (c *TransitGateway) findRemoteTGWAttachment(ctx *pulumi.Context, attachment *tgw.PeeringAttachment) pulumi.StringOutput {
	peeringAttachments := tgw.GetAttachmentsOutput(ctx, tgw.GetAttachmentsOutputArgs{
		Filters: tgw.GetAttachmentsFilterArray{
			tgw.GetAttachmentsFilterArgs{
				Name:   pulumi.String("transit-gateway-id"),
				Values: pulumi.StringArray{attachment.PeerTransitGatewayId},
			},
			tgw.GetAttachmentsFilterArgs{
				Name: pulumi.String("state"),
				Values: pulumi.StringArray{
					pulumi.String("pendingAcceptance"),
					pulumi.String("available"),
				},
			},
		},
	}, pulumi.Parent(c))

	attachmentID := pulumix.Apply2Err(peeringAttachments.Ids(), attachment.TransitGatewayId, func(idArray []string, transitGatewayID string) (string, error) {
		for _, id := range idArray {
			peeringAttachment, err := tgw.LookupPeeringAttachment(ctx, &tgw.LookupPeeringAttachmentArgs{
				Id: &id,
			}, pulumi.Parent(c))
			if err != nil {
				if ctx.DryRun() {
					return "to-be-determined", nil
				}

				return "", fmt.Errorf("unable to Lookup remote TGW Attachment ID, %w", err)
			}

			if peeringAttachment.PeerTransitGatewayId == transitGatewayID {
				return peeringAttachment.Id, nil
			}
		}

		return "", ErrUnableToFindAttachment
	})

	return pulumix.Cast[pulumi.StringOutput](attachmentID)
}

func (args *TransitGatewayArgs) validate(ctx *pulumi.Context) error {
	org := organizations.LookupOrganizationOutput(ctx, nil)
	args.organizationARN = org.Arn()
	args.organizationID = org.Id()

	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["Organization"]; !ok {
		args.Tags["Organization"] = pulumi.String(ctx.Stack())
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *TransitGatewayArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (args *PeerArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
