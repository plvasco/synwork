package networking

import (
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

type GetSubnetByAZArgs struct {
	AvailabilityZone pulumi.StringInput `pulumi:"availabilityZone"`
	UsePublicSubnet  pulumi.BoolInput   `pulumi:"usePublicSubnet"`
	VpcID            pulumi.StringInput `pulumi:"vpcID"`
}

func GetSubnetByAZ(ctx *pulumi.Context, args *GetSubnetByAZArgs) (pulumi.StringOutput, error) {
	access := pulumix.Apply(args.UsePublicSubnet.ToBoolOutput(), func(usePublicSubnet bool) string {
		if usePublicSubnet {
			return "public"
		}

		return "private"
	})

	subnetResults := ec2.GetSubnetsOutput(ctx, ec2.GetSubnetsOutputArgs{
		Filters: ec2.GetSubnetsFilterArray{
			ec2.GetSubnetsFilterArgs{
				Name:   pulumi.String("availability-zone"),
				Values: pulumi.StringArray{args.AvailabilityZone},
			},
			ec2.GetSubnetsFilterArgs{
				Name:   pulumi.String("tag:access"),
				Values: pulumi.StringArray{pulumix.Cast[pulumi.StringOutput](access)},
			},
			ec2.GetSubnetsFilterArgs{
				Name:   pulumi.String("vpc-id"),
				Values: pulumi.StringArray{args.VpcID},
			},
		},
	})

	return subnetResults.Ids().Index(pulumi.Int(0)), nil
}
