package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewSubnet(t *testing.T) {
	t.Parallel()

	type want struct {
		subnets []string
	}

	type args struct {
		name string
		args *networking.SubnetsArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "Create IGW Subnet",
			in: args{
				name: "test-igw",
				args: &networking.SubnetsArgs{
					CIDRString:        pulumi.String("10.0.0.0/24"),
					SubnetPrefixSize:  pulumi.Int(26),
					InternetGatewayID: pulumi.String("igw-123456"),
					Tags:              nil,
					VpcID:             pulumi.String("vpc-12345"),
				},
			},
			want: want{
				subnets: []string{"test-igw-us-gov-east-1a_id", "test-igw-us-gov-east-1b_id", "test-igw-us-gov-east-1c_id"},
			},
			wantErr: false,
		},
		{
			name: "Create NatGW Subnet",
			in: args{
				name: "test-ngw",
				args: &networking.SubnetsArgs{
					CIDRString:       pulumi.String("10.0.0.0/24"),
					SubnetPrefixSize: pulumi.Int(0),
					NatGatewayIDs: pulumi.StringMap{
						"us-east-1a": pulumi.String("ngw-123456"),
						"us-east-1b": pulumi.String("ngw-789012"),
						"us-east-1c": pulumi.String("ngw-345678"),
					},
					Tags:  nil,
					VpcID: pulumi.String("vpc-12345"),
				},
			},
			want: want{
				subnets: []string{"test-ngw-us-gov-east-1a_id", "test-ngw-us-gov-east-1b_id", "test-ngw-us-gov-east-1c_id"},
			},
			wantErr: false,
		},
		{
			name: "Create TGW Subnet",
			in: args{
				name: "test-tgw",
				args: &networking.SubnetsArgs{
					CIDRString:       pulumi.String("10.0.0.0/24"),
					SubnetPrefixSize: pulumi.Int(26),
					TransitGatewayID: pulumi.String("tgw-12345"),
					Tags:             nil,
					VpcID:            pulumi.String("vpc-12345"),
				},
			},
			want: want{
				subnets: []string{"test-tgw-us-gov-east-1a_id", "test-tgw-us-gov-east-1b_id", "test-tgw-us-gov-east-1c_id"},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewSubnets(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				for _, subnetCfg := range got {
					subnetCfg.ID.ApplyT(func(subnetID string) string {
						assert.Contains(t, tt.want.subnets, subnetID)

						return subnetID
					})
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestSubnetsArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.SubnetsArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"cidrString": "10.0.0.0/16",
				"subnetPrefixSize": 24,
				"internetGateway": "igw-12345",
				"natGatewayIDs": {"us-east-1a": "nat-1", "us-east-1b": "nat-2"},
				"transitGatewayID": "tgw-67890",
				"vpcID": "vpc-54321",
				"tags": {"env": "production", "team": "networking"}
			}`,
			want: &networking.SubnetsArgs{
				CIDRString:        pulumi.String("10.0.0.0/16"),
				SubnetPrefixSize:  pulumi.Int(24),
				InternetGatewayID: pulumi.String("igw-12345"),
				NatGatewayIDs:     pulumi.StringMap{"us-east-1a": pulumi.String("nat-1"), "us-east-1b": pulumi.String("nat-2")},
				TransitGatewayID:  pulumi.String("tgw-67890"),
				VpcID:             pulumi.String("vpc-54321"),
				Tags:              pulumi.StringMap{"env": pulumi.String("production"), "team": pulumi.String("networking")},
			},
			wantErr: false,
		},
		{
			name: "invalid field type",
			input: `{
				"cidrString": "10.0.0.0/16",
				"subnetPrefixSize": "invalid-size", // subnetPrefixSize should be an integer
				"vpcID": "vpc-54321"
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"cidrString": "10.0.0.0/16", "subnetPrefixSize": 24, "vpcID": "vpc-54321"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.SubnetsArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}

func TestSubnetArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.SubnetArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"availabilityZone": "us-east-1a",
				"cidrBlock": "10.0.1.0/24",
				"internetGateway": "igw-12345",
				"natGatewayIDs": "nat-67890",
				"transitGatewayID": "tgw-54321",
				"tags": {"env": "production", "team": "networking"},
				"vpcID": "vpc-12345"
			}`,
			want: &networking.SubnetArgs{
				AvailabilityZone:  pulumi.String("us-east-1a"),
				CIDRBlock:         pulumi.String("10.0.1.0/24"),
				InternetGatewayID: pulumi.String("igw-12345"),
				NatGatewayID:      pulumi.String("nat-67890"),
				TransitGatewayID:  pulumi.String("tgw-54321"),
				Tags:              pulumi.StringMap{"env": pulumi.String("production"), "team": pulumi.String("networking")},
				VpcID:             pulumi.String("vpc-12345"),
			},
			wantErr: false,
		},
		{
			name: "invalid field type",
			input: `{
				"availabilityZone": "us-east-1a",
				"cidrBlock": 12345, // cidrBlock should be a string
				"internetGateway": "igw-12345",
				"vpcID": "vpc-12345"
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"availabilityZone": "us-east-1a", "cidrBlock": "10.0.1.0/24", "vpcID": "vpc-12345"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.SubnetArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
