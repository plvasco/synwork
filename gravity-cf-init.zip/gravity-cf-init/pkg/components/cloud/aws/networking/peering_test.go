package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewVpcPeering(t *testing.T) {
	t.Parallel()

	type want struct {
		connectionID string
	}

	type args struct {
		name string
		args *networking.VpcPeeringArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create peering connection",
			in: args{
				name: "test",
				args: &networking.VpcPeeringArgs{
					PeerRegion:    pulumi.String("test-east-1"),
					PeerVpcID:     pulumi.String("123456789"),
					PeerCidrBlock: pulumi.String("10.0.0.0/24"),
					PeerRouteTableIDs: []pulumi.StringInput{
						pulumi.String("123456"),
						pulumi.String("789012"),
					},
					CidrBlock: pulumi.String("10.1.0.0/24"),
					VpcID:     pulumi.String("my-vpc-id"),
					RouteTableIDs: []pulumi.StringInput{
						pulumi.String("123456"),
						pulumi.String("789012"),
					},
					Tags: map[string]pulumi.StringInput{},
				},
			},
			want: want{
				connectionID: "test-peering_id",
			},
			wantErr: false,
		},
		{
			name: "should error on missing required input",
			in: args{
				name: "test",
				args: &networking.VpcPeeringArgs{
					PeerRegion:    pulumi.String("test-east-1"),
					PeerCidrBlock: pulumi.String("10.0.0.0/24"),
					PeerRouteTableIDs: []pulumi.StringInput{
						pulumi.String("123456"),
						pulumi.String("789012"),
					},
					CidrBlock: pulumi.String("10.1.0.0/24"),
					VpcID:     pulumi.String("my-vpc-id"),
					RouteTableIDs: []pulumi.StringInput{
						pulumi.String("123456"),
						pulumi.String("789012"),
					},
					Tags: map[string]pulumi.StringInput{},
				},
			},
			wantErr: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewVpcPeering(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.ConnectionID.ApplyT(func(id string) string {
					assert.Equal(t, tc.want.connectionID, id)

					return id
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks))) // add mocks here
			if (err != nil) != tc.wantErr {
				t.Errorf("NewVpcPeering() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestVpcPeeringArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.VpcPeeringArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"peerRegion": "us-west-2",
				"peerVpcID": "vpc-12345",
				"peerCidrBlock": "10.0.0.0/16",
				"peerRouteTableIDs": ["rtb-11111", "rtb-22222"],
				"cidrBlock": "10.1.0.0/16",
				"vpcID": "vpc-67890",
				"routeTableIDs": ["rtb-33333", "rtb-44444"],
				"tags": {"env": "production", "team": "networking"}
			}`,
			want: &networking.VpcPeeringArgs{
				PeerRegion:        pulumi.String("us-west-2"),
				PeerVpcID:         pulumi.String("vpc-12345"),
				PeerCidrBlock:     pulumi.String("10.0.0.0/16"),
				PeerRouteTableIDs: pulumi.StringArray{pulumi.String("rtb-11111"), pulumi.String("rtb-22222")},
				CidrBlock:         pulumi.String("10.1.0.0/16"),
				VpcID:             pulumi.String("vpc-67890"),
				RouteTableIDs:     pulumi.StringArray{pulumi.String("rtb-33333"), pulumi.String("rtb-44444")},
				Tags:              pulumi.StringMap{"env": pulumi.String("production"), "team": pulumi.String("networking")},
			},
			wantErr: false,
		},
		{
			name: "invalid field type",
			input: `{
				"peerRegion": "us-west-2",
				"peerVpcID": "vpc-12345",
				"peerCidrBlock": "10.0.0.0/16",
				"peerRouteTableID": "invalid", // peerRouteTableID should be an array
				"cidrBlock": "10.1.0.0/16",
				"vpcID": "vpc-67890",
				"routeTableID": ["rtb-33333", "rtb-44444"]
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"peerRegion": "us-west-2", "peerVpcID": "vpc-12345", "peerCidrBlock": "10.0.0.0/16", "routeTableID": ["rtb-33333"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.VpcPeeringArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
