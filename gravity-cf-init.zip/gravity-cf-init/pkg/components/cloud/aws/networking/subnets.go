package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const (
	subnetsComponentName = "gravity:aws:network:subnets"
)

type Subnets map[string]*Subnet

type Subnet struct {
	pulumi.ResourceState
	ID           pulumi.StringOutput `pulumi:"subnetID"`
	RouteTableID pulumi.StringOutput `pulumi:"routeTableID"`
	CIDRBlock    pulumi.StringOutput `pulumi:"cidrBlock"`
}

type SubnetsArgs struct {
	// The CIDR address to build subnets on.
	CIDRString pulumi.StringInput `pulumi:"cidrString" validate:"required"`
	// The Size of the subnet prefix to use when generating subnets per AZ (default is 26).
	SubnetPrefixSize pulumi.IntInput `pulumi:"subnetPrefixSize" validate:"default=26"`
	// Optionally route through an InternetGateway.
	InternetGatewayID pulumi.StringInput `pulumi:"internetGateway"`
	// Nat gateway ID for routes.
	NatGatewayIDs pulumi.StringMap `pulumi:"natGatewayIDs"`
	// TransitGateway to make an attachment to.
	TransitGatewayID pulumi.StringInput `pulumi:"transitGatewayID"`
	// VPC to build subnets in.
	VpcID pulumi.StringInput `pulumi:"vpcID" validate:"required"`
	// Tags to apply to all child objects of the subnet component resource.
	Tags pulumi.StringMap `pulumi:"tags"`
}

type SubnetArgs struct {
	// Availability Zone to put subnet on.
	AvailabilityZone pulumi.StringInput `pulumi:"availabilityZone"`
	// The CIDR address to build subnet on.
	CIDRBlock pulumi.StringInput `pulumi:"cidrBlock"`
	// Optionally route through an InternetGateway.
	InternetGatewayID pulumi.StringInput `pulumi:"internetGateway"`
	// Nat gateway ID for routes.
	NatGatewayID pulumi.StringInput `pulumi:"natGatewayIDs"`
	// TransitGateway to make an attachment to.
	TransitGatewayID pulumi.StringInput `pulumi:"transitGatewayID"`
	// Tags to apply to all child objects of the subnet component resource.
	Tags pulumi.StringMap `pulumi:"tags"`
	// VPC to build subnets in.
	VpcID pulumi.StringInput `pulumi:"vpcID"`
}

func NewSubnets(ctx *pulumi.Context, name string, args *SubnetsArgs, opts ...pulumi.ResourceOption) (Subnets, error) {
	if err := args.validate(); err != nil {
		return nil, err
	}

	subnets := map[string]*Subnet{}

	azs, err := aws.GetAvailabilityZones(ctx, nil)
	if err != nil {
		return nil, fmt.Errorf("unable to get azs, %w", err)
	}

	subnetCIDRs := cloud.PulumiSplitSubnet(args.CIDRString, args.SubnetPrefixSize, pulumi.Int(len(azs.ZoneIds)))

	for index := 0; index < len(azs.ZoneIds) && index < 3; index++ {
		azName := azs.Names[index]
		azID := azs.ZoneIds[index]
		nameStr := fmt.Sprintf("%s-%s", name, azName)

		subnet, err := NewSubnet(ctx, nameStr, &SubnetArgs{
			AvailabilityZone:  pulumi.String(azID),
			CIDRBlock:         subnetCIDRs.Index(pulumi.Int(index)),
			InternetGatewayID: args.InternetGatewayID,
			NatGatewayID:      args.NatGatewayIDs[azName],
			TransitGatewayID:  args.TransitGatewayID,
			Tags:              utils.GenerateTags(args.Tags, nameStr),
			VpcID:             args.VpcID,
		}, opts...)
		if err != nil {
			return nil, fmt.Errorf("unable to create subnet %s, %w", nameStr, err)
		}

		subnets[azName] = subnet
	}

	return subnets, nil
}

func NewSubnet(ctx *pulumi.Context, name string, args *SubnetArgs, opts ...pulumi.ResourceOption) (*Subnet, error) {
	component := &Subnet{}

	if err := ctx.RegisterComponentResource(subnetsComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", subnetsComponentName, name, err)
	}

	if err := component.createSubnet(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createSubnetNetworking(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", subnetsComponentName, name, err)
	}

	return component, nil
}

func (args *SubnetsArgs) validate() error {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	return nil
}

func (args *SubnetArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (args *SubnetsArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

// createSubnet creates a subnet for each availability zone in the region.
func (c *Subnet) createSubnet(ctx *pulumi.Context, name string, args *SubnetArgs) error {
	subnet, err := ec2.NewSubnet(ctx, name, &ec2.SubnetArgs{
		AvailabilityZoneId: args.AvailabilityZone,
		CidrBlock:          args.CIDRBlock,
		Tags:               utils.GenerateTags(args.Tags, name),
		VpcId:              args.VpcID,
	}, pulumi.Parent(c), pulumi.DeleteBeforeReplace(true))
	if err != nil {
		return fmt.Errorf("unable to create subnet %s, %w", name, err)
	}

	c.ID = pulumi.StringOutput(subnet.ID())
	c.CIDRBlock = subnet.CidrBlock.Elem()

	return nil
}

func (c *Subnet) createSubnetNetworking(ctx *pulumi.Context, name string, args *SubnetArgs) error {
	routeTable, err := ec2.NewRouteTable(ctx, name, &ec2.RouteTableArgs{
		Routes: &ec2.RouteTableRouteArray{
			&ec2.RouteTableRouteArgs{
				CidrBlock:        pulumi.String("0.0.0.0/0"),
				NatGatewayId:     args.NatGatewayID,
				TransitGatewayId: args.TransitGatewayID,
				GatewayId:        args.InternetGatewayID,
			},
		},
		Tags:  utils.GenerateTags(args.Tags, name),
		VpcId: args.VpcID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create route table, %w", err)
	}

	_, err = ec2.NewRouteTableAssociation(ctx, name, &ec2.RouteTableAssociationArgs{
		RouteTableId: routeTable.ID(),
		SubnetId:     c.ID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create route table associtation, %w", err)
	}

	c.RouteTableID = routeTable.ID().ToStringOutput()

	return nil
}
