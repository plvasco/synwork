package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewTransitGateway(t *testing.T) {
	t.Parallel()

	type want struct {
		TransitGatewayID string
	}

	type args struct {
		name string
		args *networking.TransitGatewayArgs
	}

	tests := []struct {
		name    string
		args    args
		want    want
		wantErr bool
	}{
		{
			name: "Test should create AWS TransitGateway",
			args: args{
				name: "aws-tgw-test",
				args: &networking.TransitGatewayArgs{
					AmazonASN: pulumi.Int(12345),
					// AWSClient: mockEC2Client,
					EgressVPC: pulumi.String("vpc-1234567"),
					IngressSubnets: map[string]*networking.Subnet{
						"test1": {
							ResourceState: pulumi.ResourceState{},
							ID:            pulumi.StringOutput{},
							RouteTableID:  pulumi.StringOutput{},
							CIDRBlock:     pulumi.StringOutput{},
						},
					},
					EgressSubnets: map[string]*networking.Subnet{
						"test1": {
							ResourceState: pulumi.ResourceState{},
							ID:            pulumi.StringOutput{},
							RouteTableID:  pulumi.StringOutput{},
							CIDRBlock:     pulumi.StringOutput{},
						},
					},
					Peers: map[string]*networking.PeerArgs{
						"test": {
							RouteCIDR:        pulumi.String(""),
							TransitGatewayID: pulumi.String(""),
							Region:           pulumi.String("us-gov-east-1"),
						},
					},
					Tags: pulumi.ToStringMap(map[string]string{"organization": "test"}),
				},
			},
			want: want{
				TransitGatewayID: "aws-tgw-test-transitGateway_id",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewTransitGateway(ctx, tt.args.name, tt.args.args)
				if err != nil {
					return err
				}

				got.TransitGateway.ID().ApplyT(func(id string) bool {
					assert.Equal(t, id, tt.want.TransitGatewayID)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
func TestPeerArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.PeerArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"accountID": "123456789012",
				"routeCIDR": "10.0.0.0/16",
				"transitGatewayID": "tgw-12345",
				"region": "us-east-1"
			}`,
			want: &networking.PeerArgs{
				RouteCIDR:        pulumi.String("10.0.0.0/16"),
				TransitGatewayID: pulumi.String("tgw-12345"),
				Region:           pulumi.String("us-east-1"),
			},
			wantErr: false,
		},
		{
			name: "invalid field type",
			input: `{
				"accountID": 123456789012, // accountID should be a string
				"routeCIDR": "10.0.0.0/16",
				"transitGatewayID": "tgw-12345",
				"region": "us-east-1"
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"accountID": "123456789012", "routeCIDR": "10.0.0.0/16", "transitGatewayID": "tgw-12345"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.PeerArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}

func TestTransitGatewayArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.TransitGatewayArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"amazonASN": 64512,
				"peers": {
					"peer-1": {
						"routeCIDR": "10.1.0.0/16",
						"transitGatewayID": "tgw-12345",
						"region": "us-east-1",
						"tags": {"env": "production"}
					},
					"peer-2": {
						"routeCIDR": "10.2.0.0/16",
						"transitGatewayID": "tgw-67890",
						"region": "us-west-2",
						"tags": {"env": "staging"}
					}
				},
				"tags": {"team": "networking"}
			}`,
			want: &networking.TransitGatewayArgs{
				AmazonASN: pulumi.Int(64512),
				Peers: map[string]*networking.PeerArgs{
					"peer-1": {
						RouteCIDR:        pulumi.String("10.1.0.0/16"),
						TransitGatewayID: pulumi.String("tgw-12345"),
						Region:           pulumi.String("us-east-1"),
						Tags:             pulumi.StringMap{"env": pulumi.String("production")},
					},
					"peer-2": {
						RouteCIDR:        pulumi.String("10.2.0.0/16"),
						TransitGatewayID: pulumi.String("tgw-67890"),
						Region:           pulumi.String("us-west-2"),
						Tags:             pulumi.StringMap{"env": pulumi.String("staging")},
					},
				},
				Tags: pulumi.StringMap{"team": pulumi.String("networking")},
			},
			wantErr: false,
		},
		{
			name: "malformed JSON",
			input: `{
				"amazonASN": 64512,
				"peers": {
					"peer-1": {
						"routeCIDR": "10.1.0.0/16",
						"transitGatewayID": "tgw-12345",
						"region": "us-east-1",
						"tags": {"env": "production"}
					}
				`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.TransitGatewayArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
