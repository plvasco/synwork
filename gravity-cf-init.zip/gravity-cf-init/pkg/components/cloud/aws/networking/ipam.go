package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	tgw "github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2transitgateway"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const IpamAllocationComponentName = "gravity:aws:ipamAllocation"

type IpamAllocation struct {
	pulumi.ResourceState
	PublicNetworkCidr pulumi.StringOutput `pulumi:"publicNetworkCidr"`
}
type IpamAllocationArgs struct {
	TransitGatewayID         pulumi.StringInput `pulumi:"transitGatewayID"         validate:"required"`
	SupernetCidr             pulumi.StringInput `pulumi:"supernetCidr"             validate:"required"`
	DesiredNetworkPrefixSize pulumi.IntInput    `pulumi:"desiredNetworkPrefixSize" validate:"required"`
	// Internal Inputs
	networkAccountProvider pulumi.ProviderResource
}

func NewIPAMAllocation(ctx *pulumi.Context, name string, args *IpamAllocationArgs, opts ...pulumi.ResourceOption) (*IpamAllocation, error) {
	component := &IpamAllocation{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(IpamAllocationComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", IpamAllocationComponentName, name, err)
	}

	component.getAvailableCIDR(ctx, name, args)

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"publicNetworkCidr": component.PublicNetworkCidr,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", IpamAllocationComponentName, name, err)
	}

	return component, nil
}

func (c *IpamAllocation) getAvailableCIDR(ctx *pulumi.Context, _ string, args *IpamAllocationArgs) {
	gateway := tgw.LookupTransitGatewayOutput(ctx, tgw.LookupTransitGatewayOutputArgs{
		Id: args.TransitGatewayID,
	})

	routeCidrs := pulumix.Apply2Err(gateway.AssociationDefaultRouteTableId(), args.SupernetCidr.ToStringOutput(), func(routeTableID string, supernetCidr string) ([]string, error) {
		cidrs := []string{}

		tgwRoutes, err := tgw.GetRouteTableRoutes(ctx, &tgw.GetRouteTableRoutesArgs{
			TransitGatewayRouteTableId: routeTableID,
			Filters: []tgw.GetRouteTableRoutesFilter{
				{
					Name:   "route-search.subnet-of-match",
					Values: []string{supernetCidr},
				},
			},
		}, pulumi.Parent(c), pulumi.Provider(args.networkAccountProvider))
		if err != nil {
			return nil, fmt.Errorf("unable to get TGW route table CIDRs for IPAM, %w", err)
		}

		for _, route := range tgwRoutes.Routes {
			cidrs = append(cidrs, route.DestinationCidrBlock)
		}

		return cidrs, nil
	})

	subnet := cloud.PulumiGetNextFreeSubnet(args.SupernetCidr, pulumix.Cast[pulumi.StringArrayOutput](routeCidrs), args.DesiredNetworkPrefixSize)

	c.PublicNetworkCidr = subnet
}

func (args *IpamAllocationArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *IpamAllocationArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
