package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const vpnConnectionComponentName = "gravity:aws:networking:vpnGateway"

type VpnGateway struct {
	pulumi.ResourceState
	Gateway       *ec2.CustomerGateway `pulumi:"gateway"`
	GatewayID     pulumi.StringOutput  `pulumi:"gatewayID"`
	GatewayType   pulumi.StringOutput  `pulumi:"gatewayType"`
	VpnConnection *ec2.VpnConnection   `pulumi:"vpnConnection"`
}

type VpnGatewayArgs struct {
	RemoteRouterASN   pulumi.IntInput    `pulumi:"remoteRouterASN"   validate:"required"`
	RouterInterfaceIP pulumi.StringInput `pulumi:"routerInterfaceIP" validate:"required"`
	TransitGatewayID  pulumi.StringInput `pulumi:"transitGatewayID"  validate:"required"`
	Tags              pulumi.StringMap   `pulumi:"tags"`
}

func NewVpnGateway(ctx *pulumi.Context, name string, args *VpnGatewayArgs, opts ...pulumi.ResourceOption) (*VpnGateway, error) {
	component := &VpnGateway{}

	if err := args.validate(ctx); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(vpnConnectionComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", vpnConnectionComponentName, name, err)
	}

	if err := component.createCustomerGateway(ctx, name+"-gateway", args); err != nil {
		return nil, err
	}

	if err := component.createVpnConnection(ctx, name+"-connection", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"gateway":       component.Gateway,
		"gatewayID":     component.GatewayID,
		"gatewayType":   component.GatewayType,
		"vpnConnection": component.VpnConnection,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", vpnConnectionComponentName, name, err)
	}

	return component, nil
}

// createCustomerGateways creates a new vpn Gateways in the AWS VPC.
func (c *VpnGateway) createCustomerGateway(ctx *pulumi.Context, name string, args *VpnGatewayArgs) error {
	gateway, err := ec2.NewCustomerGateway(ctx, name, &ec2.CustomerGatewayArgs{
		BgpAsn:    pulumi.Sprintf("%d", args.RemoteRouterASN),
		IpAddress: args.RouterInterfaceIP,
		Tags:      utils.GenerateTags(args.Tags, name),
		Type:      pulumi.String("ipsec.1"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create ha vpn gateway, %w", err)
	}

	c.Gateway = gateway
	c.GatewayID = gateway.ID().ToStringOutput()
	c.GatewayType = gateway.Type

	return nil
}

// createVPNConnections creates dynamic routing between the transit gateway and the customer gateways.
func (c *VpnGateway) createVpnConnection(ctx *pulumi.Context, name string, args *VpnGatewayArgs) error {
	vpnConnection, err := ec2.NewVpnConnection(ctx, name, &ec2.VpnConnectionArgs{
		CustomerGatewayId: c.GatewayID,
		Tags:              utils.GenerateTags(args.Tags, name),
		TransitGatewayId:  args.TransitGatewayID,
		Type:              c.Gateway.Type,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create ha vpn gateway, %w", err)
	}

	c.VpnConnection = vpnConnection

	return nil
}

func (args *VpnGatewayArgs) validate(ctx *pulumi.Context) error {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["organization"]; !ok {
		args.Tags["organization"] = pulumi.String(ctx.Stack())
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["complianceLevel"] = pulumi.String(ctx.Stack())
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	return nil
}

func (args *VpnGatewayArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
