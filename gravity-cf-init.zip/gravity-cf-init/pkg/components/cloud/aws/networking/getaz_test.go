package networking_test

import (
	"sync"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestGetSubnetByAZ(t *testing.T) {
	t.Parallel()

	type want struct {
		id string
	}

	tests := []struct {
		name    string
		args    *networking.GetSubnetByAZArgs
		want    want
		wantErr bool
	}{
		{
			name: "test should get public subnet",
			args: &networking.GetSubnetByAZArgs{
				AvailabilityZone: pulumi.String("az123"),
				UsePublicSubnet:  pulumi.Bool(true),
			},
			want: want{
				id: "testSubnetID",
			},
			wantErr: false,
		},
		{
			name: "test should get private subnet",
			args: &networking.GetSubnetByAZArgs{
				AvailabilityZone: pulumi.String("az123"),
				UsePublicSubnet:  pulumi.Bool(false),
			},
			want: want{
				id: "testSubnetID",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				var wg sync.WaitGroup

				got, err := networking.GetSubnetByAZ(ctx, tt.args)
				require.NoError(t, err)

				wg.Add(1)
				got.ApplyT(func(id string) string {
					assert.Equal(t, tt.want.id, id)
					wg.Done()

					return id
				})

				wg.Wait()

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
