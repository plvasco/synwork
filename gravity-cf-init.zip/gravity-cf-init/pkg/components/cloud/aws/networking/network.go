package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	tgw "github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2transitgateway"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const networkComponentName = "gravity:aws:network"

// Network is a struct representation of the AWS Network component Resource.
type Network struct {
	pulumi.ResourceState
	// Cidr used for public networks
	PublicNetworkCidr pulumi.StringOutput `pulumi:"publicNetworkCidr"`
	// Cidr used for private networks
	PrivateNetworkCidr pulumi.StringOutput `pulumi:"privateNetworkCidr"`
	// VPC ID for the created network.
	VpcID pulumi.IDOutput `pulumi:"vpcID"`
	// Default route table ID for the created VPC
	DefaultRouteTableID pulumi.StringOutput `pulumi:"defaultRouteTableID"`
	// A map of avaliablility zones and their associated public subnet configurations for the created network.
	PublicSubnets Subnets `pulumi:"publicSubnets"`
	// A map of avaliablility zones and their associated private subnet configurations for the created network.
	PrivateSubnets Subnets `pulumi:"privateSubnets"`
	// Internet Gateway ID if one is created.
	InternetGatewayID pulumi.StringInput `pulumi:"internetGatewayID"`
	// Natgateway IDs by AZ if they are created.
	NatGatewayIDs pulumi.StringMap `pulumi:"natGatewayIDs"`
	// Internal Inputs
	// Provider using Network account to preform transit gateway operations.
	networkAccountProvider pulumi.ProviderResource
}

// NetworkArgs contains arguments required to create a Network componentResource (can be unmarshalled from stack config).
type NetworkArgs struct {
	// Optionally attach created subnets to transit gateway
	TransitGatewayID pulumi.StringInput `pulumi:"transitGatewayID"`
	// Subnet configurations for Public Subnets
	Public *PublicNetworkArgs `pulumi:"public" validate:"dig"`
	// Subnet configurations for Private Subnets
	Private *PrivateNetworkArgs `pulumi:"private" validate:"dig"`
	// Tags to apply to all child objects of the Network component resource.
	Tags pulumi.StringMap `pulumi:"tags"`
}

type PublicNetworkArgs struct {
	// overarching cloud supernet that the ipam will use to find free ranges.
	SupernetCidr pulumi.StringInput `pulumi:"supernetCidr" validate:"default=10.10.0.0/16"`
	// optionally override ipam allocation for vpc network, required if not using transit gateway
	NetworkCidr pulumi.StringInput `pulumi:"networkCidr"`
	// The size of the network prefix to assign to the VPC (default is 24)
	NetworkPrefixSize pulumi.IntInput `pulumi:"networkPrefixSize" validate:"default=24"`
	// The size of each subnet created per az inside vpc network (default is 26)
	SubnetPrefixSize pulumi.IntInput `pulumi:"subnetPrefixSize" validate:"default=26"`
}

type PrivateNetworkArgs struct {
	// The size of the network prefix to assign to the VPC (default is 24)
	NetworkCidr pulumi.StringInput `pulumi:"networkCidr" validate:"default=10.255.0.0/16"`
	// The size of each subnet created per az inside vpc network (default is 26)
	SubnetPrefixSize pulumi.IntInput `pulumi:"subnetPrefixSize" validate:"default=26"`
	// Override TransitGateway used on Public Subnet
	TransitGatewayIDOverride pulumi.StringInput `pulumi:"transitGatewayIDOverride"`
}

// NewNetwork creates a new component resource containing a account, vpc, and subnets needed to stand up a new org.
func NewNetwork(ctx *pulumi.Context, name string, args *NetworkArgs, opts ...pulumi.ResourceOption) (*Network, error) {
	if err := args.validate(); err != nil {
		return nil, fmt.Errorf("unable to validate network args, %w", err)
	}

	component := &Network{}

	if err := ctx.RegisterComponentResource(networkComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", networkComponentName, name, err)
	}

	if args.TransitGatewayID != nil {
		if err := component.createNetworkAccountProvider(ctx, name+"-provider", args); err != nil {
			return nil, err
		}
	}

	if err := component.createVPC(ctx, name+"-vpc", args); err != nil {
		return nil, err
	}

	if err := component.createPublicSubnets(ctx, name+"-public", args); err != nil {
		return nil, err
	}

	if err := component.createPrivateSubnets(ctx, name+"-private", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"vpcID":              component.VpcID,
		"privateNetworkCidr": component.PrivateNetworkCidr,
		"publicNetworkCidr":  component.PublicNetworkCidr,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", networkComponentName, name, err)
	}

	return component, nil
}

// createVPC creates a vpc for a network resource.
func (c *Network) createVPC(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	vpc, err := ec2.NewVpc(ctx, name, &ec2.VpcArgs{
		CidrBlock:          args.Private.NetworkCidr,
		EnableDnsHostnames: pulumi.Bool(true),
		EnableDnsSupport:   pulumi.Bool(true),
		Tags:               utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create vpc %s, %w", name, err)
	}

	if args.TransitGatewayID != nil && args.Public.NetworkCidr == nil {
		nextCidr, err := NewIPAMAllocation(ctx, name, &IpamAllocationArgs{
			TransitGatewayID:         args.TransitGatewayID,
			SupernetCidr:             args.Public.SupernetCidr,
			DesiredNetworkPrefixSize: args.Public.NetworkPrefixSize,
			networkAccountProvider:   c.networkAccountProvider,
		}, pulumi.Parent(c), pulumi.Provider(c.networkAccountProvider))
		if err != nil {
			return fmt.Errorf("unable to Get IPAM CIDR allocation, %w", err)
		}

		args.Public.NetworkCidr = nextCidr.PublicNetworkCidr
	}

	publicNetwork, err := ec2.NewVpcIpv4CidrBlockAssociation(ctx, name, &ec2.VpcIpv4CidrBlockAssociationArgs{
		CidrBlock: args.Public.NetworkCidr,
		VpcId:     vpc.ID(),
	}, pulumi.Parent(vpc), pulumi.IgnoreChanges([]string{"cidrBlock"}))
	if err != nil {
		return fmt.Errorf("unable to associate public network cidr to vpc %s, %w", name, err)
	}

	c.VpcID = vpc.ID()
	c.PrivateNetworkCidr = vpc.CidrBlock
	c.PublicNetworkCidr = publicNetwork.CidrBlock
	c.DefaultRouteTableID = vpc.DefaultRouteTableId

	return nil
}

func (c *Network) createNetworkAccountProvider(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	transitGateway := tgw.LookupTransitGatewayOutput(ctx, tgw.LookupTransitGatewayOutputArgs{Id: args.TransitGatewayID}, pulumi.Parent(c))
	networkAccountID := transitGateway.OwnerId()

	region := aws.GetRegionOutput(ctx, aws.GetRegionOutputArgs{}, pulumi.Parent(c))

	partition := aws.GetPartitionOutput(ctx, aws.GetPartitionOutputArgs{}, pulumi.Parent(c))

	provider, err := aws.NewProvider(ctx, name, &aws.ProviderArgs{
		AssumeRole: &aws.ProviderAssumeRoleArgs{
			RoleArn: pulumi.Sprintf("arn:%s:iam::%s:role/%s-routeManager", partition.Partition(), networkAccountID, args.TransitGatewayID),
		},
		Region: region.Name(),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create tgw route manager aws provider, %w", err)
	}

	c.networkAccountProvider = provider

	return nil
}

// createPublicSubnets crates a public subnet for each availability zone in the region.
func (c *Network) createPublicSubnets(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	if args.TransitGatewayID == nil {
		if err := c.createInternetGateway(ctx, name, args); err != nil {
			return fmt.Errorf("unable to create IGW, %w", err)
		}
	}

	subnets, err := NewSubnets(ctx, name, &SubnetsArgs{
		CIDRString:        c.PublicNetworkCidr,
		SubnetPrefixSize:  args.Public.SubnetPrefixSize,
		InternetGatewayID: c.InternetGatewayID,
		TransitGatewayID:  args.TransitGatewayID,
		VpcID:             c.VpcID,
		Tags:              utils.GenerateTags(args.Tags, name, pulumi.StringMap{"access": pulumi.String("public")}),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create subnet %s, %w", "public", err)
	}

	c.PublicSubnets = subnets

	if err := c.createNatGateway(ctx, name, args); err != nil {
		return fmt.Errorf("unable to create NatGTWs, %w", err)
	}

	subnetIDs := pulumi.StringArray{}
	for _, subnet := range c.PublicSubnets {
		subnetIDs = append(subnetIDs, subnet.ID)
	}

	if args.TransitGatewayID != nil {
		attachment, err := tgw.NewVpcAttachment(ctx, name+"-attachment", &tgw.VpcAttachmentArgs{
			SubnetIds:        subnetIDs,
			Tags:             utils.GenerateTags(args.Tags, name),
			TransitGatewayId: args.TransitGatewayID,
			VpcId:            c.VpcID,
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create network TGW VPC attachment %s on public subnets, %w", name, err)
		}

		if _, err := tgw.NewRoute(ctx, name, &tgw.RouteArgs{
			DestinationCidrBlock:       c.PublicNetworkCidr,
			TransitGatewayAttachmentId: attachment.ID(),
			TransitGatewayRouteTableId: tgw.LookupTransitGatewayOutput(
				ctx,
				tgw.LookupTransitGatewayOutputArgs{Id: args.TransitGatewayID},
				pulumi.Parent(c),
			).AssociationDefaultRouteTableId(),
		}, pulumi.Parent(c), pulumi.Provider(c.networkAccountProvider)); err != nil {
			return fmt.Errorf("unable to create transit gateway route %s, %w", name, err)
		}
	}

	return nil
}

// createPrivateSubnets crates a private subnet for each availability zone in the region.
func (c *Network) createPrivateSubnets(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	subnets, err := NewSubnets(ctx, name, &SubnetsArgs{
		CIDRString:       c.PrivateNetworkCidr,
		SubnetPrefixSize: args.Private.SubnetPrefixSize,
		NatGatewayIDs:    c.NatGatewayIDs,
		VpcID:            c.VpcID,
		Tags:             utils.GenerateTags(args.Tags, name+"-private", pulumi.StringMap{"access": pulumi.String("private")}),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create subnet %s, %w", "private", err)
	}

	c.PrivateSubnets = subnets

	return nil
}

func (c *Network) createInternetGateway(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	igw, err := ec2.NewInternetGateway(ctx, name, &ec2.InternetGatewayArgs{
		Tags:  utils.GenerateTags(args.Tags, name),
		VpcId: c.VpcID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create internet gateway %s, %w", name, err)
	}

	c.InternetGatewayID = pulumi.StringOutput(igw.ID())

	return nil
}

func (c *Network) createNatGateway(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	c.NatGatewayIDs = pulumi.StringMap{}

	for az, subnetID := range c.PublicSubnets {
		natGWArgs := &ec2.NatGatewayArgs{}
		natGWArgs.SubnetId = subnetID.ID
		natGWArgs.Tags = utils.GenerateTags(args.Tags, name+"-"+az)

		if args.TransitGatewayID == nil {
			eip, err := ec2.NewEip(ctx, name+"-"+az, &ec2.EipArgs{
				Tags: utils.GenerateTags(args.Tags, name),
			}, pulumi.Parent(c))
			if err != nil {
				return fmt.Errorf("unable to create elastic ip for natgateway %s, %w", name, err)
			}

			natGWArgs.AllocationId = eip.ID()
		} else {
			natGWArgs.ConnectivityType = pulumi.String("private")
		}

		natGW, err := ec2.NewNatGateway(ctx, name+"-"+az, natGWArgs, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create internet gateway %s, %w", name, err)
		}

		c.NatGatewayIDs[az] = natGW.ID().ToStringOutput()
	}

	return nil
}

// validate checks that all required args are set and sets defaults for any optional args.
func (args *NetworkArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	if args.TransitGatewayID == nil && args.Public.NetworkCidr == nil {
		args.Public.NetworkCidr = pulumi.String("10.0.0.0/23")
	}

	return nil
}

func (args *NetworkArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (args *PublicNetworkArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (args *PrivateNetworkArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
