package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewNetwork(t *testing.T) {
	t.Parallel()

	type want struct {
		subnets []string
	}

	type args struct {
		name string
		args *networking.NetworkArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create network resources with TGW",
			in: args{
				name: "test-tgw",
				args: &networking.NetworkArgs{
					TransitGatewayID: pulumi.String("tgw-123456789"),
					Public: &networking.PublicNetworkArgs{
						SupernetCidr:     pulumi.String("10.0.0.0/16"),
						NetworkCidr:      pulumi.String("10.0.0.0/24"),
						SubnetPrefixSize: pulumi.Int(26),
					},
					Private: &networking.PrivateNetworkArgs{
						NetworkCidr:      pulumi.String("10.0.1.0/24"),
						SubnetPrefixSize: pulumi.Int(28),
					},
					Tags: pulumi.StringMap{},
				},
			},
			want: want{
				subnets: []string{
					"test-tgw-private-us-gov-east-1a_id",
					"test-tgw-public-us-gov-east-1a_id",
					"test-tgw-private-us-gov-east-1b_id",
					"test-tgw-public-us-gov-east-1b_id",
					"test-tgw-private-us-gov-east-1c_id",
					"test-tgw-public-us-gov-east-1c_id",
				},
			},
			wantErr: false,
		},
		{
			name: "should create network resources without TGW",
			in: args{
				name: "test-non-tgw",
				args: &networking.NetworkArgs{
					Public: &networking.PublicNetworkArgs{
						SupernetCidr:     pulumi.String("10.0.0.0/16"),
						NetworkCidr:      pulumi.String("10.0.0.0/24"),
						SubnetPrefixSize: pulumi.Int(28),
					},
					Private: &networking.PrivateNetworkArgs{
						NetworkCidr:      pulumi.String("10.0.1.0/24"),
						SubnetPrefixSize: pulumi.Int(28),
					},
					Tags: pulumi.StringMap{},
				},
			},
			want: want{
				subnets: []string{
					"test-non-tgw-private-us-gov-east-1a_id",
					"test-non-tgw-public-us-gov-east-1a_id",
					"test-non-tgw-private-us-gov-east-1b_id",
					"test-non-tgw-public-us-gov-east-1b_id",
					"test-non-tgw-private-us-gov-east-1c_id",
					"test-non-tgw-public-us-gov-east-1c_id",
				},
			},
			wantErr: false,
		},
		{
			name: "should create network with default values",
			in: args{
				name: "test-default",
				args: &networking.NetworkArgs{
					Tags: pulumi.ToStringMap(map[string]string{"test": "test"}),
				},
			},
			want: want{
				subnets: []string{
					"test-default-private-us-gov-east-1a_id",
					"test-default-public-us-gov-east-1a_id",
					"test-default-private-us-gov-east-1b_id",
					"test-default-public-us-gov-east-1b_id",
					"test-default-private-us-gov-east-1c_id",
					"test-default-public-us-gov-east-1c_id",
				},
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewNetwork(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				vpcID := got.VpcID.ApplyT(func(vpcID pulumi.ID) pulumi.ID {
					assert.Equal(t, pulumi.ID(tt.in.name+"-vpc_id"), vpcID)

					return vpcID
				})
				require.NotNil(t, vpcID)

				for _, subnetConf := range got.PublicSubnets {
					subnetConf.ID.ApplyT(func(subnetID string) string {
						assert.Contains(t, tt.want.subnets, subnetID)

						return subnetID
					})
				}

				for _, subnetConf := range got.PrivateSubnets {
					subnetConf.ID.ApplyT(func(subnetID string) string {
						assert.Contains(t, tt.want.subnets, subnetID)

						return subnetID
					})
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestNetworkArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.NetworkArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"transitGatewayID": "tgw-12345",
				"public": {
					"supernetCidr": "10.10.0.0/16",
					"networkCidr": "10.20.0.0/16",
					"networkPrefixSize": 24,
					"subnetPrefixSize": 26
				},
				"private": {
					"networkCidr": "10.255.0.0/16",
					"subnetPrefixSize": 26,
					"transitGatewayIDOverride": "tgw-override-67890"
				},
				"tags": {"env": "production", "team": "networking"}
			}`,
			want: &networking.NetworkArgs{
				TransitGatewayID: pulumi.String("tgw-12345"),
				Public: &networking.PublicNetworkArgs{
					SupernetCidr:      pulumi.String("10.10.0.0/16"),
					NetworkCidr:       pulumi.String("10.20.0.0/16"),
					NetworkPrefixSize: pulumi.Int(24),
					SubnetPrefixSize:  pulumi.Int(26),
				},
				Private: &networking.PrivateNetworkArgs{
					NetworkCidr:              pulumi.String("10.255.0.0/16"),
					SubnetPrefixSize:         pulumi.Int(26),
					TransitGatewayIDOverride: pulumi.String("tgw-override-67890"),
				},
				Tags: pulumi.StringMap{"env": pulumi.String("production"), "team": pulumi.String("networking")},
			},
			wantErr: false,
		},
		{
			name: "malformed JSON",
			input: `{
				"transitGatewayID": "tgw-12345",
				"public": {"supernetCidr": "10.10.0.0/16"},
				"private": {"networkCidr": "10.255.0.0/16"
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.NetworkArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
