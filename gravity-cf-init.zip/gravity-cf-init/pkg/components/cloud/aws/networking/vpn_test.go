package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewVpnGateway(t *testing.T) {
	t.Parallel()

	type want struct {
		gatewayID   string
		gatewayType string
		// add wanted result fields here
	}

	type args struct {
		name string
		args *networking.VpnGatewayArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test new VPN gateway",
			in: args{
				name: "test1",
				args: &networking.VpnGatewayArgs{
					RemoteRouterASN:   pulumi.Int(1234),
					RouterInterfaceIP: pulumi.String(""),
					TransitGatewayID:  pulumi.String("tgw-1234567"),
				},
			},
			want: want{
				gatewayID:   "test1-gateway_id",
				gatewayType: "ipsec.1",
			},
			wantErr: false,
		},
		{
			name: "test should fail no RemoteRouterASN",
			in: args{
				name: "test1",
				args: &networking.VpnGatewayArgs{
					RouterInterfaceIP: pulumi.String(""),
					TransitGatewayID:  pulumi.String("tgw-1234567"),
				},
			},
			wantErr: true,
		},
		{
			name: "test should fail no RouterInterfaceIP",
			in: args{
				name: "test1",
				args: &networking.VpnGatewayArgs{
					RemoteRouterASN:  pulumi.Int(1234),
					TransitGatewayID: pulumi.String("tgw-1234567"),
				},
			},
			wantErr: true,
		},
		{
			name: "test should fail with no TransitGatewayID",
			in: args{
				name: "test1",
				args: &networking.VpnGatewayArgs{
					RemoteRouterASN:   pulumi.Int(1234),
					RouterInterfaceIP: pulumi.String(""),
				},
			},
			wantErr: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewVpnGateway(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.GatewayID.ApplyT(func(id string) bool {
					assert.Equal(t, id, tc.want.gatewayID)

					return true
				})

				got.GatewayType.ApplyT(func(gwType string) bool {
					assert.Equal(t, gwType, tc.want.gatewayType)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewVpnGateway() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestVpnGatewayArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.VpnGatewayArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"remoteRouterASN": 65000,
				"routerInterfaceIP": "192.168.1.1",
				"transitGatewayID": "tgw-12345",
				"tags": {
					"env": "production",
					"team": "network"
				}
			}`,
			want: &networking.VpnGatewayArgs{
				RemoteRouterASN:   pulumi.Int(65000),
				RouterInterfaceIP: pulumi.String("192.168.1.1"),
				TransitGatewayID:  pulumi.String("tgw-12345"),
				Tags: pulumi.StringMap{
					"env":  pulumi.String("production"),
					"team": pulumi.String("network"),
				},
			},
			wantErr: false,
		},
		{
			name: "malformed JSON with incorrect type",
			input: `{
				"remoteRouterASN": 65000,
				"routerInterfaceIP": "192.168.1.1",
				"transitGatewayID": 1234,
				"tags": {
					"env": "production",
					"team": "network"
				}
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.VpnGatewayArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
