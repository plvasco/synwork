package networking_test

import (
	"sync"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestGetAvailableCIDR(t *testing.T) {
	t.Parallel()

	type in struct {
		name string
		args *networking.IpamAllocationArgs
	}

	testCases := []struct {
		name    string
		in      in
		want    string
		wantErr bool
	}{
		{
			name: "test get CIDR",
			in: in{
				name: "test_ipam",
				args: &networking.IpamAllocationArgs{
					TransitGatewayID:         pulumi.String("tgw-12345"),
					SupernetCidr:             pulumi.String("10.0.0.0/16"),
					DesiredNetworkPrefixSize: pulumi.Int(23),
				},
			},
			want:    "10.0.0.0/23",
			wantErr: false,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewIPAMAllocation(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				var wg sync.WaitGroup

				wg.Add(1)

				subnetCIDR := got.PublicNetworkCidr.ApplyT(func(cidr string) string {
					assert.Equal(t, tc.want, cidr)

					wg.Done()

					return cidr
				})

				require.NotNil(t, subnetCIDR)

				wg.Wait()

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("GetAvailableCIDR() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}
