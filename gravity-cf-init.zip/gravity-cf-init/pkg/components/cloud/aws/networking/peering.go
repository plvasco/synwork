package networking

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const peeringComponentName = "gravity:aws:network:peering"

var ErrRequiredArgumentNetworkID = errors.New("required argument NetworkID is missing")

type VpcPeering struct {
	pulumi.ResourceState
	ConnectionID pulumi.StringOutput
	awsProvider  pulumi.ProviderResource
}

type VpcPeeringArgs struct {
	PeerRegion        pulumi.StringInput `pulumi:"peerRegion"        validate:"required"`
	PeerVpcID         pulumi.StringInput `pulumi:"peerVpcID"         validate:"required"`
	PeerCidrBlock     pulumi.StringInput `pulumi:"peerCidrBlock"     validate:"required"`
	PeerRouteTableIDs pulumi.StringArray `pulumi:"peerRouteTableIDs" validate:"required"`
	CidrBlock         pulumi.StringInput `pulumi:"cidrBlock"         validate:"required"`
	VpcID             pulumi.StringInput `pulumi:"vpcID"             validate:"required"`
	RouteTableIDs     pulumi.StringArray `pulumi:"routeTableIDs"     validate:"required"`
	Tags              pulumi.StringMap   `pulumi:"tags"`
}

func NewVpcPeering(ctx *pulumi.Context, name string, args *VpcPeeringArgs, opts ...pulumi.ResourceOption) (*VpcPeering, error) {
	component := &VpcPeering{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(peeringComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", peeringComponentName, name, err)
	}

	if err := component.createVpcPeering(ctx, name+"-peering", args); err != nil {
		return nil, err
	}

	if err := component.createPeeringRoutes(ctx, name+"-route", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", peeringComponentName, name, err)
	}

	return component, nil
}

func (args *VpcPeeringArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	return nil
}

func (args *VpcPeeringArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (c *VpcPeering) createVpcPeering(ctx *pulumi.Context, name string, args *VpcPeeringArgs) error {
	peerConnection, err := ec2.NewVpcPeeringConnection(ctx, name, &ec2.VpcPeeringConnectionArgs{
		AutoAccept: pulumi.Bool(false),
		PeerRegion: args.PeerRegion,
		PeerVpcId:  args.PeerVpcID,
		Tags:       args.Tags,
		VpcId:      args.VpcID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create new VPC peering connection %s, %w", name, err)
	}

	c.ConnectionID = peerConnection.ID().ToStringOutput()

	if _, err := ec2.NewVpcPeeringConnectionAccepter(ctx, name+"-acceptor", &ec2.VpcPeeringConnectionAccepterArgs{
		VpcPeeringConnectionId: peerConnection.ID(),
		AutoAccept:             pulumi.Bool(true),
	}); err != nil {
		return fmt.Errorf("unable to create new VPC connection accepter, %w", err)
	}

	provider, err := aws.NewProvider(ctx, name+"-provider", &aws.ProviderArgs{
		Region: args.PeerRegion,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create new provider in peer region, %w", err)
	}

	c.awsProvider = provider

	return nil
}

func (c *VpcPeering) createPeeringRoutes(ctx *pulumi.Context, name string, args *VpcPeeringArgs) error {
	for idx, routeTableID := range args.RouteTableIDs {
		if _, err := ec2.NewRoute(ctx, fmt.Sprintf("%s-%d", name, idx), &ec2.RouteArgs{
			RouteTableId:           routeTableID,
			DestinationCidrBlock:   args.PeerCidrBlock,
			VpcPeeringConnectionId: c.ConnectionID,
		}, pulumi.Parent(c)); err != nil {
			return fmt.Errorf("unable to create new private route %s, %w", name, err)
		}
	}

	for idx, routeTableID := range args.PeerRouteTableIDs {
		_, err := ec2.NewRoute(ctx, fmt.Sprintf("%s-peer-%d", name, idx), &ec2.RouteArgs{
			RouteTableId:           routeTableID,
			DestinationCidrBlock:   args.CidrBlock,
			VpcPeeringConnectionId: c.ConnectionID,
		}, pulumi.Parent(c), pulumi.Provider(c.awsProvider))
		if err != nil {
			return fmt.Errorf("unable to create new peering route %s, %w", name, err)
		}
	}

	return nil
}
