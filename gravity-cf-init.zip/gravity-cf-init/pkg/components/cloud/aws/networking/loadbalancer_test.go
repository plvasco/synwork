package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

func Test_newEksLoadBalancer(t *testing.T) {
	t.Parallel()

	type want struct {
		Name string
	}

	type args struct {
		name string
		args *networking.LoadBalancerArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should create loadbalancer",
			in: args{
				name: "test1",
				args: &networking.LoadBalancerArgs{
					VpcID:           pulumi.String("vpc-123456"),
					SecurityGroupID: pulumi.ID("123456"),
					Type:            pulumi.String("network"),
					Internal:        pulumi.Bool(true),
					Ports: []*networking.PortConfig{
						{
							ListenerPort: pulumi.Int(15021),
							NodePort:     pulumi.Int(31067),
							HealthCheck:  pulumi.String("31067"),
						},
						{
							ListenerPort: pulumi.Int(80),
							NodePort:     pulumi.Int(31068),
							HealthCheck:  pulumi.String("31067"),
						},
						{
							ListenerPort: pulumi.Int(443),
							NodePort:     pulumi.Int(31069),
							HealthCheck:  pulumi.String("31067"),
						},
					},
				},
			},
			want:    want{},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewLoadBalancer(ctx, tt.in.name, tt.in.args)
				require.NoError(t, err)

				pulumix.Apply3(got.LoadBalancerARN, got.TargetGroups[0].Name, got.Listeners[0].Port.Elem(), func(arn string, tgName string, port int) string {
					assert.Equal(t, "fakeARN", arn)
					assert.Equal(t, "test1-tg-15021", tgName)
					assert.Equal(t, 15021, port)

					return ""
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestLoadBalancerArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.LoadBalancerArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"nodeSecurityGroupID": "sg-12345",
				"vpcID": "vpc-67890",
				"type": "application",
				"internalSubnetIDs": ["subnet-123", "subnet-456"],
				"externalSubnetIDs": ["subnet-789"],
				"internal": true,
				"tags": {"env": "production"},
				"ports": [
					{"ListenerPort": 443, "NodePort": 30001, "HealthCheck": "traffic-port"},
					{"ListenerPort": 80, "NodePort": 30002, "HealthCheck": "80"}
				]
			}`,
			want: &networking.LoadBalancerArgs{
				SecurityGroupID:   pulumi.String("sg-12345"),
				VpcID:             pulumi.String("vpc-67890"),
				Type:              pulumi.String("application"),
				InternalSubnetIDs: pulumi.StringArray{pulumi.String("subnet-123"), pulumi.String("subnet-456")},
				ExternalSubnetIDs: pulumi.StringArray{pulumi.String("subnet-789")},
				Internal:          pulumi.Bool(true),
				Tags:              pulumi.StringMap{"env": pulumi.String("production")},
				Ports: []*networking.PortConfig{
					{
						ListenerPort: pulumi.Int(443),
						NodePort:     pulumi.Int(30001),
						HealthCheck:  pulumi.String("traffic-port"),
					},
					{
						ListenerPort: pulumi.Int(80),
						NodePort:     pulumi.Int(30002),
						HealthCheck:  pulumi.String("80"),
					},
				},
			},
			wantErr: false,
		},
		{
			name: "invalid field type",
			input: `{
				"nodeSecurityGroupID": "sg-12345",
				"vpcID": "vpc-67890",
				"type": "application",
				"internalSubnetIDs": ["subnet-123"],
				"internal": "true", // internal should be a boolean
				"ports": [{"ListenerPort": 443, "NodePort": 30001, "HealthCheck": "traffic-port"}]
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"nodeSecurityGroupID": "sg-12345", "vpcID": "vpc-67890", "type": "application"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.LoadBalancerArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
