package eks

import (
	"encoding/base64"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/autoscaling"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/eks"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/kms"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const nodeGroupComponentName = "gravity:aws:cluster:nodeGroup"

type NodeGroup struct {
	pulumi.ResourceState
	LaunchTemplateName    pulumi.StringOutput `pulumi:"launchTemplateName"`
	LaunchTemplateVersion pulumi.IntOutput    `pulumi:"launchTemplateVersion"`
	Name                  pulumi.StringOutput `pulumi:"name"`
}

type NodeGroupArgs struct {
	AmiID            pulumi.StringInput `pulumi:"amiID"            validate:"required"`
	InstanceType     pulumi.StringInput `pulumi:"instanceType"`
	MaxSize          pulumi.IntInput    `pulumi:"maxSize"`
	MinSize          pulumi.IntInput    `pulumi:"minSize"`
	DesiredSize      pulumi.IntInput    `pulumi:"desiredSize"`
	AzOverride       pulumi.StringArray `pulumi:"azOverride"`
	VolumeSize       pulumi.IntInput    `pulumi:"volumeSize"       validate:"default=20"`
	RootVolumeSize   pulumi.IntInput    `pulumi:"rootVolumeSize"   validate:"default=20"`
	Labels           pulumi.StringMap   `pulumi:"labels"`
	Taints           []TaintArgs        `pulumi:"taints"`
	KubeletExtraArgs pulumi.StringInput `pulumi:"kubeletExtraArgs"`
	Tags             pulumi.StringMap   `pulumi:"tags"`
	// internal args
	clusterName     pulumi.StringInput `pulumi:"clusterName"`
	clusterEndpoint pulumi.StringInput `pulumi:"clusterEndpoint"`
	clusterCAData   pulumi.StringInput `pulumi:"clusterCAData"`
	securityGroupID pulumi.StringInput `pulumi:"securityGroupID"`
	nodeRoleARN     pulumi.StringInput `pulumi:"nodeRoleARN"`
	subnetIDs       pulumi.StringArray `pulumi:"subnetIDs"`
}

type TaintArgs struct {
	Effect pulumi.StringInput `pulumi:"effect"`
	Key    pulumi.StringInput `pulumi:"key"`
	Value  pulumi.StringInput `pulumi:"value"`
}

func (a *NodeGroupArgs) Validate() error {
	if a.KubeletExtraArgs != nil {
		a.KubeletExtraArgs = pulumi.Sprintf("--kubelet-extra-args %s", a.KubeletExtraArgs)
	} else {
		a.KubeletExtraArgs = pulumi.String("")
	}

	if err := utils.ValidateStruct(a); err != nil {
		return fmt.Errorf("%T validation failed: %w", a, err)
	}

	return nil
}

func (a *NodeGroupArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", a, err)
	}

	return nil
}

func (args *TaintArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func newNodeGroup(ctx *pulumi.Context, name string, args *NodeGroupArgs, opts ...pulumi.ResourceOption) (*NodeGroup, error) {
	component := &NodeGroup{}

	if err := args.Validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(nodeGroupComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", nodeGroupComponentName, name, err)
	}

	if err := component.createLaunchTemplate(ctx, name+"-launchTemplate", args); err != nil {
		return nil, err
	}

	if err := component.createNodeGroup(ctx, name+"-nodeGroup", args); err != nil {
		return nil, err
	}

	if err := component.setAutoScalingGroupTags(ctx, name+"-asg-tag", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"name":                  component.Name,
		"launchTemplateName":    component.LaunchTemplateName,
		"launchTemplateVersion": component.LaunchTemplateVersion,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", nodeGroupComponentName, name, err)
	}

	return component, nil
}

func (c *NodeGroup) createLaunchTemplate(ctx *pulumi.Context, name string, args *NodeGroupArgs) error {
	key := kms.LookupKeyOutput(ctx, kms.LookupKeyOutputArgs{
		KeyId: pulumi.String("alias/encryption-key"),
	})

	launchTemplate, err := ec2.NewLaunchTemplate(ctx, name, &ec2.LaunchTemplateArgs{
		UserData:              c.createUserData(args),
		ImageId:               args.AmiID,
		InstanceType:          args.InstanceType,
		DisableApiTermination: pulumi.Bool(false),
		EbsOptimized:          pulumi.String("true"),
		Tags:                  utils.GenerateTags(args.Tags, name),
		BlockDeviceMappings: ec2.LaunchTemplateBlockDeviceMappingArray{
			&ec2.LaunchTemplateBlockDeviceMappingArgs{
				DeviceName: pulumi.String("/dev/xvda"),
				Ebs: &ec2.LaunchTemplateBlockDeviceMappingEbsArgs{
					VolumeSize:          args.RootVolumeSize,
					VolumeType:          pulumi.String("gp3"),
					DeleteOnTermination: pulumi.String("true"),
					Encrypted:           pulumi.String("true"),
					KmsKeyId:            key.Arn(),
				},
			},
			&ec2.LaunchTemplateBlockDeviceMappingArgs{
				DeviceName: pulumi.String("/dev/sda1"),
				Ebs: &ec2.LaunchTemplateBlockDeviceMappingEbsArgs{
					VolumeType:          pulumi.String("gp3"),
					VolumeSize:          args.VolumeSize,
					DeleteOnTermination: pulumi.String("true"),
					Encrypted:           pulumi.String("true"),
					KmsKeyId:            key.Arn(),
				},
			},
		},
		MetadataOptions: &ec2.LaunchTemplateMetadataOptionsArgs{
			HttpEndpoint:            pulumi.String("enabled"),
			HttpTokens:              pulumi.String("required"),
			HttpPutResponseHopLimit: pulumi.Int(2),
			InstanceMetadataTags:    pulumi.String("enabled"),
		},
		Monitoring: &ec2.LaunchTemplateMonitoringArgs{
			Enabled: pulumi.Bool(true),
		},
		TagSpecifications: ec2.LaunchTemplateTagSpecificationArray{
			&ec2.LaunchTemplateTagSpecificationArgs{
				ResourceType: pulumi.String("instance"),
				Tags:         utils.GenerateTags(args.Tags, name),
			},
			&ec2.LaunchTemplateTagSpecificationArgs{
				ResourceType: pulumi.String("volume"),
				Tags:         utils.GenerateTags(args.Tags, name),
			},
			&ec2.LaunchTemplateTagSpecificationArgs{
				ResourceType: pulumi.String("network-interface"),
				Tags:         utils.GenerateTags(args.Tags, name),
			},
		},
		UpdateDefaultVersion: pulumi.Bool(true),
		VpcSecurityGroupIds:  pulumi.StringArray{args.securityGroupID},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create new launch template, %w", err)
	}

	c.LaunchTemplateName = launchTemplate.Name
	c.LaunchTemplateVersion = launchTemplate.LatestVersion

	return nil
}

func (c *NodeGroup) createUserData(args *NodeGroupArgs) pulumi.StringOutput {
	userData := pulumi.Sprintf(`
		#!/bin/bash -e
		/etc/eks/bootstrap.sh %s --apiserver-endpoint %s --b64-cluster-ca %s %s`,
		args.clusterName.ToStringOutput(), args.clusterEndpoint.ToStringOutput(), args.clusterCAData.ToStringOutput(), args.KubeletExtraArgs.ToStringOutput(),
	)

	encUserData, ok := userData.ApplyT(func(s string) string {
		return base64.StdEncoding.EncodeToString([]byte(s))
	}).(pulumi.StringOutput)
	if !ok {
		panic(utils.ErrUnableToTypeCast)
	}

	return encUserData
}

func (c *NodeGroup) createNodeGroup(ctx *pulumi.Context, name string, args *NodeGroupArgs) error {
	if len(args.AzOverride) > 0 {
		azOverrides := args.setNodeGroupAzOverride(ctx)

		args.subnetIDs = azOverrides
	}

	nodegroup, err := eks.NewNodeGroup(ctx, name, &eks.NodeGroupArgs{
		ClusterName: args.clusterName,
		Labels:      args.Labels,
		LaunchTemplate: &eks.NodeGroupLaunchTemplateArgs{
			Version: pulumi.Sprintf("%d", c.LaunchTemplateVersion),
			Name:    c.LaunchTemplateName,
		},
		NodeRoleArn: args.nodeRoleARN,
		ScalingConfig: &eks.NodeGroupScalingConfigArgs{
			DesiredSize: args.DesiredSize,
			MaxSize:     args.MaxSize,
			MinSize:     args.MinSize,
		},
		SubnetIds: args.subnetIDs,
		Tags:      utils.GenerateTags(args.Tags, name),
		Taints:    c.makeTaints(args),
	}, pulumi.Parent(c), pulumi.IgnoreChanges([]string{"desiredCapacity"}))
	if err != nil {
		return fmt.Errorf("unable to create nodegroup `%s`, %w", name, err)
	}

	c.Name = nodegroup.NodeGroupName

	return nil
}

func (c *NodeGroup) setAutoScalingGroupTags(ctx *pulumi.Context, name string, args *NodeGroupArgs) error {
	groups := autoscaling.GetAmiIdsOutput(ctx, autoscaling.GetAmiIdsOutputArgs{
		Filters: autoscaling.GetAmiIdsFilterArray{
			autoscaling.GetAmiIdsFilterArgs{
				Name:   pulumi.String("tag:eks:nodegroup-name"),
				Values: pulumi.StringArray{c.Name},
			},
		},
	}, pulumi.Parent(c))

	asgName := groups.Names().Index(pulumi.Int(0))

	for key, value := range utils.GenerateTags(args.Tags, name) {
		_, err := autoscaling.NewTag(ctx, name+"-"+key, &autoscaling.TagArgs{
			AutoscalingGroupName: asgName,
			Tag: &autoscaling.TagTagArgs{
				Key:               pulumi.String(key),
				PropagateAtLaunch: pulumi.Bool(true),
				Value:             value,
			},
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create tag for asg, %w", err)
		}
	}

	return nil
}

func (c *NodeGroup) makeTaints(args *NodeGroupArgs) eks.NodeGroupTaintArray {
	taints := eks.NodeGroupTaintArray{}

	taints = append(taints, &eks.NodeGroupTaintArgs{
		Key:    pulumi.String("node.cilium.io/agent-not-ready"),
		Value:  pulumi.String("true"),
		Effect: pulumi.String("NO_EXECUTE"),
	})

	if len(args.Taints) > 0 {
		for _, taint := range args.Taints {
			taints = append(taints, &eks.NodeGroupTaintArgs{
				Effect: taint.Effect,
				Key:    taint.Key,
				Value:  taint.Value,
			})
		}
	}

	return taints
}

func (a *NodeGroupArgs) setNodeGroupAzOverride(ctx *pulumi.Context) pulumi.StringArray {
	subnetIDs := pulumi.StringArray{}

	for _, subnetID := range a.subnetIDs {
		subnetID := pulumix.Apply2Err(subnetID.ToStringOutput(), a.AzOverride,
			func(subnetID string, desiredAZs []string) (string, error) {
				subnetResult, err := ec2.LookupSubnet(ctx, &ec2.LookupSubnetArgs{
					Id: &subnetID,
				})
				if err != nil {
					return "", fmt.Errorf("unable to lookup subnet `%s`, %w", subnetID, err)
				}

				for _, desiredAZ := range desiredAZs {
					if subnetResult.AvailabilityZone == desiredAZ {
						return subnetID, nil
					}
				}

				return "", nil
			},
		)
		subnetIDs = append(subnetIDs, pulumix.Cast[pulumi.StringOutput](subnetID))
	}

	return subnetIDs
}
