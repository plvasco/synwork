package eks_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/cluster/eks"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestKubernetesBootstrap(t *testing.T) {
	t.Parallel()

	type want struct{}

	type args struct {
		name string
		args *eks.KubernetesBootstrapArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should install Cilium with provided configuration",
			in: args{
				name: "test1",
				args: &eks.KubernetesBootstrapArgs{
					ClusterName:       pulumi.String("test-cluster"),
					ClusterEndpoint:   pulumi.String("https://fakeendpoint.com"),
					CiliumRegistry:    pulumi.String("docker.com/cilium"),
					CiliumVersion:     pulumi.String("1.16.0"),
					KubernetesVersion: pulumi.String("1.30"),
				},
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "test should install Cilium with default configuration",
			in: args{
				name: "test2",
				args: &eks.KubernetesBootstrapArgs{
					ClusterName:       pulumi.String("test-cluster"),
					ClusterEndpoint:   pulumi.String("https://fakeendpoint.com"),
					CiliumVersion:     pulumi.String("1.16.0"),
					KubernetesVersion: pulumi.String("1.30"),
				},
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "test should install Identity Provider when IssuerURL and ClientID is provided",
			in: args{
				name: "test2",
				args: &eks.KubernetesBootstrapArgs{
					ClusterName:       pulumi.String("test-cluster"),
					ClusterEndpoint:   pulumi.String("https://fakeendpoint.com"),
					CiliumVersion:     pulumi.String("1.16.0"),
					KubernetesVersion: pulumi.String("1.30"),
					IdpClientID:       pulumi.String("test"),
					IdpIssuerURL:      pulumi.String("test"),
				},
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "test should create image pull secret when PrivateRegistrySecret is provided",
			in: args{
				name: "test2",
				args: &eks.KubernetesBootstrapArgs{
					ClusterName:           pulumi.String("test-cluster"),
					ClusterEndpoint:       pulumi.String("https://fakeendpoint.com"),
					CiliumVersion:         pulumi.String("1.16.0"),
					KubernetesVersion:     pulumi.String("1.30"),
					PrivateRegistrySecret: pulumi.String("test"),
				},
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "should error when args validatation fails",
			in: args{
				name: "test3",
				args: &eks.KubernetesBootstrapArgs{
					ClusterEndpoint:   pulumi.String("https://fakeendpoint.com"),
					KubernetesVersion: pulumi.String("1.30"),
				},
			},
			want:    want{},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				_, err := eks.NewKubernetesBootstrap(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				require.NoError(t, err)

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
func TestKubernetesBootstrapArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *eks.KubernetesBootstrapArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"clusterName": "test-cluster",
				"endpoint": "https://k8s.example.com",
				"kubernetesVersion": "1.21",
				"imagePullSecretName": "my-private-registry",
				"privateRegistrySecret": "my-secret",
				"ciliumRegistry": "quay.io/cilium",
				"ciliumVersion": "1.11",
				"idpClientID": "client-123",
				"idpIssuerURL": "https://issuer.example.com",
				"idpAdminGroupName": "/Gamewarden/il2-eks-admin",
				"tags": {"env": "production"}
			}`,
			want: &eks.KubernetesBootstrapArgs{
				ClusterName:           pulumi.String("test-cluster"),
				ClusterEndpoint:       pulumi.String("https://k8s.example.com"),
				KubernetesVersion:     pulumi.String("1.21"),
				ImagePullSecretName:   pulumi.String("my-private-registry"),
				PrivateRegistrySecret: pulumi.String("my-secret"),
				CiliumRegistry:        pulumi.String("quay.io/cilium"),
				CiliumVersion:         pulumi.String("1.11"),
				IdpClientID:           pulumi.String("client-123"),
				IdpIssuerURL:          pulumi.String("https://issuer.example.com"),
				IdpAdminGroupName:     pulumi.String("/Gamewarden/il2-eks-admin"),
				Tags:                  pulumi.StringMap{"env": pulumi.String("production")},
			},
			wantErr: false,
		},
		{
			name: "invalid field type",
			input: `{
				"clusterName": "test-cluster",
				"endpoint": "https://k8s.example.com",
				"kubernetesVersion": "1.21",
				"ciliumVersion": 1.11,
				"tags": {"env": "production"}
			}`, // ciliumVersion should be a string, not a number
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"clusterName": "test-cluster", "endpoint": "https://k8s.example.com", "tags": {"env": "production"}`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args eks.KubernetesBootstrapArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
