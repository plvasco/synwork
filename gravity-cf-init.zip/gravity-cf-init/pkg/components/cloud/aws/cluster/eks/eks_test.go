package eks_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/cluster/eks"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/s3"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewCluster(t *testing.T) {
	t.Parallel()

	type want struct {
		Name            string
		SecurityGroupID string
		Endpoint        string
	}

	type args struct {
		name string
		args *eks.ClusterArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create EKS cluster",
			in: args{
				name: "test-cluster",
				args: &eks.ClusterArgs{
					SubnetIDs: pulumi.StringArray{
						pulumi.String(""),
						pulumi.String(""),
					},
					CiliumRegistry: pulumi.String("fake.io"),
					CiliumTag:      pulumi.String("17.0"),
					NodeGroups: map[string]*eks.NodeGroupArgs{
						"group1": {
							AmiID:          pulumi.String("ami-123456789"),
							InstanceType:   pulumi.String("t3xltest"),
							MaxSize:        pulumi.Int(2),
							MinSize:        pulumi.Int(1),
							DesiredSize:    pulumi.Int(1),
							VolumeSize:     pulumi.Int(100),
							RootVolumeSize: pulumi.Int(100),
							Labels:         pulumi.ToStringMap(map[string]string{"test": "true", "test2": "false"}),
							Taints: []eks.TaintArgs{
								{
									Effect: pulumi.String("NO_SCHEDULE"),
									Key:    pulumi.String("only"),
									Value:  pulumi.String("test"),
								},
								{
									Effect: pulumi.String("NoExecute"),
									Key:    pulumi.String("testCluster"),
									Value:  pulumi.String("true"),
								},
							},
						},
						"group2": {
							AmiID:        pulumi.String("ami-987654321"),
							InstanceType: pulumi.String("n5xl"),
							MaxSize:      pulumi.Int(5),
							MinSize:      pulumi.Int(1),
							DesiredSize:  pulumi.Int(4),
							AzOverride:   pulumi.ToStringArray([]string{"1c"}),
							Labels:       pulumi.ToStringMap(map[string]string{"test": "true", "test2": "false"}),
							Taints: []eks.TaintArgs{
								{
									Effect: pulumi.String("NO_SCHEDULE"),
									Key:    pulumi.String("only"),
									Value:  pulumi.String("test"),
								},
							},
							Tags: pulumi.StringMap{
								"name":  pulumi.String("test1"),
								"check": pulumi.String("please"),
							},
						},
					},
					KubernetesVersion: pulumi.String("1.30"),
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test"),
					Environment:       pulumi.String("dev"),
					VpcID:             pulumi.String("test"),
					Buckets: map[string]*s3.BucketArgs{
						"test": {
							ServiceAccount: pulumi.Bool(false),
						},
					},
				},
			},
			want: want{
				Endpoint:        "https://fakeendpoint.com",
				SecurityGroupID: "test-cluster-cluster-sg_id",
			},
			wantErr: false,
		},
		{
			name: "should error if Node Groups are not provided",
			in: args{
				name: "test-cluster",
				args: &eks.ClusterArgs{
					SubnetIDs: pulumi.StringArray{
						pulumi.String(""),
						pulumi.String(""),
					},
					CiliumRegistry:    pulumi.String("fake.io"),
					CiliumTag:         pulumi.String("17.0"),
					KubernetesVersion: pulumi.String("1.30"),
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test"),
					Environment:       pulumi.String("dev"),
					VpcID:             pulumi.String("test"),
				},
			},
			want:    want{},
			wantErr: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := eks.NewCluster(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.Endpoint.ApplyT(func(endpoint string) string {
					assert.Equal(t, tc.want.Endpoint, endpoint)

					return endpoint
				})

				got.SecurityGroupID.ApplyT(func(securityGroup string) string {
					assert.Equal(t, tc.want.SecurityGroupID, securityGroup)

					return securityGroup
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewCluster() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestClusterArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *eks.ClusterArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"subnetIDs": ["subnet-12345", "subnet-67890"],
				"ciliumRegistry": "quay.io/cilium",
				"ciliumTag": "1.11",
				"kubernetesVersion": "1.21",
				"complianceLevel": "high",
				"customer": "customer-abc",
				"environment": "production",
				"nodeGroups": {
					"worker-group": {
						"amiID": "ami-12345",
						"instanceType": "t2.micro",
						"maxSize": 10,
						"minSize": 1,
						"desiredSize": 3,
						"azOverride": ["us-east-1a", "us-east-1b"],
						"volumeSize": 50,
						"rootVolumeSize": 50,
						"labels": {"env": "production"},
						"taints": [
							{"effect": "NoSchedule", "key": "node-role", "value": "worker"}
						],
						"kubeletExtraArgs": "--node-labels=env=production",
						"tags": {"team": "devops"}
					}
				},
				"privateRegistrySecret": "my-secret",
				"vpcID": "vpc-12345",
				"idpClientID": "client-123",
				"idpIssuerURL": "https://issuer.example.com",
				"idpAdminGroupName": "/Gamewarden/il2-eks-admin",
				"tags": {"env": "production"}
			}`,
			want: &eks.ClusterArgs{
				SubnetIDs:         pulumi.StringArray{pulumi.String("subnet-12345"), pulumi.String("subnet-67890")},
				CiliumRegistry:    pulumi.String("quay.io/cilium"),
				CiliumTag:         pulumi.String("1.11"),
				KubernetesVersion: pulumi.String("1.21"),
				ComplianceLevel:   pulumi.String("high"),
				Customer:          pulumi.String("customer-abc"),
				Environment:       pulumi.String("production"),
				NodeGroups: map[string]*eks.NodeGroupArgs{
					"worker-group": {
						AmiID:            pulumi.String("ami-12345"),
						InstanceType:     pulumi.String("t2.micro"),
						MaxSize:          pulumi.Int(10),
						MinSize:          pulumi.Int(1),
						DesiredSize:      pulumi.Int(3),
						AzOverride:       pulumi.StringArray{pulumi.String("us-east-1a"), pulumi.String("us-east-1b")},
						VolumeSize:       pulumi.Int(50),
						RootVolumeSize:   pulumi.Int(50),
						Labels:           pulumi.StringMap{"env": pulumi.String("production")},
						Taints:           []eks.TaintArgs{{Effect: pulumi.String("NoSchedule"), Key: pulumi.String("node-role"), Value: pulumi.String("worker")}},
						KubeletExtraArgs: pulumi.String("--node-labels=env=production"),
						Tags:             pulumi.StringMap{"team": pulumi.String("devops")},
					},
				},
				PrivateRegistrySecret: pulumi.String("my-secret"),
				VpcID:                 pulumi.String("vpc-12345"),
				IdpClientID:           pulumi.String("client-123"),
				IdpIssuerURL:          pulumi.String("https://issuer.example.com"),
				IdpAdminGroupName:     pulumi.String("/Gamewarden/il2-eks-admin"),
				Tags:                  pulumi.StringMap{"env": pulumi.String("production")},
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"ciliumTag": "1.11", "nodeGroups": "invalid-node-groups"}`, // nodeGroups should be a map, not a string
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"ciliumTag": "1.11", "nodeGroups": {"worker-group": { "amiID": "ami-12345" }`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args eks.ClusterArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
