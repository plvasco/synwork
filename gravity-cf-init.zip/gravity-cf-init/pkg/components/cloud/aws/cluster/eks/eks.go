package eks

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ec2"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/s3"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/whitelist"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	awsEc2 "github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	awsEks "github.com/pulumi/pulumi-aws/sdk/v6/go/aws/eks"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/iam"
	k8s "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes"
	"github.com/pulumi/pulumi-tls/sdk/v4/go/tls"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const eksComponentName = "gravity:aws:cluster:eks"

var (
	ErrRequiredArgumentNodeGroups = errors.New("required argument `nodeGroups` is missing")
)

type Cluster struct {
	pulumi.ResourceState
	Name                 pulumi.StringOutput   `pulumi:"name"`
	Endpoint             pulumi.StringOutput   `pulumi:"endpoint"`
	CertificateAuthority pulumi.StringOutput   `pulumi:"certificateAuthority"`
	KubeconfigJSON       pulumi.StringOutput   `pulumi:"kubeconfigJSON"`
	RoleARN              pulumi.StringOutput   `pulumi:"roleARN"`
	SecurityGroupID      pulumi.StringOutput   `pulumi:"securityGroupID"`
	WorkerRoleARN        pulumi.StringOutput   `pulumi:"nodeRoleARN"`
	NodeSecurityGroupID  pulumi.StringOutput   `pulumi:"nodeSecurityGroupID"`
	IssuerURL            pulumi.StringOutput   `pulumi:"issuerURL"`
	Buckets              map[string]*s3.Bucket `pulumi:"buckets"`
}

type ClusterArgs struct {
	SubnetIDs             pulumi.StringArray        `pulumi:"subnetIDs"`
	CiliumRegistry        pulumi.StringInput        `pulumi:"ciliumRegistry"        validate:"default=quay.io/cilium"`
	CiliumTag             pulumi.StringInput        `pulumi:"ciliumTag"             validate:"required"`
	KubernetesVersion     pulumi.StringInput        `pulumi:"kubernetesVersion"     validate:"required"`
	ComplianceLevel       pulumi.StringInput        `pulumi:"complianceLevel"       validate:"required"`
	Customer              pulumi.StringInput        `pulumi:"customer"              validate:"required"`
	Environment           pulumi.StringInput        `pulumi:"environment"           validate:"required"`
	NodeGroups            map[string]*NodeGroupArgs `pulumi:"nodeGroups"            validate:"required"`
	PrivateRegistrySecret pulumi.StringInput        `pulumi:"privateRegistrySecret"`
	VpcID                 pulumi.StringInput        `pulumi:"vpcID"`
	IdpClientID           pulumi.StringInput        `pulumi:"idpClientID"`
	IdpIssuerURL          pulumi.StringInput        `pulumi:"idpIssuerURL"`
	IdpAdminGroupName     pulumi.StringInput        `pulumi:"idpAdminGroupName"     validate:"default=/Gamewarden/il2-eks-admin"`
	Buckets               map[string]*s3.BucketArgs `pulumi:"buckets"`
	Tags                  pulumi.StringMap          `pulumi:"tags"`
}

func NewCluster(ctx *pulumi.Context, name string, args *ClusterArgs, opts ...pulumi.ResourceOption) (*Cluster, error) {
	component := &Cluster{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(eksComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", eksComponentName, name, err)
	}

	if err := component.createClusterRole(ctx, name+"-clusterRole", args); err != nil {
		return nil, err
	}

	if err := component.createWorkerRole(ctx, name+"-workerRole", args); err != nil {
		return nil, err
	}

	if err := component.createSecurityGroups(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createCluster(ctx, name+"-cluster", args); err != nil {
		return nil, err
	}

	if err := component.createAccessEntry(ctx, name+"-accessEntry", args); err != nil {
		return nil, err
	}

	if err := component.createIAMOpenIDConnectProvider(ctx, name+"-iam-oidc-provider", args); err != nil {
		return nil, err
	}

	if err := component.createNodeGroups(ctx, name+"-ng", args); err != nil {
		return nil, err
	}

	if err := component.createKubernetesBootstrap(ctx, name+"-k8s", args); err != nil {
		return nil, err
	}

	if err := component.createBuckets(ctx, name+"-bucket", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"name":                 component.Name,
		"endpoint":             component.Endpoint,
		"kubeconfigJSON":       component.KubeconfigJSON,
		"securityGroupID":      component.SecurityGroupID,
		"nodeSecurityGroupID":  component.NodeSecurityGroupID,
		"certificateAuthority": component.CertificateAuthority,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", eksComponentName, name, err)
	}

	return component, nil
}

func (c *Cluster) createCluster(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	cluster, err := awsEks.NewCluster(ctx, name, &awsEks.ClusterArgs{
		AccessConfig: &awsEks.ClusterAccessConfigArgs{
			AuthenticationMode:                      pulumi.String("API_AND_CONFIG_MAP"),
			BootstrapClusterCreatorAdminPermissions: pulumi.Bool(true),
		},
		DefaultAddonsToRemoves: pulumi.StringArray{
			pulumi.String("kube-proxy"),
			pulumi.String("vpc-cni"),
		},
		RoleArn: c.RoleARN,
		Tags:    utils.GenerateTags(args.Tags, name),
		Version: args.KubernetesVersion,
		VpcConfig: &awsEks.ClusterVpcConfigArgs{
			SecurityGroupIds:      pulumi.StringArray{c.SecurityGroupID},
			EndpointPrivateAccess: pulumi.Bool(true),
			EndpointPublicAccess:  pulumi.Bool(true),
			PublicAccessCidrs:     whitelist.GetIPWhitelist(args.ComplianceLevel),
			SubnetIds:             args.SubnetIDs,
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create eks cluster, %w", err)
	}

	c.Name = cluster.Name
	c.CertificateAuthority = cluster.CertificateAuthority.Data().Elem()
	c.Endpoint = cluster.Endpoint
	c.IssuerURL = cluster.Identities.Index(pulumi.Int(0)).Oidcs().Index(pulumi.Int(0)).Issuer().Elem()

	return nil
}

func (c *Cluster) createAccessEntry(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	if _, err := awsEks.NewAccessEntry(ctx, name, &awsEks.AccessEntryArgs{
		ClusterName:  c.Name,
		PrincipalArn: c.WorkerRoleARN,
		Tags:         utils.GenerateTags(args.Tags, name),
		Type:         pulumi.String("EC2_LINUX"),
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create eks access entry, %w", err)
	}

	return nil
}

func (c *Cluster) createNodeGroups(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	for ngName, ngArgs := range args.NodeGroups {
		ngArgs.clusterName = c.Name
		ngArgs.clusterEndpoint = c.Endpoint
		ngArgs.clusterCAData = c.CertificateAuthority
		ngArgs.securityGroupID = c.NodeSecurityGroupID
		ngArgs.nodeRoleARN = c.WorkerRoleARN
		ngArgs.Tags = utils.GenerateTags(args.Tags, name+"-"+ngName, ngArgs.Tags)

		if _, err := newNodeGroup(ctx, name+"-"+ngName, ngArgs, pulumi.Parent(c)); err != nil {
			return err
		}
	}

	return nil
}

func (c *Cluster) createKubernetesBootstrap(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	c.KubeconfigJSON = getKubeConfig(ctx, &KubeconfigArgs{
		ClusterName:              c.Name,
		Endpoint:                 c.Endpoint,
		CertificateAuthorityData: c.CertificateAuthority,
	})

	provider, err := k8s.NewProvider(ctx, name+"-provider", &k8s.ProviderArgs{
		EnableServerSideApply: pulumi.Bool(true),
		Kubeconfig:            c.KubeconfigJSON,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create private registry k8s provider, %w", err)
	}

	if _, err := NewKubernetesBootstrap(ctx, name, &KubernetesBootstrapArgs{
		ClusterName:           c.Name,
		ClusterEndpoint:       c.Endpoint,
		KubernetesVersion:     args.KubernetesVersion,
		CiliumRegistry:        args.CiliumRegistry,
		CiliumVersion:         args.CiliumTag,
		PrivateRegistrySecret: args.PrivateRegistrySecret,
		IdpClientID:           args.IdpClientID,
		IdpIssuerURL:          args.IdpIssuerURL,
		IdpAdminGroupName:     args.IdpAdminGroupName,
		Tags:                  utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c), pulumi.ProviderMap(map[string]pulumi.ProviderResource{
		"kubernetes": provider,
	})); err != nil {
		return fmt.Errorf("unable to create cilium cni, %w", err)
	}

	return nil
}

func (c *Cluster) createWorkerRole(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	var awsWorkerNodePolicies = []string{
		"AmazonEKSWorkerNodePolicy",
		"AmazonEC2ContainerRegistryReadOnly",
		"AmazonEKS_CNI_Policy",
		"AmazonSSMManagedInstanceCore",
		"AmazonEBSCSIDriverPolicy",
		"kmsDecryptionPolicy",
		// "workerCosmicAssumeRolePolicy",
	}

	managedPolicyArns := pulumi.StringArray{}

	statement := iam.GetPolicyDocumentStatement{
		Actions: []string{"sts:AssumeRole"},
		Principals: []iam.GetPolicyDocumentStatementPrincipal{{
			Type:        "Service",
			Identifiers: []string{"ec2.amazonaws.com"},
		}},
	}

	policyDocArgs := &iam.GetPolicyDocumentArgs{
		Statements: []iam.GetPolicyDocumentStatement{statement},
	}

	policyDocResult, err := iam.GetPolicyDocument(ctx, policyDocArgs)
	if err != nil {
		return fmt.Errorf("unable to get policy document, %w", err)
	}

	for _, policy := range awsWorkerNodePolicies {
		result, err := iam.LookupPolicy(ctx, &iam.LookupPolicyArgs{
			Name: &policy,
		}, nil)
		if err != nil {
			return fmt.Errorf("unable to lookup IAM policy `%s`, %w", policy, err)
		}

		managedPolicyArns = append(managedPolicyArns, pulumi.String(result.Arn))
	}

	role, err := iam.NewRole(ctx, name, &iam.RoleArgs{
		AssumeRolePolicy:  pulumi.String(policyDocResult.Json),
		Description:       pulumi.String("Eks Worker Role for communicating with the control plane and decrypting with KMS"),
		ManagedPolicyArns: managedPolicyArns,
		Tags:              utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create eks worker role, %w", err)
	}

	c.WorkerRoleARN = role.Arn

	return nil
}

func (c *Cluster) createClusterRole(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	statement := iam.GetPolicyDocumentStatement{
		Actions: []string{"sts:AssumeRole"},
		Principals: []iam.GetPolicyDocumentStatementPrincipal{{
			Type:        "Service",
			Identifiers: []string{"eks.amazonaws.com"},
		}},
	}

	policyDocArgs := &iam.GetPolicyDocumentArgs{
		Statements: []iam.GetPolicyDocumentStatement{statement},
	}

	policyDocResult, err := iam.GetPolicyDocument(ctx, policyDocArgs)
	if err != nil {
		return fmt.Errorf("unable to get policy document, %w", err)
	}

	policy := iam.LookupPolicyOutput(ctx, iam.LookupPolicyOutputArgs{
		Name: pulumi.String("AmazonEKSClusterPolicy"),
	}, pulumi.Parent(c))

	role, err := iam.NewRole(ctx, name, &iam.RoleArgs{
		AssumeRolePolicy:  pulumi.String(policyDocResult.Json),
		Description:       pulumi.String("Default EKS cluster role."),
		ManagedPolicyArns: pulumi.StringArray{policy.Arn()},
		Name:              pulumi.String(name),
		Tags:              utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create eks cluster role, %w", err)
	}

	c.RoleARN = role.Arn

	if _, err := iam.NewRolePolicyAttachment(ctx, name+"-attachment", &iam.RolePolicyAttachmentArgs{
		PolicyArn: policy.Arn(),
		Role:      role,
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create eks cluster role policy attachment, %w", err)
	}

	return nil
}

func (c *Cluster) createSecurityGroups(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	clusterSecurityGroup, err := ec2.NewSecurityGroup(ctx, name+"-cluster", &ec2.SecurityGroupArgs{
		Description: pulumi.String("EKS Cluster Security Group"),
		VpcID:       args.VpcID,
		Tags:        utils.GenerateTags(args.Tags, name+"-cluster"),
		Rules: map[string]*ec2.SecurityGroupRuleArgs{
			"egress-internet": {
				CidrBlocks:  pulumi.ToStringArray([]string{"0.0.0.0/0"}),
				Description: pulumi.String("Allow internet access."),
				FromPort:    pulumi.Int(0),
				Protocol:    pulumi.String("all"),
				ToPort:      pulumi.Int(0),
				Type:        pulumi.String("egress"),
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create eks cluster security group, %w", err)
	}

	nodeSecurityGroup, err := ec2.NewSecurityGroup(ctx, name+"-node", &ec2.SecurityGroupArgs{
		Description: pulumi.String("EKS Cluster NodeGroup Security Group"),
		VpcID:       args.VpcID,
		Tags:        utils.GenerateTags(args.Tags, name+"-node"),
		Rules: map[string]*ec2.SecurityGroupRuleArgs{
			"ingress-nodes": {
				Description: pulumi.String("Allow Nodes to comunicate with each other."),
				FromPort:    pulumi.Int(0),
				Protocol:    pulumi.String("all"),
				ToPort:      pulumi.Int(0),
				Self:        pulumi.Bool(true),
				Type:        pulumi.String("ingress"),
			},
			"ingress-controlplane": {
				Description:           pulumi.String("Allow worker Kubelets and pods to receive communication from the cluster control plane"),
				FromPort:              pulumi.Int(1025),
				Protocol:              pulumi.String("tcp"),
				ToPort:                pulumi.Int(65535),
				SourceSecurityGroupID: clusterSecurityGroup.ID,
				Type:                  pulumi.String("ingress"),
			},
			"ingress-extension-controlplane": {
				Description:           pulumi.String("Allow pods running extension API servers on port 443 to receive communication from cluster control plane"),
				FromPort:              pulumi.Int(443),
				Protocol:              pulumi.String("tcp"),
				ToPort:                pulumi.Int(443),
				SourceSecurityGroupID: clusterSecurityGroup.ID,
				Type:                  pulumi.String("ingress"),
			},
			"egress-internet": {
				CidrBlocks:  pulumi.ToStringArray([]string{"0.0.0.0/0"}),
				Description: pulumi.String("Allow internet access."),
				FromPort:    pulumi.Int(0),
				Protocol:    pulumi.String("all"),
				ToPort:      pulumi.Int(0),
				Type:        pulumi.String("egress"),
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create eks node security group, %w", err)
	}

	if _, err := awsEc2.NewSecurityGroupRule(ctx, name+"-cluster-rule-ingress-api", &awsEc2.SecurityGroupRuleArgs{
		Description:           pulumi.String("Allow pods to communicate with the cluster API Server"),
		FromPort:              pulumi.Int(443),
		Protocol:              pulumi.String("tcp"),
		ToPort:                pulumi.Int(443),
		Type:                  pulumi.String("ingress"),
		SecurityGroupId:       clusterSecurityGroup.ID,
		SourceSecurityGroupId: nodeSecurityGroup.ID,
	}, pulumi.Parent(clusterSecurityGroup), pulumi.DeleteBeforeReplace(true)); err != nil {
		return fmt.Errorf("unable to create eks cluster security group rule, %w", err)
	}

	c.SecurityGroupID = clusterSecurityGroup.ID.ToStringOutput()
	c.NodeSecurityGroupID = nodeSecurityGroup.ID.ToStringOutput()

	return nil
}

func (c *Cluster) createIAMOpenIDConnectProvider(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	_, err := iam.NewOpenIdConnectProvider(ctx, name, &iam.OpenIdConnectProviderArgs{
		ClientIdLists: pulumi.ToStringArray([]string{"sts.amazonaws.com"}),
		Tags:          utils.GenerateTags(args.Tags, name),
		ThumbprintLists: pulumi.StringArray{
			tls.GetCertificateOutput(ctx, tls.GetCertificateOutputArgs{Url: c.IssuerURL}, pulumi.Parent(c)).Certificates().Index(pulumi.Int(0)).Sha1Fingerprint(),
		},
		Url: c.IssuerURL,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create IAM OIDC Provider %s, %w", name, err)
	}

	return nil
}

func (c *Cluster) createBuckets(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	buckets := map[string]*s3.Bucket{}

	for bucketName, bucketArgs := range args.Buckets {
		if bucketArgs.Principals == nil {
			bucketArgs.Principals = pulumi.StringArray{}
		}

		bucketArgs.Principals = append(bucketArgs.Principals, c.WorkerRoleARN)

		bucket, err := s3.NewBucket(ctx, name+"-"+bucketName, bucketArgs, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create bucket %s, %w", bucketName, err)
		}

		buckets[bucketName] = bucket
	}

	c.Buckets = buckets

	return nil
}

func (args *ClusterArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	if len(args.NodeGroups) == 0 {
		return ErrRequiredArgumentNodeGroups
	}

	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["customer"]; !ok {
		args.Tags["customer"] = args.Customer
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["complianceLevel"] = args.ComplianceLevel
	}

	if _, ok := args.Tags["environment"]; !ok {
		args.Tags["environment"] = args.Environment
	}

	for _, ngArgs := range args.NodeGroups {
		ngArgs.subnetIDs = args.SubnetIDs

		ngArgs.Tags = utils.CombineTags(args.Tags, ngArgs.Tags)
	}

	return nil
}

func (args *ClusterArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
