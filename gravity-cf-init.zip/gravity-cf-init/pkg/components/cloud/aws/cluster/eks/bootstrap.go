package eks

import (
	"errors"
	"fmt"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"

	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/eks"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/kms"
	coreV1 "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes/core/v1"
	helm "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes/helm/v3"
	metaV1 "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes/meta/v1"
	rbacV1 "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes/rbac/v1"
	storageV1 "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes/storage/v1"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const (
	KubernetesBootstrapComponentName = "gravity:aws:cluster:eks:k8s:bootstrap"
)

var (
	ErrRequiredArgumentIdpClientID  = errors.New("`IdpIssuerURL` detected: required argument `IdpClientID` is missing")
	ErrRequiredArgumentIdpIssuerURL = errors.New("`IdpClientID` detected: required argument `IdpIssuerURL` is missing")
)

type KubernetesBootstrap struct {
	pulumi.ResourceState
	CiliumReleaseName pulumi.StringOutput
	helmRelease       *helm.Release
}

type KubernetesBootstrapArgs struct {
	ClusterName           pulumi.StringInput `pulumi:"clusterName"           validate:"required"`
	ClusterEndpoint       pulumi.StringInput `pulumi:"endpoint"              validate:"required"`
	KubernetesVersion     pulumi.StringInput `pulumi:"kubernetesVersion"     validate:"required"`
	ImagePullSecretName   pulumi.StringInput `pulumi:"imagePullSecretName"   validate:"default=private-registry"`
	PrivateRegistrySecret pulumi.StringInput `pulumi:"privateRegistrySecret"`
	CiliumRegistry        pulumi.StringInput `pulumi:"ciliumRegistry"        validate:"default=quay.io/cilium"`
	CiliumVersion         pulumi.StringInput `pulumi:"ciliumVersion"         validate:"required"`
	IdpClientID           pulumi.StringInput `pulumi:"idpClientID"`
	IdpIssuerURL          pulumi.StringInput `pulumi:"idpIssuerURL"`
	IdpAdminGroupName     pulumi.StringInput `pulumi:"idpAdminGroupName"     validate:"default=/Gamewarden/il2-eks-admin"`
	Tags                  pulumi.StringMap   `pulumi:"tags"`
}

func NewKubernetesBootstrap(ctx *pulumi.Context, name string, args *KubernetesBootstrapArgs, opts ...pulumi.ResourceOption) (*KubernetesBootstrap, error) {
	component := &KubernetesBootstrap{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(KubernetesBootstrapComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", KubernetesBootstrapComponentName, name, err)
	}

	if args.PrivateRegistrySecret != nil {
		if err := component.createPrivateRegistrySecret(ctx, name+"-private-reg-cred", args); err != nil {
			return nil, err
		}
	}

	if err := component.configureAWSStorageClasses(ctx, name+"-sc", args); err != nil {
		return nil, err
	}

	if err := component.createCiliumRelease(ctx, name+"-cilium", args); err != nil {
		return nil, err
	}

	if err := component.createAddOns(ctx, name+"-addon", args); err != nil {
		return nil, err
	}

	if args.IdpClientID != nil && args.IdpIssuerURL != nil {
		if err := component.createIdentityProviderConfig(ctx, name+"-idp", args); err != nil {
			return nil, err
		}
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"ciliumReleaseName": component.CiliumReleaseName,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", KubernetesBootstrapComponentName, name, err)
	}

	return component, nil
}

func (c *KubernetesBootstrap) createCiliumRelease(ctx *pulumi.Context, name string, args *KubernetesBootstrapArgs) error {
	host, ok := args.ClusterEndpoint.ToStringOutput().ApplyT(
		func(endpoint string) string {
			return strings.TrimPrefix(endpoint, "https://")
		},
	).(pulumi.StringOutput)
	if !ok {
		return utils.ErrUnableToTypeCast
	}

	release, err := helm.NewRelease(ctx, name, &helm.ReleaseArgs{
		Chart:     pulumi.String("cilium"),
		Version:   args.CiliumVersion,
		Namespace: pulumi.String("kube-system"),
		Timeout:   pulumi.Int(1200),
		RepositoryOpts: helm.RepositoryOptsArgs{
			Repo: pulumi.String("https://helm.cilium.io/"),
		},
		Values: pulumi.Map{
			"image": pulumi.Map{
				"repository": pulumi.Sprintf("%s/cilium", args.CiliumRegistry),
				"useDigest":  pulumi.Bool(false),
			},
			"imagePullSecrets": pulumi.Array{
				pulumi.Map{"name": args.ImagePullSecretName},
			},
			"eni": pulumi.Map{
				"enabled":             pulumi.Bool(true),
				"awsReleaseExcessIPs": pulumi.Bool(true),
			},
			"envoy": pulumi.Map{"enabled": pulumi.Bool(false)},
			"ipam":  pulumi.Map{"mode": pulumi.String("eni")},
			"operator": pulumi.Map{
				"image": pulumi.Map{
					"repository": pulumi.Sprintf("%s/operator", args.CiliumRegistry),
					"useDigest":  pulumi.Bool(false),
				},
				"prometheus":     pulumi.Map{"enabled": pulumi.Bool(true)},
				"serviceMonitor": pulumi.Map{"enabled": pulumi.Bool(false)},
			},
			"prometheus": pulumi.Map{
				"enabled":        pulumi.Bool(true),
				"serviceMonitor": pulumi.Map{"enabled": pulumi.Bool(false)},
			},
			"clustermesh": pulumi.Map{
				"apiserver": pulumi.Map{
					"image": pulumi.Map{
						"repository": pulumi.Sprintf("%s/clustermesh-apiserver", args.CiliumRegistry),
						"useDigest":  pulumi.Bool(false),
					},
					"metrics":        pulumi.Map{"enabled": pulumi.Bool(true)},
					"serviceMonitor": pulumi.Map{"enabled": pulumi.Bool(false)},
					"tls": pulumi.Map{
						"auto": pulumi.Map{"method": pulumi.String("cronJob")},
					},
				},
			},
			"certgen": pulumi.Map{
				"image": pulumi.Map{
					"repository": pulumi.Sprintf("%s/certgen", args.CiliumRegistry),
					"useDigest":  pulumi.Bool(false),
				},
			},
			"hubble": pulumi.Map{
				"metrics": pulumi.Map{
					"enabled": pulumi.StringArray{
						//nolint:lll //needed for cilium values
						pulumi.String("policy:sourceContext=app|workload-name|pod|reserved-identity;destinationContext=app|workload-name|pod|dns|reserved-identity;labelsContext=source_namespace,destination_namespace"),
						//nolint:lll //needed for cilium values
						pulumi.String("httpV2:sourceContext=workload-name|pod-name|reserved-identity;destinationContext=workload-name|pod-name|reserved-identity;labelsContext=source_namespace,destination_namespace,traffic_direction"),
					},
					"serviceMonitor": pulumi.Map{"enabled": pulumi.Bool(false)},
				},
				"tls": pulumi.Map{
					"auto": pulumi.Map{"method": pulumi.String("cronJob")},
				},
				"relay": pulumi.Map{
					"enabled": pulumi.Bool(true),
					"image": pulumi.Map{
						"repository": pulumi.Sprintf("%s/hubble-relay", args.CiliumRegistry),
						"useDigest":  pulumi.Bool(false),
					},
					"prometheus": pulumi.Map{
						"enabled": pulumi.Bool(true),
						"serviceMonitor": pulumi.Map{
							"enabled": pulumi.Bool(false),
						},
					},
				},
				"ui": pulumi.Map{
					"enabled": pulumi.Bool(true),
					"frontend": pulumi.Map{
						"image": pulumi.Map{
							"repository": pulumi.Sprintf("%s/hubble-ui", args.CiliumRegistry),
							"useDigest":  pulumi.Bool(false),
						},
					},
					"backend": pulumi.Map{
						"image": pulumi.Map{
							"repository": pulumi.Sprintf("%s/hubble-ui-backend", args.CiliumRegistry),
							"useDigest":  pulumi.Bool(false),
						},
					},
				},
			},
			"egressMasqueradeInterfaces": pulumi.String("eth+"),
			"kubeProxyReplacement":       pulumi.String("true"),
			"k8sServiceHost":             host,
			"k8sServicePort":             pulumi.String("443"),
			"socketLB":                   pulumi.Map{"hostNamespaceOnly": pulumi.Bool(true)},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to install cilium helm chart, %w", err)
	}

	c.helmRelease = release

	return nil
}

func (c *KubernetesBootstrap) configureAWSStorageClasses(ctx *pulumi.Context, name string, _ *KubernetesBootstrapArgs) error {
	if _, err := storageV1.NewStorageClassPatch(ctx, name+"-gp2-patch", &storageV1.StorageClassPatchArgs{
		Metadata: metaV1.ObjectMetaPatchArgs{
			Name: pulumi.String("gp2"),
			Annotations: pulumi.StringMap{
				"storageclass.kubernetes.io/is-default-class": pulumi.String("false"),
				"pulumi.com/patchForce":                       pulumi.String("true"),
			},
		},
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to patch eks gp2 storage class for %s, %w", name, err)
	}

	key := kms.LookupKeyOutput(ctx, kms.LookupKeyOutputArgs{
		KeyId: pulumi.String("alias/encryption-key"),
	})

	if _, err := storageV1.NewStorageClass(ctx, name+"-gp3", &storageV1.StorageClassArgs{
		ApiVersion: pulumi.String("storage.k8s.io/v1"),
		Kind:       pulumi.String("StorageClass"),
		Metadata: metaV1.ObjectMetaArgs{
			Name: pulumi.String("gp3"),
			Annotations: pulumi.StringMap{
				"storageclass.kubernetes.io/is-default-class": pulumi.String("true"),
			},
		},
		Parameters: pulumi.StringMap{
			"Encrypted": pulumi.String("true"),
			"Type":      pulumi.String("gp3"),
			"FsType":    pulumi.String("ext4"),
			"kmsKeyId":  key.Arn(),
		},
		Provisioner:          pulumi.String("ebs.csi.aws.com"),
		ReclaimPolicy:        pulumi.String("Retain"),
		AllowVolumeExpansion: pulumi.Bool(true),
		VolumeBindingMode:    pulumi.String("WaitForFirstConsumer"),
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create eks gp3 storage class for %s, %w", name, err)
	}

	return nil
}

func (c *KubernetesBootstrap) createPrivateRegistrySecret(ctx *pulumi.Context, name string, args *KubernetesBootstrapArgs) error {
	if _, err := coreV1.NewSecret(ctx, name, &coreV1.SecretArgs{
		Metadata: &metaV1.ObjectMetaArgs{
			Name:      args.ImagePullSecretName,
			Namespace: pulumi.String("kube-system"),
		},
		Type: pulumi.String("kubernetes.io/dockerconfigjson"),
		Data: pulumi.StringMap{".dockerconfigjson": args.PrivateRegistrySecret},
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create %s secret, %w", "private-registry", err)
	}

	return nil
}

func (c *KubernetesBootstrap) createAddOns(ctx *pulumi.Context, name string, args *KubernetesBootstrapArgs) error {
	addons := []string{"aws-ebs-csi-driver", "coredns"}

	for _, addon := range addons {
		addonVersion := eks.GetAddonVersionOutput(ctx, eks.GetAddonVersionOutputArgs{
			AddonName:         pulumi.String(addon),
			KubernetesVersion: args.KubernetesVersion,
			MostRecent:        pulumi.Bool(true),
		})

		if _, err := eks.NewAddon(ctx, name+"-"+addon, &eks.AddonArgs{
			AddonName:    pulumi.String(addon),
			AddonVersion: addonVersion.Version(),
			ClusterName:  args.ClusterName,
			Tags:         utils.GenerateTags(args.Tags, name+"-"+addon),
		}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{c.helmRelease})); err != nil {
			return fmt.Errorf("unable to deploy addons, %w", err)
		}
	}

	return nil
}

func (c *KubernetesBootstrap) createIdentityProviderConfig(ctx *pulumi.Context, name string, args *KubernetesBootstrapArgs) error {
	idpConfig, err := eks.NewIdentityProviderConfig(ctx, name+"-config", &eks.IdentityProviderConfigArgs{
		ClusterName: args.ClusterName,
		Oidc: &eks.IdentityProviderConfigOidcArgs{
			IdentityProviderConfigName: pulumi.String("keycloak"),
			ClientId:                   args.IdpClientID,
			GroupsClaim:                pulumi.String("groups"),
			IssuerUrl:                  args.IdpIssuerURL,
			UsernameClaim:              pulumi.String("email"),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create Identity Provider Config for %s, %w", name, err)
	}

	_, err = rbacV1.NewClusterRoleBinding(ctx, name+"-oidc-keycloak-crb", &rbacV1.ClusterRoleBindingArgs{
		Metadata: metaV1.ObjectMetaArgs{
			Name: pulumi.String("oidc-keycloak-cluster-admin-role-binding"),
		},
		RoleRef: &rbacV1.RoleRefArgs{
			Kind:     pulumi.String("ClusterRole"),
			Name:     pulumi.String("cluster-admin"),
			ApiGroup: pulumi.String("rbac.authorization.k8s.io"),
		},
		Subjects: &rbacV1.SubjectArray{
			&rbacV1.SubjectArgs{
				Kind:     pulumi.String("Group"),
				Name:     args.IdpAdminGroupName,
				ApiGroup: pulumi.String("rbac.authorization.k8s.io"),
			},
		},
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{idpConfig}))
	if err != nil {
		return fmt.Errorf("unable to create oidc cluster role binding for %s, %w", name, err)
	}

	return nil
}

func (args *KubernetesBootstrapArgs) validate() error {
	if args.IdpClientID != nil && args.IdpIssuerURL == nil {
		return ErrRequiredArgumentIdpIssuerURL
	}

	if args.IdpIssuerURL != nil && args.IdpClientID == nil {
		return ErrRequiredArgumentIdpClientID
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	return nil
}

func (args *KubernetesBootstrapArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
