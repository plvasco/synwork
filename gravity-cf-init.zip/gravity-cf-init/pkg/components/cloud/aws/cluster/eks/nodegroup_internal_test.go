package eks

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewNodeGroup(t *testing.T) {
	t.Parallel()

	type want struct {
		LaunchTemplateName string
		// add wanted result fields here
	}

	type args struct {
		name string
		args *NodeGroupArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create eks node group",
			in: args{
				name: "test-nodegroup-1",
				args: &NodeGroupArgs{
					clusterName:     pulumi.String("test-cluster"),
					clusterEndpoint: pulumi.String("https://fakeendpoint.com"),
					clusterCAData:   pulumi.String("Potato"),
					nodeRoleARN:     pulumi.String("test"),
					AmiID:           pulumi.String("ami-123456789"),
					InstanceType:    pulumi.String("t3xltest"),
					MaxSize:         pulumi.Int(2),
					MinSize:         pulumi.Int(1),
					DesiredSize:     pulumi.Int(1),
					VolumeSize:      pulumi.Int(100),
					RootVolumeSize:  pulumi.Int(100),
					Labels:          pulumi.ToStringMap(map[string]string{"test": "true", "test2": "false"}),
					Taints: []TaintArgs{
						{
							Effect: pulumi.String("NO_SCHEDULE"),
							Key:    pulumi.String("only"),
							Value:  pulumi.String("test"),
						},
						{
							Effect: pulumi.String("NoExecute"),
							Key:    pulumi.String("testCluster"),
							Value:  pulumi.String("true"),
						},
					},
				},
			},
			want: want{
				LaunchTemplateName: "test-nodegroup-1-launchTemplate",
			},
			wantErr: false,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := newNodeGroup(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.LaunchTemplateName.ApplyT(func(name string) string {
					assert.Equal(t, tc.want.LaunchTemplateName, name)

					return name
				})
				// add validation tests here

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks))) // add mocks here
			if (err != nil) != tc.wantErr {
				t.Errorf("NewNodeGroup() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}
