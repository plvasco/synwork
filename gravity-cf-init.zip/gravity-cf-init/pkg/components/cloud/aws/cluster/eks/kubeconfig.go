package eks

import (
	"encoding/json"
	"fmt"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

type KubeconfigArgs struct {
	ClusterName              pulumi.StringInput
	Endpoint                 pulumi.StringInput
	CertificateAuthorityData pulumi.StringInput
}

func getKubeConfig(_ *pulumi.Context, args *KubeconfigArgs) pulumi.StringOutput {
	kubeconfig := pulumix.Apply3Err(
		args.ClusterName.ToStringOutput(),
		args.Endpoint.ToStringOutput(),
		args.CertificateAuthorityData.ToStringOutput(),
		func(name, endpoint, caData string) (string, error) {
			tokenArgs := []string{"eks", "get-token", "--cluster-name", name}

			config := map[string]any{
				"apiVersion": "v1",
				"clusters": []map[string]any{
					{
						"cluster": map[string]any{
							"server":                     endpoint,
							"certificate-authority-data": caData,
						},
						"name": "kubernetes",
					},
				},
				"contexts": []map[string]any{
					{
						"context": map[string]any{
							"cluster": "kubernetes",
							"user":    "aws",
						},
						"name": "aws",
					},
				},
				"current-context": "aws",
				"kind":            "Config",
				"users": []map[string]any{
					{
						"name": "aws",
						"user": map[string]any{
							"exec": map[string]any{
								"apiVersion": "client.authentication.k8s.io/v1beta1",
								"command":    "aws",
								"args":       tokenArgs,
								"env": []map[string]any{
									{
										"name":  "KUBERNETES_EXEC_INFO",
										"Value": `{"apiVersion": "client.authentication.k8s.io/v1beta1"}`,
									},
								},
							},
						},
					},
				},
			}

			configJSON, err := json.MarshalIndent(config, "", "  ")
			if err != nil {
				return "", fmt.Errorf("unable to marshal kubeconfig to json, %w", err)
			}

			return string(configJSON), err
		},
	)

	return pulumix.Cast[pulumi.StringOutput](kubeconfig)
}

// func getSubnetIDs(public, private pulumi.StringArray) pulumi.StringArrayOutput {
// 	subnets := pulumix.Apply2(public, private, func(pub, priv []string) []string {
// 		return append(pub, priv...)
// 	})

// 	return pulumix.Cast[pulumi.StringArrayOutput](subnets)
// }
