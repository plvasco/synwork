package eks_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/cluster/eks"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestNodeGroupArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *eks.NodeGroupArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"amiID": "ami-12345",
				"instanceType": "t2.micro",
				"maxSize": 10,
				"minSize": 1,
				"desiredSize": 3,
				"azOverride": ["us-east-1a", "us-east-1b"],
				"volumeSize": 50,
				"rootVolumeSize": 50,
				"labels": {"env": "production"},
				"taints": [
					{"effect": "NoSchedule", "key": "node-role", "value": "worker"}
				],
				"kubeletExtraArgs": "--node-labels=env=production",
				"tags": {"team": "devops"}
			}`,
			want: &eks.NodeGroupArgs{
				AmiID:            pulumi.String("ami-12345"),
				InstanceType:     pulumi.String("t2.micro"),
				MaxSize:          pulumi.Int(10),
				MinSize:          pulumi.Int(1),
				DesiredSize:      pulumi.Int(3),
				AzOverride:       pulumi.StringArray{pulumi.String("us-east-1a"), pulumi.String("us-east-1b")},
				VolumeSize:       pulumi.Int(50),
				RootVolumeSize:   pulumi.Int(50),
				Labels:           pulumi.StringMap{"env": pulumi.String("production")},
				Taints:           []eks.TaintArgs{{Effect: pulumi.String("NoSchedule"), Key: pulumi.String("node-role"), Value: pulumi.String("worker")}},
				KubeletExtraArgs: pulumi.String("--node-labels=env=production"),
				Tags:             pulumi.StringMap{"team": pulumi.String("devops")},
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"amiID": "ami-12345", "instanceType": 123, "maxSize": 10}`, // instanceType should be a string
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"amiID": "ami-12345", "instanceType": "t2.micro", "maxSize": 10`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args eks.NodeGroupArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}

func TestTaintArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *eks.TaintArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"effect": "NoSchedule",
				"key": "node-role",
				"value": "worker"
			}`,
			want: &eks.TaintArgs{
				Effect: pulumi.String("NoSchedule"),
				Key:    pulumi.String("node-role"),
				Value:  pulumi.String("worker"),
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"effect": "NoSchedule", "key": 123, "value": "worker"}`, // key should be a string
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"effect": "NoSchedule", "key": "node-role", "value": "worker"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args eks.TaintArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
