package talos_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/cluster/talos"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewCluster(t *testing.T) {
	t.Parallel()

	type want struct {
		securityGroupIDs map[string]string
	}

	type args struct {
		name string
		args *talos.ClusterInfraArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create talos cluster",
			in: args{
				name: "test-talos",
				args: &talos.ClusterInfraArgs{
					CiliumVersion: pulumi.String("v1.14.5"),
					Workers: &talos.NodeArgs{
						InstanceType: pulumi.String("xLtest"),
						Count:        pulumi.Int(3),
					},
					ControlPlane: &talos.NodeArgs{
						InstanceType: pulumi.String("XLtestyboi"),
						Count:        pulumi.Int(3),
					},
					SubnetIDs: pulumi.StringArray{
						pulumi.String("subnet-123467899"),
						pulumi.String("subnet-900190019"),
					},
					VpcID:             pulumi.String("vpc-123456"),
					Tags:              pulumi.ToStringMap(map[string]string{"organization": "test"}),
					KubernetesVersion: pulumi.String("1.30.0"),
					ComplianceLevel:   pulumi.String("il2"),
					Customer:          pulumi.String("testing"),
					Environment:       pulumi.String("testing"),
					OSVersion:         pulumi.String("v1.9"),
				},
			},
			want: want{
				securityGroupIDs: map[string]string{
					"cluster":      "test-talos-cluster-sg_id",
					"loadBalancer": "test-talos-loadbalancer-sg_id",
				},
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := talos.NewCluster(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.SecurityGroupIDs.ToStringMapOutput().ApplyT(func(idMap map[string]string) error {
					assert.Contains(t, tt.want.securityGroupIDs["cluster"], idMap["cluster"])
					assert.Contains(t, tt.want.securityGroupIDs["loadBalancer"], idMap["loadBalancer"])

					return nil
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestClusterInfraArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *talos.ClusterInfraArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"controlPlane": {
					"osVersion": "v1.2.3",
					"subnetIDs": ["subnet-12345"],
					"instanceType": "t2.micro",
					"count": 1,
					"tags": {"env": "production"}
				},
				"workers": {
					"osVersion": "v1.2.4",
					"subnetIDs": ["subnet-67890"],
					"instanceType": "t2.small",
					"count": 2,
					"tags": {"team": "devops"}
				},
				"subnetIDs": ["subnet-12345", "subnet-67890"],
				"kubernetesVersion": "1.21",
				"tags": {"env": "production", "team": "devops"},
				"complianceLevel": "high",
				"customer": "customer-abc",
				"environment": "production",
				"vpcID": "vpc-12345",
				"osVersion": "v1.2.5",
				"privateRegistrySecret": "my-secret",
				"imagePullSecretName": "custom-registry",
				"ciliumRegistry": "quay.io/cilium",
				"ciliumVersion": "1.11"
			}`,
			want: &talos.ClusterInfraArgs{
				ControlPlane: &talos.NodeArgs{
					OSVersion:    pulumi.String("v1.2.3"),
					SubnetIDs:    pulumi.StringArray{pulumi.String("subnet-12345")},
					InstanceType: pulumi.String("t2.micro"),
					Count:        1,
					Tags:         pulumi.StringMap{"env": pulumi.String("production")},
				},
				Workers: &talos.NodeArgs{
					OSVersion:    pulumi.String("v1.2.4"),
					SubnetIDs:    pulumi.StringArray{pulumi.String("subnet-67890")},
					InstanceType: pulumi.String("t2.small"),
					Count:        2,
					Tags:         pulumi.StringMap{"team": pulumi.String("devops")},
				},
				SubnetIDs:             pulumi.StringArray{pulumi.String("subnet-12345"), pulumi.String("subnet-67890")},
				KubernetesVersion:     pulumi.String("1.21"),
				Tags:                  pulumi.StringMap{"env": pulumi.String("production"), "team": pulumi.String("devops")},
				ComplianceLevel:       pulumi.String("high"),
				Customer:              pulumi.String("customer-abc"),
				Environment:           pulumi.String("production"),
				VpcID:                 pulumi.String("vpc-12345"),
				OSVersion:             pulumi.String("v1.2.5"),
				PrivateRegistrySecret: pulumi.String("my-secret"),
				ImagePullSecretName:   pulumi.String("custom-registry"),
				CiliumRegistry:        pulumi.String("quay.io/cilium"),
				CiliumVersion:         pulumi.String("1.11"),
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"controlPlane": "invalid-node-args", "workers": {"instanceType": "t2.small"}, "kubernetesVersion": "1.21"}`, // controlPlane should be a struct, not a string
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"controlPlane": {"osVersion": "v1.2.3", "instanceType": "t2.micro"}`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args talos.ClusterInfraArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}

func TestNodeArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *talos.NodeArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"osVersion": "v1.2.3",
				"subnetIDs": ["subnet-12345", "subnet-67890"],
				"instanceType": "t2.micro",
				"count": 5,
				"tags": {"env": "production"}
			}`,
			want: &talos.NodeArgs{
				OSVersion:    pulumi.String("v1.2.3"),
				SubnetIDs:    pulumi.StringArray{pulumi.String("subnet-12345"), pulumi.String("subnet-67890")},
				InstanceType: pulumi.String("t2.micro"),
				Count:        5,
				Tags:         pulumi.StringMap{"env": pulumi.String("production")},
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"osVersion": "v1.2.3", "instanceType": "t2.micro", "count": "five"}`, // count should be an integer
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"osVersion": "v1.2.3", "instanceType": "t2.micro", "tags": {"env": "production"}`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args talos.NodeArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
