package talos

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ec2"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cluster/talos"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	awsSDK "github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	awsEC2 "github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/lb"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const infrastructureComponentName = "gravity:aws:cluster:talos"

var (
	ErrRequiredArgumentAMI = errors.New("required argument `ami` is missing")
)

type Cluster struct {
	pulumi.ResourceState
	Cluster             *talos.Cluster      `pulumi:"cluster"`
	SecurityGroupIDs    pulumi.StringMap    `pulumi:"securityGroupIDs"`
	TalosTargetGroupARN pulumi.StringOutput `pulumi:"talosTargetGroupARN"`
	TargetGroupARN      pulumi.StringOutput `pulumi:"targetGroupARN"`
	LoadBalancerDNS     pulumi.StringOutput `pulumi:"loadBalancerARN"`
	ControlPlane        *talos.MachineArgs  `pulumi:"controlPlane"`
	Workers             *talos.MachineArgs  `pulumi:"workers"`
}

type ClusterInfraArgs struct {
	ControlPlane          *NodeArgs          `pulumi:"controlPlane"          validate:"required,dig"`
	Workers               *NodeArgs          `pulumi:"workers"               validate:"required,dig"`
	SubnetIDs             pulumi.StringArray `pulumi:"subnetIDs"`
	KubernetesVersion     pulumi.StringInput `pulumi:"kubernetesVersion"     validate:"required"`
	Tags                  pulumi.StringMap   `pulumi:"tags"`
	ComplianceLevel       pulumi.StringInput `pulumi:"complianceLevel"       validate:"required"`
	Customer              pulumi.StringInput `pulumi:"customer"              validate:"required"`
	Environment           pulumi.StringInput `pulumi:"environment"           validate:"required"`
	VpcID                 pulumi.StringInput `pulumi:"vpcID"`
	OSVersion             pulumi.StringInput `pulumi:"osVersion"`
	PrivateRegistrySecret pulumi.StringInput `pulumi:"privateRegistrySecret"`
	ImagePullSecretName   pulumi.StringInput `pulumi:"imagePullSecretName"   validate:"default=private-registry"`
	CiliumRegistry        pulumi.StringInput `pulumi:"ciliumRegistry"        validate:"default=quay.io/cilium"`
	CiliumVersion         pulumi.StringInput `pulumi:"ciliumVersion"         validate:"required"`
}

type NodeArgs struct {
	OSVersion    pulumi.StringInput `pulumi:"osVersion"`
	SubnetIDs    pulumi.StringArray `pulumi:"subnetIDs"`
	InstanceType pulumi.StringInput `pulumi:"instanceType" validate:"required"`
	Count        pulumi.Int         `pulumi:"count"        validate:"default=3"`
	Tags         pulumi.StringMap   `pulumi:"tags"`
}

func NewCluster(ctx *pulumi.Context, name string, args *ClusterInfraArgs, opts ...pulumi.ResourceOption) (*Cluster, error) {
	if err := args.validate(); err != nil {
		return nil, fmt.Errorf("could not validate AWS infra args, %w", err)
	}

	component := &Cluster{}

	if err := ctx.RegisterComponentResource(infrastructureComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", infrastructureComponentName, name, err)
	}

	if err := component.createSecurityGroups(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createLoadBalancer(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createControlPlaneNodes(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createWorkerNodes(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.configureCluster(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", infrastructureComponentName, name, err)
	}

	return component, nil
}

func (c *Cluster) createSecurityGroups(ctx *pulumi.Context, name string, args *ClusterInfraArgs) error {
	var securityGroupMap = make(pulumi.StringMap, 2)

	loadBalancerGroup, err := ec2.NewSecurityGroup(ctx, name+"-loadbalancer", &ec2.SecurityGroupArgs{
		Description: pulumi.String("Cluster Load Balancer security group"),
		VpcID:       args.VpcID,
		Tags:        utils.GenerateTags(args.Tags, name+"-loadbalancer"),
		Rules: map[string]*ec2.SecurityGroupRuleArgs{
			"ingress-k8s": {
				Description: pulumi.String("Allow K8s API inbound to load balancer"),
				Type:        pulumi.String("ingress"),
				FromPort:    pulumi.Int(443),
				ToPort:      pulumi.Int(443),
				Protocol:    pulumi.String("tcp"),
				CidrBlocks:  pulumi.StringArray{pulumi.String("0.0.0.0/0")},
			},
			"ingress-talos": {
				Description: pulumi.String("Allow Talos API inbound to load balancer"),
				Type:        pulumi.String("ingress"),
				FromPort:    pulumi.Int(50000),
				ToPort:      pulumi.Int(50000),
				Protocol:    pulumi.String("tcp"),
				CidrBlocks:  pulumi.StringArray{pulumi.String("0.0.0.0/0")},
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create cluster security group, %w", err)
	}

	securityGroupMap["loadBalancer"] = loadBalancerGroup.ID

	clusterGroup, err := ec2.NewSecurityGroup(ctx, name+"-cluster", &ec2.SecurityGroupArgs{
		Description: pulumi.String("Cluster security group"),
		VpcID:       args.VpcID,
		Tags:        utils.GenerateTags(args.Tags, name+"-cluster"),
		Rules: map[string]*ec2.SecurityGroupRuleArgs{
			"ingress-internal": {
				Description: pulumi.String("allow all traffic within the security group"),
				Type:        pulumi.String("ingress"),
				FromPort:    pulumi.Int(0),
				ToPort:      pulumi.Int(65535),
				Protocol:    pulumi.String("all"),
				Self:        pulumi.Bool(true),
			},
			"ingress-lb": {
				Description:           pulumi.String("allow inbound access to Kubernetes APIs from LB"),
				Type:                  pulumi.String("ingress"),
				FromPort:              pulumi.Int(6443),
				ToPort:                pulumi.Int(6443),
				Protocol:              pulumi.String("tcp"),
				SourceSecurityGroupID: loadBalancerGroup.ID,
			},
			"ingress-talos": {
				Description: pulumi.String("Allow inbound access to Talos APIs"),
				Type:        pulumi.String("ingress"),
				FromPort:    pulumi.Int(50000),
				ToPort:      pulumi.Int(50001),
				Protocol:    pulumi.String("tcp"),
				CidrBlocks:  pulumi.StringArray{pulumi.String("0.0.0.0/0")},
			},
			"egress-internet": {
				Description: pulumi.String("Allow all outbound traffic"),
				Type:        pulumi.String("egress"),
				FromPort:    pulumi.Int(0),
				ToPort:      pulumi.Int(65535),
				Protocol:    pulumi.String("all"),
				CidrBlocks:  pulumi.StringArray{pulumi.String("0.0.0.0/0")},
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create cluster network, %w", err)
	}

	_, err = awsEC2.NewSecurityGroupRule(ctx, "allowK8sApiLb", &awsEC2.SecurityGroupRuleArgs{
		Type:                  pulumi.String("egress"),
		FromPort:              pulumi.Int(6443),
		ToPort:                pulumi.Int(6443),
		Protocol:              pulumi.String("tcp"),
		SourceSecurityGroupId: clusterGroup.ID,
		SecurityGroupId:       loadBalancerGroup.ID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create k8s api lb rule, %w", err)
	}

	_, err = awsEC2.NewSecurityGroupRule(ctx, "allowTalosApiLb", &awsEC2.SecurityGroupRuleArgs{
		Type:                  pulumi.String("egress"),
		FromPort:              pulumi.Int(50000),
		ToPort:                pulumi.Int(50000),
		Protocol:              pulumi.String("tcp"),
		SourceSecurityGroupId: clusterGroup.ID,
		SecurityGroupId:       loadBalancerGroup.ID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create talos api lb rule, %w", err)
	}

	securityGroupMap["cluster"] = clusterGroup.ID

	c.SecurityGroupIDs = securityGroupMap

	return nil
}

func (c *Cluster) createLoadBalancer(ctx *pulumi.Context, name string, args *ClusterInfraArgs) error {
	loadBalancer, err := lb.NewLoadBalancer(ctx, name, &lb.LoadBalancerArgs{
		Internal:         pulumi.Bool(false),
		LoadBalancerType: pulumi.String("network"),
		Name:             pulumi.String(name),
		SecurityGroups:   pulumi.StringArray{c.SecurityGroupIDs["loadBalancer"]},
		Subnets:          args.SubnetIDs,
		Tags:             utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create load balancer %s, %w", name, err)
	}

	targetGroup, err := lb.NewTargetGroup(ctx, "k8s-api-tg", &lb.TargetGroupArgs{
		Port:       pulumi.Int(6443),
		Protocol:   pulumi.String("TCP"),
		Tags:       utils.GenerateTags(args.Tags, "k8s-api-tg"),
		TargetType: pulumi.String("ip"),
		VpcId:      args.VpcID,
	}, pulumi.Parent(c))

	if err != nil {
		return fmt.Errorf("unable to create load balancer target group %s, %w", name, err)
	}

	_, err = lb.NewListener(ctx, name+"-k8s", &lb.ListenerArgs{
		DefaultActions: lb.ListenerDefaultActionArray{
			&lb.ListenerDefaultActionArgs{
				TargetGroupArn: targetGroup.Arn,
				Type:           pulumi.String("forward"),
			},
		},
		LoadBalancerArn: loadBalancer.Arn,
		Port:            pulumi.Int(443),
		Protocol:        pulumi.String("TCP"),
		Tags:            utils.GenerateTags(args.Tags, name+"-k8s"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create k8s load balancer listener %s, %w", name, err)
	}

	talosTargetGroup, err := lb.NewTargetGroup(ctx, "talos-api-tg", &lb.TargetGroupArgs{
		Port:       pulumi.Int(50000),
		Protocol:   pulumi.String("TCP"),
		Tags:       utils.GenerateTags(args.Tags, "talos-api-tg"),
		TargetType: pulumi.String("ip"),
		VpcId:      args.VpcID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create load balancer talos api target group %s, %w", name, err)
	}

	_, err = lb.NewListener(ctx, name+"-talos", &lb.ListenerArgs{
		DefaultActions: lb.ListenerDefaultActionArray{
			&lb.ListenerDefaultActionArgs{
				TargetGroupArn: talosTargetGroup.Arn,
				Type:           pulumi.String("forward"),
			},
		},
		LoadBalancerArn: loadBalancer.Arn,
		Port:            pulumi.Int(50000),
		Protocol:        pulumi.String("TCP"),
		Tags:            utils.GenerateTags(args.Tags, name+"-talos"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create k8s load balancer talos api listener %s, %w", name, err)
	}

	c.LoadBalancerDNS = loadBalancer.DnsName
	c.TargetGroupARN = targetGroup.Arn
	c.TalosTargetGroupARN = talosTargetGroup.Arn

	return nil
}

func (c *Cluster) createControlPlaneNodes(ctx *pulumi.Context, name string, args *ClusterInfraArgs) error {
	nodes, err := c.createNodes(ctx, name+"-control", args.ControlPlane)
	if err != nil {
		return err
	}

	for idx, nodeIP := range nodes.NodeIPs {
		if _, err := lb.NewTargetGroupAttachment(ctx, fmt.Sprintf("%s-controlPlane-%d", name, idx), &lb.TargetGroupAttachmentArgs{
			TargetGroupArn: c.TargetGroupARN,
			TargetId:       nodeIP,
		}, pulumi.Parent(c)); err != nil {
			return fmt.Errorf("unable to attach instance %s, to targetgroup: %w", nodeIP, err)
		}

		if _, err := lb.NewTargetGroupAttachment(ctx, fmt.Sprintf("%s-talos-attachment-%d", name, idx), &lb.TargetGroupAttachmentArgs{
			TargetGroupArn: c.TalosTargetGroupARN,
			TargetId:       nodeIP,
		}, pulumi.Parent(c)); err != nil {
			return fmt.Errorf("unable to attach instance %s, to talos targetgroup: %w", nodeIP, err)
		}
	}

	c.ControlPlane = nodes

	return nil
}

func (c *Cluster) createWorkerNodes(ctx *pulumi.Context, name string, args *ClusterInfraArgs) error {
	nodes, err := c.createNodes(ctx, name+"-workers", args.Workers)
	if err != nil {
		return err
	}

	c.Workers = nodes

	return nil
}

func (c *Cluster) createNodes(ctx *pulumi.Context, name string, args *NodeArgs) (*talos.MachineArgs, error) {
	nodes := make(pulumi.StringArray, args.Count)
	nodeIPs := make(pulumi.StringArray, args.Count)
	nodePublicIPs := make(pulumi.StringArray, args.Count)

	region, err := awsSDK.GetRegion(ctx, nil, nil)

	if err != nil {
		return nil, fmt.Errorf("unable to get region, %w", err)
	}

	amiID, err := awsEC2.LookupAmi(ctx, &awsEC2.LookupAmiArgs{
		Filters: []awsEC2.GetAmiFilter{
			{
				Name:   "name",
				Values: []string{fmt.Sprintf("talos-%s-%s-amd64", args.OSVersion, region.Name)},
			},
		},
		Owners: []string{"540036508848"},
	}, pulumi.Parent(c))

	if err != nil {
		return nil, fmt.Errorf("unable to get ami ID, %w", err)
	}

	subnetLen := len(args.SubnetIDs)

	for index := range int(args.Count) {
		nodeName := fmt.Sprintf("%s-%03d", name, index)

		node, err := awsEC2.NewInstance(ctx, nodeName, &awsEC2.InstanceArgs{
			Ami:                      pulumi.String(amiID.Id),
			AssociatePublicIpAddress: pulumi.Bool(true),
			InstanceType:             args.InstanceType,
			SubnetId:                 args.SubnetIDs[index%subnetLen],
			Tags:                     utils.GenerateTags(args.Tags, nodeName),
			VpcSecurityGroupIds:      pulumi.StringArray{c.SecurityGroupIDs["cluster"]},
		}, pulumi.Parent(c))
		if err != nil {
			return nil, fmt.Errorf("unable to create control plane node %s, %w", nodeName, err)
		}

		nodes[index] = node.ID()
		nodeIPs[index] = node.PrivateIp
		nodePublicIPs[index] = node.PublicIp
	}

	nodesOutput := &talos.MachineArgs{
		PublicIPs: nodePublicIPs,
		NodeIPs:   nodeIPs,
		IDs:       nodes,
		OSVersion: args.OSVersion,
	}

	return nodesOutput, nil
}

func (c *Cluster) configureCluster(ctx *pulumi.Context, name string, args *ClusterInfraArgs) error {
	talosCluster, err := talos.NewCluster(ctx, name, &talos.ClusterArgs{
		ControlPlane:        c.ControlPlane,
		Workers:             c.Workers,
		LoadBalancerDNS:     c.LoadBalancerDNS,
		KubernetesVersion:   args.KubernetesVersion,
		ImagePullSecretName: args.ImagePullSecretName,
		CiliumRegistry:      args.CiliumRegistry,
		CiliumVersion:       args.CiliumVersion,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to configure %s talos cluster, %w", name, err)
	}

	c.Cluster = talosCluster

	return nil
}

func (args *ClusterInfraArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	if args.ControlPlane.OSVersion == nil {
		args.ControlPlane.OSVersion = args.OSVersion
	}

	if args.ControlPlane.SubnetIDs == nil {
		args.ControlPlane.SubnetIDs = args.SubnetIDs
	}

	if args.Workers.OSVersion == nil {
		args.Workers.OSVersion = args.OSVersion
	}

	if args.Workers.SubnetIDs == nil {
		args.Workers.SubnetIDs = args.SubnetIDs
	}

	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["customer"]; !ok {
		args.Tags["customer"] = args.Customer
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["complianceLevel"] = args.ComplianceLevel
	}

	if _, ok := args.Tags["environment"]; !ok {
		args.Tags["environment"] = args.Environment
	}

	args.ControlPlane.Tags = utils.CombineTags(args.Tags, args.Workers.Tags)
	args.Workers.Tags = utils.CombineTags(args.Tags, args.Workers.Tags)

	return nil
}

func (args *ClusterInfraArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (args *NodeArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
