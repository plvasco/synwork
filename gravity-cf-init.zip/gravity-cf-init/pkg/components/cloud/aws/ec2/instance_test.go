package ec2_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ec2"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const userData = pulumi.String(`#!/bin/bash
# Test Install
echo "Installing curl..."
sudo yum install -y curl`)

func TestNewInstance(t *testing.T) {
	t.Parallel()

	type want struct {
		ID               string
		SecurityGroupIDs []string
	}

	tests := []struct {
		name    string
		args    *ec2.InstanceArgs
		want    want
		focus   bool
		wantErr bool
	}{
		{
			name: "test should create ec2 instance in Subnet",
			args: &ec2.InstanceArgs{
				AmiID:        pulumi.String("ami-12345678"),
				SubnetID:     pulumi.String("subnet-1234"),
				UserData:     userData,
				InstanceType: pulumi.String("m5.xlarge"),
				SecutiryGroupArgs: map[string]*ec2.SecurityGroupArgs{
					"sg-test1": {
						Description: pulumi.String("testSG"),
						VpcID:       pulumi.String("vpc-123456789"),
						Tags:        nil,
						Rules: map[string]*ec2.SecurityGroupRuleArgs{
							"test": {
								CidrBlocks:            pulumi.ToStringArray([]string{"10.0.0.0/24"}),
								Description:           pulumi.String("x10d-rules"),
								FromPort:              pulumi.Int(80),
								Protocol:              pulumi.String("all"),
								SourceSecurityGroupID: pulumi.String("test-source-group-id"),
								ToPort:                pulumi.Int(80),
								Type:                  pulumi.String("ingress"),
							},
							"x10d-test": {
								CidrBlocks:            pulumi.ToStringArray([]string{"10.0.0.0/24"}),
								Description:           pulumi.String("x10d-rules"),
								FromPort:              pulumi.Int(80),
								Protocol:              pulumi.String("all"),
								SourceSecurityGroupID: pulumi.String("test-source-group-id"),
								ToPort:                pulumi.Int(80),
								Type:                  pulumi.String("ingress"),
							},
						},
					},
				},
				VpcID:           pulumi.String("vpc-12345678"),
				Tags:            pulumi.StringMap{},
				ComplianceLevel: pulumi.String("test"),
				Customer:        pulumi.String("test"),
				Environment:     pulumi.String("test"),
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "test should create ec2 instance in AZ",
			args: &ec2.InstanceArgs{
				AmiID:            pulumi.String("ami-12345678"),
				AvailabilityZone: pulumi.String("us-gov-east-1a"),
				UserData:         userData,
				InstanceType:     pulumi.String("m5.xlarge"),
				SecutiryGroupArgs: map[string]*ec2.SecurityGroupArgs{
					"sg-test1": {
						Description: pulumi.String("testSG"),
						VpcID:       pulumi.String("vpc-123456789"),
						Tags:        nil,
						Rules: map[string]*ec2.SecurityGroupRuleArgs{
							"test": {
								CidrBlocks:            pulumi.ToStringArray([]string{"10.0.0.0/24"}),
								Description:           pulumi.String("x10d-rules"),
								FromPort:              pulumi.Int(80),
								Protocol:              pulumi.String("all"),
								SourceSecurityGroupID: pulumi.String("test-source-group-id"),
								ToPort:                pulumi.Int(80),
								Type:                  pulumi.String("ingress"),
							},
						},
					},
				},
				VpcID:           pulumi.String("vpc-12345678"),
				Tags:            pulumi.StringMap{},
				ComplianceLevel: pulumi.String("test"),
				Customer:        pulumi.String("test"),
				Environment:     pulumi.String("test"),
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "test should create ec2 instance with a key",
			args: &ec2.InstanceArgs{
				AmiID:            pulumi.String("ami-12345678"),
				AvailabilityZone: pulumi.String("us-gov-east-1a"),
				UserData:         userData,
				CreateKeyPair:    pulumi.Bool(true),
				InstanceType:     pulumi.String("m5.xlarge"),
				SecutiryGroupArgs: map[string]*ec2.SecurityGroupArgs{
					"sg-test1": {
						Description: pulumi.String("testSG"),
						VpcID:       pulumi.String("vpc-123456789"),
						Tags:        nil,
						Rules: map[string]*ec2.SecurityGroupRuleArgs{
							"test": {
								CidrBlocks:            pulumi.ToStringArray([]string{"10.0.0.0/24"}),
								Description:           pulumi.String("x10d-rules"),
								FromPort:              pulumi.Int(80),
								Protocol:              pulumi.String("all"),
								SourceSecurityGroupID: pulumi.String("test-source-group-id"),
								ToPort:                pulumi.Int(80),
								Type:                  pulumi.String("ingress"),
							},
						},
					},
				},
				VpcID:           pulumi.String("vpc-12345678"),
				Tags:            pulumi.StringMap{},
				ComplianceLevel: pulumi.String("test"),
				Customer:        pulumi.String("test"),
				Environment:     pulumi.String("test"),
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "test should fail creating instance because missing required arg",
			args: &ec2.InstanceArgs{
				AmiID:           nil,
				ComplianceLevel: pulumi.String("test"),
				Customer:        pulumi.String("test"),
				Environment:     pulumi.String("test"),
			},
			want:    want{},
			wantErr: true,
		},
	}

	focused := false

	for _, tc := range tests {
		if tc.focus {
			focused = true

			break
		}
	}

	for _, tt := range tests {
		if focused && !tt.focus {
			continue
		}

		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := ec2.NewInstance(ctx, "test", tt.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.ID.ApplyT(func(id string) string {
					assert.Equal(t, "test_id", id)

					return id
				})

				if tt.args.CreateKeyPair == pulumi.Bool(true) {
					got.PrivateKey.ApplyT(func(key string) string {
						assert.Equal(t, "testPrivKey", key)

						return key
					})
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}

	if focused {
		t.Fatalf("testcase(s) still focused")
	}
}
func TestInstanceArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *ec2.InstanceArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"amiID": "ami-12345",
				"availabilityZone": "us-east-1a",
				"subnetID": "subnet-67890",
				"userData": "echo 'Hello, World!'",
				"instanceType": "t2.micro",
				"usePublicSubnet": true,
				"secutiryGroupArgs": {
					"web": {
						"description": "Web Security Group",
						"vpcID": "vpc-12345",
						"tags": {"env": "production"},
						"rules": {}
					}
				},
				"tags": {"env": "production"},
				"complianceLevel": "high",
				"customer": "customer-abc",
				"environment": "prod",
				"vpcID": "vpc-12345",
				"createKeyPair": false
			}`,
			want: &ec2.InstanceArgs{
				AmiID:            pulumi.String("ami-12345"),
				AvailabilityZone: pulumi.String("us-east-1a"),
				SubnetID:         pulumi.String("subnet-67890"),
				UserData:         pulumi.String("echo 'Hello, World!'"),
				InstanceType:     pulumi.String("t2.micro"),
				UsePublicSubnet:  pulumi.Bool(true),
				SecutiryGroupArgs: map[string]*ec2.SecurityGroupArgs{
					"web": {
						Description: pulumi.String("Web Security Group"),
						VpcID:       pulumi.String("vpc-12345"),
						Tags:        pulumi.StringMap{"env": pulumi.String("production")},
						Rules:       map[string]*ec2.SecurityGroupRuleArgs{},
					},
				},
				Tags:            pulumi.StringMap{"env": pulumi.String("production")},
				ComplianceLevel: pulumi.String("high"),
				Customer:        pulumi.String("customer-abc"),
				Environment:     pulumi.String("prod"),
				VpcID:           pulumi.String("vpc-12345"),
				CreateKeyPair:   pulumi.Bool(false),
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"amiID": "ami-12345", "instanceType": "t2.micro", "usePublicSubnet": "true"}`, // usePublicSubnet should be boolean
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"amiID": "ami-12345", "instanceType": "t2.micro", "tags": {"env": "production"}`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args ec2.InstanceArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
