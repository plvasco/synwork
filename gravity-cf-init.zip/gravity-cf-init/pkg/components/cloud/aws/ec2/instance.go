package ec2

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi-tls/sdk/v4/go/tls"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const instanceComponentName = "gravity:ec2:instance"

var (
	ErrRequiredArgumentAzorSubnetID = errors.New("required to set `AvailabilityZone` or `SubnetID`")
)

type Instance struct {
	pulumi.ResourceState
	SecurityGroupIDs pulumi.StringArray  `pulumi:"securityGroupIDs"`
	PrivateKey       pulumi.StringOutput `pulumi:"privateKey"`
	ID               pulumi.IDOutput     `pulumi:"id"`
}

type InstanceArgs struct {
	AmiID             pulumi.StringInput            `pulumi:"amiID"             validate:"required"`
	AvailabilityZone  pulumi.StringInput            `pulumi:"availabilityZone"`
	SubnetID          pulumi.StringInput            `pulumi:"subnetID"`
	UserData          pulumi.StringInput            `pulumi:"userData"`
	InstanceType      pulumi.StringInput            `pulumi:"instanceType"      validate:"required"`
	UsePublicSubnet   pulumi.BoolInput              `pulumi:"usePublicSubnet"   validate:"default=false"`
	SecutiryGroupArgs map[string]*SecurityGroupArgs `pulumi:"secutiryGroupArgs"`
	Tags              pulumi.StringMap              `pulumi:"tags"`
	ComplianceLevel   pulumi.StringInput            `pulumi:"complianceLevel"`
	Customer          pulumi.StringInput            `pulumi:"customer"`
	Environment       pulumi.StringInput            `pulumi:"environment"`
	VpcID             pulumi.StringInput            `pulumi:"vpcID"`
	CreateKeyPair     pulumi.BoolInput              `pulumi:"createKeyPair"     validate:"default=false"`
}

func NewInstance(ctx *pulumi.Context, name string, args *InstanceArgs, opts ...pulumi.ResourceOption) (*Instance, error) {
	component := &Instance{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(instanceComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", instanceComponentName, name, err)
	}

	if err := component.createSecurityGroups(ctx, args); err != nil {
		return nil, err
	}

	if err := component.createInstance(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", instanceComponentName, name, err)
	}

	return component, nil
}

func (c *Instance) createSecurityGroups(ctx *pulumi.Context, args *InstanceArgs) error {
	for secGrpName, secGrpCfg := range args.SecutiryGroupArgs {
		secGrpCfg.Tags = args.Tags
		secGrpCfg.VpcID = args.VpcID
		secGrp, err := NewSecurityGroup(ctx, secGrpName, secGrpCfg, pulumi.Parent(c))

		if err != nil {
			return fmt.Errorf("unable to create security group %s, %w", secGrpName, err)
		}

		c.SecurityGroupIDs = append(c.SecurityGroupIDs, secGrp.ID)
	}

	return nil
}

func (c *Instance) createInstance(ctx *pulumi.Context, name string, args *InstanceArgs) error {
	if args.SubnetID == nil {
		subnetID, err := networking.GetSubnetByAZ(ctx, &networking.GetSubnetByAZArgs{
			AvailabilityZone: args.AvailabilityZone,
			UsePublicSubnet:  args.UsePublicSubnet,
			VpcID:            args.VpcID,
		})
		if err != nil {
			return fmt.Errorf("unable to get defined AZs subnetId `%s`, %w", name, err)
		}

		args.SubnetID = subnetID
	}

	instanceArgs := &ec2.InstanceArgs{
		Ami:                      args.AmiID,
		AssociatePublicIpAddress: pulumi.Bool(false),
		InstanceType:             args.InstanceType,
		SubnetId:                 args.SubnetID,
		Tags:                     args.Tags,
		UserData:                 args.UserData,
		VpcSecurityGroupIds:      c.SecurityGroupIDs,
	}

	if args.CreateKeyPair == pulumi.Bool(true) {
		// Generate a new private key
		privateKey, err := tls.NewPrivateKey(ctx, "keyPairPrivateKey", &tls.PrivateKeyArgs{
			Algorithm: pulumi.String("RSA"),
			RsaBits:   pulumi.Int(4096),
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create instance tls keys, %w", err)
		}

		// Create an EC2 Key Pair
		keyPair, err := ec2.NewKeyPair(ctx, name+"-instanceKeyPair", &ec2.KeyPairArgs{
			PublicKey: privateKey.PublicKeyOpenssh,
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create ec2 keyPair, %w", err)
		}

		ctx.Export(name+"_PrivKeyPem", privateKey.PrivateKeyPem)
		c.PrivateKey = privateKey.PrivateKeyPem
		instanceArgs.KeyName = keyPair.KeyName
	}

	instance, err := ec2.NewInstance(ctx, name, instanceArgs, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create ec2 instance, %w", err)
	}

	ctx.Export(name+"_IP", instance.PrivateIp)
	c.ID = instance.ID()

	return nil
}

func (args *InstanceArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	if args.AvailabilityZone == nil && args.SubnetID == nil {
		return ErrRequiredArgumentAzorSubnetID
	}

	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["customer"]; !ok {
		args.Tags["customer"] = args.Customer
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["complianceLevel"] = args.ComplianceLevel
	}

	if _, ok := args.Tags["environment"]; !ok {
		args.Tags["environment"] = args.Environment
	}

	return nil
}

func (args *InstanceArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
