package ec2

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const securityGroupComponentName = "gravity:aws:securitygroup"

type SecurityGroup struct {
	pulumi.ResourceState
	ID pulumi.IDOutput
}

type SecurityGroupArgs struct {
	Description pulumi.StringInput                `pulumi:"description"`
	VpcID       pulumi.StringInput                `pulumi:"vpcID"       validate:"required"`
	Tags        pulumi.StringMap                  `pulumi:"tags"`
	Rules       map[string]*SecurityGroupRuleArgs `pulumi:"rules"`
}

type SecurityGroupRuleArgs struct {
	// List of CIDR blocks. Cannot be specified with `sourceSecurityGroupId` or `self`.
	CidrBlocks pulumi.StringArray `pulumi:"cidrBlocks"`
	// Description of the rule.
	Description pulumi.StringPtrInput `pulumi:"description"`
	// Start port (or ICMP type number if protocol is "icmp" or "icmpv6").
	FromPort pulumi.IntInput `pulumi:"fromPort"`
	// Protocol. If not icmp, icmpv6, tcp, udp, or all use the [protocol number](https://www.iana.org/assignments/protocol-numbers/protocol-numbers.xhtml)
	Protocol pulumi.StringInput `pulumi:"protocol"`
	// Whether the security group itself will be added as a source to this ingress rule. Cannot be specified with `cidrBlocks`, `ipv6CidrBlocks`, or `sourceSecurityGroupId`.
	Self pulumi.BoolPtrInput `pulumi:"self"`
	// Security group id to allow access to/from, depending on the `type`. Cannot be specified with `cidrBlocks`, `ipv6CidrBlocks`, or `self`.
	SourceSecurityGroupID pulumi.StringPtrInput `pulumi:"sourceSecurityGroupID"`
	// End port (or ICMP code if protocol is "icmp").
	ToPort pulumi.IntInput `pulumi:"toPort"`
	// Type of rule being created. Valid options are `ingress` (inbound)
	// or `egress` (outbound).
	Type pulumi.StringInput `pulumi:"type"`
}

func NewSecurityGroup(ctx *pulumi.Context, name string, args *SecurityGroupArgs, opts ...pulumi.ResourceOption) (*SecurityGroup, error) {
	component := &SecurityGroup{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(securityGroupComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", securityGroupComponentName, name, err)
	}

	if err := component.createSecurityGroup(ctx, name+"-sg", args); err != nil {
		return nil, err
	}

	if err := component.createSecurityGroupRules(ctx, name+"-sg-rule", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", securityGroupComponentName, name, err)
	}

	return component, nil
}

// createSecurityGroup creates a network security group from port, ingress, and egress args from ###.
func (c *SecurityGroup) createSecurityGroup(ctx *pulumi.Context, name string, args *SecurityGroupArgs) error {
	securityGroup, err := ec2.NewSecurityGroup(ctx, name, &ec2.SecurityGroupArgs{
		Description: args.Description,
		Tags:        utils.GenerateTags(args.Tags, name),
		VpcId:       args.VpcID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create security group %s, %w", name, err)
	}

	c.ID = securityGroup.ID()

	return nil
}

func (c *SecurityGroup) createSecurityGroupRules(ctx *pulumi.Context, name string, args *SecurityGroupArgs) error {
	for ruleName, rule := range args.Rules {
		if _, err := ec2.NewSecurityGroupRule(ctx, name+"-"+ruleName, &ec2.SecurityGroupRuleArgs{
			FromPort:              rule.FromPort,
			ToPort:                rule.ToPort,
			Protocol:              rule.Protocol,
			SecurityGroupId:       c.ID,
			CidrBlocks:            rule.CidrBlocks,
			Self:                  rule.Self,
			SourceSecurityGroupId: rule.SourceSecurityGroupID,
			Type:                  rule.Type,
			Description:           rule.Description,
		}, pulumi.Parent(c), pulumi.DeleteBeforeReplace(true)); err != nil {
			return fmt.Errorf("unable to create securityGroupRule %s, %w", name, err)
		}
	}

	return nil
}

func (args *SecurityGroupArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *SecurityGroupArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (args *SecurityGroupRuleArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
