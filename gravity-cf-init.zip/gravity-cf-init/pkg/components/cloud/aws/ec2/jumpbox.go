package ec2

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi-command/sdk/go/command/remote"
	"github.com/pulumi/pulumi-tls/sdk/v4/go/tls"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const jumpboxComponentName = "gravity:ec2:jumpbox"

//nolint:dupword // It is correct
const userData = pulumi.String(`#!/bin/bash
# Install kubectl
echo "Installing kubectl..."
sudo yum install -y curl
curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl
chmod +x ./kubectl
sudo mv ./kubectl /usr/local/bin/kubectl
kubectl version --client
echo "kubectl installed successfully."

echo "Adding alias for kubectl to k in /home/ec2-user/.bashrc..."
echo "alias k='kubectl'" >> /home/ec2-user/.bashrc
echo "Alias added successfully."

# Install Helm
echo "Installing Helm..."
sudo yum install -y tar gzip
curl -LO https://get.helm.sh/helm-v3.8.0-linux-amd64.tar.gz
tar -zxvf helm-v3.8.0-linux-amd64.tar.gz
sudo mv linux-amd64/helm /usr/local/bin/helm
echo "Helm installed successfully."

# Install k9s
su ec2-user -c "curl -sS https://webinstall.dev/k9s | bash"

su ec2-user -c "source ~/.config/envman/PATH.env"

echo "Tool Installation completed."`)

type Jumpbox struct {
	pulumi.ResourceState
	SecurityGroup *ec2.SecurityGroup  `pulumi:"securityGroup"`
	InstanceID    pulumi.IDOutput     `pulumi:"instanceID"`
	PublicIP      pulumi.StringOutput `pulumi:"publicIP"`
	PrivateKey    pulumi.StringOutput `pulumi:"privateKey"`
}

type JumpboxArgs struct {
	VpcID      pulumi.StringInput `pulumi:"vpcID"      validate:"required"`
	SubnetID   pulumi.StringInput `pulumi:"subnetID"   validate:"required"`
	KubeConfig pulumi.StringInput `pulumi:"kubeconfig" validate:"required"`
}

func NewJumpbox(ctx *pulumi.Context, name string, args *JumpboxArgs, opts ...pulumi.ResourceOption) (*Jumpbox, error) {
	component := &Jumpbox{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(jumpboxComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", jumpboxComponentName, name, err)
	}

	if err := component.createSecurityGroups(ctx, name+"-securityGroups", args); err != nil {
		return nil, err
	}

	if err := component.createInstance(ctx, name+"-instance", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"publicIP":   component.PublicIP,
		"privateKey": component.PrivateKey,
		"InstanceID": component.InstanceID,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", jumpboxComponentName, name, err)
	}

	ctx.Export("privateKeyPem", component.PrivateKey)

	ctx.Export("instancePublicIp", component.PublicIP)

	return component, nil
}

func (c *Jumpbox) createSecurityGroups(ctx *pulumi.Context, name string, args *JumpboxArgs) error {
	// Create security groups
	instanceSG, err := ec2.NewSecurityGroup(ctx, name+"jumpBoxSg", &ec2.SecurityGroupArgs{
		VpcId: args.VpcID,
		Egress: ec2.SecurityGroupEgressArray{
			&ec2.SecurityGroupEgressArgs{
				CidrBlocks: pulumi.StringArray{pulumi.String("0.0.0.0/0")},
				FromPort:   pulumi.Int(0),
				Protocol:   pulumi.String("-1"),
				ToPort:     pulumi.Int(0),
			},
		},
		Ingress: ec2.SecurityGroupIngressArray{
			&ec2.SecurityGroupIngressArgs{
				Protocol:   pulumi.String("tcp"),
				FromPort:   pulumi.Int(22),
				ToPort:     pulumi.Int(22),
				CidrBlocks: pulumi.StringArray{pulumi.String("0.0.0.0/0")},
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create jumpBox security group, %w", err)
	}

	c.SecurityGroup = instanceSG

	return nil
}

func (c *Jumpbox) createInstance(ctx *pulumi.Context, name string, args *JumpboxArgs) error {
	// Generate a new private key
	privateKey, err := tls.NewPrivateKey(ctx, "keyPairPrivateKey", &tls.PrivateKeyArgs{
		Algorithm: pulumi.String("RSA"),
		RsaBits:   pulumi.Int(4096),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create jumpBox tls keys, %w", err)
	}

	// Create an EC2 Key Pair
	keyPair, err := ec2.NewKeyPair(ctx, name+"-jumpBoxKeyPair", &ec2.KeyPairArgs{
		PublicKey: privateKey.PublicKeyOpenssh,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create ec2 keyPair, %w", err)
	}

	latestAmi, err := ec2.LookupAmi(ctx, &ec2.LookupAmiArgs{
		Owners: []string{"amazon"},
		Filters: []ec2.GetAmiFilter{
			{
				Name:   "name",
				Values: []string{"amzn2-ami-hvm-*-x86_64-gp2"},
			},
			{
				Name:   "state",
				Values: []string{"available"},
			},
		},
		MostRecent: pulumi.BoolRef(true),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to get latest ami, %w", err)
	}

	// Create an EC2 instance
	instance, err := ec2.NewInstance(ctx, name+"jumpbox", &ec2.InstanceArgs{
		AssociatePublicIpAddress: pulumi.Bool(true),
		Ami:                      pulumi.String(latestAmi.Id),
		InstanceType:             pulumi.String("t2.micro"),
		KeyName:                  keyPair.KeyName,
		UserData:                 userData,
		SubnetId:                 args.SubnetID,
		VpcSecurityGroupIds: pulumi.StringArray{
			c.SecurityGroup.ID(),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create jumpBox, %w", err)
	}

	// Command to be executed on the remote instance
	commandStr := pulumi.Sprintf(`
		mkdir -p ~/.kube
		echo "%s" > /home/ec2-user/.kube/config
		chmod 600 /home/ec2-user/.kube/config
		chown ec2-user:ec2-user /home/ec2-user/.kube/config
	`, args.KubeConfig)

	// Define SSH connection information
	connection := &remote.ConnectionArgs{
		Host:       instance.PublicIp,
		User:       pulumi.String("ec2-user"),
		PrivateKey: privateKey.PrivateKeyPem,
	}

	// Wait until the instance is reachable by running a remote command
	_, err = remote.NewCommand(ctx, name+"-copy-k8scfg", &remote.CommandArgs{
		Connection: connection,
		Create:     commandStr.ToStringPtrOutput(),
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{instance}))
	if err != nil {
		return fmt.Errorf("unable to copy k8s config to jumpbox, %w", err)
	}

	c.PrivateKey = privateKey.PrivateKeyPem
	c.PublicIP = instance.PublicIp
	c.InstanceID = instance.ID()

	return nil
}

func (args *JumpboxArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *JumpboxArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
