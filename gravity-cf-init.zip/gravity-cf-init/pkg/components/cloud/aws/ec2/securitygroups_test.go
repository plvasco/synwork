package ec2_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ec2"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewSecurityGroup(t *testing.T) {
	t.Parallel()

	type want struct{}

	type args struct {
		name string
		args *ec2.SecurityGroupArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create Security Group",
			in: args{
				name: "test-org-cluster",
				args: &ec2.SecurityGroupArgs{
					Description: pulumi.String("test-description"),
					VpcID:       pulumi.String("test-vpc"),
					Tags:        pulumi.ToStringMap(map[string]string{"organization": "test"}),
					Rules: map[string]*ec2.SecurityGroupRuleArgs{
						"test": {
							FromPort:              pulumi.Int(80),
							Protocol:              pulumi.String("all"),
							SourceSecurityGroupID: pulumi.String("test-source-group-id"),
							ToPort:                pulumi.Int(80),
							Type:                  pulumi.String("ingress"),
						},
					}},
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "should error with no VPCID",
			in: args{
				name: "test-org-cluster",
				args: &ec2.SecurityGroupArgs{
					Description: pulumi.String("test-description"),
					Tags:        pulumi.ToStringMap(map[string]string{"organization": "test"}),
					Rules: map[string]*ec2.SecurityGroupRuleArgs{
						"test": {
							FromPort:              pulumi.Int(80),
							Protocol:              pulumi.String("all"),
							SourceSecurityGroupID: pulumi.String("test-source-group-id"),
							ToPort:                pulumi.Int(80),
							Type:                  pulumi.String("ingress"),
						},
					}},
			},
			want:    want{},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := ec2.NewSecurityGroup(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				securityGroupID := got.ID.ApplyT(func(securityGroupID pulumi.ID) pulumi.ID {
					assert.Equal(t, pulumi.ID(tt.in.name+"-sg_id"), securityGroupID)

					return securityGroupID
				})
				require.NotNil(t, securityGroupID)

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestSecurityGroupArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *ec2.SecurityGroupArgs
		wantErr bool
	}{
		{
			name:  "valid input",
			input: `{"description": "Test SG", "vpcID": "vpc-12345", "tags": {"env": "test"}, "rules": {}}`,
			want: &ec2.SecurityGroupArgs{
				Description: pulumi.String("Test SG"),
				VpcID:       pulumi.String("vpc-12345"),
				Tags:        pulumi.StringMap{"env": pulumi.String("test")},
				Rules:       map[string]*ec2.SecurityGroupRuleArgs{},
			},
			wantErr: false,
		},
		{
			name:    "invalid input",
			input:   `{"description": ["test"], "tags": {"env": "test"}}`, //wrong type
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"description": "Test SG", "vpcID": vpc-12345"]`, // Malformed JSON
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args ec2.SecurityGroupArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)
			assert.Equal(t, tc.want.Description, args.Description)
			assert.Equal(t, tc.want.VpcID, args.VpcID)
			assert.Equal(t, tc.want.Tags, args.Tags)
			assert.Equal(t, tc.want.Rules, args.Rules)
		})
	}
}

func TestSecurityGroupRuleArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *ec2.SecurityGroupRuleArgs
		wantErr bool
	}{
		{
			name:  "valid input",
			input: `{"cidrBlocks": ["10.0.0.0/16"], "fromPort": 80, "toPort": 80, "protocol": "tcp", "type": "ingress"}`,
			want: &ec2.SecurityGroupRuleArgs{
				CidrBlocks: pulumi.StringArray{pulumi.String("10.0.0.0/16")},
				FromPort:   pulumi.Int(80),
				ToPort:     pulumi.Int(80),
				Protocol:   pulumi.String("tcp"),
				Type:       pulumi.String("ingress"),
			},
			wantErr: false,
		},
		{
			name:    "invalid input",
			input:   `{"cidrBlocks": "10.0.0.0/16", "fromPort": 80, "protocol": "tcp"}`,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"cidrBlocks": ["10.0.0.0/16, "fromPort": 80, "toPort": 80`, // Malformed JSON
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args ec2.SecurityGroupRuleArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
