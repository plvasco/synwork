package ec2_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ec2"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewJumpbox(t *testing.T) {
	t.Parallel()

	type want struct {
		ID              string
		SecurityGroupID string
		PrivKey         string
	}

	tests := []struct {
		name    string
		args    *ec2.JumpboxArgs
		want    want
		wantErr bool
	}{
		{
			name: "jump box test",
			args: &ec2.JumpboxArgs{
				VpcID:      pulumi.String("vpc-123456789"),
				SubnetID:   pulumi.String("subnet-1234"),
				KubeConfig: pulumi.String("testk8sconf"),
			},
			want: want{
				ID:              "test-instancejumpbox_id",
				SecurityGroupID: "test-securityGroupsjumpBoxSg_id",
				PrivKey:         "testPrivKey",
			},
			wantErr: false,
		},
		{
			name: "should fail if vpc is not provided",
			args: &ec2.JumpboxArgs{
				SubnetID:   pulumi.String("subnet-1234"),
				KubeConfig: pulumi.String("testk8sconf"),
			},
			wantErr: true,
		},
		{
			name: "should fail if subnetID is not provided",
			args: &ec2.JumpboxArgs{
				VpcID:      pulumi.String("vpc-123456789"),
				KubeConfig: pulumi.String("testk8sconf"),
			},
			wantErr: true,
		},
		{
			name: "should fail if KubeConfig is not provided",
			args: &ec2.JumpboxArgs{
				VpcID:    pulumi.String("vpc-123456789"),
				SubnetID: pulumi.String("subnet-1234"),
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := ec2.NewJumpbox(ctx, "test", tt.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.InstanceID.ApplyT(func(id string) string {
					assert.Equal(t, tt.want.ID, id)

					return id
				})

				got.PrivateKey.ApplyT(func(pKey string) string {
					assert.Equal(t, tt.want.PrivKey, pKey)

					return pKey
				})

				got.SecurityGroup.ID().ApplyT(func(sgID string) string {
					assert.Equal(t, tt.want.SecurityGroupID, sgID)

					return sgID
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestJumpboxArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *ec2.JumpboxArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"vpcID": "vpc-12345",
				"subnetID": "subnet-67890",
				"kubeconfig": "my-kubeconfig"
			}`,
			want: &ec2.JumpboxArgs{
				VpcID:      pulumi.String("vpc-12345"),
				SubnetID:   pulumi.String("subnet-67890"),
				KubeConfig: pulumi.String("my-kubeconfig"),
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"vpcID": 12345, "subnetID": "subnet-67890", "kubeconfig": "my-kubeconfig"}`, // vpcID is wrong type
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"vpcID": "vpc-12345", "subnetID": "subnet-67890", "kubeconfig": "my-kubeconfig"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args ec2.JumpboxArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
