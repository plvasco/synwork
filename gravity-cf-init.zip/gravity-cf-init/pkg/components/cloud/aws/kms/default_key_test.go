package kms_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/kms"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

func TestNewdefaultKms(t *testing.T) {
	t.Parallel()

	type want struct {
		Alias              string
		DecryptionPolicyID string
	}

	type args struct {
		ctx  *pulumi.Context
		name string
		args *kms.DefaultKmsArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{name: "Test should create default key", in: args{
			ctx:  &pulumi.Context{},
			name: "defaultKey",
			args: &kms.DefaultKmsArgs{},
		}, want: want{
			Alias:              "alias/encryption-key",
			DecryptionPolicyID: "test-policy-id",
		}, wantErr: false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := kms.NewDefaultKms(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				got.Alias.ApplyT(func(alias string) bool {
					assert.Contains(t, tt.want.Alias, alias)

					return true
				})

				got.DecryptionPolicyID.ApplyT(func(id string) bool {
					assert.Equal(t, tt.want.DecryptionPolicyID, id)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
