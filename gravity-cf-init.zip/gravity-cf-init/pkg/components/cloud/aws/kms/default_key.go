package kms

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ebs"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/iam"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/kms"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const defaultKeyComponentName = "gravity:aws:kms:defaultKey"

type DefaultKms struct {
	pulumi.ResourceState
	Alias              pulumi.StringOutput `pulumi:"alias"`
	DefaultKey         *kms.Key            `pulumi:"defaultKey"`
	DecryptionPolicyID pulumi.StringOutput `pulumi:"policy"`
}

type DefaultKmsArgs struct {
	Tags pulumi.StringMap `pulumi:"tags"`
}

func NewDefaultKms(ctx *pulumi.Context, name string, args *DefaultKmsArgs, opts ...pulumi.ResourceOption) (*DefaultKms, error) {
	component := &DefaultKms{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(defaultKeyComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", defaultKeyComponentName, name, err)
	}

	if err := component.createDefaultKey(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createDefaultKeyDecryptionPolicy(ctx, name+"-decryption-policy", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", defaultKeyComponentName, name, err)
	}

	return component, nil
}

func (c *DefaultKms) createDefaultKey(ctx *pulumi.Context, name string, args *DefaultKmsArgs) error {
	key, err := kms.NewKey(ctx, name, &kms.KeyArgs{
		Description:       pulumi.String("KMS key for encrypting configuration repository, rds, eks, ebs, and efs configs"),
		EnableKeyRotation: pulumi.Bool(true),
		Policy:            c.generateKeyPolicyDocument(ctx),
		Tags:              utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create default KMS key, %w", err)
	}

	_, err = ebs.NewDefaultKmsKey(ctx, name, &ebs.DefaultKmsKeyArgs{
		KeyArn: key.Arn,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to set new default KMS Key, %w", err)
	}

	alias, err := kms.NewAlias(ctx, "encryption-key", &kms.AliasArgs{
		Name:        pulumi.String("alias/encryption-key"),
		TargetKeyId: key.KeyId,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to alias default KMS key, %w", err)
	}

	c.Alias = alias.Name
	c.DefaultKey = key

	return nil
}

func (c *DefaultKms) createDefaultKeyDecryptionPolicy(ctx *pulumi.Context, name string, args *DefaultKmsArgs) error {
	decryptionStatement := iam.GetPolicyDocumentStatementArgs{
		Actions: pulumi.ToStringArray([]string{
			"kms:Encrypt",
			"kms:Decrypt",
			"kms:ReEncrypt*",
			"kms:GenerateDataKey*",
			"kms:DescribeKey",
		}),
		Resources: pulumi.StringArray{c.DefaultKey.Arn},
	}

	policyDocArgs := iam.GetPolicyDocumentOutputArgs{
		Statements: iam.GetPolicyDocumentStatementArray{decryptionStatement},
	}

	document := iam.GetPolicyDocumentOutput(ctx, policyDocArgs)

	policy, err := iam.NewPolicy(ctx, name, &iam.PolicyArgs{
		Description: pulumi.String("Policy to allow decryption from the account's kms key"),
		Name:        pulumi.String("kmsDecryptionPolicy"),
		Policy:      document,
		Tags:        utils.GenerateTags(args.Tags, name),
	})
	if err != nil {
		return fmt.Errorf("unable to create default kms decryption policy, %w", err)
	}

	c.DecryptionPolicyID = policy.PolicyId

	return nil
}

func (c *DefaultKms) generateKeyPolicyDocument(ctx *pulumi.Context) pulumi.StringOutput {
	result := aws.GetCallerIdentityOutput(ctx, aws.GetCallerIdentityOutputArgs{}, pulumi.Parent(c))

	currentRegion := aws.GetRegionOutput(ctx, aws.GetRegionOutputArgs{}, pulumi.Parent(c))

	partitionResult := aws.GetPartitionOutput(ctx, aws.GetPartitionOutputArgs{}, pulumi.Parent(c))

	partition := partitionResult.Partition()

	policy := pulumi.Sprintf(`
	{
		"Version":"2012-10-17",
		"Id":"key-default-1",
		"Statement":
			[
				{
					"Sid": "EnableIAMUserPermissions",
					"Effect": "Allow",
					"Principal":"*",
					"Action":"kms:*",
					"Resource": "*",
					"Condition":
						{
							"ArnEquals":
								{
									"aws:PrincipalArn": "arn:%s:iam::%s:role/*"
								}
						}
				},
				{
					"Sid": "EnableIAMUserPermissions",
					"Effect": "Allow",
					"Principal": "*",
					"Action": "kms:*",
					"Resource": "*",
					"Condition":
						{
							"ArnEquals":
								{
									"aws:PrincipalArn": "arn:%s:iam::%s:user/*"
								}
						}
				},
				{
					"Sid": "AllowAmazonInspectorPermission",
					"Effect": "Allow",
					"Principal":
						{
							"Service": "inspector2.amazonaws.com"
						},
					"Action": "kms:*",
					"Resource": "*",
					"Condition":
						{
							"StringEquals":
								{
									"aws:SourceAccount": "%s"
								},
							"ArnLike":
								{
									"aws:SourceArn": "arn:%s:inspector2:%s:%s:report/*"
								}
						}
				}
			]
	}`, partition, result.AccountId, partition, result.AccountId, result.AccountId, partition, currentRegion.Name, result.AccountId)

	return policy
}

func (args *DefaultKmsArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}
