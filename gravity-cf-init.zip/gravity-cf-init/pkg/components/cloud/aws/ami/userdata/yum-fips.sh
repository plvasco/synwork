#!/bin/bash
yum versionlock clear
yum upgrade kernel kernel-devel kernel-headers -y
yum install -y openscap-scanner scap-security-guide
yum update -y
fips_status=$(sudo sysctl crypto.fips_enabled | awk '{print $3}')
if [ "$fips_status" -eq 0 ]; then
echo -e "\tFIPS is not enabled in kernel (fips=1)\n"
# Install FIPS packages
    yum install -y dracut-fips
    # Regenerate initramfs with FIPS
    dracut -f
    /sbin/grubby --update-kernel=ALL --args="fips=1"
else
    echo -e "\tFIPS is enabled in kernel (fips=1)\n"
fi
