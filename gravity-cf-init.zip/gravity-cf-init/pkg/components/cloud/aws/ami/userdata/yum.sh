#!/bin/bash
yum versionlock clear
yum upgrade kernel kernel-devel kernel-headers -y
yum install -y openscap-scanner scap-security-guide
yum update -y
