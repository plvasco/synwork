package ami

import (
	"embed"
	"errors"
	"fmt"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/kms"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/organizations"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const amiComponentName = "gravity:aws:ami"

type AMI struct {
	pulumi.ResourceState
	// Security group of intsance for AMI creation.
	SecurityGroupID pulumi.StringOutput `pulumi:"securityGroupID"`
	// VPC ID for AMI Creation.
	VpcID pulumi.IDOutput `pulumi:"vpcID"`
	// InstanceID for AMI Creation.
	InstanceID pulumi.StringOutput `pulumi:"instanceID"`
	// Name of AMI.
	Name pulumi.StringOutput `pulumi:"name"`
	// Subnet ID for AMI creation.
	SubnetID pulumi.StringOutput `pulumi:"subnetID"`
	// ID of created AMI.
	ID pulumi.StringOutput `pulumi:"id"`
}

//nolint:revive //Aligning with standards
type AMIArgs struct {
	AvailabilityZone pulumi.String `pulumi:"availabilityZone"`
	// Set to true to disable FIPS on new AMI. Defaults to `false` if not set.
	DisableFIPS pulumi.Bool `pulumi:"disableFIPS"`
	// Defines additional AWS Regions to copy AMI to.
	Copy *Copy `pulumi:"copy"`
	// Instance type to create AMI from
	InstanceType pulumi.StringInput `pulumi:"instanceType"`
	// ARN of the key created for the instance root block device encryption.
	KeyAlias string `pulumi:"keyAlias"`
	// Arguments for the source AMI you want to build New AMI from.
	SourceAMI *SourceAMIArgs `pulumi:"sourceAMI"`
	// Tags for the AMI.
	Tags pulumi.StringMap `pulumi:"tags"`
	// Defines the package manager used when setting userdata for the instance. Defaults to `yum` if not set.
	PackageManager pulumi.String `pulumi:"packageManager"`
}

type SourceAMIArgs struct {
	// Used for filters when looking up existing AMIs. Must be set if ID is not defined.
	Name pulumi.StringInput `pulumi:"name"`
	// Defines owner of the source AMI. If not set, will default to `amazon`.
	Owner pulumi.String `pulumi:"owner"`
	// If set, will use this AMI ID exactly instead of performing a lookup.
	ID pulumi.StringInput `pulumi:"id"`
}

type Copy struct {
	// Bool to enable copy of AMI to additional AWS Regions.
	Enabled bool `pulumi:"enabled"`
	// AWS region you would like the AMI to be copied to.
	DestRegion string `pulumi:"destRegion"`
}

var (
	ErrRequiredArgumentSourceAMIName = errors.New("required argument `SourceAMIName` is missing")
)

//go:embed userdata
var userDataScripts embed.FS

// NewAMI creates an AMI that is sharable with every account in the organization.
func NewAMI(ctx *pulumi.Context, name string, args *AMIArgs, opts ...pulumi.ResourceOption) (*AMI, error) {
	component := &AMI{}

	if err := args.validate(ctx, name); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(amiComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", amiComponentName, name, err)
	}

	if err := component.createNetwork(ctx, name+"-network", args); err != nil {
		return nil, err
	}

	if err := component.createSecurityGroups(ctx, name+"-sg", args); err != nil {
		return nil, err
	}

	if err := component.createInstance(ctx, name+"-instance", args); err != nil {
		return nil, err
	}

	if err := component.createAMI(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", amiComponentName, name, err)
	}

	return component, nil
}

func (c *AMI) createNetwork(ctx *pulumi.Context, name string, args *AMIArgs) error {
	network, err := networking.NewNetwork(ctx, name, &networking.NetworkArgs{
		Tags: utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create new VPC, %w", err)
	}

	for _, subnet := range network.PrivateSubnets {
		c.SubnetID = subnet.ID

		break // Exit after the first iteration
	}

	c.VpcID = network.VpcID

	return nil
}

func (c *AMI) createSecurityGroups(ctx *pulumi.Context, name string, args *AMIArgs) error {
	egressCfg := &ec2.SecurityGroupEgressArgs{
		CidrBlocks: pulumi.ToStringArray([]string{"0.0.0.0/0"}),
		FromPort:   pulumi.Int(0),
		Protocol:   pulumi.String("-1"),
		ToPort:     pulumi.Int(0),
	}

	securityGroup, err := ec2.NewSecurityGroup(ctx, name, &ec2.SecurityGroupArgs{
		Description: pulumi.String(name),
		Egress: ec2.SecurityGroupEgressArray{
			egressCfg,
		},
		Tags:  args.Tags,
		VpcId: c.VpcID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create security group %s, %w", name, err)
	}

	c.SecurityGroupID = securityGroup.ID().ToStringOutput()

	return nil
}

func (c *AMI) createInstance(ctx *pulumi.Context, name string, args *AMIArgs) error {
	if args.SourceAMI.ID == nil {
		latestAmi, err := ec2.LookupAmi(ctx, &ec2.LookupAmiArgs{
			Owners: []string{string(args.SourceAMI.Owner)},
			Filters: []ec2.GetAmiFilter{
				{
					Name:   "name",
					Values: []string{fmt.Sprintf("%s*", args.SourceAMI.Name)},
				},
				{
					Name:   "state",
					Values: []string{"available"},
				},
			},
			MostRecent: pulumi.BoolRef(true),
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to get latest ami, %w", err)
		}

		args.SourceAMI.ID = pulumi.String(latestAmi.Id)
	}

	userdata, err := getUserData(args)
	if err != nil {
		return err
	}

	amiKey, err := kms.LookupKey(ctx, &kms.LookupKeyArgs{
		KeyId: "alias/" + args.KeyAlias,
	})
	if err != nil {
		return fmt.Errorf("unable to lookup key `%s`, %w", args.KeyAlias, err)
	}

	instance, err := ec2.NewInstance(ctx, name, &ec2.InstanceArgs{
		Ami:          args.SourceAMI.ID,
		InstanceType: args.InstanceType,
		SubnetId:     c.SubnetID,
		RootBlockDevice: ec2.InstanceRootBlockDeviceArgs{
			Encrypted:  pulumi.Bool(true),
			KmsKeyId:   pulumi.String(amiKey.Arn),
			VolumeType: pulumi.String("gp3"),
		},
		UserData:       userdata,
		SecurityGroups: pulumi.StringArray{c.SecurityGroupID},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create ec2 instance, %w", err)
	}

	c.InstanceID = instance.ID().ToStringOutput()

	return nil
}

func (c *AMI) createAMI(ctx *pulumi.Context, name string, args *AMIArgs) error {
	org, err := organizations.LookupOrganization(ctx)
	if err != nil {
		return fmt.Errorf("unable to lookup organization, %w", err)
	}

	newAmi, err := ec2.NewAmiFromInstance(ctx, name, &ec2.AmiFromInstanceArgs{
		Description:      pulumi.String("Gamewarden Generated AMI"),
		EbsBlockDevices:  ec2.AmiFromInstanceEbsBlockDeviceArray{},
		SourceInstanceId: c.InstanceID,
		Tags:             args.Tags,
	}, pulumi.Parent(c), pulumi.RetainOnDelete(true))
	if err != nil {
		return fmt.Errorf("unable to create a new ami %s, %w", name, err)
	}

	c.ID = newAmi.ID().ToStringOutput()

	_, err = ec2.NewAmiLaunchPermission(ctx, name, &ec2.AmiLaunchPermissionArgs{
		ImageId:         newAmi.ID(),
		OrganizationArn: pulumi.String(org.Arn),
	}, pulumi.Parent(c), pulumi.RetainOnDelete(true))
	if err != nil {
		return fmt.Errorf("unable to set ami launch permissions %s, %w", name, err)
	}

	return nil
}

func getUserData(args *AMIArgs) (pulumi.String, error) {
	if !args.DisableFIPS {
		args.PackageManager += "-fips"
	}

	fileName := fmt.Sprintf("userdata/%s.sh", strings.ToLower(string(args.PackageManager)))

	file, err := userDataScripts.ReadFile(fileName)
	if err != nil {
		return "", fmt.Errorf("unable to read user data script file `%s` does it exist?, %w", fileName, err)
	}

	return pulumi.String(file), nil
}

func (a *AMIArgs) validate(ctx *pulumi.Context, name string) error {
	if a == nil {
		a = &AMIArgs{}
	}

	if a.AvailabilityZone == "" {
		region, err := aws.GetRegion(ctx, nil, nil)
		if err != nil {
			return fmt.Errorf("unable to get region, %w", err)
		}

		a.AvailabilityZone = pulumi.String(region.Name + "a")
	}

	if a.SourceAMI.Owner == "" {
		a.SourceAMI.Owner = pulumi.String("amazon")
	}

	if a.SourceAMI.ID == nil && a.SourceAMI.Name == nil {
		return ErrRequiredArgumentSourceAMIName
	}

	if a.InstanceType == nil {
		a.InstanceType = pulumi.String("t3.micro")
	}

	if a.PackageManager == "" {
		a.PackageManager = pulumi.String("yum")
	}

	if a.Tags == nil {
		a.Tags = pulumi.ToStringMap(map[string]string{})
	}

	if _, ok := a.Tags["Name"]; !ok {
		a.Tags["Name"] = pulumi.String(name)
	}

	return nil
}

func (a *AMIArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal ami args, %w", err)
	}

	return nil
}

func (a *SourceAMIArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal source ami args, %w", err)
	}

	return nil
}
