package ami_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ami"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestNewGrants(t *testing.T) {
	t.Parallel()

	type want struct {
		// add wanted result fields here
	}

	type args struct {
		name string
		args *ami.GrantsArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "Test grants",
			in: args{
				name: "test1",
				args: &ami.GrantsArgs{
					KmsArn: pulumi.String("arn:testing"),
				},
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "Test failed empty args",
			in: args{
				name: "test-fail",
				args: &ami.GrantsArgs{
					KmsArn: nil,
				},
			},
			want:    want{},
			wantErr: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := ami.NewGrants(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks))) // add mocks here
			if (err != nil) != tc.wantErr {
				t.Errorf("NewGrants() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}
