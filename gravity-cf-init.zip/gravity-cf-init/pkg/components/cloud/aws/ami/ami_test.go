package ami_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ami"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewAMI(t *testing.T) {
	t.Parallel()

	type want struct {
	}

	tests := []struct {
		name    string
		args    *ami.AMIArgs
		want    want
		focus   bool
		wantErr bool
	}{
		{
			name: "testing AMI build with copy and only Source AMI ",
			args: &ami.AMIArgs{
				DisableFIPS: false,
				Copy: &ami.Copy{
					Enabled:    true,
					DestRegion: "us-gov-west-1",
				},
				KeyAlias: "test-key",
				SourceAMI: &ami.SourceAMIArgs{
					Name: pulumi.String("testingAmi"),
				},
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "testing AMI build without copy, set source AMI ID, and Apt Packagemanager",
			args: &ami.AMIArgs{
				DisableFIPS: false,
				SourceAMI: &ami.SourceAMIArgs{
					ID: pulumi.String("ami-123456789"),
				},
				KeyAlias: "test-key",
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "AMI build should fail with unsupported package manager",
			args: &ami.AMIArgs{
				DisableFIPS: false,
				SourceAMI: &ami.SourceAMIArgs{
					ID: pulumi.String("ami-123456789"),
				},
				PackageManager: "unsupported",
				KeyAlias:       "test-key",
			},
			want:    want{},
			wantErr: true,
		},
		{
			name: "testing AMI build with Source AMI Name and Owner, and FIPS disabled",
			args: &ami.AMIArgs{
				DisableFIPS: true,
				Copy: &ami.Copy{
					Enabled:    false,
					DestRegion: "",
				},
				SourceAMI: &ami.SourceAMIArgs{
					Name:  pulumi.String("1.30"),
					Owner: "amazon",
				},
				Tags:     nil,
				KeyAlias: "test-key",
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "testing AMI build with Source AMI ID",
			args: &ami.AMIArgs{
				DisableFIPS: false,
				SourceAMI: &ami.SourceAMIArgs{
					ID: pulumi.String("ami-123456789"),
				},
				KeyAlias: "test-key",
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "AMI should fail if missing SourceAMI arguments",
			args: &ami.AMIArgs{
				SourceAMI: &ami.SourceAMIArgs{},
				KeyAlias:  "test-key",
			},
			want:    want{},
			wantErr: true,
		},
	}

	focused := false

	for _, tc := range tests {
		if tc.focus {
			focused = true

			break
		}
	}

	for _, tt := range tests {
		if focused && !tt.focus {
			continue
		}

		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := ami.NewAMI(ctx, "test", tt.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.ID.ApplyT(func(id string) string {
					assert.Equal(t, "test_id", id)

					return id
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}

	if focused {
		t.Fatalf("testcase(s) still focused")
	}
}
