package ami

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/iam"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/kms"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/organizations"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const grantComponentName = "gravity:ami:grant"

var ErrRequiredArgumentKmsArn = errors.New("required argument KmsARN is missing")

type Grants struct {
	pulumi.ResourceState
}

type GrantsArgs struct {
	KmsArn pulumi.StringInput `pulumi:"kmsArn" validate:"required"`
}

func NewGrants(ctx *pulumi.Context, name string, args *GrantsArgs, opts ...pulumi.ResourceOption) (*Grants, error) {
	component := &Grants{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(grantComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", grantComponentName, name, err)
	}

	if err := component.createKmsGrants(ctx, name+"-grants", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", grantComponentName, name, err)
	}

	return component, nil
}

func (a *GrantsArgs) validate() error {
	if err := utils.ValidateStruct(a); err != nil {
		return fmt.Errorf("%T validation failed: %w", a, err)
	}

	return nil
}

func (a *GrantsArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", a, err)
	}

	return nil
}

func (c *Grants) createKmsGrants(ctx *pulumi.Context, name string, args *GrantsArgs) error {
	// Create a KMS Grant in all active account in the org
	org, err := organizations.LookupOrganization(ctx)
	if err != nil {
		return fmt.Errorf("unable to lookup organization, %w", err)
	}

	for _, account := range org.NonMasterAccounts {
		if account.Status != "ACTIVE" {
			continue
		}

		nameStr := name + "-" + account.Name

		region := aws.GetRegionOutput(ctx, aws.GetRegionOutputArgs{}, pulumi.Parent(c))

		partition := aws.GetPartitionOutput(ctx, aws.GetPartitionOutputArgs{}, pulumi.Parent(c))

		provider, err := aws.NewProvider(ctx, nameStr, &aws.ProviderArgs{
			AssumeRole: &aws.ProviderAssumeRoleArgs{
				RoleArn: pulumi.Sprintf("arn:%s:iam::%s:role/OrganizationAccountAccessRole", partition.Partition(), account.Id),
			},
			Region: region.Name(),
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create aws provider for account %s, %w", account.Name, err)
		}

		asRole, err := iam.LookupRole(ctx, &iam.LookupRoleArgs{
			Name: "AWSServiceRoleForAutoScaling",
		}, pulumi.Parent(c), pulumi.Provider(provider))
		if err != nil {
			continue
		}

		if _, err := kms.NewGrant(ctx, nameStr, &kms.GrantArgs{
			GranteePrincipal: pulumi.String(asRole.Arn),
			KeyId:            args.KmsArn,
			Operations: pulumi.StringArray{
				pulumi.String("Decrypt"),
				pulumi.String("DescribeKey"),
				pulumi.String("CreateGrant"),
				pulumi.String("ReEncryptFrom"),
				pulumi.String("ReEncryptTo"),
				pulumi.String("GenerateDataKey"),
				pulumi.String("GenerateDataKeyWithoutPlaintext"),
			},
		}, pulumi.Parent(c), pulumi.Provider(provider)); err != nil {
			return fmt.Errorf("unable to give a new kms grant for %s, %w", nameStr, err)
		}
	}

	return nil
}
