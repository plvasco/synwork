package aws

import (
	"errors"
	"fmt"
	"slices"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/cluster/eks"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/cluster/talos"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ec2"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/rds"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/s3"
	talosCluster "code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cluster/talos"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"

	awsEC2 "github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ec2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const infraComponentName = "gravity:aws:infrastructure"

var (
	ErrArgumentNetworkingDupe = errors.New("can not provide both `networking` and `existingNetwork` only one can be defined")
)

type Infrastructure struct {
	pulumi.ResourceState
	Clusters       map[string]*eks.Cluster          `pulumi:"Clusters"`
	TalosClusters  map[string]*talosCluster.Cluster `pulumi:"talosClusters"`
	PublicSubnets  map[string]*networking.Subnet    `pulumi:"publicSubnetIDs"`
	PrivateSubnets map[string]*networking.Subnet    `pulumi:"privateSubnetIDs"`
	VpcID          pulumi.StringOutput              `pulumi:"vpcID"`
	Databases      map[string]*rds.Database         `pulumi:"databaseOutputs"`
	Buckets        map[string]*s3.Bucket            `pulumi:"buckets"`
	Instances      map[string]*ec2.Instance         `pulumi:"instanceCfgs"`
}

type InfrastructureArgs struct {
	Tags            pulumi.StringMap                   `pulumi:"tags"`
	Clusters        map[string]*eks.ClusterArgs        `pulumi:"clusters"`
	TalosClusters   map[string]*talos.ClusterInfraArgs `pulumi:"talosClusters"`
	Instances       map[string]*ec2.InstanceArgs       `pulumi:"instances"`
	Databases       map[string]*rds.DatabaseArgs       `pulumi:"databases"`
	Networking      *networking.NetworkArgs            `pulumi:"networking"`
	ExistingNetwork *ExistingNetworkArgs               `pulumi:"existingNetwork"`
	// Buckets args for the creation of default S3 Buckets
	Buckets         map[string]*s3.BucketArgs `pulumi:"buckets"`
	ComplianceLevel pulumi.StringInput        `pulumi:"complianceLevel"`
	Customer        pulumi.StringInput        `pulumi:"customer"`
	Environment     pulumi.StringInput        `pulumi:"environment"`
	VPCPeering      *networking.VpcPeeringArgs
}

type ExistingNetworkArgs struct {
	VpcID          pulumi.StringInput `pulumi:"vpcID"`
	PublicSubnets  pulumi.StringMap   `pulumi:"publicSubnets"`
	PrivateSubnets pulumi.StringMap   `pulumi:"privateSubnets"`
}

func NewInfrastructure(ctx *pulumi.Context, name string, args *InfrastructureArgs, opts ...pulumi.ResourceOption) (*Infrastructure, error) {
	component := &Infrastructure{
		Databases: map[string]*rds.Database{},
		Buckets:   map[string]*s3.Bucket{},
	}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(infraComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", infraComponentName, name, err)
	}

	if args.ExistingNetwork == nil {
		if err := component.createNetwork(ctx, name+"-network", args); err != nil {
			return nil, err
		}
	} else {
		component.getExistingNetwork(ctx, args)
	}

	if err := component.createTalosClusters(ctx, name+"-talos", args); err != nil {
		return nil, err
	}

	if err := component.createEksClusters(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createInstances(ctx, name+"-instance", args); err != nil {
		return nil, err
	}

	if err := component.createDatabases(ctx, name+"-db", args); err != nil {
		return nil, err
	}

	if err := component.createS3Buckets(ctx, name+"-bucket", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", infraComponentName, name, err)
	}

	return component, nil
}

func (a *InfrastructureArgs) validate() error {
	if a.Tags == nil {
		a.Tags = pulumi.StringMap{}
	}

	if _, ok := a.Tags["customer"]; !ok {
		a.Tags["customer"] = a.Customer
	}

	if _, ok := a.Tags["complianceLevel"]; !ok {
		a.Tags["complianceLevel"] = a.ComplianceLevel
	}

	if _, ok := a.Tags["environment"]; !ok {
		a.Tags["environment"] = a.Environment
	}

	if a.ExistingNetwork != nil && a.Networking != nil {
		return ErrArgumentNetworkingDupe
	}

	if err := utils.ValidateStruct(a); err != nil {
		return fmt.Errorf("%T validation failed, %w", a, err)
	}

	return nil
}

func (a *InfrastructureArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", a, err)
	}

	return nil
}

func (a *ExistingNetworkArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", a, err)
	}

	return nil
}

func (c *Infrastructure) createNetwork(ctx *pulumi.Context, name string, args *InfrastructureArgs) error {
	// Create Networking for AWS stack
	if args.Networking == nil {
		args.Networking = &networking.NetworkArgs{}
	}

	args.Networking.Tags = utils.CombineTags(args.Tags, args.Networking.Tags)

	network, err := networking.NewNetwork(ctx, name, args.Networking, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("error building networking %w", err)
	}

	c.PublicSubnets = network.PublicSubnets

	c.PrivateSubnets = network.PrivateSubnets

	c.VpcID = network.VpcID.ToStringOutput()

	return nil
}

func (c *Infrastructure) getExistingNetwork(ctx *pulumi.Context, args *InfrastructureArgs) {
	// Get info from existing network
	c.PrivateSubnets = map[string]*networking.Subnet{}
	for az, subnetID := range args.ExistingNetwork.PrivateSubnets {
		rt := awsEC2.LookupRouteTableOutput(ctx, awsEC2.LookupRouteTableOutputArgs{
			SubnetId: subnetID,
		}, pulumi.Parent(c))

		c.PrivateSubnets[az] = &networking.Subnet{
			ID:           subnetID.ToStringOutput(),
			RouteTableID: rt.Id(),
		}
	}

	c.PublicSubnets = map[string]*networking.Subnet{}
	for az, subnetID := range args.ExistingNetwork.PublicSubnets {
		rt := awsEC2.LookupRouteTableOutput(ctx, awsEC2.LookupRouteTableOutputArgs{
			SubnetId: subnetID,
		}, pulumi.Parent(c))

		c.PrivateSubnets[az] = &networking.Subnet{
			ID:           subnetID.ToStringOutput(),
			RouteTableID: rt.Id(),
		}
	}

	c.VpcID = args.ExistingNetwork.VpcID.ToStringOutput()
}

func (c *Infrastructure) createEksClusters(ctx *pulumi.Context, name string, args *InfrastructureArgs) error {
	for clusterName, clusterCfg := range args.Clusters {
		clusterCfg.SubnetIDs = getSubnetIDArray(c.PrivateSubnets)
		clusterCfg.Tags = utils.CombineTags(args.Tags, clusterCfg.Tags)
		clusterCfg.ComplianceLevel = args.ComplianceLevel
		clusterCfg.Customer = args.Customer
		clusterCfg.Environment = args.Environment
		clusterCfg.VpcID = c.VpcID

		if _, err := eks.NewCluster(ctx, name+"-"+clusterName, clusterCfg, pulumi.Parent(c)); err != nil {
			return fmt.Errorf("unable to create eks clusters, %w", err)
		}
	}

	return nil
}

func (c *Infrastructure) createTalosClusters(ctx *pulumi.Context, name string, args *InfrastructureArgs) error {
	c.TalosClusters = map[string]*talosCluster.Cluster{}
	for clusterName, clusterCfg := range args.TalosClusters {
		clusterCfg.SubnetIDs = getSubnetIDArray(c.PublicSubnets)
		clusterCfg.Tags = utils.CombineTags(args.Tags, clusterCfg.Tags)
		clusterCfg.ComplianceLevel = args.ComplianceLevel
		clusterCfg.Customer = args.Customer
		clusterCfg.Environment = args.Environment
		clusterCfg.VpcID = c.VpcID

		talosCfg, err := talos.NewCluster(ctx, name+clusterName, clusterCfg, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create new instance `%s`, %w", clusterName, err)
		}

		c.TalosClusters[clusterName] = talosCfg.Cluster
	}

	return nil
}

func (c *Infrastructure) createInstances(ctx *pulumi.Context, name string, args *InfrastructureArgs) error {
	// Creates instances defined in the stack
	c.Instances = map[string]*ec2.Instance{}

	for instance, instanceCfg := range args.Instances {
		nameStr := name + "-" + instance
		instanceCfg.VpcID = c.VpcID
		instanceCfg.Tags = utils.CombineTags(args.Tags, instanceCfg.Tags)
		instanceCfg.Tags["Name"] = pulumi.String(nameStr)

		newInstance, err := ec2.NewInstance(ctx, nameStr, instanceCfg, pulumi.Parent(c))

		if err != nil {
			return fmt.Errorf("unable to create new instance `%s`, %w", instance, err)
		}

		c.Instances[instance] = newInstance
	}

	return nil
}

func (c *Infrastructure) createDatabases(ctx *pulumi.Context, name string, args *InfrastructureArgs) error {
	for dbName, dbArgs := range args.Databases {
		dbArgs.Tags = utils.CombineTags(args.Tags, dbArgs.Tags)
		if dbArgs.Cluster != nil {
			dbArgs.Cluster.VpcID = c.VpcID
			dbArgs.Cluster.SubnetIDs = getSubnetIDArray(c.PrivateSubnets)
		}

		if dbArgs.Instance != nil {
			dbArgs.Instance.VpcID = c.VpcID
			dbArgs.Instance.SubnetIDs = getSubnetIDArray(c.PrivateSubnets)
		}

		database, err := rds.NewDatabase(ctx, name+"-"+dbName, dbArgs, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create new RDS databases, %w", err)
		}

		c.Databases[dbName] = database
	}

	return nil
}

func (c *Infrastructure) createS3Buckets(ctx *pulumi.Context, name string, args *InfrastructureArgs) error {
	for bucketName, bucketConf := range args.Buckets {
		bucketConf.Tags = utils.CombineTags(args.Tags, bucketConf.Tags)

		buckets, err := s3.NewBucket(ctx, name, bucketConf, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create S3 bucket for %s, %w", bucketName, err)
		}

		c.Buckets[bucketName] = buckets
	}

	return nil
}

func getSubnetIDArray(args networking.Subnets) pulumi.StringArray {
	subnetIDArray := pulumi.StringArray{}

	keys := []string{}

	for k := range args {
		keys = append(keys, k)
	}

	slices.Sort(keys)

	for _, key := range keys {
		subnetIDArray = append(subnetIDArray, args[key].ID)
	}

	return subnetIDArray
}
