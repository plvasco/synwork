package aws_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/cluster/eks"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ec2"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/rds"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/s3"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

type dbOuts struct {
	ID       string
	Endpoint string
	Password string
}

type bucketOuts struct {
	ID string
}

func TestNewInfrastructure(t *testing.T) {
	t.Parallel()

	type want struct {
		dbOuts     map[string]*dbOuts
		vpcID      string
		subnets    []string
		bucketOuts map[string]*bucketOuts
	}

	tests := []struct {
		name    string
		args    *aws.InfrastructureArgs
		want    want
		wantErr bool
		focus   bool
	}{
		{
			name: "test infra build should fail because of both network and exsisitng args",
			args: &aws.InfrastructureArgs{
				Clusters: map[string]*eks.ClusterArgs{},
				Networking: &networking.NetworkArgs{
					TransitGatewayID: pulumi.String("tgw-12345"),
				},
				ExistingNetwork: &aws.ExistingNetworkArgs{
					VpcID: pulumi.String("vpc-123456789"),
				},
				ComplianceLevel: pulumi.String("testing"),
				Customer:        pulumi.String("test"),
				Environment:     pulumi.String("testing"),
			},
			want:    want{},
			wantErr: true,
		},
		{
			name: "test new cluster infra build with networking",
			args: &aws.InfrastructureArgs{
				Clusters: map[string]*eks.ClusterArgs{
					"testCluster": {
						CiliumTag: pulumi.String("14.6"),
						NodeGroups: map[string]*eks.NodeGroupArgs{
							"test-ng": {
								AmiID:        pulumi.String("ami-12345678"),
								InstanceType: pulumi.String("m5.xlarge"),
							},
						},
						KubernetesVersion: pulumi.String("1.30"),
						ComplianceLevel:   pulumi.String("testing"),
						Customer:          pulumi.String("test"),
						Environment:       pulumi.String("testing"),
					},
				},
				Networking: &networking.NetworkArgs{
					Public: &networking.PublicNetworkArgs{
						NetworkCidr:       pulumi.String("10.0.0.0/24"),
						NetworkPrefixSize: pulumi.Int(24),
						SubnetPrefixSize:  pulumi.Int(28),
					},
					Private: &networking.PrivateNetworkArgs{
						NetworkCidr:      pulumi.String("10.0.1.0/24"),
						SubnetPrefixSize: pulumi.Int(28),
					},
				},
				Buckets: map[string]*s3.BucketArgs{
					"test-bucket": {
						ServiceAccount: true,
					},
				},
				ComplianceLevel: pulumi.String("testing"),
				Customer:        pulumi.String("test"),
				Environment:     pulumi.String("testing"),
			},
			want: want{
				vpcID: "test-network-vpc_id",
				subnets: []string{
					"test-network-private-us-gov-east-1a_id",
					"test-network-public-us-gov-east-1a_id",
					"test-network-private-us-gov-east-1b_id",
					"test-network-public-us-gov-east-1b_id",
					"test-network-private-us-gov-east-1c_id",
					"test-network-public-us-gov-east-1c_id",
				},
				bucketOuts: map[string]*bucketOuts{
					"test-bucket": {
						ID: "test-bucket_id",
					},
				},
			},
			wantErr: false,
		},
		{
			name: "test instance only infra build without networking",
			args: &aws.InfrastructureArgs{
				Instances: map[string]*ec2.InstanceArgs{
					"test-instance-1": {
						AmiID:            pulumi.String("ami-9001"),
						AvailabilityZone: pulumi.String("us-gov-east-1a"),
						UserData:         pulumi.String("echo 'x10d'"),
						InstanceType:     pulumi.String("t2.micro"),
						ComplianceLevel:  pulumi.String("test"),
						Customer:         pulumi.String("test"),
						Environment:      pulumi.String("test"),
					},
					"test-instance-2": {
						AmiID:           pulumi.String("ami-1337"),
						UserData:        pulumi.String("echo 'x10d'"),
						InstanceType:    pulumi.String("m5.xlarge"),
						SubnetID:        pulumi.String("subnet-test"),
						ComplianceLevel: pulumi.String("test"),
						Customer:        pulumi.String("test"),
						Environment:     pulumi.String("test"),
					},
				},
				Databases: map[string]*rds.DatabaseArgs{
					"testDB1": {
						Instance: &rds.InstanceArgs{
							SourceSecurityGroupID: pulumi.String("sg-testing"),
							AllocatedStorage:      pulumi.Int(20),
							Engine:                pulumi.String("postgres"),
							EngineVersion:         pulumi.String("14.12"),
							InstanceClass:         pulumi.String("db.t4g.medium"),
							MaxAllocatedStorage:   pulumi.Int(100),
							Username:              pulumi.String("x10d"),
							OptionGroupName:       pulumi.String("default:postgres-14"),
							Port:                  pulumi.Int(5432),
							ReadReplicas:          pulumi.Int(2),
							ParameterGroup: &rds.ParameterGroupArgs{
								Family: pulumi.String("postgres14"),
								Parameters: []*rds.Parameter{
									{
										Name:  pulumi.String("timezone"),
										Value: pulumi.String("US/Eastern"),
									},
								},
							},
						},
					},
					"testDB2": {
						Cluster: &rds.AuroraClusterArgs{
							SourceSecurityGroupID: pulumi.String("sg-testing"),
							ClusterIdentifier:     pulumi.String("test-auroraCluster-ID"),
							DatabaseName:          pulumi.String("test-auroraCluster-db"),
							Engine:                pulumi.String("aurora-mysql"),
							EngineVersion:         pulumi.String("8.0.mysql_aurora.3.05.2"),
							Password:              pulumi.String("password"),
							Username:              pulumi.String("testUser"),
							Port:                  pulumi.Int(3306),
							ParameterGroup: &rds.ParameterGroupArgs{
								Family: pulumi.String("aurora-mysql8.0"),
								Parameters: []*rds.Parameter{
									{
										Name:  pulumi.String("max_allowed_packet"),
										Value: pulumi.String("1073741824"),
									},
								},
							},
							ClusterInstances: map[string]*rds.AuroraClusterInstanceArgs{
								"testInstance1": {
									InstanceClass: pulumi.String("db.t4g.medium"),
									ParameterGroup: &rds.ParameterGroupArgs{
										Family: pulumi.String("aurora-mysql8.0"),
										Parameters: []*rds.Parameter{
											{
												Name:  pulumi.String("max_allowed_packet"),
												Value: pulumi.String("1073741824"),
											},
										},
									},
								},
							},
						},
					},
				},
				ExistingNetwork: &aws.ExistingNetworkArgs{
					VpcID: pulumi.String("vpc123456"),
					PublicSubnets: pulumi.StringMap{
						"test-az-1": pulumi.String("id-123456").ToStringOutput(),
						"test-az-2": pulumi.String("id-78901").ToStringOutput(),
						"test-az-3": pulumi.String("id-345678").ToStringOutput(),
					},
					PrivateSubnets: pulumi.StringMap{
						"private-test-az-1": pulumi.String("id-654321").ToStringOutput(),
						"private-test-az-2": pulumi.String("id-765432").ToStringOutput(),
						"private-test-az-3": pulumi.String("id-098765").ToStringOutput(),
					},
				},
				ComplianceLevel: pulumi.String("testing"),
				Customer:        pulumi.String("test"),
				Environment:     pulumi.String("testing"),
			},
			want: want{
				dbOuts: map[string]*dbOuts{
					"testDB1": {
						ID:       "test-db-testDB1-rds-instance_id",
						Endpoint: "mockrdsinstance.db.x10d",
						Password: "mockPass",
					},
					"testDB2": {
						ID:       "test-db-testDB2-aurora-cluster_id",
						Endpoint: "mockauraoracluster.db.x10d",
						Password: "password",
					},
				},
				vpcID:   "vpc123456789",
				subnets: []string{"subnet-12345", "subnet-67890"},
			},
			wantErr: false,
			focus:   false,
		},
	}

	focused := false

	for _, tc := range tests {
		if tc.focus {
			focused = true

			break
		}
	}

	for _, tt := range tests {
		if focused && !tt.focus {
			continue
		}

		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := aws.NewInfrastructure(ctx, "test", tt.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				if tt.args.ExistingNetwork == nil {
					for _, subnetID := range got.PublicSubnets {
						subnetID.ID.ToStringOutput().ApplyT(func(subnetID string) string {
							assert.Contains(t, tt.want.subnets, subnetID)

							return subnetID
						})
					}

					for _, subnetID := range got.PrivateSubnets {
						subnetID.ID.ToStringOutput().ApplyT(func(subnetID string) string {
							assert.Contains(t, tt.want.subnets, subnetID)

							return subnetID
						})
					}
				}

				got.VpcID.ApplyT(func(id string) string {
					assert.Contains(t, tt.want.vpcID, id)

					return id
				})

				for dbName, dbOut := range got.Databases {
					dbOut.ID.ApplyT(func(id string) string {
						assert.Equal(t, tt.want.dbOuts[dbName].ID, id)

						return id
					})

					dbOut.Endpoint.ApplyT(func(endpoint string) string {
						assert.Equal(t, tt.want.dbOuts[dbName].Endpoint, endpoint)

						return endpoint
					})

					dbOut.Password.ApplyT(func(p string) string {
						assert.Equal(t, tt.want.dbOuts[dbName].Password, p)

						return p
					})
				}

				if got.Buckets != nil {
					for bucketName, bucketOut := range got.Buckets {
						bucketOut.ID.ApplyT(func(id string) error {
							assert.Equal(t, tt.want.bucketOuts[bucketName].ID, id)

							return nil
						})
					}
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}

	if focused {
		t.Fatalf("testcase(s) still focused")
	}
}

func TestInfrastructureArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *aws.InfrastructureArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"instances": {
					"test-instance-1": {
						"amiID": "ami-9001",
						"availabilityZone": "us-gov-east-1a",
						"userData": "echo 'x10d'",
						"instanceType": "t2.micro",
						"complianceLevel": "test",
						"customer": "test",
						"environment": "test"
					},
					"test-instance-2": {
						"amiID": "ami-1337",
						"userData": "echo 'x10d'",
						"instanceType": "m5.xlarge",
						"subnetID": "subnet-test",
						"complianceLevel": "test",
						"customer": "test",
						"environment": "test"
					}
				},
				"existingNetwork": {
					"vpcID": "vpc123456",
					"publicSubnets": {
						"test-az-1": "id-123456",
						"test-az-2": "id-78901",
						"test-az-3": "id-345678"
					},
					"privateSubnets": {
						"private-test-az-1": "id-654321",
						"private-test-az-2": "id-765432",
						"private-test-az-3": "id-098765"
					}
				},
				"complianceLevel": "testing",
				"customer": "test",
				"environment": "testing"
			}`,
			want: &aws.InfrastructureArgs{
				Instances: map[string]*ec2.InstanceArgs{
					"test-instance-1": {
						AmiID:            pulumi.String("ami-9001"),
						AvailabilityZone: pulumi.String("us-gov-east-1a"),
						UserData:         pulumi.String("echo 'x10d'"),
						InstanceType:     pulumi.String("t2.micro"),
						ComplianceLevel:  pulumi.String("test"),
						Customer:         pulumi.String("test"),
						Environment:      pulumi.String("test"),
					},
					"test-instance-2": {
						AmiID:           pulumi.String("ami-1337"),
						UserData:        pulumi.String("echo 'x10d'"),
						InstanceType:    pulumi.String("m5.xlarge"),
						SubnetID:        pulumi.String("subnet-test"),
						ComplianceLevel: pulumi.String("test"),
						Customer:        pulumi.String("test"),
						Environment:     pulumi.String("test"),
					},
				},
				ExistingNetwork: &aws.ExistingNetworkArgs{
					VpcID: pulumi.String("vpc123456"),
					PublicSubnets: pulumi.StringMap{
						"test-az-1": pulumi.String("id-123456"),
						"test-az-2": pulumi.String("id-78901"),
						"test-az-3": pulumi.String("id-345678"),
					},
					PrivateSubnets: pulumi.StringMap{
						"private-test-az-1": pulumi.String("id-654321"),
						"private-test-az-2": pulumi.String("id-765432"),
						"private-test-az-3": pulumi.String("id-098765"),
					},
				},
				ComplianceLevel: pulumi.String("testing"),
				Customer:        pulumi.String("test"),
				Environment:     pulumi.String("testing"),
			},
			wantErr: false,
		},
		{
			name:    "malformed JSON",
			input:   `{"instances": {"test-instance-1": {"amiID": "ami-9001"}}`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args aws.InfrastructureArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
