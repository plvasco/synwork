package accounts

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/organizations"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const accountComponentName = "gravity:aws:account"

var ErrRequiredArgumentNetworkID = errors.New("required argument NetworkID is missing")

type Accounts struct {
	pulumi.ResourceState
}

type AccountArgsMap map[string]*AccountArgs

type AccountArgs struct {
	Email pulumi.StringInput `pulumi:"email" validate:"required"`
	Role  pulumi.StringInput `pulumi:"role"`
	Gov   pulumi.BoolInput   `pulumi:"gov"   validate:"default=true"`
}

func NewAccount(ctx *pulumi.Context, name string, args AccountArgsMap, opts ...pulumi.ResourceOption) (*Accounts, error) {
	component := &Accounts{}

	if err := ctx.RegisterComponentResource(accountComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", accountComponentName, name, err)
	}

	if err := component.createOrganizationAccount(ctx, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", accountComponentName, name, err)
	}

	return component, nil
}

func (a *AccountArgs) validate() error {
	if err := utils.ValidateStruct(a); err != nil {
		return fmt.Errorf("%T validation failed: %w", a, err)
	}

	return nil
}

func (a *AccountArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", a, err)
	}

	return nil
}

func (c *Accounts) createOrganizationAccount(ctx *pulumi.Context, args AccountArgsMap) error {
	// Lookup current Organization
	org := organizations.LookupOrganizationOutput(ctx)

	for accountName, acctConf := range args {
		if err := acctConf.validate(); err != nil {
			return err
		}

		// Create an AWS Account and add it to the Organization
		account, err := organizations.NewAccount(ctx, accountName, &organizations.AccountArgs{
			Email:          acctConf.Email,
			Name:           pulumi.String(accountName),
			RoleName:       acctConf.Role,
			ParentId:       org.Roots().Index(pulumi.Int(0)).Id(),
			CreateGovcloud: acctConf.Gov,
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("error creating Account %s, %w", accountName, err)
		}

		ctx.Export(accountName+"-AWS ACCOUNT:", account.ID())
		ctx.Export(accountName+"-AWS_ACCOUNT_ARN", account.Arn)
		ctx.Export(accountName+"-AWS_ACCOUNT_STATUS", account.Status)
		ctx.Export(accountName+"-AWS_ACCOUNT_GOVCLOUD_ID", account.GovcloudId)
		ctx.Export(accountName+"-AWS_ACCOUNT_JOINED_METHOD", account.JoinedMethod)
		ctx.Export(accountName+"-AWS_ACCOUNT_JOINED_TIMESTAMP", account.JoinedTimestamp)
	}

	return nil
}
