package accounts_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/accounts"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestNewAccount(t *testing.T) {
	t.Parallel()

	type want struct {
		// add wanted result fields here
	}

	type args struct {
		name string
		args accounts.AccountArgsMap
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test accounts",
			in: args{
				name: "test1",
				args: accounts.AccountArgsMap{
					"testAcct1": {
						Email: pulumi.String("test1@x10d.com"),
						Gov:   pulumi.Bool(false),
					},
					"testAccts2": {
						Email: pulumi.String("test2@x10d.com"),
					},
				},
			},
			want:    want{},
			wantErr: false,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := accounts.NewAccount(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				// add validation tests here

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewAccount() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestAccountArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *accounts.AccountArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"email": "test@example.com",
				"role": "admin",
				"gov": true,
				"googleGroupMembership": ["group1@example.com", "group2@example.com"]
			}`,
			want: &accounts.AccountArgs{
				Email: pulumi.String("test@example.com"),
				Role:  pulumi.String("admin"),
				Gov:   pulumi.Bool(true),
			},
			wantErr: false,
		},
		{
			name: "invalid field type",
			input: `{
				"email": "test@example.com",
				"role": "admin",
				"gov": "true", // gov should be a bool
				"googleGroupMembership": ["group1@example.com"]
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"email": "test@example.com", "role": "admin", "gov": true, "googleGroupMembership": ["group1@example.com"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args accounts.AccountArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
