package policy

import (
	"bytes"
	"fmt"
	"html/template"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/organizations"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const componentName = "gravity:aws:servicecontrolpolicy"

type ServiceControlPolicy struct {
	pulumi.ResourceState
	// ID of the Policy.
	PolicyID pulumi.IDOutput `pulumi:"policyID"`
}

type ServiceControlPolicyArgs struct {
	// Name of Template to create.
	TemplateName ServiceControlPolicyTemplate `pulumi:"templateName"`
	// A list of OUs for the policy to be attached.
	TargetOUs []string `pulumi:"targetOUs"`
	// Accelerator Prefix (used in template generation).
	AcceleratorPrefix pulumi.StringInput `pulumi:"accleratorPrefix" validate:"required"`
	// Management Account Access Role (used in template generation).
	ManagementAccountAccessRole pulumi.StringInput `pulumi:"managementAccountAccessRole" validate:"required"`
	// Tags to apply to all child objects of the ServiceControlPolicy component resource.
	Tags pulumi.StringMapInput `pulumi:"tags"`
	// Partition to use in template generation.
	Partition pulumi.StringInput
	// Region to use in template generation.
	Region pulumi.StringInput
}

// NewServiceControlPolicy creates a pulumi component resource containing a service control policy and attachments to OUs.
func NewServiceControlPolicy(ctx *pulumi.Context, name string, args *ServiceControlPolicyArgs, opts ...pulumi.ResourceOption) (*ServiceControlPolicy, error) {
	if err := args.validate(ctx); err != nil {
		return nil, err
	}

	component := &ServiceControlPolicy{}

	if err := ctx.RegisterComponentResource(componentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", componentName, name, err)
	}

	if err := component.createPolicy(ctx, name+"-policy", args); err != nil {
		return nil, err
	}

	if err := component.createPolicyAttachments(ctx, name+"-attachment", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"policyID": component.PolicyID,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", componentName, name, err)
	}

	return component, nil
}

// createPolicy creates a policy of type service control policy based off of a template.
func (c *ServiceControlPolicy) createPolicy(ctx *pulumi.Context, name string, args *ServiceControlPolicyArgs) error {
	content, err := args.getPolicyContent()
	if err != nil {
		return err
	}

	policy, err := organizations.NewPolicy(ctx, name, &organizations.PolicyArgs{
		Content:     content,
		Description: pulumi.String(args.TemplateName.getDescription()),
		Name:        pulumi.String(args.TemplateName.String()),
		Tags:        args.Tags,
		Type:        pulumi.String("SERVICE_CONTROL_POLICY"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create service control policy %s, %w", name, err)
	}

	c.PolicyID = policy.ID()

	return nil
}

func (c *ServiceControlPolicy) createPolicyAttachments(ctx *pulumi.Context, name string, args *ServiceControlPolicyArgs) error {
	org, err := organizations.LookupOrganization(ctx, nil)
	if err != nil {
		return fmt.Errorf("unable to find root organization, %w", err)
	}

	for _, targetOU := range args.TargetOUs {
		attachmentName := fmt.Sprintf("%s-%s)", name, targetOU)

		orgUnit, err := organizations.LookupOrganizationalUnit(ctx, &organizations.LookupOrganizationalUnitArgs{
			Name:     targetOU,
			ParentId: org.Roots[0].Id,
		})
		if err != nil {
			return fmt.Errorf("unable to find target ou %s for policy attachment %s, %w", targetOU, attachmentName, err)
		}

		if _, err := organizations.NewPolicyAttachment(ctx, attachmentName, &organizations.PolicyAttachmentArgs{
			PolicyId: c.PolicyID,
			TargetId: pulumi.String(orgUnit.Id),
		}, pulumi.Parent(c)); err != nil {
			return fmt.Errorf("unable to create policy attachment %s, %w", attachmentName, err)
		}
	}

	return nil
}

// getPolicyContent generates the content for a policy based off of a template.
func (args *ServiceControlPolicyArgs) getPolicyContent() (pulumi.StringOutput, error) {
	if !args.TemplateName.isValid() {
		return pulumi.StringOutput{}, ErrUnknownServiceControlPolicy
	}

	var buf bytes.Buffer

	policyContent, ok := pulumi.All(args.ManagementAccountAccessRole, args.AcceleratorPrefix, args.Partition, args.Region).ApplyT(func(all []any) (string, error) {
		role := all[0].(string)
		prefix := all[1].(string)
		partition := all[2].(string)
		region := all[3].(string)

		values := struct {
			ManagementAccountAccessRole string
			AcceleratorPrefix           string
			Partition                   string
			Region                      string
		}{
			ManagementAccountAccessRole: role,
			AcceleratorPrefix:           prefix,
			Partition:                   partition,
			Region:                      region,
		}

		tpl, err := template.New(args.TemplateName.String()+".json.tmpl").ParseFS(
			policyTemplates, fmt.Sprintf("templates/%s.json.tmpl", args.TemplateName),
		)
		if err != nil {
			return "", fmt.Errorf("unable to get service policy template %s, %w", args.TemplateName, err)
		}

		if err := tpl.Execute(&buf, values); err != nil {
			return "", fmt.Errorf("unable to generate service control policy from template %s, %w", args.TemplateName, err)
		}

		// need to remove spaces so we don't exceed maximum character limit of 5,120 characters
		content := strings.ReplaceAll(buf.String(), " ", "")
		content = strings.ReplaceAll(content, "\n", "")

		return content, nil
	}).(pulumi.StringOutput)
	if !ok {
		panic("unable to convert ServicePolicyTemplate to string")
	}

	return policyContent, nil
}

// validate checks that all required args are set and sets defaults for any optional args.
func (args *ServiceControlPolicyArgs) validate(ctx *pulumi.Context) error {
	if args.Region == nil {
		region, err := aws.GetRegion(ctx, nil)
		if err != nil {
			return fmt.Errorf("unable to get aws region, %w", err)
		}

		args.Region = pulumi.String(region.Name)
	}

	if args.Partition == nil {
		partition, err := aws.GetPartition(ctx, nil)
		if err != nil {
			return fmt.Errorf("unable to get aws partition, %w", err)
		}

		args.Partition = pulumi.String(partition.Partition)
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}
