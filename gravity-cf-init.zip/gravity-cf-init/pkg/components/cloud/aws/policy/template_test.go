package policy_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/policy"

	"github.com/stretchr/testify/assert"
)

func TestServicePolicy_String(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		sp   policy.ServiceControlPolicyTemplate
		want string
	}{
		{
			name: "FullAccess",
			sp:   policy.ServiceControlPolicyFullAccess,
			want: "FullAccess",
		},
		{
			name: "GuardRails-Part0-CoreOUs",
			sp:   policy.ServiceControlPolicyGuardRailsPart0CoreOUs,
			want: "GuardRails-Part0-CoreOUs",
		},
		{
			name: "GuardRails-Part0-WrkldOUs",
			sp:   policy.ServiceControlPolicyGuardRailsPart0WrkldOUs,
			want: "GuardRails-Part0-WrkldOUs",
		},
		{
			name: "GuardRails-Part1",
			sp:   policy.ServiceControlPolicyGuardRailsPart1,
			want: "GuardRails-Part1",
		},
		{
			name: "Sandbox",
			sp:   policy.ServiceControlPolicySandbox,
			want: "Sandbox",
		},
		{
			name: "Unclass",
			sp:   policy.ServiceControlPolicyUnclass,
			want: "Unclass",
		},
		{
			name: "Sensitive",
			sp:   policy.ServiceControlPolicySensitive,
			want: "Sensitive",
		},
		{
			name: "Quarantine",
			sp:   policy.ServiceControlPolicyQuarantine,
			want: "Quarantine",
		},
		{
			name: "Unknown",
			sp:   policy.ServiceControlPolicyUnknown,
			want: "Unknown Policy",
		},
		{
			name: "Bad Value -1",
			sp:   policy.ServiceControlPolicyTemplate(-1),
			want: "Unknown Policy",
		},
		{
			name: "Bad Value 9",
			sp:   policy.ServiceControlPolicyTemplate(9),
			want: "Unknown Policy",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			if got := tt.sp.String(); got != tt.want {
				t.Errorf("ServicePolicy.String() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestServicePolicy_FromString(t *testing.T) {
	t.Parallel()

	type args struct {
		str string
	}

	tests := []struct {
		name string
		sp   *policy.ServiceControlPolicyTemplate
		args args
		want policy.ServiceControlPolicyTemplate
	}{
		{
			name: "FullAccess",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "FullAccess",
			},
			want: policy.ServiceControlPolicyFullAccess,
		},
		{
			name: "GuardRails-Part0-CoreOUs",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "GuardRails-Part0-CoreOUs",
			},
			want: policy.ServiceControlPolicyGuardRailsPart0CoreOUs,
		},
		{
			name: "GuardRails-Part0-WrkldOUs",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "GuardRails-Part0-WrkldOUs",
			},
			want: policy.ServiceControlPolicyGuardRailsPart0WrkldOUs,
		},
		{
			name: "GuardRails-Part1",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "GuardRails-Part1",
			},
			want: policy.ServiceControlPolicyGuardRailsPart1,
		},
		{
			name: "Sandbox",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "Sandbox",
			},
			want: policy.ServiceControlPolicySandbox,
		},
		{
			name: "Unclass",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "Unclass",
			},
			want: policy.ServiceControlPolicyUnclass,
		},
		{
			name: "Sensitive",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "Sensitive",
			},
			want: policy.ServiceControlPolicySensitive,
		},
		{
			name: "Quarantine",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "Quarantine",
			},
			want: policy.ServiceControlPolicyQuarantine,
		},
		{
			name: "Unknown",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "Unknown Policy",
			},
			want: policy.ServiceControlPolicyUnknown,
		},
		{
			name: "Bad Value Potato",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "Potato",
			},
			want: policy.ServiceControlPolicyUnknown,
		},
		{
			name: "Bad Value empty",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				str: "",
			},
			want: policy.ServiceControlPolicyUnknown,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			tt.sp.FromString(tt.args.str)

			assert.Equal(t, tt.want, *tt.sp)
		})
	}
}

func TestServicePolicy_MarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		sp      policy.ServiceControlPolicyTemplate
		want    []byte
		wantErr bool
	}{
		{
			name:    "FullAccess",
			sp:      policy.ServiceControlPolicyFullAccess,
			want:    []byte(`"FullAccess"`),
			wantErr: false,
		},
		{
			name:    "GuardRails-Part0-CoreOUs",
			sp:      policy.ServiceControlPolicyGuardRailsPart0CoreOUs,
			want:    []byte(`"GuardRails-Part0-CoreOUs"`),
			wantErr: false,
		},
		{
			name:    "GuardRails-Part0-WrkldOUs",
			sp:      policy.ServiceControlPolicyGuardRailsPart0WrkldOUs,
			want:    []byte(`"GuardRails-Part0-WrkldOUs"`),
			wantErr: false,
		},
		{
			name:    "GuardRails-Part1",
			sp:      policy.ServiceControlPolicyGuardRailsPart1,
			want:    []byte(`"GuardRails-Part1"`),
			wantErr: false,
		},
		{
			name:    "Sandbox",
			sp:      policy.ServiceControlPolicySandbox,
			want:    []byte(`"Sandbox"`),
			wantErr: false,
		},
		{
			name:    "Unclass",
			sp:      policy.ServiceControlPolicyUnclass,
			want:    []byte(`"Unclass"`),
			wantErr: false,
		},
		{
			name:    "Sensitive",
			sp:      policy.ServiceControlPolicySensitive,
			want:    []byte(`"Sensitive"`),
			wantErr: false,
		},
		{
			name:    "Quarantine",
			sp:      policy.ServiceControlPolicyQuarantine,
			want:    []byte(`"Quarantine"`),
			wantErr: false,
		},
		{
			name:    "Unknown",
			sp:      policy.ServiceControlPolicyUnknown,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "Bad Value -1",
			sp:      policy.ServiceControlPolicyTemplate(-1),
			want:    nil,
			wantErr: true,
		},
		{
			name:    "Bad Value 9",
			sp:      policy.ServiceControlPolicyTemplate(9),
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			got, err := tt.sp.MarshalJSON()
			if (err != nil) != tt.wantErr {
				t.Errorf("ServicePolicy.MarshalJSON() error = %v, wantErr %v", err, tt.wantErr)

				return
			}

			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ServicePolicy.MarshalJSON() = %v, want %v", string(got), string(tt.want))
			}
		})
	}
}

func TestServicePolicy_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	type args struct {
		b []byte
	}

	tests := []struct {
		name    string
		sp      *policy.ServiceControlPolicyTemplate
		args    args
		want    policy.ServiceControlPolicyTemplate
		wantErr bool
	}{
		{
			name: "FullAccess",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"FullAccess"`),
			},
			want:    policy.ServiceControlPolicyFullAccess,
			wantErr: false,
		},
		{
			name: "GuardRails-Part0-CoreOUs",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"GuardRails-Part0-CoreOUs"`),
			},
			want:    policy.ServiceControlPolicyGuardRailsPart0CoreOUs,
			wantErr: false,
		},
		{
			name: "GuardRails-Part0-WrkldOUs",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"GuardRails-Part0-WrkldOUs"`),
			},
			want:    policy.ServiceControlPolicyGuardRailsPart0WrkldOUs,
			wantErr: false,
		},
		{
			name: "GuardRails-Part1",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"GuardRails-Part1"`),
			},
			want:    policy.ServiceControlPolicyGuardRailsPart1,
			wantErr: false,
		},
		{
			name: "Sandbox",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"Sandbox"`),
			},
			want:    policy.ServiceControlPolicySandbox,
			wantErr: false,
		},
		{
			name: "Unclass",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"Unclass"`),
			},
			want:    policy.ServiceControlPolicyUnclass,
			wantErr: false,
		},
		{
			name: "Sensitive",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"Sensitive"`),
			},
			want:    policy.ServiceControlPolicySensitive,
			wantErr: false,
		},
		{
			name: "Quarantine",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"Quarantine"`),
			},
			want:    policy.ServiceControlPolicyQuarantine,
			wantErr: false,
		},
		{
			name: "Unknown",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"Unknown Policy"`),
			},
			want:    policy.ServiceControlPolicyUnknown,
			wantErr: true,
		},
		{
			name: "Bad Value Potato",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`"Potato"`),
			},
			want:    policy.ServiceControlPolicyUnknown,
			wantErr: true,
		},
		{
			name: "Bad Value empty",
			sp:   new(policy.ServiceControlPolicyTemplate),
			args: args{
				b: []byte(`""`),
			},
			want:    policy.ServiceControlPolicyUnknown,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			if err := tt.sp.UnmarshalJSON(tt.args.b); (err != nil) != tt.wantErr {
				t.Errorf("ServicePolicy.UnmarshalJSON() error = %v, wantErr %v", err, tt.wantErr)

				return
			}

			assert.Equal(t, tt.want, *tt.sp)
		})
	}
}

func TestServicePolicyArray_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	type args struct {
		b []byte
	}

	tests := []struct {
		name    string
		sp      []policy.ServiceControlPolicyTemplate
		args    args
		want    []policy.ServiceControlPolicyTemplate
		wantErr bool
	}{
		{
			name: "FullAccess",
			sp:   []policy.ServiceControlPolicyTemplate{},
			args: args{
				b: []byte(`["FullAccess", "GuardRails-Part0-CoreOUs"]`),
			},
			want: []policy.ServiceControlPolicyTemplate{
				policy.ServiceControlPolicyFullAccess,
				policy.ServiceControlPolicyGuardRailsPart0CoreOUs,
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			if err := json.Unmarshal(tt.args.b, &tt.sp); (err != nil) != tt.wantErr {
				t.Errorf("ServicePolicy.UnmarshalJSON() error = %v, wantErr %v", err, tt.wantErr)

				return
			}

			assert.Equal(t, tt.want, tt.sp)
		})
	}
}
