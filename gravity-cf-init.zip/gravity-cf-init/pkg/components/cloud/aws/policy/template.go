package policy

import (
	"embed"
	"encoding/json"
	"errors"
	"fmt"
)

var ErrUnknownServiceControlPolicy = errors.New("unknown service control policy")

//go:embed templates
var policyTemplates embed.FS

// ServiceControlPolicyTemplate is a validated template type for service control policies, their templates can be found in the template directory.
type ServiceControlPolicyTemplate int

const (
	// an Unknown Policy Template.
	ServiceControlPolicyUnknown ServiceControlPolicyTemplate = iota
	// maps to templates/FullAccess.json.tmpl.
	ServiceControlPolicyFullAccess
	// maps to templates/GuardRails-Part0-CoreOUs.json.tmpl.
	ServiceControlPolicyGuardRailsPart0CoreOUs
	// maps to templates/GuardRails-Part0-WrkldOUs.json.tmpl.
	ServiceControlPolicyGuardRailsPart0WrkldOUs
	// maps to templates/GuardRails-Part1.json.tmpl.
	ServiceControlPolicyGuardRailsPart1
	// maps to templates/Sandbox.json.tmpl.
	ServiceControlPolicySandbox
	// maps to templates/Unclass.json.tmpl.
	ServiceControlPolicyUnclass
	// maps to templates/Sensitive.json.tmpl.
	ServiceControlPolicySensitive
	// maps to templates/Quarantine.json.tmpl.
	ServiceControlPolicyQuarantine
)

// String converts a ServiceControlPolicyTemplate to string.
func (sc ServiceControlPolicyTemplate) String() string {
	policies := []string{
		"Unknown Policy",
		"FullAccess",
		"GuardRails-Part0-CoreOUs",
		"GuardRails-Part0-WrkldOUs",
		"GuardRails-Part1",
		"Sandbox",
		"Unclass",
		"Sensitive",
		"Quarantine",
	}

	if !sc.isValid() {
		return policies[0]
	}

	return policies[sc]
}

// FromString sets a ServiceControlPolicyTemplate from a given string.
func (sc *ServiceControlPolicyTemplate) FromString(str string) {
	var policy ServiceControlPolicyTemplate

	policy, foundKey := map[string]ServiceControlPolicyTemplate{
		"Unknown Policy":            ServiceControlPolicyUnknown,
		"FullAccess":                ServiceControlPolicyFullAccess,
		"GuardRails-Part0-CoreOUs":  ServiceControlPolicyGuardRailsPart0CoreOUs,
		"GuardRails-Part0-WrkldOUs": ServiceControlPolicyGuardRailsPart0WrkldOUs,
		"GuardRails-Part1":          ServiceControlPolicyGuardRailsPart1,
		"Sandbox":                   ServiceControlPolicySandbox,
		"Unclass":                   ServiceControlPolicyUnclass,
		"Sensitive":                 ServiceControlPolicySensitive,
		"Quarantine":                ServiceControlPolicyQuarantine,
	}[str]
	if !foundKey {
		policy = ServiceControlPolicyUnknown
	}

	*sc = policy
}

// is valid checks to see if the given ServiceProfileTemplate is a valid template.
func (sc ServiceControlPolicyTemplate) isValid() bool {
	if sc > ServiceControlPolicyUnknown && sc <= ServiceControlPolicyQuarantine {
		return true
	}

	return false
}

// MarshalJSON implements the Marshaller interface to dictate how ServiceProfileTemplates get marshaled to JSON.
func (sc ServiceControlPolicyTemplate) MarshalJSON() ([]byte, error) {
	if !sc.isValid() {
		return nil, ErrUnknownServiceControlPolicy
	}

	b, err := json.Marshal(sc.String())
	if err != nil {
		return nil, fmt.Errorf("unable to marshal `%s` to json, %w", sc, err)
	}

	return b, nil
}

// UnmarshalJSON implements the Unmarshaller interface to dictate how ServiceProfileTemplates get unmarshaled from JSON.
func (sc *ServiceControlPolicyTemplate) UnmarshalJSON(b []byte) error {
	var s string
	if err := json.Unmarshal(b, &s); err != nil {
		return fmt.Errorf("unable to unmarshal `%s` from json, %w", b, err)
	}

	sc.FromString(s)

	if !sc.isValid() {
		return ErrUnknownServiceControlPolicy
	}

	return nil
}

// getDescription generates a description for a ServiceProfileTemplate.
func (sc ServiceControlPolicyTemplate) getDescription() string {
	descriptions := map[ServiceControlPolicyTemplate]string{
		ServiceControlPolicyFullAccess:              "Full AWS Access",
		ServiceControlPolicyGuardRailsPart0CoreOUs:  "LZA Guardrails Part 0 Core Accounts",
		ServiceControlPolicyGuardRailsPart0WrkldOUs: "LZA Guardrails Part 0 Workload Accounts",
		ServiceControlPolicyGuardRailsPart1:         "LZA Guardrails Part 1",
		ServiceControlPolicySandbox:                 "LZA Guardrails Sandbox Environment Specific",
		ServiceControlPolicyUnclass:                 "LZA Guardrails Unclassified Environment Specific",
		ServiceControlPolicySensitive:               "LZA Guardrails Sensitive Environment Specific",
		ServiceControlPolicyQuarantine:              "LZA Quarantine policy - Apply to ACCOUNTS that need to be quarantined",
	}

	return descriptions[sc]
}
