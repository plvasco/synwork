package policy_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/policy"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewServiceControlPolicy(t *testing.T) {
	t.Parallel()

	type want struct {
		ServiceControlPolicyName policy.ServiceControlPolicyTemplate
	}

	type args struct {
		name string
		args *policy.ServiceControlPolicyArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create guard rails part 1 service control policy resource",
			in: args{
				name: policy.ServiceControlPolicyGuardRailsPart1.String(),
				args: &policy.ServiceControlPolicyArgs{
					TemplateName:                policy.ServiceControlPolicyGuardRailsPart1,
					TargetOUs:                   []string{"infrastructure"},
					AcceleratorPrefix:           pulumi.String("test"),
					ManagementAccountAccessRole: pulumi.String("OrganizationAccountAccessRole"),
					Tags:                        pulumi.ToStringMap(map[string]string{"test": "test"}),
				},
			},
			want: want{
				ServiceControlPolicyName: policy.ServiceControlPolicyGuardRailsPart1,
			},
			wantErr: false,
		},
		{
			name: "should error when TemplateName is not defined",
			in: args{
				name: "unknown-policy",
				args: &policy.ServiceControlPolicyArgs{
					TargetOUs:                   []string{"infrastructure"},
					AcceleratorPrefix:           pulumi.String("test"),
					ManagementAccountAccessRole: pulumi.String("OrganizationAccountAccessRole"),
					Tags:                        pulumi.ToStringMap(map[string]string{"test": "test"}),
				},
			},
			wantErr: true,
		},
		{
			name: "should error when AccleratorPrefix is not defined",
			in: args{
				name: "unknown-policy",
				args: &policy.ServiceControlPolicyArgs{
					TemplateName:                policy.ServiceControlPolicyFullAccess,
					TargetOUs:                   []string{"infrastructure"},
					ManagementAccountAccessRole: pulumi.String("OrganizationAccountAccessRole"),
					Tags:                        pulumi.ToStringMap(map[string]string{"test": "test"}),
				},
			},
			wantErr: true,
		},
		{
			name: "should error when ManagementAccountAccessRole is not defined",
			in: args{
				name: "unknown-policy",
				args: &policy.ServiceControlPolicyArgs{
					TemplateName:      policy.ServiceControlPolicyFullAccess,
					TargetOUs:         []string{"infrastructure"},
					AcceleratorPrefix: pulumi.String("test"),
					Tags:              pulumi.ToStringMap(map[string]string{"test": "test"}),
				},
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := policy.NewServiceControlPolicy(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				output := got.PolicyID.ApplyT(func(policyID pulumi.ID) pulumi.ID {
					assert.Equal(t, pulumi.ID(tt.in.name+"-policy_id"), policyID)

					return policyID
				})
				require.NotNil(t, output)

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
