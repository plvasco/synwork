package rds

import (
	"fmt"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/kms"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/rds"
	"github.com/pulumi/pulumi-random/sdk/v4/go/random"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const auroraClusterComponentName = "gravity:aws:rds:auroraCluster"

type AuroraCluster struct {
	pulumi.ResourceState
	ID              pulumi.StringOutput `pulumi:"id"`              // Database cluster id.
	Endpoint        pulumi.StringOutput `pulumi:"endpoint"`        // Address of cluster endpoint.
	Password        pulumi.StringOutput `pulumi:"password"`        // Password for the created database.
	SecurityGroupID pulumi.StringOutput `pulumi:"securityGroupID"` // ID of SecurityGroup used for cluster traffic.
	SubnetGroupName pulumi.StringOutput `pulumi:"subnetGroupName"` // Name of subnet group used in cluster creation.
	Engine          pulumi.StringOutput `pulumi:"engine"`          // Name of database engine.
	EngineVersion   pulumi.StringOutput `pulumi:"engineVersion"`   // Database engine version.
}

type AuroraClusterArgs struct {
	SourceSecurityGroupID pulumi.StringInput                    `pulumi:"sourceSecurityGroupID" validate:"required"`      // Security group id to allow access to/from.
	VpcID                 pulumi.StringInput                    `pulumi:"vpcID"                 validate:"required"`      // VPC id where cluster will live.
	SubnetIDs             pulumi.StringArray                    `pulumi:"subnetIDs"             validate:"required"`      // Subnet IDs
	EnableBackups         pulumi.BoolInput                      `pulumi:"enableBackups"         validate:"default=false"` // Enable Cluster Backups.
	AllocatedStorage      pulumi.IntInput                       `pulumi:"allocatedStorage"`                               // The amount of storage in gibibytes (GiB) to allocate to each DB instance in the Multi-AZ DB cluster.
	ClusterIdentifier     pulumi.StringInput                    `pulumi:"clusterIdentifier"`                              // The cluster identifier. If omitted, this provider will assign a random, unique identifier.
	DatabaseName          pulumi.StringInput                    `pulumi:"databaseName"`                                   // Name for an automatically created database on cluster creation. If omitted no database will be created.
	Engine                pulumi.StringInput                    `pulumi:"engine"                validate:"required"`      // Name of the database engine to be used for this DB cluster. Valid Values: `aurora-mysql`, `aurora-postgresql`, `mysql`, `postgres`. (Note that `mysql` and `postgres` are Multi-AZ RDS clusters).
	EngineVersion         pulumi.StringInput                    `pulumi:"engineVersion"`                                  // Database engine version. Updating this argument results in an outage.
	Password              pulumi.StringInput                    `pulumi:"password"`                                       // Password for the master DB user. Note that this may show up in logs, and it will be stored in the state file.
	Username              pulumi.StringInput                    `pulumi:"username"              validate:"required"`      // Username for the master DB user.
	Port                  pulumi.IntInput                       `pulumi:"port"                  validate:"required"`      // Port on which the DB accepts connections.
	ClusterInstances      map[string]*AuroraClusterInstanceArgs `pulumi:"clusterInstances"`                               // Map of cluster instances to create
	ParameterGroup        *ParameterGroupArgs                   `pulumi:"parameterGroup"`                                 // Parameter Group options
	Tags                  pulumi.StringMap                      `pulumi:"tags"`                                           // A map of tags to assign to the DB cluster.
}

type AuroraClusterInstanceArgs struct {
	// Instance class to use. For details on CPU and memory, see [Scaling Aurora DB Instances](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Aurora.Managing.html). Aurora uses `db.*` instance classes/types. Please see [AWS Documentation](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Concepts.DBInstanceClass.html) for currently available instance classes and complete details. For Aurora Serverless v2 use `db.serverless`.
	InstanceClass pulumi.StringInput `pulumi:"instanceClass"`
	// Parameter Group options
	ParameterGroup *ParameterGroupArgs `pulumi:"parameterGroup"`
	// A map of tags to assign to the DB cluster instance. If configured with a provider `defaultTags` configuration block present, tags with matching keys will overwrite those defined at the provider-level.
	Tags pulumi.StringMap `pulumi:"tags"`
}

func NewAuroraCluster(ctx *pulumi.Context, name string, args *AuroraClusterArgs, opts ...pulumi.ResourceOption) (*AuroraCluster, error) {
	component := &AuroraCluster{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(auroraClusterComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", auroraClusterComponentName, name, err)
	}

	if err := component.createCluster(ctx, name+"-cluster", args); err != nil {
		return nil, err
	}

	if err := component.createAuroraClusterInstances(ctx, name+"-instance", args); err != nil {
		return nil, fmt.Errorf("unable to create aurora cluster instances for `%s`, %w", name, err)
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"id":       component.ID,
		"endpoint": component.Endpoint,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", auroraClusterComponentName, name, err)
	}

	return component, nil
}
func (c *AuroraCluster) createCluster(ctx *pulumi.Context, name string, args *AuroraClusterArgs) error {
	if args.Password == nil {
		password, err := random.NewRandomPassword(ctx, name+"-password", &random.RandomPasswordArgs{
			Length:          pulumi.Int(16),
			Special:         pulumi.Bool(false),
			OverrideSpecial: pulumi.String(fmt.Sprintf("_%v@", "%")),
		}, pulumi.Parent(c), pulumi.AdditionalSecretOutputs([]string{"result"}))
		if err != nil {
			return fmt.Errorf("unable to create random password for `%s`, %w", name, err)
		}

		args.Password = password.Result
	}

	retentionPeriod := pulumix.Apply(args.EnableBackups.ToBoolOutput(), func(enabled bool) int {
		if enabled {
			return int(backupRetentionPeriod)
		}

		return 1
	})

	var pgGroupName pulumi.StringInput

	if args.ParameterGroup != nil {
		args.ParameterGroup.Tags = utils.CombineTags(args.Tags, args.ParameterGroup.Tags)

		p, err := c.makeParameterGroup(ctx, name+"-param-group", args.ParameterGroup)
		if err != nil {
			return fmt.Errorf("unable to create cluster parameter group for `%s`, %w", name, err)
		}

		pgGroupName = p
	}

	subnetGroup, err := rds.NewSubnetGroup(ctx, name, &rds.SubnetGroupArgs{
		Description: pulumi.String("Managed By Pulumi"),
		SubnetIds:   args.SubnetIDs,
		Tags:        utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create subnet group for %s, %w", name, err)
	}

	securityGroup, err := makeSecurityGroup(ctx, name, &databaseSecurityGroupArgs{
		Port:            args.Port,
		SecurityGroupID: args.SourceSecurityGroupID,
		VpcID:           args.VpcID,
		Tags:            map[string]pulumi.StringInput{},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	newCluster, err := rds.NewCluster(ctx, name, &rds.ClusterArgs{
		AllocatedStorage:                 args.AllocatedStorage,
		BackupRetentionPeriod:            pulumix.Cast[pulumi.IntOutput](retentionPeriod),
		ClusterIdentifier:                args.ClusterIdentifier,
		CopyTagsToSnapshot:               pulumi.Bool(true),
		DatabaseName:                     args.DatabaseName,
		DbSubnetGroupName:                subnetGroup.Name,
		DbClusterParameterGroupName:      pgGroupName,
		DeletionProtection:               args.EnableBackups,
		EnabledCloudwatchLogsExports:     getCloudWatchLogExports(args.Engine),
		Engine:                           args.Engine,
		EngineVersion:                    args.EngineVersion,
		IamDatabaseAuthenticationEnabled: pulumi.Bool(true),
		KmsKeyId:                         kms.LookupKeyOutput(ctx, kms.LookupKeyOutputArgs{KeyId: pulumi.String("alias/encryption-key")}, pulumi.Parent(c)).Arn(),
		MasterPassword:                   args.Password,
		MasterUsername:                   args.Username,
		Port:                             args.Port,
		PreferredBackupWindow:            backupWindow,
		PreferredMaintenanceWindow:       maintenanceWindow,
		SkipFinalSnapshot:                pulumi.Bool(true),
		StorageEncrypted:                 pulumi.Bool(true),
		Tags:                             args.Tags,
		VpcSecurityGroupIds:              pulumi.StringArray{securityGroup.ID},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create aurora cluster `%s`, %w", name, err)
	}

	c.ID = newCluster.ID().ToStringOutput()
	c.Endpoint = newCluster.Endpoint
	c.Password = newCluster.MasterPassword.Elem()
	c.Engine = newCluster.Engine
	c.EngineVersion = newCluster.EngineVersionActual
	c.SecurityGroupID = securityGroup.ID.ToStringOutput()
	c.SubnetGroupName = subnetGroup.Name

	return nil
}

func (c *AuroraCluster) createAuroraClusterInstances(ctx *pulumi.Context, name string, args *AuroraClusterArgs) error {
	// Create Aurora Cluster Instances
	for instanceName, instanceArgs := range args.ClusterInstances {
		if err := c.createAuroraClusterInstance(ctx, name+"-"+instanceName, instanceArgs); err != nil {
			return fmt.Errorf("unable to create aurora cluster instance `%s`, %w", instanceName, err)
		}
	}

	return nil
}

func (c *AuroraCluster) createAuroraClusterInstance(ctx *pulumi.Context, name string, args *AuroraClusterInstanceArgs) error {
	var pgGroupName pulumi.StringInput

	if args.ParameterGroup != nil {
		p, err := c.makeParameterGroup(ctx, name+"-param-group", args.ParameterGroup)
		if err != nil {
			return fmt.Errorf("unable to create cluster parameter group for `%s`, %w", name, err)
		}

		pgGroupName = p
	}

	_, err := rds.NewClusterInstance(ctx, name, &rds.ClusterInstanceArgs{
		ClusterIdentifier:          c.ID,
		CopyTagsToSnapshot:         pulumi.Bool(true),
		DbParameterGroupName:       pgGroupName,
		DbSubnetGroupName:          c.SubnetGroupName,
		Engine:                     c.Engine,
		EngineVersion:              c.EngineVersion,
		IdentifierPrefix:           pulumi.String(name),
		InstanceClass:              args.InstanceClass,
		PreferredBackupWindow:      backupWindow,
		PreferredMaintenanceWindow: maintenanceWindow,
		PubliclyAccessible:         pulumi.Bool(false),
		Tags:                       utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create aurora cluster instance `%s`, %w", name, err)
	}

	return nil
}

func (c *AuroraCluster) makeParameterGroup(ctx *pulumi.Context, name string, args *ParameterGroupArgs) (pulumi.StringOutput, error) {
	parameterGroup, err := rds.NewClusterParameterGroup(ctx, strings.ToLower(name+"-param-group"), &rds.ClusterParameterGroupArgs{
		Description: args.Description,
		Family:      args.Family,
		NamePrefix:  pulumi.String(name),
		Parameters: func() rds.ClusterParameterGroupParameterArrayInput {
			parameterList := rds.ClusterParameterGroupParameterArray{}
			for _, parameter := range args.Parameters {
				p := &rds.ClusterParameterGroupParameterArgs{
					Name:  parameter.Name,
					Value: parameter.Value,
				}

				parameterList = append(parameterList, p)
			}

			return parameterList
		}(),
		Tags: utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return pulumi.String("").ToStringOutput(), fmt.Errorf("unable to create custom db parameter group, %w", err)
	}

	return parameterGroup.Name.ToStringOutput(), nil
}

func (args *AuroraClusterArgs) validate() error {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	if args.ClusterInstances != nil {
		for name, instance := range args.ClusterInstances {
			if err := instance.validate(); err != nil {
				return fmt.Errorf("%s: %w", name, err)
			}
		}
	}

	return nil
}

func (args *AuroraClusterArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (args *AuroraClusterInstanceArgs) validate() error {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	return nil
}

func (args *AuroraClusterInstanceArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
