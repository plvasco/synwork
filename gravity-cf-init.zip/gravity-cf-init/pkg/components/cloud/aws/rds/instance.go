package rds

import (
	"fmt"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/kms"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/rds"
	"github.com/pulumi/pulumi-random/sdk/v4/go/random"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const instanceComponentName = "gravity:aws:rds:instance"

type Instance struct {
	pulumi.ResourceState
	ID              pulumi.StringOutput `pulumi:"id"`              // Instance ID
	Endpoint        pulumi.StringOutput `pulumi:"endpoint"`        // Address for Instance Endpoint.
	Password        pulumi.StringOutput `pulumi:"password"`        // Password for created Instance.
	SecurityGroupID pulumi.StringOutput `pulumi:"securityGroupID"` // ID of SecurityGroup used for cluster traffic.
	SubnetGroupName pulumi.StringOutput `pulumi:"subnetGroupName"` // Name of subnet group used in cluster creation.
}

type InstanceArgs struct {
	SourceSecurityGroupID      pulumi.StringInput  `pulumi:"sourceSecurityGroupID"      validate:"required"`      // Security group id to allow access to/from.
	SubnetIDs                  pulumi.StringArray  `pulumi:"subnetIDs"                  validate:"required"`      // Subnet IDs to build instance on.
	VpcID                      pulumi.StringInput  `pulumi:"vpcID"                      validate:"required"`      // VPC id where cluster will live.
	EnableBackups              pulumi.BoolInput    `pulumi:"enableBackups"              validate:"default=false"` // Enable Cluster Backups.
	AllocatedStorage           pulumi.IntInput     `pulumi:"allocatedStorage"`                                    // The allocated storage in gibibytes.
	ReadReplicas               pulumi.IntInput     `pulumi:"readReplicas"               validate:"default=0"`     // Amount of read replicas to make.
	ParameterGroup             *ParameterGroupArgs `pulumi:"parameterGroup"`                                      // Parameter group args (see struct for more details).
	DBName                     pulumi.StringInput  `pulumi:"dbName"`                                              // The name of the database to create when the DB instance is created.
	Engine                     pulumi.StringInput  `pulumi:"engine"`                                              // The database engine to use. For supported values, see the Engine parameter in [API action CreateDBInstance](https://docs.aws.amazon.com/AmazonRDS/latest/APIReference/API_CreateDBInstance.html).
	EngineVersion              pulumi.StringInput  `pulumi:"engineVersion"`                                       // The engine version to use.
	InstanceClass              pulumi.StringInput  `pulumi:"instanceClass"`                                       // The instance type of the RDS instance.
	Username                   pulumi.StringInput  `pulumi:"username"                   validate:"required"`      //  Username for the master DB user. Cannot be specified for a replica.
	Password                   pulumi.StringInput  `pulumi:"password"`                                            // Password for the master DB user. Note that this may show up in logs, and it will be stored in the state file.
	MaxAllocatedStorage        pulumi.IntInput     `pulumi:"maxAllocatedStorage"`                                 // When configured, the upper limit to which Amazon RDS can automatically scale the storage of the DB instance. Configuring this will automatically ignore differences to `allocatedStorage`. Must be greater than or equal to `allocatedStorage` or `0` to disable Storage Autoscaling.
	OptionGroupName            pulumi.StringInput  `pulumi:"optionGroupName"`                                     // Name of the DB option group to associate.
	PerformanceInsightsEnabled pulumi.BoolInput    `pulumi:"performanceInsightsEnabled"`                          // Specifies whether Performance Insights are enabled. Defaults to false.
	Port                       pulumi.IntInput     `pulumi:"port"`                                                // The port on which the DB accepts connections.
	StorageType                pulumi.StringInput  `pulumi:"storageType"`                                         // One of "standard" (magnetic), "gp2" (general purpose SSD), "gp3" (general purpose SSD that needs `iops` independently) "io1" (provisioned IOPS SSD) or "io2" (block express storage provisioned IOPS SSD). The default is "io1" if `iops` is specified, "gp2" if not.
	SnapshotARN                pulumi.StringInput  `pulumi:"snapshotARN"`                                         // ARN of snapshot to restore from. (only required if restoring from backup)
	// The amount of provisioned IOPS. Setting this implies a
	// storageType of "io1" or "io2". Can only be set when `storageType` is `"io1"`, `"io2` or `"gp3"`.
	// Cannot be specified for gp3 storage if the `allocatedStorage` value is below a per-`engine` threshold.
	// See the [RDS User Guide](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_Storage.html#gp3-storage) for details.
	Iops pulumi.IntInput `pulumi:"iops"`
	// License model information for this DB instance. Valid values for this field are as follows:
	// * RDS for MariaDB: `general-public-license`
	// * RDS for Microsoft SQL Server: `license-included`
	// * RDS for MySQL: `general-public-license`
	// * RDS for Oracle: `bring-your-own-license | license-included`
	// * RDS for PostgreSQL: `postgresql-license`
	LicenseModel pulumi.StringInput `pulumi:"licenseModel"`
	Tags         pulumi.StringMap   `pulumi:"tags"` // A map of tags to assign to the resource. If configured with a provider `defaultTags` configuration block present, tags with matching keys will overwrite those defined at the provider-level.
}

func NewInstance(ctx *pulumi.Context, name string, args *InstanceArgs, opts ...pulumi.ResourceOption) (*Instance, error) {
	component := &Instance{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(instanceComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", instanceComponentName, name, err)
	}

	if err := component.createInstance(ctx, name+"-instance", args); err != nil {
		return nil, err
	}

	component.createReadReplicas(ctx, name+"-replica", args)

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"id":       component.ID,
		"endpoint": component.Endpoint,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", rdsComponentName, name, err)
	}

	return component, nil
}

func (c *Instance) createInstance(ctx *pulumi.Context, name string, args *InstanceArgs) error {
	if args.Password == nil {
		password, err := random.NewRandomPassword(ctx, name+"-password", &random.RandomPasswordArgs{
			Length:          pulumi.Int(16),
			Special:         pulumi.Bool(false),
			OverrideSpecial: pulumi.String(fmt.Sprintf("_%v@", "%")),
		}, pulumi.Parent(c), pulumi.AdditionalSecretOutputs([]string{"result"}))
		if err != nil {
			return fmt.Errorf("unable to create random password for `%s`, %w", name, err)
		}

		args.Password = password.Result
	}

	retentionPeriod := pulumix.Apply(args.EnableBackups.ToBoolOutput(), func(enabled bool) int {
		if enabled {
			return int(backupRetentionPeriod)
		}

		return 1
	})

	var pgGroupNamme pulumi.StringInput

	if args.ParameterGroup != nil {
		p, err := c.makeParameterGroup(ctx, name, args.ParameterGroup)
		if err != nil {
			return fmt.Errorf("unable to create cluster parameter group for `%s`, %w", name, err)
		}

		pgGroupNamme = p
	}

	subnetGroup, err := rds.NewSubnetGroup(ctx, name, &rds.SubnetGroupArgs{
		Description: pulumi.String("Managed By Pulumi"),
		SubnetIds:   args.SubnetIDs,
		Tags:        utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create subnet group for %s, %w", name, err)
	}

	securityGroup, err := makeSecurityGroup(ctx, name, &databaseSecurityGroupArgs{
		Port:            args.Port,
		SecurityGroupID: args.SourceSecurityGroupID,
		VpcID:           args.VpcID,
		Tags:            map[string]pulumi.StringInput{},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	newInstance, err := rds.NewInstance(ctx, name, &rds.InstanceArgs{
		AllocatedStorage:             args.AllocatedStorage,
		BackupRetentionPeriod:        pulumix.Cast[pulumi.IntOutput](retentionPeriod),
		BackupWindow:                 backupWindow,
		CopyTagsToSnapshot:           pulumi.Bool(true),
		DbName:                       args.DBName,
		DbSubnetGroupName:            subnetGroup.Name,
		DeleteAutomatedBackups:       pulumi.Bool(true),
		DeletionProtection:           args.EnableBackups,
		EnabledCloudwatchLogsExports: getCloudWatchLogExports(args.Engine.ToStringPtrOutput().Elem()),
		Engine:                       args.Engine,
		EngineVersion:                args.EngineVersion,
		Iops:                         args.Iops,
		InstanceClass:                args.InstanceClass,
		KmsKeyId:                     kms.LookupKeyOutput(ctx, kms.LookupKeyOutputArgs{KeyId: pulumi.String("alias/encryption-key")}, pulumi.Parent(c)).Arn(),
		LicenseModel:                 args.LicenseModel,
		MaintenanceWindow:            maintenanceWindow,
		MaxAllocatedStorage:          args.MaxAllocatedStorage,
		MultiAz:                      pulumi.Bool(true),
		OptionGroupName:              args.OptionGroupName,
		ParameterGroupName:           pgGroupNamme,
		Password:                     args.Password,
		PerformanceInsightsEnabled:   args.PerformanceInsightsEnabled,
		Port:                         args.Port,
		PubliclyAccessible:           pulumi.Bool(false),
		ReplicateSourceDb:            args.SnapshotARN,
		StorageEncrypted:             pulumi.Bool(true),
		StorageType:                  args.StorageType,
		Tags:                         args.Tags,
		Username:                     args.Username,
		VpcSecurityGroupIds:          pulumi.StringArray{securityGroup.ID},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create rds instance `%s`, %w", name, err)
	}

	c.ID = newInstance.ID().ToStringOutput()
	c.Endpoint = newInstance.Endpoint
	c.Password = newInstance.Password.Elem()
	c.SecurityGroupID = securityGroup.ID.ToStringOutput()
	c.SubnetGroupName = subnetGroup.Name

	return nil
}

func (c *Instance) createReadReplica(ctx *pulumi.Context, name string, args *InstanceArgs) error {
	_, err := rds.NewInstance(ctx, name, &rds.InstanceArgs{
		InstanceClass:          args.InstanceClass,
		MaxAllocatedStorage:    args.MaxAllocatedStorage,
		DeleteAutomatedBackups: pulumi.Bool(true),
		DeletionProtection:     pulumi.Bool(false),
		Password:               args.Password,
		PubliclyAccessible:     pulumi.Bool(false),
		SkipFinalSnapshot:      pulumi.Bool(true),
		StorageEncrypted:       pulumi.Bool(true),
		StorageType:            args.StorageType,
		VpcSecurityGroupIds:    pulumi.StringArray{c.SecurityGroupID},
		ReplicateSourceDb:      c.ID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create rds instance read replica, %w", err)
	}

	return nil
}

func (c *Instance) createReadReplicas(ctx *pulumi.Context, name string, args *InstanceArgs) {
	pulumix.ApplyErr(args.ReadReplicas.ToIntOutput(), func(replicas int) (bool, error) {
		for replica := range replicas {
			if err := c.createReadReplica(ctx, fmt.Sprintf("%s-%d", name, replica), args); err != nil {
				return false, fmt.Errorf("unable to create rds instance read replicas `%s-%d`, %w", name, replica, err)
			}
		}

		return true, nil
	})
}

func (c *Instance) makeParameterGroup(ctx *pulumi.Context, name string, args *ParameterGroupArgs) (pulumi.StringOutput, error) {
	parameterGroup, err := rds.NewParameterGroup(ctx, strings.ToLower(name+"-param-group"), &rds.ParameterGroupArgs{
		Description: args.Description,
		Family:      args.Family,
		NamePrefix:  pulumi.String(name),
		Parameters: func() rds.ParameterGroupParameterArrayInput {
			parameterList := rds.ParameterGroupParameterArray{}
			for _, parameter := range args.Parameters {
				p := &rds.ParameterGroupParameterArgs{
					Name:  parameter.Name,
					Value: parameter.Value,
				}

				parameterList = append(parameterList, p)
			}

			return parameterList
		}(),
		Tags: utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return pulumi.String("").ToStringOutput(), fmt.Errorf("unable to create custom db parameter group, %w", err)
	}

	return parameterGroup.Name.ToStringOutput(), nil
}

func (args *InstanceArgs) validate() error {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	return nil
}

func (args *InstanceArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
