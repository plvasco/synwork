package rds_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/rds"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewAuroraCluster(t *testing.T) {
	t.Parallel()

	type want struct {
		ID              string
		Endpoint        string
		Password        string
		SecurityGroupID string
	}

	type in struct {
		name string
		args *rds.AuroraClusterArgs
	}

	testCases := []struct {
		name    string
		in      *in
		want    want
		wantErr bool
	}{
		{
			name: "test should create Aurora Cluster",
			in: &in{
				name: "aurora-test",
				args: &rds.AuroraClusterArgs{
					ClusterIdentifier:     pulumi.String("test-auroraCluster-ID"),
					SourceSecurityGroupID: pulumi.String("test-securityGroup"),
					DatabaseName:          pulumi.String("test-auroraCluster-db"),
					SubnetIDs: pulumi.StringArray{
						pulumi.String("subnet-1"),
						pulumi.String("subnet-2"),
						pulumi.String("subnet-3"),
					},
					Engine:        pulumi.String("aurora-mysql"),
					EngineVersion: pulumi.String("8.0.mysql_aurora.3.05.2"),
					Password:      pulumi.String("password"),
					Username:      pulumi.String("testUser"),
					Port:          pulumi.Int(3306),
					ParameterGroup: &rds.ParameterGroupArgs{
						Family: pulumi.String("aurora-mysql8.0"),
						Parameters: []*rds.Parameter{
							{
								Name:  pulumi.String("max_allowed_packet"),
								Value: pulumi.String("1073741824"),
							},
						},
					},

					ClusterInstances: map[string]*rds.AuroraClusterInstanceArgs{
						"testInstance1": {
							InstanceClass: pulumi.String("db.t4g.medium"),
							ParameterGroup: &rds.ParameterGroupArgs{
								Family: pulumi.String("aurora-mysql8.0"),
								Parameters: []*rds.Parameter{
									{
										Name:  pulumi.String("max_allowed_packet"),
										Value: pulumi.String("1073741824"),
									},
								},
							},
						},
					},
					VpcID: pulumi.String("vpc-123456789"),
					Tags: pulumi.StringMap{
						"environment": pulumi.String("dev"),
					},
				},
			},
			want: want{
				ID:              "aurora-test-cluster_id",
				Endpoint:        "mockauraoracluster.db.x10d",
				Password:        "password",
				SecurityGroupID: "aurora-test-cluster-traffic-sg_id",
			},
			wantErr: false,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := rds.NewAuroraCluster(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.ID.ApplyT(func(id string) string {
					assert.Equal(t, tc.want.ID, id)

					return id
				})

				got.Endpoint.ApplyT(func(endpoint string) string {
					assert.Equal(t, tc.want.Endpoint, endpoint)

					return endpoint
				})

				got.Password.ApplyT(func(p string) string {
					assert.Equal(t, tc.want.Password, p)

					return p
				})

				got.SecurityGroupID.ApplyT(func(p string) string {
					assert.Equal(t, tc.want.SecurityGroupID, p)

					return p
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewAuroraCluster() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestAuroraClusterArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *rds.AuroraClusterArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"sourceSecurityGroupID": "sg-12345",
				"vpcID": "vpc-67890",
				"subnetIDs": ["subnet-11111", "subnet-22222"],
				"enableBackups": true,
				"allocatedStorage": 100,
				"clusterIdentifier": "aurora-cluster-1",
				"databaseName": "exampledb",
				"engine": "aurora-mysql",
				"engineVersion": "5.7.mysql_aurora.2.10.2",
				"password": "examplepassword",
				"username": "admin",
				"port": 3306,
				"clusterInstances": {
					"instance-1": {
						"instanceClass": "db.t4g.medium",
						"parameterGroup": {
							"family": "aurora-mysql8.0"
						},
						"tags": {
							"env": "production",
							"team": "database"
						}
					}
				},
				"parameterGroup": {
					"family": "aurora-mysql8.0"
				},
				"tags": {
					"env": "production",
					"team": "rds"
				}
			}`,
			want: &rds.AuroraClusterArgs{
				SourceSecurityGroupID: pulumi.String("sg-12345"),
				VpcID:                 pulumi.String("vpc-67890"),
				SubnetIDs:             pulumi.StringArray{pulumi.String("subnet-11111"), pulumi.String("subnet-22222")},
				EnableBackups:         pulumi.Bool(true),
				AllocatedStorage:      pulumi.Int(100),
				ClusterIdentifier:     pulumi.String("aurora-cluster-1"),
				DatabaseName:          pulumi.String("exampledb"),
				Engine:                pulumi.String("aurora-mysql"),
				EngineVersion:         pulumi.String("5.7.mysql_aurora.2.10.2"),
				Password:              pulumi.String("examplepassword"),
				Username:              pulumi.String("admin"),
				Port:                  pulumi.Int(3306),
				ClusterInstances: map[string]*rds.AuroraClusterInstanceArgs{
					"instance-1": {
						InstanceClass: pulumi.String("db.t4g.medium"),
						ParameterGroup: &rds.ParameterGroupArgs{
							Family: pulumi.String("aurora-mysql8.0"),
						},
						Tags: pulumi.StringMap{
							"env":  pulumi.String("production"),
							"team": pulumi.String("database"),
						},
					},
				},
				ParameterGroup: &rds.ParameterGroupArgs{
					Family: pulumi.String("aurora-mysql8.0"),
				},
				Tags: pulumi.StringMap{
					"env":  pulumi.String("production"),
					"team": pulumi.String("rds"),
				},
			},
			wantErr: false,
		},
		{
			name:    "malformed JSON",
			input:   `{"sourceSecurityGroupID": "sg-12345", "vpcID": "vpc-67890",`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args rds.AuroraClusterArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}

func TestAuroraClusterInstanceArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *rds.AuroraClusterInstanceArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"instanceClass": "db.t4g.medium",
				"parameterGroup": {
					"family": "aurora-mysql8.0"
				},
				"tags": {
					"env": "production",
					"team": "database"
				}
			}`,
			want: &rds.AuroraClusterInstanceArgs{
				InstanceClass: pulumi.String("db.t4g.medium"),
				ParameterGroup: &rds.ParameterGroupArgs{
					Family: pulumi.String("aurora-mysql8.0"),
				},
				Tags: pulumi.StringMap{
					"env":  pulumi.String("production"),
					"team": pulumi.String("database"),
				},
			},
			wantErr: false,
		},
		{
			name: "malformed JSON",
			input: `{
				"instanceClass": "db.t4g.medium",
				"parameterGroup": {
					"family": true
				},
				"tags": {
					"env": "production",
					"team": "database"
				}
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args rds.AuroraClusterInstanceArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
