package rds

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const (
	backupWindow          = pulumi.String("05:00-06:00")
	maintenanceWindow     = pulumi.String("sun:03:00-sun:04:00")
	backupRetentionPeriod = pulumi.Int(7)
	rdsComponentName      = "gravity:aws:rds"
)

var (
	ErrRequiredArgumentEnvironmentTag        = errors.New("required argument for database environment tag is missing")
	ErrRequiredArgumentSourceSecurityGroupID = errors.New("required argument for database sourceSecurityGroupID is missing")
	ErrUnsupportedDBEngine                   = errors.New("unsupported DB engine type for log exports")
)

type Database struct {
	pulumi.ResourceState
	ID              pulumi.StringOutput `pulumi:"id"`
	Endpoint        pulumi.StringOutput `pulumi:"endpoint"`
	Password        pulumi.StringOutput `pulumi:"password"`
	SecurityGroupID pulumi.StringOutput `pulumi:"securityGroupID"`
}

type DatabaseArgs struct {
	// Security group id to allow access to/from.
	Cluster  *AuroraClusterArgs `pulumi:"cluster"`
	Instance *InstanceArgs      `pulumi:"instance"`
	Tags     pulumi.StringMap   `pulumi:"tags"`
}

func NewDatabase(ctx *pulumi.Context, name string, args *DatabaseArgs, opts ...pulumi.ResourceOption) (*Database, error) {
	component := &Database{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(rdsComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", rdsComponentName, name, err)
	}

	if args.Instance != nil {
		if err := component.createInstance(ctx, name+"-rds", args); err != nil {
			return nil, err
		}
	}

	if args.Cluster != nil {
		if err := component.createAuroraCluster(ctx, name+"-aurora", args); err != nil {
			return nil, err
		}
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"id":       component.ID,
		"endpoint": component.Endpoint,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", rdsComponentName, name, err)
	}

	ctx.Export(name+"-endpoint", component.Endpoint)
	ctx.Export(name+"-password", component.Password)

	return component, nil
}

func (c *Database) createInstance(ctx *pulumi.Context, name string, args *DatabaseArgs) error {
	args.Instance.Tags = utils.CombineTags(args.Tags, args.Instance.Tags)

	instance, err := NewInstance(ctx, name, args.Instance, pulumi.Parent(c))
	if err != nil {
		return err
	}

	c.ID = instance.ID
	c.Endpoint = instance.Endpoint
	c.Password = instance.Password
	c.SecurityGroupID = instance.SecurityGroupID

	return nil
}

func (c *Database) createAuroraCluster(ctx *pulumi.Context, name string, args *DatabaseArgs) error {
	args.Cluster.Tags = utils.CombineTags(args.Tags, args.Cluster.Tags)

	cluster, err := NewAuroraCluster(ctx, name, args.Cluster, pulumi.Parent(c))
	if err != nil {
		return err
	}

	c.ID = cluster.ID
	c.Endpoint = cluster.Endpoint
	c.Password = cluster.Password
	c.SecurityGroupID = cluster.SecurityGroupID

	return nil
}

func getCloudWatchLogExports(engine pulumi.StringInput) pulumi.StringArrayOutput {
	logExports, ok := engine.ToStringOutput().ApplyT(func(engineStr string) ([]string, error) {
		switch engineStr {
		case "mysql":
			return []string{"audit", "error", "general", "slowquery"}, nil
		case "sqlserver-se":
			return []string{"agent", "error"}, nil
		case "postgres":
			return []string{"postgresql", "upgrade"}, nil
		case "aurora-postgresql":
			return []string{"postgresql"}, nil
		case "mariadb":
			return []string{"audit", "error", "general", "slowquery"}, nil
		case "aurora-mysql":
			return []string{"audit", "error", "general", "slowquery"}, nil
		case "oracle":
			return []string{"audit", "alert", "trace", "listener"}, nil
		default:
			return nil, ErrUnsupportedDBEngine
		}
	}).(pulumi.StringArrayOutput)
	if !ok {
		panic("unable to generate DB log export configs")
	}

	return logExports
}

func (args *DatabaseArgs) validate() error {
	if args == nil {
		args = &DatabaseArgs{}
	}

	if args.Tags == nil {
		args.Tags = pulumi.ToStringMap(map[string]string{})
	}

	if _, ok := args.Tags["environment"]; !ok {
		return ErrRequiredArgumentEnvironmentTag
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	return nil
}

func (args *DatabaseArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal  %T, %w", args, err)
	}

	return nil
}
