package rds_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/rds"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewDatabase(t *testing.T) {
	t.Parallel()

	type want struct {
		ID              string
		Endpoint        string
		Password        string
		SecurityGroupID string
	}

	tests := []struct {
		name    string
		args    map[string]*rds.DatabaseArgs
		want    map[string]want
		wantErr bool
		focus   bool
	}{
		{
			name: "Test should create RDS Instances",
			args: map[string]*rds.DatabaseArgs{
				"testDB1": {
					Instance: &rds.InstanceArgs{
						SubnetIDs: pulumi.StringArray{
							pulumi.String("subnet-1"),
							pulumi.String("subnet-2"),
							pulumi.String("subnet-3"),
						},
						SourceSecurityGroupID: pulumi.String("sg-testing"),
						AllocatedStorage:      pulumi.Int(20),
						Engine:                pulumi.String("postgres"),
						EngineVersion:         pulumi.String("14.12"),
						Username:              pulumi.String("x10d"),
						InstanceClass:         pulumi.String("db.t4g.medium"),
						MaxAllocatedStorage:   pulumi.Int(100),
						OptionGroupName:       pulumi.String("default:postgres-14"),
						Port:                  pulumi.Int(5432),
						ReadReplicas:          pulumi.Int(3),
						VpcID:                 pulumi.String("vpc-123456789"),
						ParameterGroup: &rds.ParameterGroupArgs{
							Family: pulumi.String("postgres14"),
							Parameters: []*rds.Parameter{
								{
									Name:  pulumi.String("timezone"),
									Value: pulumi.String("US/Eastern"),
								},
							},
						},
					},
					Tags: pulumi.StringMap{
						"environment": pulumi.String("prd"),
					},
				},
			},
			want: map[string]want{
				"testDB1": {
					ID:              "testDB1-rds-instance_id",
					Endpoint:        "mockrdsinstance.db.x10d",
					Password:        "mockPass",
					SecurityGroupID: "testDB1-rds-instance-traffic-sg_id",
				},
			},
			wantErr: false,
		},
		{
			name: "test should create Aurora Cluster",
			args: map[string]*rds.DatabaseArgs{
				"testDB2": {
					Cluster: &rds.AuroraClusterArgs{
						SourceSecurityGroupID: pulumi.String("sg-testing"),
						ClusterIdentifier:     pulumi.String("test-auroraCluster-ID"),
						DatabaseName:          pulumi.String("test-auroraCluster-db"),
						SubnetIDs: pulumi.StringArray{
							pulumi.String("subnet-1"),
							pulumi.String("subnet-2"),
							pulumi.String("subnet-3"),
						},
						Engine:        pulumi.String("aurora-mysql"),
						EngineVersion: pulumi.String("8.0.mysql_aurora.3.05.2"),
						Password:      pulumi.String("password"),
						Username:      pulumi.String("testUser"),
						Port:          pulumi.Int(3306),
						ParameterGroup: &rds.ParameterGroupArgs{
							Family: pulumi.String("aurora-mysql8.0"),
							Parameters: []*rds.Parameter{
								{
									Name:  pulumi.String("max_allowed_packet"),
									Value: pulumi.String("1073741824"),
								},
							},
						},
						VpcID: pulumi.String("vpc-123456789"),
						ClusterInstances: map[string]*rds.AuroraClusterInstanceArgs{
							"testInstance1": {
								InstanceClass: pulumi.String("db.t4g.medium"),
								ParameterGroup: &rds.ParameterGroupArgs{
									Family: pulumi.String("aurora-mysql8.0"),
									Parameters: []*rds.Parameter{
										{
											Name:  pulumi.String("max_allowed_packet"),
											Value: pulumi.String("1073741824"),
										},
									},
								},
							},
						},
					},
					Tags: pulumi.StringMap{
						"environment": pulumi.String("dev"),
					},
				},
			},
			want: map[string]want{
				"testDB2": {
					ID:              "testDB2-aurora-cluster_id",
					Endpoint:        "mockauraoracluster.db.x10d",
					Password:        "password",
					SecurityGroupID: "testDB2-aurora-cluster-traffic-sg_id",
				},
			},
			wantErr: false,
		},
	}

	focused := false

	for _, tc := range tests {
		if tc.focus {
			focused = true

			break
		}
	}

	for _, tt := range tests {
		if focused && !tt.focus {
			continue
		}

		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				for dbName, dbConf := range tt.args {
					got, err := rds.NewDatabase(ctx, dbName, dbConf)
					if err != nil {
						return err
					}

					got.ID.ApplyT(func(id string) string {
						assert.Equal(t, tt.want[dbName].ID, id)

						return id
					})

					got.Endpoint.ApplyT(func(endpoint string) string {
						assert.Equal(t, tt.want[dbName].Endpoint, endpoint)

						return endpoint
					})

					got.Password.ApplyT(func(p string) string {
						assert.Equal(t, tt.want[dbName].Password, p)

						return p
					})

					got.SecurityGroupID.ApplyT(func(p string) string {
						assert.Equal(t, tt.want[dbName].SecurityGroupID, p)

						return p
					})
					require.NotNil(t, got)
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestDatabaseArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *rds.DatabaseArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"cluster": {
					"sourceSecurityGroupID": "sg-cluster-12345",
					"vpcID": "vpc-12345",
					"subnetIDs": ["subnet-11111"],
					"allocatedStorage": 100,
					"engine": "aurora-mysql",
					"engineVersion": "5.7.mysql_aurora.2.10.2",
					"username": "admin",
					"password": "password",
					"clusterInstances": {
						"instance-1": {
							"instanceClass": "db.t4g.medium",
							"tags": {
								"env": "production"
							}
						}
					},
					"tags": {"env": "production"}
				},
				"instance": {
					"sourceSecurityGroupID": "sg-instance-67890",
					"subnetIDs": ["subnet-22222"],
					"vpcID": "vpc-67890",
					"allocatedStorage": 50,
					"engine": "mysql",
					"engineVersion": "8.0.23",
					"instanceClass": "db.t3.medium",
					"tags": {"env": "staging"}
				},
				"tags": {"team": "rds", "project": "databases"}
			}`,
			want: &rds.DatabaseArgs{
				Cluster: &rds.AuroraClusterArgs{
					SourceSecurityGroupID: pulumi.String("sg-cluster-12345"),
					VpcID:                 pulumi.String("vpc-12345"),
					SubnetIDs:             pulumi.StringArray{pulumi.String("subnet-11111")},
					AllocatedStorage:      pulumi.Int(100),
					Engine:                pulumi.String("aurora-mysql"),
					EngineVersion:         pulumi.String("5.7.mysql_aurora.2.10.2"),
					Username:              pulumi.String("admin"),
					Password:              pulumi.String("password"),
					ClusterInstances: map[string]*rds.AuroraClusterInstanceArgs{
						"instance-1": {
							InstanceClass: pulumi.String("db.t4g.medium"),
							Tags: pulumi.StringMap{
								"env": pulumi.String("production"),
							},
						},
					},
					Tags: pulumi.StringMap{
						"env": pulumi.String("production"),
					},
				},
				Instance: &rds.InstanceArgs{
					SourceSecurityGroupID: pulumi.String("sg-instance-67890"),
					SubnetIDs:             pulumi.StringArray{pulumi.String("subnet-22222")},
					VpcID:                 pulumi.String("vpc-67890"),
					AllocatedStorage:      pulumi.Int(50),
					Engine:                pulumi.String("mysql"),
					EngineVersion:         pulumi.String("8.0.23"),
					InstanceClass:         pulumi.String("db.t3.medium"),
					Tags: pulumi.StringMap{
						"env": pulumi.String("staging"),
					},
				},
				Tags: pulumi.StringMap{
					"team":    pulumi.String("rds"),
					"project": pulumi.String("databases"),
				},
			},
			wantErr: false,
		},
		{
			name: "missing optional fields",
			input: `{
				"tags": {"team": "rds"}
			}`,
			want: &rds.DatabaseArgs{
				Cluster:  nil,
				Instance: nil,
				Tags: pulumi.StringMap{
					"team": pulumi.String("rds"),
				},
			},
			wantErr: false,
		},
		{
			name: "malformed JSON",
			input: `{
				"cluster": {
					"sourceSecurityGroupID": "sg-cluster-12345",
					"vpcID": "vpc-12345",
					"subnetIDs": ["subnet-11111"],
					"allocatedStorage": "100",
					"engine": "aurora-mysql",
					"engineVersion": "5.7.mysql_aurora.2.10.2",
					"username": "admin",
					"password": "password",
					"clusterInstances": {
						"instance-1": {
							"instanceClass": "db.t4g.medium",
							"tags": {
								"env": "production"
							}
						}
					},
					"tags": {"env": "production"}
				},
				"instance": {
					"sourceSecurityGroupID": "sg-instance-67890",
					"subnetIDs": ["subnet-22222"],
					"vpcID": "vpc-67890",
					"allocatedStorage": 50,
					"engine": "mysql",
					"engineVersion": "8.0.23",
					"instanceClass": "db.t3.medium",
					"tags": {"env": "staging"}
				},
				"tags": {"team": "rds", "project": "databases"}
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args rds.DatabaseArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
