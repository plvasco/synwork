package rds

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ec2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type databaseSecurityGroupArgs struct {
	Port            pulumi.IntInput    `pulumi:"port"`
	SecurityGroupID pulumi.StringInput `pulumi:"securityGroupID"`
	VpcID           pulumi.StringInput `pulumi:"vpcID"`
	Tags            pulumi.StringMap   `pulumi:"tags"`
}

func makeSecurityGroup(ctx *pulumi.Context, name string, args *databaseSecurityGroupArgs, opts ...pulumi.ResourceOption) (*ec2.SecurityGroup, error) {
	rules := map[string]*ec2.SecurityGroupRuleArgs{
		"egress-rds": {
			Description: pulumi.Sprintf("Allow all Egress from RDS"),
			FromPort:    args.Port,
			Protocol:    pulumi.String("all"),
			Self:        pulumi.Bool(true),
			ToPort:      pulumi.Int(0),
			Type:        pulumi.String("egress"),
		},
		"ingress-rds": {
			Description:           pulumi.String("Allow Ingress only to and from the DB port"),
			FromPort:              args.Port,
			Protocol:              pulumi.String("TCP"),
			SourceSecurityGroupID: args.SecurityGroupID,
			ToPort:                args.Port,
			Type:                  pulumi.String("ingress"),
		},
	}

	securityGroup, err := ec2.NewSecurityGroup(ctx, name+"-traffic", &ec2.SecurityGroupArgs{
		Tags:  args.Tags,
		VpcID: args.VpcID,
		Rules: rules,
	}, opts...)
	if err != nil {
		return nil, fmt.Errorf("unable to create RDS Security Group for %s, %w", name, err)
	}

	return securityGroup, nil
}
