package rds_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/rds"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewInstance(t *testing.T) {
	t.Parallel()

	type want struct {
		ID              string
		Endpoint        string
		Password        string
		SecurityGroupID string
	}

	type args struct {
		name string
		args *rds.InstanceArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "can deploy instance",
			in: args{
				name: "test-db",
				args: &rds.InstanceArgs{
					SourceSecurityGroupID: pulumi.String("sg-testing"),
					SubnetIDs: pulumi.StringArray{
						pulumi.String("subnet-1"),
						pulumi.String("subnet-2"),
						pulumi.String("subnet-3"),
					},
					Username:            pulumi.String("x10d"),
					AllocatedStorage:    pulumi.Int(20),
					Engine:              pulumi.String("postgres"),
					EngineVersion:       pulumi.String("14.12"),
					InstanceClass:       pulumi.String("db.t4g.medium"),
					MaxAllocatedStorage: pulumi.Int(100),
					OptionGroupName:     pulumi.String("default:postgres-14"),
					Port:                pulumi.Int(5432),
					ReadReplicas:        pulumi.Int(3),
					ParameterGroup: &rds.ParameterGroupArgs{
						Family: pulumi.String("postgres14"),
						Parameters: []*rds.Parameter{
							{
								Name:  pulumi.String("timezone"),
								Value: pulumi.String("US/Eastern"),
							},
						},
					},
					Tags: pulumi.StringMap{
						"environment": pulumi.String("prd"),
					},
					VpcID: pulumi.String("vpc-123456789"),
				},
			},
			want: want{
				ID:              "test-db-instance_id",
				Endpoint:        "mockrdsinstance.db.x10d",
				Password:        "mockPass",
				SecurityGroupID: "test-db-instance-traffic-sg_id",
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := rds.NewInstance(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.ID.ApplyT(func(id string) string {
					assert.Equal(t, tc.want.ID, id)

					return id
				})

				got.Endpoint.ApplyT(func(endpoint string) string {
					assert.Equal(t, tc.want.Endpoint, endpoint)

					return endpoint
				})

				got.Password.ApplyT(func(p string) string {
					assert.Equal(t, tc.want.Password, p)

					return p
				})

				got.SecurityGroupID.ApplyT(func(p string) string {
					assert.Equal(t, tc.want.SecurityGroupID, p)

					return p
				})
				// add validation tests here

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewInstance() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestInstanceArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *rds.InstanceArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"sourceSecurityGroupID": "sg-12345",
				"subnetIDs": ["subnet-11111", "subnet-22222"],
				"vpcID": "vpc-67890",
				"enableBackups": true,
				"allocatedStorage": 100,
				"readReplicas": 2,
				"parameterGroup": {
					"family": "mysql8.0"
				},
				"dbName": "exampledb",
				"engine": "mysql",
				"engineVersion": "8.0.23",
				"instanceClass": "db.t3.medium",
				"iops": 1000,
				"licenseModel": "general-public-license",
				"maxAllocatedStorage": 200,
				"optionGroupName": "default:mysql-8-0",
				"username": "admin",
				"password": "examplepassword",
				"performanceInsightsEnabled": true,
				"port": 3306,
				"storageType": "gp3",
				"snapshotARN": "arn:aws:rds:us-east-1:123456789012:snapshot:rds-mysql-snapshot",
				"tags": {"env": "production", "team": "rds"}
			}`,
			want: &rds.InstanceArgs{
				SourceSecurityGroupID: pulumi.String("sg-12345"),
				SubnetIDs:             pulumi.StringArray{pulumi.String("subnet-11111"), pulumi.String("subnet-22222")},
				VpcID:                 pulumi.String("vpc-67890"),
				EnableBackups:         pulumi.Bool(true),
				AllocatedStorage:      pulumi.Int(100),
				ReadReplicas:          pulumi.Int(2),
				ParameterGroup: &rds.ParameterGroupArgs{
					Family: pulumi.String("mysql8.0"),
				},
				DBName:                     pulumi.String("exampledb"),
				Engine:                     pulumi.String("mysql"),
				EngineVersion:              pulumi.String("8.0.23"),
				InstanceClass:              pulumi.String("db.t3.medium"),
				Iops:                       pulumi.Int(1000),
				LicenseModel:               pulumi.String("general-public-license"),
				MaxAllocatedStorage:        pulumi.Int(200),
				OptionGroupName:            pulumi.String("default:mysql-8-0"),
				Username:                   pulumi.String("admin"),
				Password:                   pulumi.String("examplepassword"),
				PerformanceInsightsEnabled: pulumi.Bool(true),
				Port:                       pulumi.Int(3306),
				StorageType:                pulumi.String("gp3"),
				SnapshotARN:                pulumi.String("arn:aws:rds:us-east-1:123456789012:snapshot:rds-mysql-snapshot"),
				Tags: pulumi.StringMap{
					"env":  pulumi.String("production"),
					"team": pulumi.String("rds"),
				},
			},
			wantErr: false,
		},
		{
			name: "malformed JSON",
			input: `{
				"sourceSecurityGroupID": "sg-12345",
				"subnetIDs": ["subnet-11111", "subnet-22222"],
				"vpcID": "vpc-67890",
				"enableBackups": true,
				"allocatedStorage": "100",
				"readReplicas": 2,
				"parameterGroup": {
					"family": "mysql8.0"
				},
				"dbName": "exampledb",
				"engine": "mysql",
				"engineVersion": "8.0.23",
				"instanceClass": "db.t3.medium",
				"iops": 1000,
				"licenseModel": "general-public-license",
				"maxAllocatedStorage": 200,
				"optionGroupName": "default:mysql-8-0",
				"username": "admin",
				"password": "examplepassword",
				"performanceInsightsEnabled": true,
				"port": 3306,
				"storageType": "gp3",
				"snapshotARN": "arn:aws:rds:us-east-1:123456789012:snapshot:rds-mysql-snapshot",
				"tags": {"env": "production", "team": "rds"}
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args rds.InstanceArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
