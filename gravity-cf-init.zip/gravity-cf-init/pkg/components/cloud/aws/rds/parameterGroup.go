package rds

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type ParameterGroupArgs struct {
	Description pulumi.StringInput // The description of the DB parameter group. Defaults to "Managed by Pulumi".
	Family      pulumi.StringInput // The family of the DB parameter group.
	Parameters  []*Parameter       // The DB parameters to apply.
	SkipDestroy pulumi.BoolInput   // dont destroy on delete.
	Tags        pulumi.StringMap   // A map of tags to assign to the resource.
}

type Parameter struct {
	Name  pulumi.StringInput
	Value pulumi.StringInput
}

func (args *ParameterGroupArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}

func (args *Parameter) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
