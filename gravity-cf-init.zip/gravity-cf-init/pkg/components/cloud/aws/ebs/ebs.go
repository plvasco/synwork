package ebs

import (
	"fmt"

	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/ebs"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const ebsComponentName = "gravity:aws:ebs"

type EBS struct {
	pulumi.ResourceState
	DefaultEncryptionID pulumi.IDOutput `pulumi:"defaultEncryptionID"`
}

func NewEBSDefaultEncryption(ctx *pulumi.Context, name string, opts ...pulumi.ResourceOption) error {
	// sets default EBS encryption policy to true
	component := &EBS{}

	if err := ctx.RegisterComponentResource(ebsComponentName, name, component, opts...); err != nil {
		return fmt.Errorf("unable to register component resource [%s] %s, %w", ebsComponentName, name, err)
	}

	if err := component.setEBSEncryptionByDefault(ctx, name+"-default-ebs-encryption"); err != nil {
		return fmt.Errorf("unable to enable EBS encryption be default %w", err)
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return fmt.Errorf("unable to register [%s] %s resource outputs, %w", ebsComponentName, name, err)
	}

	return nil
}

func (c *EBS) setEBSEncryptionByDefault(ctx *pulumi.Context, name string) error {
	encryption, err := ebs.NewEncryptionByDefault(ctx, name, &ebs.EncryptionByDefaultArgs{
		Enabled: pulumi.Bool(true),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to set default ebs encryption, %w", err)
	}

	c.DefaultEncryptionID = encryption.ID()

	return nil
}
