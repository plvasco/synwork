package ebs_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/ebs"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestShouldTurnOnDefaultEBSEncryption(t *testing.T) {
	t.Parallel()

	_ = pulumi.RunErr(func(ctx *pulumi.Context) error {
		err := ebs.NewEBSDefaultEncryption(ctx, "test-default")
		require.NoError(t, err)

		return nil
	}, testutils.WithMocksAndConfig("project", "stack", nil, testutils.AWSMocks(0)))
}
