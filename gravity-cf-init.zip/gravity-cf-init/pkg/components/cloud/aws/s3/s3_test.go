package s3_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/aws/s3"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewS3Buckets(t *testing.T) {
	t.Parallel()

	var truePtr = true

	type want struct {
		Name               string
		Principals         []string
		ServiceAccountName string
		ForceDestroy       *bool
	}

	tests := []struct {
		name    string
		args    map[string]*s3.BucketArgs
		want    want
		wantErr bool
	}{
		{
			name: "should create s3 bucket",
			args: map[string]*s3.BucketArgs{
				"test-bucket": {
					ServiceAccount: pulumi.Bool(true),
					Tags:           pulumi.ToStringMap(map[string]string{"test-tag": "test"}),
				},
			},
			want: want{
				Name:               "test-bucket",
				ServiceAccountName: "test-bucket-service-account",
			},
			wantErr: false,
		},
		{
			name: "should create s3 bucket",
			args: map[string]*s3.BucketArgs{
				"test-bucket": {
					ServiceAccount:      pulumi.Bool(false),
					BucketPolicyActions: pulumi.StringArray{pulumi.String("test-policy")},
					Principals:          pulumi.StringArray{pulumi.String("test-principal")},
					RoleName:            pulumi.String("test-role"),
					Tags:                pulumi.ToStringMap(map[string]string{"test-tag": "test"}),
				},
			},
			want: want{
				Name: "test-bucket",
			},
			wantErr: false,
		},
		{
			name: "should create s3 bucket without eks role added to bucket policy",
			args: map[string]*s3.BucketArgs{
				"test-bucket": {
					ServiceAccount: pulumi.Bool(true),
				},
			},
			want: want{
				Name:               "test-bucket",
				ServiceAccountName: "test-bucket-service-account",
			},
			wantErr: false,
		},
		{
			name: "should create s3 with custom service account policy",
			args: map[string]*s3.BucketArgs{
				"test-bucket": {
					ServiceAccount: pulumi.Bool(true),
					SAPolicyActions: pulumi.StringArray{
						pulumi.String("kms:Decrypt"),
						pulumi.String("s3:GetObject"),
					},
				},
			},
			want: want{
				Name:               "test-bucket",
				ServiceAccountName: "test-bucket-service-account",
			},
			wantErr: false,
		},
		{
			name: "should create s3 with force destroy",
			args: map[string]*s3.BucketArgs{
				"test-bucket": {
					ServiceAccount: pulumi.Bool(true),
					SAPolicyActions: pulumi.StringArray{
						pulumi.String("kms:Decrypt"),
						pulumi.String("s3:GetObject"),
					},
					ForceDestroy: pulumi.BoolPtr(true),
				},
			},
			want: want{
				Name:               "test-bucket",
				ServiceAccountName: "test-bucket-service-account",
				ForceDestroy:       &truePtr,
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				for bucketName, bucketConf := range tt.args {
					got, err := s3.NewBucket(ctx, bucketName, bucketConf)
					if err != nil {
						return err
					}

					got.Name.ApplyT(func(bucketName string) bool {
						assert.Equal(t, tt.want.Name, bucketName)

						return true
					})

					got.ForceDestroy.ApplyT(func(forceDestroy *bool) bool {
						assert.Equal(t, tt.want.ForceDestroy, forceDestroy)

						return true
					})

					if got.ServiceAccount != nil {
						got.ServiceAccount.Name.ApplyT(func(userName string) bool {
							assert.Equal(t, tt.want.ServiceAccountName, userName)

							return true
						})
					}

					require.NotNil(t, got)
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestBucketArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *s3.BucketArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"serviceAccount": true,
				"bucketPolicyActions": ["s3:GetObject", "s3:PutObject"],
				"saPolicyActions": ["iam:CreateRole", "iam:DeleteRole"],
				"principals": ["arn:aws:iam::123456789012:role/Admin"],
				"roleName": "s3-access-role",
				"tags": {"env": "production", "team": "storage"}
			}`,
			want: &s3.BucketArgs{
				ServiceAccount:      true,
				BucketPolicyActions: pulumi.StringArray{pulumi.String("s3:GetObject"), pulumi.String("s3:PutObject")},
				SAPolicyActions:     pulumi.StringArray{pulumi.String("iam:CreateRole"), pulumi.String("iam:DeleteRole")},
				Principals:          pulumi.StringArray{pulumi.String("arn:aws:iam::123456789012:role/Admin")},
				RoleName:            pulumi.String("s3-access-role"),
				Tags:                pulumi.StringMap{"env": pulumi.String("production"), "team": pulumi.String("storage")},
			},
			wantErr: false,
		},
		{
			name: "invalid field type",
			input: `{
				"serviceAccount": "true", // serviceAccount should be a boolean
				"bucketPolicyActions": ["s3:GetObject"],
				"roleName": "s3-access-role"
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"serviceAccount": true, "bucketPolicyActions": ["s3:GetObject"], "roleName": "s3-access-role"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args s3.BucketArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
