package s3

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	pulumiAws "github.com/pulumi/pulumi-aws/sdk/v6/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/iam"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/kms"
	"github.com/pulumi/pulumi-aws/sdk/v6/go/aws/s3"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const (
	bucketComponentName = "gravity:aws:Bucket"
)

type Bucket struct {
	pulumi.ResourceState
	ServiceAccount  *iam.User            `pulumi:"serviceAccount"`
	SAPolicyActions pulumi.StringArray   `pulumi:"saPolicyActions"`
	Name            pulumi.StringOutput  `pulumi:"name"`
	ID              pulumi.IDOutput      `pulumi:"id"`
	ARN             pulumi.StringOutput  `pulumi:"arn"`
	ForceDestroy    pulumi.BoolPtrOutput `pulumi:"forceDestroy"`
}

type BucketArgs struct {
	ServiceAccount      pulumi.Bool         `pulumi:"serviceAccount"`
	BucketPolicyActions pulumi.StringArray  `pulumi:"bucketPolicyActions"`
	ForceDestroy        pulumi.BoolPtrInput `pulumi:"forceDestroy"`
	SAPolicyActions     pulumi.StringArray  `pulumi:"saPolicyActions"`
	Principals          pulumi.StringArray  `pulumi:"principals"`
	RoleName            pulumi.StringInput  `pulumi:"roleName"`
	Tags                pulumi.StringMap    `pulumi:"tags"`
}

func NewBucket(ctx *pulumi.Context, name string, args *BucketArgs, opts ...pulumi.ResourceOption) (*Bucket, error) {
	component := &Bucket{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(bucketComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", bucketComponentName, name, err)
	}

	if err := component.createBucket(ctx, name, args); err != nil {
		return nil, err
	}

	if args.ServiceAccount {
		if err := component.createServiceUser(ctx, name+"-service-account", args); err != nil {
			return nil, err
		}

		if err := component.createServiceUserPolicy(ctx, name+"-user-policy", args); err != nil {
			return nil, err
		}

		if err := component.createAccessKey(ctx, name+"-access-key"); err != nil {
			return nil, err
		}
	}

	if err := component.createBucketPolicy(ctx, name+"-bucket-policy", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"name":            component.Name,
		"id":              component.ID,
		"arn":             component.ARN,
		"serviceAccount":  component.ServiceAccount.ToUserOutput(),
		"saPolicyActions": component.SAPolicyActions.ToStringArrayOutput(),
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", bucketComponentName, name, err)
	}

	return component, nil
}

func (c *Bucket) createBucket(ctx *pulumi.Context, name string, args *BucketArgs) error {
	awsBucket, err := s3.NewBucketV2(ctx, name, &s3.BucketV2Args{
		Tags:              utils.GenerateTags(args.Tags, name),
		ObjectLockEnabled: pulumi.Bool(true),
		ForceDestroy:      args.ForceDestroy,
	}, pulumi.Parent(c), pulumi.IgnoreChanges([]string{"objectLockEnabled"}))
	if err != nil {
		return fmt.Errorf("unable to create bucket %w", err)
	}

	_, err = s3.NewBucketPublicAccessBlock(ctx, name+"-access-block", &s3.BucketPublicAccessBlockArgs{
		BlockPublicAcls:       pulumi.Bool(true),
		BlockPublicPolicy:     pulumi.Bool(true),
		Bucket:                awsBucket.ID(),
		IgnorePublicAcls:      pulumi.Bool(true),
		RestrictPublicBuckets: pulumi.Bool(true),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create public access block for %w", err)
	}

	c.Name = awsBucket.Bucket
	c.ID = awsBucket.ID()
	c.ARN = awsBucket.Arn
	c.ForceDestroy = awsBucket.ForceDestroy

	if err := c.createS3EncryptionConfig(ctx, name+"-encryption"); err != nil {
		return err
	}

	if err := c.createS3LoggingConfig(ctx, name+"-logging"); err != nil {
		return err
	}

	if err := c.createS3VersioningConfig(ctx, name+"-versioning"); err != nil {
		return err
	}

	return nil
}

func (c *Bucket) createS3EncryptionConfig(ctx *pulumi.Context, name string) error {
	key := kms.LookupKeyOutput(ctx, kms.LookupKeyOutputArgs{
		KeyId: pulumi.String("alias/encryption-key"),
	}, pulumi.Parent(c))

	if _, err := s3.NewBucketServerSideEncryptionConfigurationV2(ctx, name, &s3.BucketServerSideEncryptionConfigurationV2Args{
		Bucket: c.ID,
		Rules: s3.BucketServerSideEncryptionConfigurationV2RuleArray{&s3.BucketServerSideEncryptionConfigurationV2RuleArgs{
			ApplyServerSideEncryptionByDefault: s3.BucketServerSideEncryptionConfigurationV2RuleApplyServerSideEncryptionByDefaultArgs{
				KmsMasterKeyId: key.Arn(),
				SseAlgorithm:   pulumi.String("aws:kms"),
			},
		}},
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create s3 encryption config %s, %w", name, err)
	}

	return nil
}

func (c *Bucket) createS3LoggingConfig(ctx *pulumi.Context, name string) error {
	_, err := s3.NewBucketLoggingV2(ctx, name, &s3.BucketLoggingV2Args{
		Bucket:       c.ID,
		TargetBucket: c.ID,
		TargetPrefix: pulumi.String("log/"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create s3 logging config %s, %w", name, err)
	}

	return nil
}

func (c *Bucket) createS3VersioningConfig(ctx *pulumi.Context, name string) error {
	_, err := s3.NewBucketVersioningV2(ctx, name, &s3.BucketVersioningV2Args{
		Bucket: c.ID,
		VersioningConfiguration: s3.BucketVersioningV2VersioningConfigurationArgs{
			Status: pulumi.String("Enabled"),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create s3 versioning config %s, %w", name, err)
	}

	return nil
}

func (c *Bucket) createBucketPolicy(ctx *pulumi.Context, name string, args *BucketArgs) error {
	statements := iam.GetPolicyDocumentStatementArray{}

	principals := c.generatePrincipalList(ctx, args)

	if len(principals) != 0 {
		statement := iam.GetPolicyDocumentStatementArgs{
			Actions: args.BucketPolicyActions,
			Principals: iam.GetPolicyDocumentStatementPrincipalArray{
				iam.GetPolicyDocumentStatementPrincipalArgs{
					Type:        pulumi.String("AWS"),
					Identifiers: c.generatePrincipalList(ctx, args),
				}},
			Resources: pulumi.StringArray{
				c.ARN,
				pulumi.Sprintf("%s/*", c.ARN),
			},
		}

		statements = append(statements, statement)
	}

	httpStatement := iam.GetPolicyDocumentStatementArgs{
		Actions: pulumi.ToStringArray([]string{"s3:*"}),
		Conditions: iam.GetPolicyDocumentStatementConditionArray{
			iam.GetPolicyDocumentStatementConditionArgs{
				Test:     pulumi.String("Bool"),
				Values:   pulumi.ToStringArray([]string{"false"}),
				Variable: pulumi.String("aws:SecureTransport"),
			},
		},
		Effect: pulumi.String("Deny"),
		Principals: iam.GetPolicyDocumentStatementPrincipalArray{
			iam.GetPolicyDocumentStatementPrincipalArgs{
				Type:        pulumi.String("AWS"),
				Identifiers: pulumi.ToStringArray([]string{"*"}),
			}},
		Resources: pulumi.StringArray{
			c.ARN,
			pulumi.Sprintf("%s/*", c.ARN),
		},
	}

	statements = append(statements, httpStatement)

	document := iam.GetPolicyDocumentOutput(ctx, iam.GetPolicyDocumentOutputArgs{
		Statements: statements,
	}, pulumi.Parent(c))

	if _, err := s3.NewBucketPolicy(ctx, name, &s3.BucketPolicyArgs{
		Bucket: c.ID,
		Policy: document.Json(),
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create bucket policy for %s, %w", name, err)
	}

	return nil
}

func (c *Bucket) createServiceUser(ctx *pulumi.Context, name string, args *BucketArgs) error {
	user, err := iam.NewUser(ctx, name, &iam.UserArgs{
		Tags: utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create service user for %s, %w", name, err)
	}

	c.ServiceAccount = user

	return nil
}

func (c *Bucket) generatePrincipalList(ctx *pulumi.Context, args *BucketArgs) pulumi.StringArray {
	principalIdentifiers := pulumi.StringArray{}

	callerIdentity := pulumiAws.GetCallerIdentityOutput(ctx, pulumiAws.GetCallerIdentityOutputArgs{}, pulumi.Parent(c))

	partition := pulumiAws.GetPartitionOutput(ctx, pulumiAws.GetPartitionOutputArgs{}, pulumi.Parent(c))

	if args.RoleName != nil {
		roleArn := pulumi.Sprintf("arn:%s:iam::%s:role/%s", partition.Partition(), callerIdentity.AccountId(), args.RoleName)
		principalIdentifiers = append(principalIdentifiers, roleArn)
	}

	if len(args.Principals) != 0 {
		principalIdentifiers = append(principalIdentifiers, args.Principals...)
	}

	return principalIdentifiers
}

func (c *Bucket) createAccessKey(ctx *pulumi.Context, name string) error {
	key, err := iam.NewAccessKey(ctx, name, &iam.AccessKeyArgs{
		User: c.ServiceAccount.Name,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create access key for %s, %w", name, err)
	}

	ctx.Export(name+"-bucket", c.Name)
	ctx.Export(name+"-access-key", key.ID())
	ctx.Export(name+"-secret-key", key.Secret)

	return nil
}

func (c *Bucket) createServiceUserPolicy(ctx *pulumi.Context, name string, args *BucketArgs) error {
	key := kms.LookupKeyOutput(ctx, kms.LookupKeyOutputArgs{
		KeyId: pulumi.String("alias/encryption-key"),
	}, pulumi.Parent(c))

	statement := iam.GetPolicyDocumentStatementArgs{
		Actions: args.SAPolicyActions,
		Resources: pulumi.StringArray{
			key.Arn(),
			c.ARN,
			pulumi.Sprintf("%s/*", c.ARN),
		},
	}

	policyDocArgs := iam.GetPolicyDocumentOutputArgs{
		Statements: iam.GetPolicyDocumentStatementArray{statement},
	}

	document := iam.GetPolicyDocumentOutput(ctx, policyDocArgs, pulumi.Parent(c))

	if _, err := iam.NewUserPolicy(ctx, name, &iam.UserPolicyArgs{
		Policy: document.Json(),
		User:   c.ServiceAccount.Name,
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create new user policy for %s, %w", name, err)
	}

	return nil
}

func (args *BucketArgs) validate() error {
	if len(args.BucketPolicyActions) == 0 {
		args.BucketPolicyActions = pulumi.ToStringArray(
			[]string{
				"s3:PutObjectAcl",
				"s3:PutObject",
				"s3:ListBucket",
				"s3:GetObjectVersion",
				"s3:GetObject",
				"s3:DeleteObject",
			},
		)
	}

	if len(args.SAPolicyActions) == 0 {
		args.SAPolicyActions = pulumi.ToStringArray(
			[]string{
				"s3:PutObjectAcl",
				"s3:PutObject",
				"s3:ListBucket",
				"s3:GetObjectVersion",
				"s3:GetObject",
				"s3:DeleteObject",
				"kms:Decrypt",
				"kms:GenerateDataKey",
			},
		)
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed, %w", args, err)
	}

	return nil
}

func (args *BucketArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal buckets args, %w", err)
	}

	return nil
}
