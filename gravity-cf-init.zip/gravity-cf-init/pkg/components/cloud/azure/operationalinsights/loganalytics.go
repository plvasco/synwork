package operationalinsights

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native/sdk/go/azure/operationalinsights"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const loganalyticsComponentName = "gravity:azure:loganalytics"

type LogAnalyticsWorkspace struct {
	pulumi.ResourceState
	WorkspaceID   pulumi.IDOutput     `pulumi:"workspaceID"`
	WorkspaceName pulumi.StringOutput `pulumi:"workspaceName"`
}

type LogAnalyticsWorkspaceArgs struct {
	ResourceGroupName pulumi.StringInput
}

func NewLogAnalyticsWorkspace(ctx *pulumi.Context, name string, args *LogAnalyticsWorkspaceArgs, opts ...pulumi.ResourceOption) (*LogAnalyticsWorkspace, error) {
	if err := args.validate(); err != nil {
		return nil, fmt.Errorf("unable to validate network args, %w", err)
	}

	component := &LogAnalyticsWorkspace{}

	if err := ctx.RegisterComponentResource(loganalyticsComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", loganalyticsComponentName, name, err)
	}

	if err := component.createLogAnalyticsWorkspace(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"workspaceID":   component.WorkspaceID,
		"workspaceName": component.WorkspaceName,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", loganalyticsComponentName, name, err)
	}

	return component, nil

}

func (c *LogAnalyticsWorkspace) createLogAnalyticsWorkspace(ctx *pulumi.Context, name string, args *LogAnalyticsWorkspaceArgs) error {
	workspace, err := operationalinsights.NewWorkspace(ctx, name, &operationalinsights.WorkspaceArgs{
		ResourceGroupName: args.ResourceGroupName,
		Sku: &operationalinsights.WorkspaceSkuArgs{
			Name: pulumi.String("PerGB2018"),
		},
		RetentionInDays: pulumi.Int(30),
	}, pulumi.Parent(c))

	c.WorkspaceID = workspace.ID()
	c.WorkspaceName = workspace.Name

	return err
}

// validate checks that all required args are set and sets defaults for any optional args.
func (args *LogAnalyticsWorkspaceArgs) validate() error {
	if args == nil {
		args = &LogAnalyticsWorkspaceArgs{}
	}

	return nil
}

func (args *LogAnalyticsWorkspaceArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal network args, %w", err)
	}

	return nil
}
