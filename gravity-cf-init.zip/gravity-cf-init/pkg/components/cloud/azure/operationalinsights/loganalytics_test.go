package operationalinsights_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/operationalinsights"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestNewLogAnalyticsWorkspace(t *testing.T) {
	t.Parallel()

	type want struct {
		name              string
		resourceGroupName string
	}

	type args struct {
		name string
		args *operationalinsights.LogAnalyticsWorkspaceArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create log analytics workspace resource",
			in: args{
				name: "test-log-analytics-workspace",
				args: &operationalinsights.LogAnalyticsWorkspaceArgs{
					ResourceGroupName: pulumi.String("test-rg"),
				},
			},
			want: want{
				name:              "test-log-analytics-workspace",
				resourceGroupName: "test-rg",
			},
			wantErr: false,
		},
		// {
		// 	name: "should handle nil args",
		// 	in: args{
		// 		name: "test-workspace",
		// 		args: nil,
		// 	},
		// 	wantErr: true,
		// },
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := operationalinsights.NewLogAnalyticsWorkspace(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}
				// if tt.wantErr {
				// 	require.Error(t, err)
				// 	return nil
				// }

				require.NoError(t, err)
				require.NotNil(t, got)

				// got.WorkspaceName.ApplyT(func(name string) string {
				// 	assert.Equal(t, tt.want.name, name)
				// 	return name
				// })

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))

			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

// func TestLogAnalyticsWorkspaceArgs_Validate(t *testing.T) {
// 	t.Parallel()

// 	tests := []struct {
// 		name    string
// 		args    *operationalinsights.LogAnalyticsWorkspaceArgs
// 		wantErr bool
// 	}{
// 		{
// 			name:    "should validate nil args",
// 			args:    nil,
// 			wantErr: false,
// 		},
// 		{
// 			name: "should validate valid args",
// 			args: &operationalinsights.LogAnalyticsWorkspaceArgs{
// 				ResourceGroupName: pulumi.String("test-rg"),
// 			},
// 			wantErr: false,
// 		},
// 	}

// 	for _, tt := range tests {
// 		t.Run(tt.name, func(t *testing.T) {
// 			err := tt.args.validate()
// 			if tt.wantErr {
// 				require.Error(t, err)
// 				return
// 			}
// 			require.NoError(t, err)
// 		})
// 	}
// }

func TestLogAnalyticsWorkspaceArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		in      string
		want    *operationalinsights.LogAnalyticsWorkspaceArgs
		wantErr bool
	}{
		{
			name: "valid input",
			in:   `{"resourceGroupName":"test-rg"}`,
			want: &operationalinsights.LogAnalyticsWorkspaceArgs{
				ResourceGroupName: pulumi.String("test-rg"),
			},
			wantErr: false,
		},
		// nil test
		{
			name:    "nil input",
			in:      `null`,
			want:    &operationalinsights.LogAnalyticsWorkspaceArgs{},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			var got operationalinsights.LogAnalyticsWorkspaceArgs

			b := []byte(tt.in)
			err := json.Unmarshal(b, &got)

			if tt.wantErr {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tt.want, &got) {
				t.Errorf("unexpected result: got %+v, want %+v", got, *tt.want)
			}
		})
	}
}
