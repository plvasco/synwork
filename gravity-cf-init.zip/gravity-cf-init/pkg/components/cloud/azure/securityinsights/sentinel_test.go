package securityinsights_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/securityinsights"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestEnableSentinel(t *testing.T) {
	t.Parallel()

	type want struct {
		name              string
		resourceGroupName string
		workspaceName     string
	}

	type args struct {
		name string
		args *securityinsights.SentinelArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should enable sentinel",
			in: args{
				name: "test-sentinel",
				args: &securityinsights.SentinelArgs{
					ResourceGroupName: pulumi.String("test-rg"),
					WorkspaceName:     pulumi.String("test-workspace"),
					Name:              pulumi.String("test-sentinel"),
				},
			},
			want: want{
				name:              "test-sentinel",
				resourceGroupName: "test-rg",
				workspaceName:     "test-workspace",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := securityinsights.EnableSentinel(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestSentinelArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    securityinsights.SentinelArgs
		wantErr bool
	}{
		{
			name:  "should unmarshal sentinel args",
			input: `{"resourceGroupName":"test-rg","workspaceName":"test-workspace","name":"test-sentinel"}`,
			want: securityinsights.SentinelArgs{
				ResourceGroupName: pulumi.String("test-rg"),
				WorkspaceName:     pulumi.String("test-workspace"),
				Name:              pulumi.String("test-sentinel"),
			},
			wantErr: false,
		},
		{
			name:  "should unmarshal sentinel args with empty strings",
			input: `{"resourceGroupName":"","workspaceName":"","name":""}`,
			want: securityinsights.SentinelArgs{
				ResourceGroupName: pulumi.String(""),
				WorkspaceName:     pulumi.String(""),
				Name:              pulumi.String(""),
			},
			wantErr: false,
		},
		{
			name:    "should fail to unmarshal invalid JSON",
			input:   `{"resourceGroupName":"test-rg","workspaceName":"test-workspace","name":`,
			wantErr: true,
		},
		{
			name:  "should unmarshal sentinel args with additional fields",
			input: `{"resourceGroupName":"test-rg","workspaceName":"test-workspace","name":"test-sentinel","extra":"field"}`,
			want: securityinsights.SentinelArgs{
				ResourceGroupName: pulumi.String("test-rg"),
				WorkspaceName:     pulumi.String("test-workspace"),
				Name:              pulumi.String("test-sentinel"),
			},
			wantErr: false,
		},
		{
			name:  "should unmarshal sentinel args with missing fields",
			input: `{"resourceGroupName":"test-rg","workspaceName":"test-workspace"}`,
			want: securityinsights.SentinelArgs{
				ResourceGroupName: pulumi.String("test-rg"),
				WorkspaceName:     pulumi.String("test-workspace"),
			},
			wantErr: false,
		},
		{
			name:  "should unmarshal sentinel args with null fields",
			input: `{"resourceGroupName":null,"workspaceName":null,"name":null}`,
			want: securityinsights.SentinelArgs{
				ResourceGroupName: pulumi.String(""),
				WorkspaceName:     pulumi.String(""),
				Name:              pulumi.String(""),
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			var got securityinsights.SentinelArgs

			b := []byte(tt.input)
			err := json.Unmarshal(b, &got)

			if tt.wantErr {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tt.want, got) {
				t.Errorf("unexpected result: got %+v, want %+v", got, tt.want)
			}
		})
	}
}
