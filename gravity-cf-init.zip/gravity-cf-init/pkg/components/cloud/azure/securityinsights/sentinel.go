package securityinsights

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native/sdk/go/azure/securityinsights"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const sentinelComponentName = "gravity:azure:sentinel"

type Sentinel struct {
	pulumi.ResourceState
}

type SentinelArgs struct {
	ResourceGroupName pulumi.StringInput
	WorkspaceName     pulumi.StringInput
	Name              pulumi.StringInput `pulumi:"name"`
}

func EnableSentinel(ctx *pulumi.Context, name string, args *SentinelArgs, opts ...pulumi.ResourceOption) (*Sentinel, error) {
	if err := args.validate(); err != nil {
		return nil, fmt.Errorf("unable to validate network args, %w", err)
	}

	component := &Sentinel{}

	if err := ctx.RegisterComponentResource(sentinelComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", sentinelComponentName, name, err)
	}

	if err := component.enableSentinel(ctx, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", sentinelComponentName, name, err)
	}

	return component, nil

}

func (c *Sentinel) enableSentinel(ctx *pulumi.Context, args *SentinelArgs) error {

	_, err := securityinsights.NewSentinelOnboardingState(ctx, "sentinelOnboarding", &securityinsights.SentinelOnboardingStateArgs{
		ResourceGroupName:                   args.ResourceGroupName,
		WorkspaceName:                       args.WorkspaceName,
		OperationalInsightsResourceProvider: pulumi.String("Microsoft.OperationalInsights"),
		SentinelOnboardingStateName:         pulumi.String("default"), // Must be "default"
	}, pulumi.Parent(c))

	if err != nil {
		return err
	}

	return err
}

type WatchlistArgs struct {
	ResourceGroupName pulumi.StringInput
	WorkspaceName     pulumi.StringInput
	CsvFilePath       string
	Name              string
}

// validate checks that all required args are set and sets defaults for any optional args.
func (args *SentinelArgs) validate() error {
	return nil
}

func (args *SentinelArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal network args, %w", err)
	}

	return nil
}
