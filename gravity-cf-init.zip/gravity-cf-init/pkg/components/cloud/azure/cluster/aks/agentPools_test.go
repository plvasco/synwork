package aks_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/cluster/aks"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewAgentPool(t *testing.T) {
	t.Parallel()

	type want struct {
		id string
	}

	type args struct {
		name string
		args *aks.AgentPoolArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should create agent pool w/ defaults",
			in: args{
				name: "test-ap",
				args: &aks.AgentPoolArgs{
					ResourceGroupName: pulumi.String("test-cluster-1-rg"),
					SubnetID:          pulumi.String("subnet1234"),
					ClusterName:       pulumi.String("aksx10d"),
				},
			},
			want: want{
				id: "ap-test-ap_id",
			},
			wantErr: false,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := aks.NewAgentPool(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.ID.ApplyT(func(id string) string {
					assert.Equal(t, tc.want.id, id)

					return id
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewAgentPool() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}
func TestAgentPoolArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *aks.AgentPoolArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"initialWorkerCount": 3,
				"maxWorkers": 10,
				"minWorkers": 2,
				"instanceType": "Standard_D4s_v3",
				"diskSize": 50,
				"labels": {"env": "production"},
				"taints": ["key1=value1:NoSchedule", "key2=value2:PreferNoSchedule"],
				"tags": {"team": "aks", "project": "gov-project"}
			}`,
			want: &aks.AgentPoolArgs{
				InitialWorkerCount: pulumi.Int(3),
				MaxWorkers:         pulumi.Int(10),
				MinWorkers:         pulumi.Int(2),
				InstanceType:       pulumi.String("Standard_D4s_v3"),
				DiskSize:           pulumi.Int(50),
				Labels: pulumi.StringMap{
					"env": pulumi.String("production"),
				},
				Taints: pulumi.StringArray{
					pulumi.String("key1=value1:NoSchedule"),
					pulumi.String("key2=value2:PreferNoSchedule"),
				},
				Tags: pulumi.StringMap{
					"team":    pulumi.String("aks"),
					"project": pulumi.String("gov-project"),
				},
			},
			wantErr: false,
		},
		{
			name: "malformed JSON",
			input: `{
				"initialWorkerCount": "3",
				"maxWorkers": 10,
				"minWorkers": 2,
				"instanceType": "Standard_D4s_v3",
				"diskSize": 50,
				"labels": {"env": "production"},
				"taints": ["key1=value1:NoSchedule", "key2=value2:PreferNoSchedule"],
				"tags": {"team": "aks", "project": "gov-project"}
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args aks.AgentPoolArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
