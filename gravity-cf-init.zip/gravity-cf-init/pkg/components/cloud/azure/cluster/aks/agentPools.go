package aks

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/containerservice/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const agentPoolsComponentName = "gravity:azure:agentPools"

var ErrRequiredArgumentNetworkID = errors.New("required argument NetworkID is missing")

type AgentPool struct {
	pulumi.ResourceState
	ID pulumi.StringOutput `pulumi:"id"`
}

type AgentPoolArgs struct {
	InitialWorkerCount pulumi.IntInput    `pulumi:"initialWorkerCount" validate:"default=0"`
	MaxWorkers         pulumi.IntInput    `pulumi:"maxWorkers"         validate:"default=3"`
	MinWorkers         pulumi.IntInput    `pulumi:"minWorkers"         validate:"default=1"`
	InstanceType       pulumi.StringInput `pulumi:"instanceType"       validate:"default=Standard_D2s_v3"`
	DiskSize           pulumi.IntInput    `pulumi:"diskSize"           validate:"default=30"`
	Labels             pulumi.StringMap   `pulumi:"labels"`
	// taints added to new nodes during node pool create and scale. For example, key=value:NoSchedule
	Taints pulumi.StringArray `pulumi:"taints"`
	Tags   pulumi.StringMap   `pulumi:"tags"`
	// Internal Args
	ClusterName       pulumi.StringInput `pulumi:"clusterName"`
	ResourceGroupName pulumi.StringInput `pulumi:"resourceGroupName"`
	SubnetID          pulumi.StringInput `pulumi:"subnetID"`
}

func NewAgentPool(ctx *pulumi.Context, name string, args *AgentPoolArgs, opts ...pulumi.ResourceOption) (*AgentPool, error) {
	component := &AgentPool{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(agentPoolsComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", agentPoolsComponentName, name, err)
	}

	if err := component.createAgentPool(ctx, "ap-"+name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", agentPoolsComponentName, name, err)
	}

	return component, nil
}
func (c *AgentPool) createAgentPool(ctx *pulumi.Context, name string, args *AgentPoolArgs) error {
	pool, err := containerservice.NewAgentPool(ctx, name, &containerservice.AgentPoolArgs{
		Count:              args.InitialWorkerCount,
		EnableAutoScaling:  pulumi.Bool(true),
		EnableFIPS:         pulumi.Bool(true),
		EnableNodePublicIP: pulumi.Bool(false),
		MaxCount:           args.MaxWorkers,
		MinCount:           args.MinWorkers,
		Mode:               containerservice.AgentPoolModeUser,
		// AgentPoolName:      pulumi.String(name),
		NodeLabels:        args.Labels,
		NodeTaints:        args.Taints,
		OsDiskSizeGB:      args.DiskSize,
		OsSKU:             containerservice.OSSKUAzureLinux,
		ResourceName:      args.ClusterName,
		ResourceGroupName: args.ResourceGroupName,
		Tags:              utils.GenerateTags(args.Tags, name),
		Type:              containerservice.AgentPoolTypeVirtualMachineScaleSets,
		VmSize:            args.InstanceType,
		VnetSubnetID:      args.SubnetID,
		WorkloadRuntime:   containerservice.WorkloadRuntimeOCIContainer,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create agent pool %s, %w", name, err)
	}

	c.ID = pool.ID().ToStringOutput()

	return nil
}

func (args *AgentPoolArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *AgentPoolArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal cluster args, %w", err)
	}

	return nil
}
