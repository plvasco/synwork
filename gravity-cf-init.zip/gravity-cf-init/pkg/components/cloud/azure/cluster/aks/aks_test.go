package aks_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/cluster/aks"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewCluster(t *testing.T) {
	t.Parallel()

	type want struct {
		name         string
		kubeconfig   string
		agentPoolIDs []string
	}

	type args struct {
		name string
		args *aks.ClusterArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create cluster resource",
			in: args{
				name: "test-cluster-1",
				args: &aks.ClusterArgs{
					KubernetesVersion: pulumi.String("1.30"),
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test-customer"),
					Environment:       pulumi.String("test"),
					ResourceGroupName: pulumi.String("test-cluster-1-rg"),
					SubnetID:          pulumi.String("subnet1234"),
				},
			},
			want: want{
				name:       "aks-test-cluster-1",
				kubeconfig: "test-kube-config",
			},
			wantErr: false,
		},
		{
			name: "should create cluster resource with multiple subnets",
			in: args{
				name: "test-cluster-1",
				args: &aks.ClusterArgs{
					KubernetesVersion: pulumi.String("1.30"),
					ComplianceLevel:   pulumi.String("testing"),
					Environment:       pulumi.String("test"),
					Customer:          pulumi.String("test-customer"),
					SubnetID:          pulumi.String("subnet1234"),
					AgentPools: map[string]*aks.AgentPoolArgs{
						"newpool": {
							InitialWorkerCount: pulumi.Int(3),
							InstanceType:       pulumi.String("test"),
							DiskSize:           pulumi.Int(250),
							MaxWorkers:         pulumi.Int(5),
							MinWorkers:         pulumi.Int(1),
						},
					},
					Tags:              map[string]pulumi.StringInput{},
					ResourceGroupName: pulumi.String("test-cluster-1-rg"),
				},
			},
			want: want{
				name:         "aks-test-cluster-1",
				kubeconfig:   "test-kube-config",
				agentPoolIDs: []string{"ap-newpool_id"},
			},
			wantErr: false,
		},
		{
			name: "should create extra agent pools",
			in: args{
				name: "test-cluster-1",
				args: &aks.ClusterArgs{
					KubernetesVersion: pulumi.String("1.30"),
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test-customer"),
					Environment:       pulumi.String("test"),
					ResourceGroupName: pulumi.String("test-cluster-1-rg"),
					SubnetID:          pulumi.String("subnet1234"),
					AgentPools: map[string]*aks.AgentPoolArgs{
						"newpool": {
							InitialWorkerCount: pulumi.Int(3),
							InstanceType:       pulumi.String("test"),
							DiskSize:           pulumi.Int(250),
							MaxWorkers:         pulumi.Int(5),
							MinWorkers:         pulumi.Int(1),
						},
						"newpool2": {
							InitialWorkerCount: pulumi.Int(3),
							InstanceType:       pulumi.String("test"),
							DiskSize:           pulumi.Int(250),
							MaxWorkers:         pulumi.Int(5),
							MinWorkers:         pulumi.Int(1),
						},
					},
				},
			},
			want: want{
				name:         "aks-test-cluster-1",
				kubeconfig:   "test-kube-config",
				agentPoolIDs: []string{"ap-newpool_id", "ap-newpool2_id"},
			},
			wantErr: false,
		},
		{
			name: "should fail if compliance level is not provided",
			in: args{
				name: "test-root-1",
				args: &aks.ClusterArgs{
					ComplianceLevel:   nil,
					Customer:          pulumi.String("test-customer"),
					Environment:       pulumi.String("test"),
					ResourceGroupName: pulumi.String("test-cluster-1-rg"),
				},
			},
			wantErr: true,
		},
		{
			name: "should fail if customer is not provided",
			in: args{
				name: "test-root-1",
				args: &aks.ClusterArgs{
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          nil,
					Environment:       pulumi.String("test"),
					ResourceGroupName: pulumi.String("test-cluster-1-rg"),
				},
			},
			wantErr: true,
		},
		{
			name: "should fail if environment is not provided",
			in: args{
				name: "test-root-1",
				args: &aks.ClusterArgs{
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test-customer"),
					Environment:       nil,
					ResourceGroupName: pulumi.String("test-cluster-1-rg"),
				},
			},
			wantErr: true,
		},
		{
			name: "should fail if ResourceGroupName is not provided",
			in: args{
				name: "test-root-1",
				args: &aks.ClusterArgs{
					ComplianceLevel: pulumi.String("testing"),
					Customer:        pulumi.String("test-customer"),
					Environment:     pulumi.String("test"),

					ResourceGroupName: nil,
				},
			},
			wantErr: true,
		},
		{
			name: "should fail without subnetID",
			in: args{
				name: "test-cluster-1",
				args: &aks.ClusterArgs{
					KubernetesVersion: pulumi.String("1.30"),
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test-customer"),
					Environment:       pulumi.String("test"),
					ResourceGroupName: pulumi.String("test-cluster-1-rg"),
				},
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := aks.NewCluster(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.Kubeconfig.ApplyT(func(k string) string {
					assert.Equal(t, tt.want.kubeconfig, k)

					return k
				})

				got.AgentPoolIDs.ApplyT(func(ids []string) []string {
					if tt.want.agentPoolIDs == nil {
						tt.want.agentPoolIDs = []string{}
					}

					for _, agentPoolID := range tt.want.agentPoolIDs {
						assert.Contains(t, ids, agentPoolID)
					}

					return ids
				})

				got.Name.ApplyT(func(name string) bool {
					assert.Equal(t, tt.want.name, name)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestClusterArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *aks.ClusterArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"kubernetesVersion": "1.25.0",
				"complianceLevel": "high",
				"tier": "Standard",
				"location": "usgovvirginia",
				"environment": "production",
				"customer": "gov-customer",
				"subnetID": "subnet-12345",
				"agentPools": {
					"pool-1": {
						"initialWorkerCount": 3,
						"maxWorkers": 10,
						"minWorkers": 2,
						"instanceType": "Standard_D4s_v3",
						"diskSize": 50,
						"labels": {"env": "production"},
						"taints": ["key1=value1:NoSchedule", "key2=value2:PreferNoSchedule"],
						"tags": {"team": "aks", "project": "gov-project"}
					}
				},
				"tags": {"team": "aks", "project": "gov-project"},
				"resourceGroupName": "gov-resource-group"
			}`,
			want: &aks.ClusterArgs{
				KubernetesVersion: pulumi.String("1.25.0"),
				ComplianceLevel:   pulumi.String("high"),
				Tier:              pulumi.String("Standard"),
				Location:          pulumi.String("usgovvirginia"),
				Environment:       pulumi.String("production"),
				Customer:          pulumi.String("gov-customer"),
				SubnetID:          pulumi.String("subnet-12345"),
				AgentPools: map[string]*aks.AgentPoolArgs{
					"pool-1": {
						InitialWorkerCount: pulumi.Int(3),
						MaxWorkers:         pulumi.Int(10),
						MinWorkers:         pulumi.Int(2),
						InstanceType:       pulumi.String("Standard_D4s_v3"),
						DiskSize:           pulumi.Int(50),
						Labels: pulumi.StringMap{
							"env": pulumi.String("production"),
						},
						Taints: pulumi.StringArray{
							pulumi.String("key1=value1:NoSchedule"),
							pulumi.String("key2=value2:PreferNoSchedule"),
						},
						Tags: pulumi.StringMap{
							"team":    pulumi.String("aks"),
							"project": pulumi.String("gov-project"),
						},
					},
				},
				Tags: pulumi.StringMap{
					"team":    pulumi.String("aks"),
					"project": pulumi.String("gov-project"),
				},
				ResourceGroupName: pulumi.String("gov-resource-group"),
			},
			wantErr: false,
		},
		{
			name: "malformed JSON",
			input: `{
				"kubernetesVersion": "1.25.0",
				"complianceLevel": "high",
				"tier": "Standard",
				"location": "usgovvirginia",
				"environment": "production",
				"customer": "gov-customer",
				"subnetID": 12345,
				"agentPools": {
					"pool-1": {
						"initialWorkerCount": 3,
						"maxWorkers": 10,
						"minWorkers": 2,
						"instanceType": "Standard_D4s_v3",
						"diskSize": 50,
						"labels": {"env": "production"},
						"taints": ["key1=value1:NoSchedule", "key2=value2:PreferNoSchedule"],
						"tags": {"team": "aks", "project": "gov-project"}
					}
				},
				"tags": {"team": "aks", "project": "gov-project"},
				"resourceGroupName": "gov-resource-group"
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args aks.ClusterArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
