package aks

import (
	"encoding/base64"
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/whitelist"
	"github.com/pulumi/pulumi-azure-native-sdk/containerservice/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const clusterComponentName = "gravity:azure:cluster:aks"

var ErrUnableToCreateKubeConfig = errors.New("unable to create kubeconfig")

// Cluster is the pulumi Component resource containing a aks cluster and its dependencies.
type Cluster struct {
	pulumi.ResourceState
	// admin kubeconfig for the cluster to be used for creating explicit providers.
	Kubeconfig   pulumi.StringOutput      `pulumi:"kubeconfig"`
	Name         pulumi.StringOutput      `pulumi:"name"`
	AgentPoolIDs pulumi.StringArrayOutput `pulumi:"agentPoolIDs"`
}

type ClusterArgs struct {
	KubernetesVersion pulumi.StringInput        `pulumi:"kubernetesVersion" validate:"required"`
	Tier              pulumi.StringInput        `pulumi:"tier"              validate:"default=Free"`
	Location          pulumi.StringInput        `pulumi:"location"          validate:"default=usgovvirginia"`
	SubnetID          pulumi.StringInput        `pulumi:"subnetID"          validate:"required"`
	AgentPools        map[string]*AgentPoolArgs `pulumi:"agentPools"`
	Tags              pulumi.StringMap          `pulumi:"tags"`
	Environment       pulumi.StringInput        `pulumi:"environment"       validate:"required"`
	Customer          pulumi.StringInput        `pulumi:"customer"          validate:"required"`
	ResourceGroupName pulumi.StringInput        `pulumi:"resourceGroupName" validate:"required"`
	ComplianceLevel   pulumi.StringInput        `pulumi:"complianceLevel"   validate:"required"`
}

// New Cluster creates a aks cluster and its dependencies.
func NewCluster(ctx *pulumi.Context, name string, args *ClusterArgs, opts ...pulumi.ResourceOption) (*Cluster, error) {
	component := &Cluster{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(clusterComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource %s, %w", clusterComponentName, err)
	}

	if err := component.createAKSCluster(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createAgentPools(ctx, name+"-agent-pool", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"kubeconfig":   component.Kubeconfig,
		"agentPoolIDs": component.AgentPoolIDs,
	}); err != nil {
		return nil, fmt.Errorf("unable to register component resource outputs %s, %w", clusterComponentName, err)
	}

	return component, nil
}

func (c *Cluster) createAKSCluster(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	cluster, err := containerservice.NewManagedCluster(ctx, name, &containerservice.ManagedClusterArgs{
		AadProfile: &containerservice.ManagedClusterAADProfileArgs{
			EnableAzureRBAC: pulumi.Bool(true),
			Managed:         pulumi.Bool(true),
		},
		AddonProfiles: containerservice.ManagedClusterAddonProfileMap{
			"azureKeyvaultSecretsProvider": &containerservice.ManagedClusterAddonProfileArgs{
				Config: pulumi.StringMap{
					"enableSecretRotation": pulumi.String("true"),
					"rotationPollInterval": pulumi.String("2m"),
				},
				Enabled: pulumi.Bool(true),
			},
			// "azurePolicy": &containerservice.ManagedClusterAddonProfileArgs{
			// 	Config:  nil,
			// 	Enabled: pulumi.Bool(true),
			// },
		},
		AgentPoolProfiles: containerservice.ManagedClusterAgentPoolProfileArray{
			&containerservice.ManagedClusterAgentPoolProfileArgs{
				AvailabilityZones:  pulumi.ToStringArray([]string{"1", "2", "3"}),
				Count:              pulumi.Int(3),
				EnableAutoScaling:  pulumi.Bool(true),
				EnableFIPS:         pulumi.Bool(true),
				EnableNodePublicIP: pulumi.Bool(false),
				MaxCount:           pulumi.Int(6),
				MinCount:           pulumi.Int(3),
				Mode:               containerservice.AgentPoolModeSystem,
				Name:               pulumi.String("default"),
				OsSKU:              containerservice.OSSKUAzureLinux,
				ScaleSetPriority:   containerservice.ScaleSetPriorityRegular,
				Tags:               utils.GenerateTags(args.Tags, name),
				Type:               containerservice.AgentPoolTypeVirtualMachineScaleSets,
				VmSize:             pulumi.String("Standard_D2s_v3"),
				WorkloadRuntime:    containerservice.WorkloadRuntimeOCIContainer,
				VnetSubnetID:       args.SubnetID,
			},
		},
		ApiServerAccessProfile: &containerservice.ManagedClusterAPIServerAccessProfileArgs{
			AuthorizedIPRanges:   whitelist.GetIPWhitelist(args.ComplianceLevel),
			EnablePrivateCluster: pulumi.Bool(false),
		},
		AutoUpgradeProfile: &containerservice.ManagedClusterAutoUpgradeProfileArgs{
			UpgradeChannel: pulumi.String("patch"),
		},
		DisableLocalAccounts: pulumi.Bool(false),
		DnsPrefix:            pulumi.String(name),
		EnableRBAC:           pulumi.Bool(true),
		Identity: &containerservice.ManagedClusterIdentityArgs{
			Type: containerservice.ResourceIdentityTypeSystemAssigned,
		},
		KubernetesVersion: args.KubernetesVersion,
		Location:          args.Location,
		NetworkProfile: &containerservice.ContainerServiceNetworkProfileArgs{
			NatGatewayProfile: &containerservice.ManagedClusterNATGatewayProfileArgs{
				ManagedOutboundIPProfile: &containerservice.ManagedClusterManagedOutboundIPProfileArgs{
					Count: pulumi.Int(2),
				},
			},
			DnsServiceIP:      pulumi.String("172.22.0.10"),
			NetworkDataplane:  containerservice.NetworkDataplaneCilium,
			NetworkPlugin:     containerservice.NetworkPluginAzure,
			NetworkPluginMode: containerservice.NetworkPluginModeOverlay,
			NetworkPolicy:     containerservice.NetworkPolicyCilium,
			OutboundType:      containerservice.OutboundTypeLoadBalancer,
			PodCidr:           pulumi.String("172.21.0.0/16"),
			ServiceCidr:       pulumi.String("172.22.0.0/16"),
		},
		PublicNetworkAccess: containerservice.PublicNetworkAccessEnabled,
		ResourceGroupName:   args.ResourceGroupName,
		Sku: containerservice.ManagedClusterSKUArgs{
			Name: containerservice.ManagedClusterSKUNameBase,
			Tier: args.Tier,
		},
		StorageProfile: &containerservice.ManagedClusterStorageProfileArgs{
			BlobCSIDriver: &containerservice.ManagedClusterStorageProfileBlobCSIDriverArgs{
				Enabled: pulumi.Bool(true),
			},
			DiskCSIDriver: &containerservice.ManagedClusterStorageProfileDiskCSIDriverArgs{
				Enabled: pulumi.Bool(true),
			},
			SnapshotController: &containerservice.ManagedClusterStorageProfileSnapshotControllerArgs{
				Enabled: pulumi.Bool(true),
			},
		},
		Tags: utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create aks cluster %s, %w", name, err)
	}

	c.Name = cluster.Name

	if err := c.createKubeConfig(ctx, name, args); err != nil {
		return err
	}

	return nil
}

func (c *Cluster) createAgentPools(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	agentPools := pulumi.StringArray{}

	for poolName, poolArgs := range args.AgentPools {
		poolArgs.ClusterName = c.Name
		poolArgs.ResourceGroupName = args.ResourceGroupName

		pool, err := NewAgentPool(ctx, poolName, poolArgs)
		if err != nil {
			return fmt.Errorf("unable to create aks agentPool %s, %w", poolName, err)
		}

		agentPools = append(agentPools, pool.ID)
	}

	c.AgentPoolIDs = agentPools.ToStringArrayOutput()

	return nil
}

func (c *Cluster) createKubeConfig(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	adminCreds := containerservice.ListManagedClusterAdminCredentialsOutput(ctx,
		containerservice.ListManagedClusterAdminCredentialsOutputArgs{
			ResourceGroupName: args.ResourceGroupName,
			ResourceName:      c.Name,
		}, pulumi.Parent(c))

	adminKubeconfig, ok := adminCreds.Kubeconfigs().Index(pulumi.Int(0)).Value().ApplyT(func(encoded string) string {
		adminKubeconfig, err := base64.StdEncoding.DecodeString(encoded)
		if err != nil {
			return ""
		}

		return string(adminKubeconfig)
	}).(pulumi.StringOutput)
	if !ok {
		return fmt.Errorf("%w for cluster %s", ErrUnableToCreateKubeConfig, name)
	}

	c.Kubeconfig = adminKubeconfig

	return nil
}

func (args *ClusterArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *ClusterArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal cluster args, %w", err)
	}

	return nil
}
