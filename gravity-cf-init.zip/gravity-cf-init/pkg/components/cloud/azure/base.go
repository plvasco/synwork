package azure

import (
	"fmt"
	"regexp"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/whitelist"
	"github.com/pulumi/pulumi-azure-native-sdk/authorization/v2"
	"github.com/pulumi/pulumi-azure-native-sdk/keyvault/v2"
	"github.com/pulumi/pulumi-azure-native-sdk/managedidentity/v2"
	"github.com/pulumi/pulumi-azure-native-sdk/resources/v2"
	"github.com/pulumi/pulumi-azure-native-sdk/storage/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const baseComponentName = "gravity:azure:base"

type Base struct {
	pulumi.ResourceState
	ResourceGroupName          pulumi.StringOutput `pulumi:"resourceGroupName"`
	ManagedIdentityID          pulumi.StringOutput `pulumi:"managedIdentityID"`
	ManagedIdentityPrincipalID pulumi.StringOutput `pulumi:"managedIdentityPrincipalID"`
	VaultName                  pulumi.StringOutput `pulumi:"vaultName"`
	VaultURI                   pulumi.StringOutput `pulumi:"vaultURI"`
	KeyURI                     pulumi.StringOutput `pulumi:"keyURI"`
	KeyName                    pulumi.StringOutput `pulumi:"keyName"`
	StorageAccountName         pulumi.StringOutput `pulumi:"storageAccountName"`
	BlobContainerName          pulumi.StringOutput `pulumi:"blobContainerName"`
	BlobContainerURI           pulumi.StringOutput `pulumi:"blobContainerURI"`
	SecretProviderURI          pulumi.StringOutput `pulumi:"secretProviderURI"`
}

type BaseArgs struct {
	Customer        pulumi.StringInput `pulumi:"customer"        validate:"required"`
	Environment     pulumi.StringInput `pulumi:"environment"     validate:"required"`
	ComplianceLevel pulumi.StringInput `pulumi:"complianceLevel" validate:"required"`
	Location        pulumi.String      `pulumi:"location"`
	Tags            pulumi.StringMap   `pulumi:"tags"`
}

func NewBase(ctx *pulumi.Context, name string, args *BaseArgs, opts ...pulumi.ResourceOption) (*Base, error) {
	component := &Base{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(baseComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource %s, %w", baseComponentName, err)
	}

	if err := component.createResourceGroup(ctx, "rg-"+name+"-", args); err != nil {
		return nil, err
	}

	if err := component.createManagedIdentity(ctx, "mi-"+name+"-", args); err != nil {
		return nil, err
	}

	if err := component.createVault(ctx, "kv-"+name+"-", args); err != nil {
		return nil, err
	}

	if err := component.createKey(ctx, "key-"+name, args); err != nil {
		return nil, err
	}

	if err := component.createStorageAccount(ctx, "sa"+name, args); err != nil {
		return nil, err
	}

	if err := component.createBlobStorage(ctx, "blob-"+name, args); err != nil {
		return nil, err
	}

	component.setSecretsProvider()

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"resourceGroupName":  component.ResourceGroupName,
		"secretsProviderURI": component.SecretProviderURI,
		"blobContainerURI":   component.BlobContainerURI,
	}); err != nil {
		return nil, fmt.Errorf("unable to register component resource outputs %s, %w", baseComponentName, err)
	}

	return component, nil
}

func (c *Base) createResourceGroup(ctx *pulumi.Context, name string, args *BaseArgs) error {
	rg, err := resources.NewResourceGroup(ctx, name, &resources.ResourceGroupArgs{
		Location: args.Location,
		Tags:     args.Tags,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create resource group %s, %w", name, err)
	}

	c.ResourceGroupName = rg.Name

	return nil
}

func (c *Base) createManagedIdentity(ctx *pulumi.Context, name string, args *BaseArgs) error {
	identity, err := managedidentity.NewUserAssignedIdentity(ctx, name, &managedidentity.UserAssignedIdentityArgs{
		Location:          args.Location,
		ResourceGroupName: c.ResourceGroupName,
		Tags:              args.Tags,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create managed identity %s, %w", name, err)
	}

	c.ManagedIdentityID = identity.ID().ToStringOutput()
	c.ManagedIdentityPrincipalID = identity.PrincipalId

	return nil
}

func (c *Base) createVault(ctx *pulumi.Context, name string, args *BaseArgs) error {
	client, err := authorization.GetClientConfig(ctx, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("error creating authorization client, %w", err)
	}

	vault, err := keyvault.NewVault(ctx, name, &keyvault.VaultArgs{
		Location: args.Location,
		Properties: &keyvault.VaultPropertiesArgs{
			EnablePurgeProtection:     pulumi.Bool(true),
			EnableRbacAuthorization:   pulumi.Bool(true),
			Sku:                       &keyvault.SkuArgs{Family: pulumi.String("A"), Name: keyvault.SkuNameStandard},
			SoftDeleteRetentionInDays: pulumi.Int(90),
			TenantId:                  pulumi.String(client.TenantId),
		},
		ResourceGroupName: c.ResourceGroupName,
		Tags:              args.Tags,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create vault %s, %w", name, err)
	}

	// built in roleDefinition of Key Vault Crypto User
	roleID := fmt.Sprintf("/subscriptions/%s/providers/Microsoft.Authorization/roleDefinitions/12338af0-0e69-4776-bea7-57ae8d297424",
		client.SubscriptionId)

	if _, err := authorization.NewRoleAssignment(ctx, name+"ra", &authorization.RoleAssignmentArgs{
		PrincipalId:      c.ManagedIdentityPrincipalID,
		PrincipalType:    pulumi.String("ServicePrincipal"),
		RoleDefinitionId: pulumi.String(roleID),
		Scope:            vault.ID(),
	}, pulumi.Parent(vault)); err != nil {
		return fmt.Errorf("error creating base role assignment %s for vault, %w", name, err)
	}

	c.VaultName = vault.Name
	c.VaultURI = vault.Properties.VaultUri().Elem()

	return nil
}

func (c *Base) createKey(ctx *pulumi.Context, name string, args *BaseArgs) error {
	key, err := keyvault.NewKey(ctx, name, &keyvault.KeyArgs{
		Properties: &keyvault.KeyPropertiesArgs{
			Attributes: &keyvault.KeyAttributesArgs{
				Enabled: pulumi.Bool(true),
			},
			Kty: pulumi.String("RSA"),
		},
		ResourceGroupName: c.ResourceGroupName,
		Tags:              args.Tags,
		VaultName:         c.VaultName,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("error creating base key %s for vault %v, %w", name, c.VaultName, err)
	}

	c.KeyURI = key.KeyUri
	c.KeyName = key.Name

	return nil
}

func (c *Base) createWhiteListRules(args *BaseArgs) storage.IPRuleArrayOutput {
	list := whitelist.GetIPWhitelist(args.ComplianceLevel)

	ipRules := pulumix.Apply(list, func(ips []string) []storage.IPRule {
		ipRulesList := []storage.IPRule{}

		for _, ip := range ips {
			action := storage.ActionAllow
			ipRule := storage.IPRule{
				Action:           &action,
				IPAddressOrRange: strings.ReplaceAll(ip, "/32", ""),
			}

			ipRulesList = append(ipRulesList, ipRule)
		}

		return ipRulesList
	})

	return storage.IPRuleArrayOutput(ipRules.AsAny())
}

func (c *Base) createStorageAccount(ctx *pulumi.Context, name string, args *BaseArgs) error {
	re := regexp.MustCompile("[^a-z0-9]")

	storageAccount, err := storage.NewStorageAccount(ctx, re.ReplaceAllString(name, ""), &storage.StorageAccountArgs{
		AllowBlobPublicAccess: pulumi.Bool(false),
		Identity: &storage.IdentityArgs{
			Type: storage.IdentityTypeUserAssigned,
			UserAssignedIdentities: pulumi.StringArray{
				c.ManagedIdentityID,
			},
		},
		Encryption: &storage.EncryptionArgs{
			EncryptionIdentity: &storage.EncryptionIdentityArgs{
				EncryptionUserAssignedIdentity: c.ManagedIdentityID,
			},
			KeySource: storage.KeySource_Microsoft_Keyvault,
			KeyVaultProperties: &storage.KeyVaultPropertiesArgs{
				KeyName:     c.KeyName,
				KeyVaultUri: c.VaultURI,
			},
			RequireInfrastructureEncryption: pulumi.Bool(true),
			Services: &storage.EncryptionServicesArgs{
				Blob: &storage.EncryptionServiceArgs{
					Enabled: pulumi.Bool(true),
					KeyType: pulumi.String("Account"),
				},
			},
		},
		MinimumTlsVersion: pulumi.String("TLS1_2"),
		NetworkRuleSet: &storage.NetworkRuleSetArgs{
			DefaultAction: storage.DefaultActionDeny,
			IpRules:       c.createWhiteListRules(args),
		},
		Kind:     storage.KindStorageV2,
		Location: args.Location,
		ImmutableStorageWithVersioning: storage.ImmutableStorageAccountArgs{
			Enabled: pulumi.Bool(true),
		},
		ResourceGroupName: c.ResourceGroupName,
		Sku: &storage.SkuArgs{
			Name: storage.SkuName_Standard_ZRS,
		},
		Tags: args.Tags,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create root storage account %s, %w", name, err)
	}

	c.StorageAccountName = storageAccount.Name

	return nil
}

func (c *Base) createBlobStorage(ctx *pulumi.Context, name string, args *BaseArgs) error {
	blobContainer, err := storage.NewBlobContainer(ctx, name, &storage.BlobContainerArgs{
		ContainerName:     pulumi.Sprintf("gamewarden-infrastructure-state-%s-%s", args.ComplianceLevel, args.Customer),
		AccountName:       c.StorageAccountName,
		Metadata:          args.Tags,
		PublicAccess:      storage.PublicAccessNone,
		ResourceGroupName: c.ResourceGroupName,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create root blob container %s, %w", name, err)
	}

	c.BlobContainerName = blobContainer.Name

	c.BlobContainerURI = pulumi.Sprintf("azblob://%s", blobContainer.Name)

	return nil
}

func (c *Base) setSecretsProvider() {
	secretProviderURI := pulumix.Apply(c.KeyURI, func(uri string) string {
		return strings.ReplaceAll(uri, "https://", "azurekeyvault://")
	})

	c.SecretProviderURI = pulumix.Cast[pulumi.StringOutput](secretProviderURI)
}

func (args *BaseArgs) validate() error {
	args.setDefaultTags()

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *BaseArgs) setDefaultTags() {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["complianceLevel"] = args.ComplianceLevel
	}

	if _, ok := args.Tags["environment"]; !ok {
		args.Tags["environment"] = args.Environment
	}

	if _, ok := args.Tags["customer"]; !ok {
		args.Tags["customer"] = args.Customer
	}
}

func (args *BaseArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal agent pool args, %w", err)
	}

	return nil
}
