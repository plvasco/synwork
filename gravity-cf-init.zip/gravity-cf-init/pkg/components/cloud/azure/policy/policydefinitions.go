package policy

import (
	"bytes"
	"embed"
	"encoding/json"
	"fmt"
	"html/template"
	"path/filepath"
	"reflect"
	"strings"

	"github.com/pulumi/pulumi-azure-native-sdk/authorization/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

//go:embed templates
var templateFiles embed.FS

const policyDefinitionsComponentName = "gravity:azure:custompolicies"

const policyDefinitionsDirectory = "templates/policyDefinitions"
const policySetDefinitionsDirectory = "templates/policySetDefinitions"

type PolicyDefinitionsState struct {
	pulumi.ResourceState
	PolicyDefinitionIDs pulumi.IDArrayOutput `pulumi:"policyDefinitionIDs"`
	InitiativeIDs       pulumi.IDArrayOutput `pulumi:"initiativeIDs"`
}

type Policy struct {
	Name       string           `json:"name"`
	Properties PolicyProperties `json:"properties"`
}

type PolicyProperties struct {
	DisplayName string                 `json:"displayName"`
	Description string                 `json:"description"`
	PolicyType  string                 `json:"policyType"`
	Mode        string                 `json:"mode"`
	Metadata    Metadata               `json:"metadata"`
	Parameters  map[string]Parameter   `json:"parameters"`
	PolicyRule  map[string]interface{} `json:"policyRule"`
}

type Metadata struct {
	Category string `json:"category"`
}

type Parameter struct {
	Type          string      `json:"type"`
	AllowedValues []string    `json:"allowedValues"`
	DefaultValue  interface{} `json:"defaultValue"`
}

type Initiative struct {
	Name       string               `json:"name"`
	Properties InitiativeProperties `json:"properties"`
}

type InitiativeProperties struct {
	DisplayName       string                                    `json:"displayName"`
	Description       string                                    `json:"description"`
	PolicyType        string                                    `json:"policyType"`
	Metadata          Metadata                                  `json:"metadata"`
	Parameters        map[string]Parameter                      `json:"parameters"`
	PolicyDefinitions []authorization.PolicyDefinitionReference `json:"policyDefinitions"`
}

type InitiativeOutput struct {
	*pulumi.OutputState
}

func (InitiativeOutput) ElementType() reflect.Type {
	return reflect.TypeOf((*Initiative)(nil)).Elem()
}

func NewCustomPolicyDefinitions(ctx *pulumi.Context, name string, policyDefinitionScope pulumi.String, opts ...pulumi.ResourceOption) (*PolicyDefinitionsState, error) {
	component := &PolicyDefinitionsState{}

	if err := ctx.RegisterComponentResource(policyDefinitionsComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource %s, %w", policyDefinitionsComponentName, err)
	}

	policyDefinitionResources, err := component.createCustomPolicyDefinitions(ctx)
	if err != nil {
		return nil, err
	}

	if err := component.createCustomInitiativeDefinitions(ctx, policyDefinitionScope, policyDefinitionResources); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"policyDefinitionIDs": component.PolicyDefinitionIDs,
		"initiativeIDs":       component.InitiativeIDs,
	}); err != nil {
		return nil, fmt.Errorf("unable to register component resource outputs %s, %w", policyDefinitionsComponentName, err)
	}

	return component, nil
}

func (c *PolicyDefinitionsState) createCustomPolicyDefinitions(ctx *pulumi.Context) ([]pulumi.Resource, error) {
	var results []pulumi.Resource

	policyDefinitions, err := readPolicies(policyDefinitionsDirectory)
	if err != nil {
		return nil, err
	}
	var policyDefinitionIds []pulumi.IDOutput

	for _, policy := range policyDefinitions {
		policyDef, err := authorization.NewPolicyDefinition(ctx, policy.Name, &authorization.PolicyDefinitionArgs{
			PolicyDefinitionName: pulumi.String(policy.Name),
			PolicyType:           authorization.PolicyTypeCustom,
			Mode:                 pulumi.String(policy.Properties.Mode),
			DisplayName:          pulumi.String(policy.Properties.DisplayName),
			Description:          pulumi.String(policy.Properties.Description),
			PolicyRule:           toPulumiMap(policy.Properties.PolicyRule),
			Parameters:           toParameterDefinitionsValueMapInput(policy.Properties.Parameters),
		}, pulumi.Parent(c))
		if err != nil {
			return nil, err
		}
		results = append(results, policyDef)
		policyDefinitionIds = append(policyDefinitionIds, policyDef.ID())
	}

	c.PolicyDefinitionIDs = pulumi.ToIDArrayOutput(policyDefinitionIds)
	return results, err
}

func (c *PolicyDefinitionsState) createCustomInitiativeDefinitions(ctx *pulumi.Context, policyDefinitionScope pulumi.String, policyDefinitions []pulumi.Resource) error {
	initiatives, err := readInitiatives(policySetDefinitionsDirectory, policyDefinitionScope)
	if err != nil {
		return err
	}

	var initiativeIDs []pulumi.IDOutput
	for _, initiative := range initiatives {
		initiative, err := authorization.NewPolicySetDefinition(ctx, initiative.Name, &authorization.PolicySetDefinitionArgs{
			PolicySetDefinitionName: pulumi.String(initiative.Name),
			PolicyType:              authorization.PolicyTypeCustom,
			DisplayName:             pulumi.String(initiative.Properties.DisplayName),
			Description:             pulumi.String(initiative.Properties.Description),
			PolicyDefinitions:       ConvertToPolicyDefinitionReferenceArray(initiative.Properties.PolicyDefinitions),
			Parameters:              toParameterDefinitionsValueMapInput(initiative.Properties.Parameters),
		}, pulumi.Parent(c), pulumi.DependsOn(policyDefinitions))
		if err != nil {
			return err
		}
		initiativeIDs = append(initiativeIDs, initiative.ID())
	}

	c.InitiativeIDs = pulumi.ToIDArrayOutput(initiativeIDs)
	return nil
}

func ReadPolicies() ([]Policy, error) {
	dir := "templates/policyDefinitions"
	return readPolicies(dir)
}

func ReadInitiatives(customPolicyManagementGroup pulumi.String) ([]Initiative, error) {
	dir := "templates/policySetDefinitions"
	return readInitiatives(dir, customPolicyManagementGroup)
}

func readPolicies(dir string) ([]Policy, error) {
	var policies []Policy

	// Read all files in the directory
	files, err := templateFiles.ReadDir(dir)
	if err != nil {
		fmt.Println("Error reading directory:", err)
		return nil, err
	}

	// Iterate over each file
	for _, file := range files {
		if filepath.Ext(file.Name()) == ".json" {
			// Read the file content
			// filePath := filepath.Join(dir, file.Name())
			content, err := templateFiles.ReadFile(fmt.Sprintf("%s/%s", dir, file.Name()))
			if err != nil {
				fmt.Println("Error reading file:", file, err)
				continue
			}

			// Deserialize JSON content into a map
			var properties PolicyProperties
			if err := json.Unmarshal(content, &properties); err != nil {
				fmt.Println("Error unmarshalling JSON:", file, err)
				continue
			}

			// Create a Policy object
			policy := Policy{
				Name:       strings.TrimSuffix(file.Name(), filepath.Ext(file.Name())),
				Properties: properties,
			}

			// Append to the policies slice
			policies = append(policies, policy)
		}
	}

	return policies, nil
}

func readInitiatives(dir string, policyDefinitionScope pulumi.String) ([]Initiative, error) {
	var initiatives []Initiative

	var values struct {
		PolicyDefinitionScope string
	}
	values.PolicyDefinitionScope = string(policyDefinitionScope)

	// Read all files in the directory
	files, err := templateFiles.ReadDir(dir)
	if err != nil {
		fmt.Println("Error reading directory:", err)
		return nil, err
	}

	// Iterate over each file
	for _, file := range files {
		if filepath.Ext(file.Name()) != ".tmpl" {
			continue
		}

		// Create a buffer to hold the executed template
		var buf bytes.Buffer

		tmpl, err := template.ParseFS(templateFiles, fmt.Sprintf("%s/%s", dir, file.Name()))
		if err != nil {
			return nil, fmt.Errorf("error parsing template file: %v", err)
		}

		// Execute the template with the data
		if err := tmpl.Execute(&buf, values); err != nil {
			return nil, fmt.Errorf("error executing template: %v", err)
		}

		// Deserialize the JSON from the buffer
		var properties InitiativeProperties
		if err := json.Unmarshal(buf.Bytes(), &properties); err != nil {
			return nil, fmt.Errorf("error unmarshaling JSON: %v", err)
		}

		// Create a Policy object
		initiative := Initiative{
			Name:       strings.SplitN(file.Name(), ".", 2)[0],
			Properties: properties,
		}
		// Append to the policies slice
		initiatives = append(initiatives, initiative)
	}

	return initiatives, nil
}

func toPulumiMap(input map[string]interface{}) pulumi.Map {
	result := make(pulumi.Map)
	for key, value := range input {
		result[key] = pulumi.Any(value)
	}
	return result
}

func ConvertToPolicyDefinitionReferenceArray(input []authorization.PolicyDefinitionReference) authorization.PolicyDefinitionReferenceArray {
	var result authorization.PolicyDefinitionReferenceArray

	for _, pd := range input {
		// ParameterValuesValueMap{ "key": ParameterValuesValueArgs{...} }
		parameters := make(authorization.ParameterValuesValueMap)
		for k, v := range pd.Parameters {
			parameters[k] = authorization.ParameterValuesValueArgs{
				Value: pulumi.Any(v.Value),
			}
		}

		result = append(result, authorization.PolicyDefinitionReferenceArgs{
			PolicyDefinitionId:          pulumi.String(pd.PolicyDefinitionId),
			PolicyDefinitionReferenceId: pulumi.StringPtr(*pd.PolicyDefinitionReferenceId),
			Parameters:                  parameters,
		})
	}
	return result
}

func toParameterDefinitionsValueMapInput(input map[string]Parameter) authorization.ParameterDefinitionsValueMapInput {
	result := make(authorization.ParameterDefinitionsValueMap)
	for key, value := range input {
		var pulumiAllowedValues []pulumi.Input
		for _, s := range value.AllowedValues {
			pulumiAllowedValues = append(pulumiAllowedValues, pulumi.String(s))
		}
		result[key] = authorization.ParameterDefinitionsValueArgs{
			AllowedValues: pulumi.Array(pulumiAllowedValues),
			DefaultValue:  pulumi.Any(value.DefaultValue),
			Type:          pulumi.String(value.Type),
		}
	}
	return result
}
