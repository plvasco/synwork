package policy_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/policy"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestNewPolicyAssignmentsAtSubscription(t *testing.T) {
	type want struct {
		AllLogsInitiativeAssignmentID   pulumi.IDOutput `pulumi:"allLogsInitiativeAssignmentID"`
		AuditLogsInitiativeAssignmentID pulumi.IDOutput `pulumi:"auditLogsInitiativeAssignmentID"`
		DefenderInitiativeAssignmentID  pulumi.IDOutput `pulumi:"defenderInitiativeAssignmentID"`
	}

	type args struct {
		name string
		args policy.PolicyAssignmentsArgs
		opts []pulumi.ResourceOption
	}

	tests := []struct {
		name    string
		args    args
		want    want
		wantErr bool
	}{
		{
			name: "should create policy assignments",
			args: args{
				name: "test-policy-assignments",
				args: policy.PolicyAssignmentsArgs{
					AllLogsResourceTypes:    pulumi.StringArray{pulumi.String("microsoft.automation/automationaccounts"), pulumi.String("microsoft.containerregistry/registries")},
					AuditLogsResourceTypes:  pulumi.StringArray{pulumi.String("microsoft.aad/domainservices"), pulumi.String("microsoft.cache/redis")},
					LogAnalyticsWorkspaceID: pulumi.String("123e4567-e89b-12d3-a456-426614174000"),
					SubscriptionID:          pulumi.String("123e4567-e89b-12d3-a456-426614174000"),
				},
			},
			want:    want{},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := policy.NewPolicyAssignmentsAtSubscription(ctx, tt.args.name, tt.args.args, tt.args.opts...)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
