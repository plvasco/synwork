package policy_test

import (
	"fmt"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/policy"
	"github.com/google/uuid"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

func TestReadLoggingPolicies(t *testing.T) {
	t.Parallel()

	t.Run("readPolicies", func(t *testing.T) {
		t.Parallel()

		policies, err := policy.ReadPolicies()

		assert.NotZero(t, len(policies))

		if err != nil {
			t.Errorf("error = %v", err)
		}
	})
}

func TestReadLoggingInitiatives(t *testing.T) {
	t.Parallel()

	t.Run("readLoggingInitiativesReturns", func(t *testing.T) {
		t.Parallel()

		initiatives, err := policy.ReadInitiatives("foo")

		assert.NotZero(t, len(initiatives))

		if err != nil {
			t.Errorf("error = %v", err)
		}
	})

	t.Run("initiativesReflectManagementGroup", func(t *testing.T) {
		t.Parallel()

		var subscriptionScope = fmt.Sprintf("/subscriptions/%s", uuid.New().String())

		initiatives, err := policy.ReadInitiatives(pulumi.String(subscriptionScope))

		test := initiatives[0].Properties.PolicyDefinitions[0].PolicyDefinitionId
		assert.Contains(t, test, subscriptionScope) // ensures that MG substitution worked correctly

		if err != nil {
			t.Errorf("error = %v", err)
		}
	})
}
