package policy

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/authorization/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const policyAssignmentsComponentName = "gravity:azure:policyassignments"

const allLogsInitiativeName = "deploy-allLogs-category-logs-to-laws"
const auditLogsInitiativeName = "deploy-audit-category-logs-to-laws"
const defenderInitiativeName = "configure-microsoft-defender-for-cloud-plans"

type PolicyAssignmentsState struct {
	pulumi.ResourceState
	AllLogsInitiativeAssignmentID    pulumi.IDOutput `pulumi:"allLogsInitiativeAssignmentID"`
	AuditLogsInitiativeAssignmentID  pulumi.IDOutput `pulumi:"auditLogsInitiativeAssignmentID"`
	DefenderInitiativeAssignmentID   pulumi.IDOutput `pulumi:"defenderInitiativeAssignmentID"`
	AzureActivityLogsAssignmentID    pulumi.IDOutput `pulumi:"azureActivityLogsAssignmentID"`
	AzureKubernetesAuditAssignmentID pulumi.IDOutput `pulumi:"azureKubernetesAuditAssignmentID"`
}

type PolicyAssignmentsArgs struct {
	AllLogsResourceTypes    pulumi.StringArrayInput `pulumi:"allLogsResourceTypes"`
	AuditLogsResourceTypes  pulumi.StringArrayInput `pulumi:"auditLogsResourceTypes"`
	LogAnalyticsWorkspaceID pulumi.StringInput      `pulumi:"logAnalyticsWorkspaceID"      validate:"required"`
	SubscriptionID          pulumi.StringInput      `pulumi:"subscriptionID"               validate:"required"`
	Tags                    pulumi.StringMap        `pulumi:"tags"`
}

func NewPolicyAssignmentsAtSubscription(ctx *pulumi.Context, name string, args PolicyAssignmentsArgs, opts ...pulumi.ResourceOption) (*PolicyAssignmentsState, error) {
	component := &PolicyAssignmentsState{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	err := ctx.RegisterComponentResource(policyAssignmentsComponentName, name, component, opts...)
	if err != nil {
		return nil, err
	}

	if initiative, err := component.assignLogsInitiative(ctx, name+"-all-logs", args,
		pulumi.String(allLogsInitiativeName),
		pulumi.String("Deploy all logs category logs to Log Analytics Workspace"),
		args.AllLogsResourceTypes,
	); err != nil {
		return nil, err
	} else {
		component.AllLogsInitiativeAssignmentID = initiative.ID()
	}

	if initiative, err := component.assignLogsInitiative(ctx, name+"-audit-logs", args,
		pulumi.String(auditLogsInitiativeName),
		pulumi.String("Deploy audit logs category logs to Log Analytics Workspace"),
		args.AuditLogsResourceTypes,
	); err != nil {
		return nil, err
	} else {
		component.AuditLogsInitiativeAssignmentID = initiative.ID()
	}

	if policy, err := component.assignAzureActivityLogsPolicy(ctx, name+"-azure-activity-logs", args); err != nil {
		return nil, err
	} else {
		component.AzureActivityLogsAssignmentID = policy.ID()
	}

	if initiative, err := component.assignDefenderInitiative(ctx, name+"-configure-defender", args); err != nil {
		return nil, err
	} else {
		component.DefenderInitiativeAssignmentID = initiative.ID()
	}

	if policy, err := component.assignKubernetesAuditInitiative(ctx, name+"-configure-kubernetes-audit", args); err != nil {
		return nil, err
	} else {
		component.AzureKubernetesAuditAssignmentID = policy.ID()
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"allLogsInitiativeAssignmentID":    pulumi.String("allLogsInitiativeAssignmentID"),
		"auditLogsInitiativeAssignmentID":  pulumi.String("auditLogsInitiativeAssignmentID"),
		"defenderInitiativeAssignmentID":   pulumi.String("defenderInitiativeAssignmentID"),
		"azureActivityLogsAssignmentID":    pulumi.String("azureActivityLogsAssignmentID"),
		"azureKubernetesAuditAssignmentID": pulumi.String("azureKubernetesAuditAssignmentID"),
	}); err != nil {
		return nil, err
	}

	return component, nil
}

func (args PolicyAssignmentsArgs) validate() error {
	err := utils.ValidateStruct(args)
	if err != nil {
		return fmt.Errorf("unable to validate policy assignments args, %w", err)
	}

	return nil
}

func (component *PolicyAssignmentsState) assignLogsInitiative(ctx *pulumi.Context, name string, args PolicyAssignmentsArgs, initiativeName pulumi.StringInput, assignmentDescription pulumi.StringInput, resourceTypes pulumi.StringArrayInput) (*authorization.PolicyAssignment, error) {
	parameters := authorization.ParameterValuesValueMap{
		"logAnalytics": authorization.ParameterValuesValueArgs{
			Value: args.LogAnalyticsWorkspaceID,
		},
	}

	if resourceTypes != nil {
		parameters["resourceTypeList"] = authorization.ParameterValuesValueArgs{
			Value: resourceTypes,
		}
	}

	assignment, err := authorization.NewPolicyAssignment(ctx, name, &authorization.PolicyAssignmentArgs{
		DisplayName:        assignmentDescription,
		PolicyDefinitionId: pulumi.String(fmt.Sprintf("/subscriptions/%s/providers/Microsoft.Authorization/policySetDefinitions/%s", args.SubscriptionID, initiativeName)),
		Scope:              pulumi.String(fmt.Sprintf("/subscriptions/%s", args.SubscriptionID)),
		Parameters:         parameters,
		Identity: &authorization.IdentityArgs{
			Type: authorization.ResourceIdentityTypeSystemAssigned,
		},
	}, pulumi.Parent(component))
	if err != nil {
		return nil, fmt.Errorf("unable to assign initiative %s, %w", name, err)
	}

	// Log Analytics Contributor role (https://www.azadvertizer.net/azrolesadvertizer/92aaf0da-9dab-42b6-94a3-d43ce8d16293.html)
	roleID := fmt.Sprintf("/subscriptions/%s/providers/Microsoft.Authorization/roleDefinitions/92aaf0da-9dab-42b6-94a3-d43ce8d16293", args.SubscriptionID)

	principalID := assignment.Identity.PrincipalId().Elem()

	_, err = authorization.NewRoleAssignment(ctx, name+"-ra", &authorization.RoleAssignmentArgs{
		PrincipalId:      principalID,
		PrincipalType:    pulumi.String("ServicePrincipal"),
		RoleDefinitionId: pulumi.String(roleID),
		Scope:            pulumi.String(fmt.Sprintf("/subscriptions/%s", args.SubscriptionID)),
	}, pulumi.Parent(assignment))
	if err != nil {
		return nil, fmt.Errorf("error creating base role assignment %s for policy assignment, %w", name, err)
	}

	return assignment, nil
}

func (component *PolicyAssignmentsState) assignAzureActivityLogsPolicy(ctx *pulumi.Context, name string, args PolicyAssignmentsArgs) (*authorization.PolicyAssignment, error) {
	parameters := authorization.ParameterValuesValueMap{
		"logAnalytics": authorization.ParameterValuesValueArgs{
			Value: args.LogAnalyticsWorkspaceID,
		},
	}

	assignment, err := authorization.NewPolicyAssignment(ctx, name, &authorization.PolicyAssignmentArgs{
		DisplayName:        pulumi.String("Deploy Azure Activity Logs to Log Analytics Workspace"),
		PolicyDefinitionId: pulumi.String("/providers/Microsoft.Authorization/policyDefinitions/2465583e-4e78-4c15-b6be-a36cbc7c8b0f"),
		Scope:              pulumi.String(fmt.Sprintf("/subscriptions/%s", args.SubscriptionID)),
		Parameters:         parameters,
		Identity: &authorization.IdentityArgs{
			Type: authorization.ResourceIdentityTypeSystemAssigned,
		},
	}, pulumi.Parent(component))
	if err != nil {
		return nil, fmt.Errorf("unable to assign policy %s, %w", name, err)
	}

	// Log Analytics Contributor role (https://www.azadvertizer.net/azrolesadvertizer/92aaf0da-9dab-42b6-94a3-d43ce8d16293.html)
	roleID := fmt.Sprintf("/subscriptions/%s/providers/Microsoft.Authorization/roleDefinitions/92aaf0da-9dab-42b6-94a3-d43ce8d16293", args.SubscriptionID)

	principalID := assignment.Identity.PrincipalId().Elem()

	_, err = authorization.NewRoleAssignment(ctx, name+"-ra", &authorization.RoleAssignmentArgs{
		PrincipalId:      principalID,
		PrincipalType:    pulumi.String("ServicePrincipal"),
		RoleDefinitionId: pulumi.String(roleID),
		Scope:            pulumi.String(fmt.Sprintf("/subscriptions/%s", args.SubscriptionID)),
	}, pulumi.Parent(assignment))
	if err != nil {
		return nil, fmt.Errorf("error creating base role assignment %s for policy assignment, %w", name, err)
	}

	return assignment, nil
}

func (component *PolicyAssignmentsState) assignDefenderInitiative(ctx *pulumi.Context, name string, args PolicyAssignmentsArgs) (*authorization.PolicyAssignment, error) {
	assignment, err := authorization.NewPolicyAssignment(ctx, name, &authorization.PolicyAssignmentArgs{
		DisplayName:        pulumi.String("Configure Microsoft Defender for Cloud Plans"),
		PolicyDefinitionId: pulumi.String(fmt.Sprintf("/subscriptions/%s/providers/Microsoft.Authorization/policySetDefinitions/%s", args.SubscriptionID, defenderInitiativeName)),
		Scope:              pulumi.String(fmt.Sprintf("/subscriptions/%s", args.SubscriptionID)),
		Parameters:         nil,
		Identity: &authorization.IdentityArgs{
			Type: authorization.ResourceIdentityTypeSystemAssigned,
		},
	}, pulumi.Parent(component))
	if err != nil {
		return nil, fmt.Errorf("unable to assign initiative %s, %w", name, err)
	}

	// Owner role [Privileged] (https://www.azadvertizer.net/azrolesadvertizer/8e3af657-a8ff-443c-a75c-2fe8c4bcb635.html)
	roleID := fmt.Sprintf("/subscriptions/%s/providers/Microsoft.Authorization/roleDefinitions/8e3af657-a8ff-443c-a75c-2fe8c4bcb635", args.SubscriptionID)

	principalID := assignment.Identity.PrincipalId().Elem()

	_, err = authorization.NewRoleAssignment(ctx, name+"-ra", &authorization.RoleAssignmentArgs{
		PrincipalId:      principalID,
		PrincipalType:    pulumi.String("ServicePrincipal"),
		RoleDefinitionId: pulumi.String(roleID),
		Scope:            pulumi.String(fmt.Sprintf("/subscriptions/%s", args.SubscriptionID)),
	}, pulumi.Parent(assignment))
	if err != nil {
		return nil, fmt.Errorf("error creating base role assignment %s for policy assignment, %w", name, err)
	}

	return assignment, nil
}

func (component *PolicyAssignmentsState) assignKubernetesAuditInitiative(ctx *pulumi.Context, name string, args PolicyAssignmentsArgs) (*authorization.PolicyAssignment, error) {
	parameters := authorization.ParameterValuesValueMap{
		"logAnalytics": authorization.ParameterValuesValueArgs{
			Value: args.LogAnalyticsWorkspaceID,
		},
		"diagnosticsSettingNameToUse": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("aks-audit-logs-to-central-laws"),
		},
		"kube-apiserver": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("True"),
		},
		"kube-audit": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("True"),
		},
		"kube-controller-manager": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("True"),
		},
		"kube-audit-admin": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("True"),
		},
		"guard": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("True"),
		},
		"cluster-autoscaler": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("False"),
		},
		// Don't log the below, as they don't contribute significant value to Sentinel
		"AllMetrics": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("False"),
		},
		"kube-scheduler": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("False"),
		},
		"cloud-controller-manager": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("False"),
		},
		"csi-azuredisk-controller": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("False"),
		},
		"csi-azurefile-controller": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("False"),
		},
		"csi-snapshot-controller": authorization.ParameterValuesValueArgs{
			Value: pulumi.String("False"),
		},
	}

	assignment, err := authorization.NewPolicyAssignment(ctx, name, &authorization.PolicyAssignmentArgs{
		DisplayName:        pulumi.String("Configure AKS Audit Logs"),
		PolicyDefinitionId: pulumi.String("/providers/Microsoft.Authorization/policyDefinitions/6c66c325-74c8-42fd-a286-a74b0e2939d8"),
		Scope:              pulumi.String(fmt.Sprintf("/subscriptions/%s", args.SubscriptionID)),
		Parameters:         parameters,
		Identity: &authorization.IdentityArgs{
			Type: authorization.ResourceIdentityTypeSystemAssigned,
		},
	}, pulumi.Parent(component))
	if err != nil {
		return nil, fmt.Errorf("unable to assign initiative %s, %w", name, err)
	}

	// Log Analytics Contributor role (https://www.azadvertizer.net/azrolesadvertizer/92aaf0da-9dab-42b6-94a3-d43ce8d16293.html)
	roleID := fmt.Sprintf("/subscriptions/%s/providers/Microsoft.Authorization/roleDefinitions/92aaf0da-9dab-42b6-94a3-d43ce8d16293", args.SubscriptionID)

	principalID := assignment.Identity.PrincipalId().Elem()

	_, err = authorization.NewRoleAssignment(ctx, name+"-ra", &authorization.RoleAssignmentArgs{
		PrincipalId:      principalID,
		PrincipalType:    pulumi.String("ServicePrincipal"),
		RoleDefinitionId: pulumi.String(roleID),
		Scope:            pulumi.String(fmt.Sprintf("/subscriptions/%s", args.SubscriptionID)),
	}, pulumi.Parent(assignment))
	if err != nil {
		return nil, fmt.Errorf("error creating base role assignment %s for policy assignment, %w", name, err)
	}

	return assignment, nil
}

func (a *PolicyAssignmentsArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal infra args, %w", err)
	}

	return nil
}
