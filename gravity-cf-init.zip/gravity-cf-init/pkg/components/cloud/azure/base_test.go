package azure_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewBase(t *testing.T) {
	t.Parallel()

	type want struct {
		resourceGroupName string
		managedIdentityID string
	}

	type args struct {
		name string
		args *azure.BaseArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create base resource",
			in: args{
				name: "test-base-1",
				args: &azure.BaseArgs{
					ComplianceLevel: pulumi.String("testing"),
					Customer:        pulumi.String("test-customer"),
					Environment:     pulumi.String("test"),
				},
			},
			want: want{
				resourceGroupName: "rg-test-base-1",
				managedIdentityID: "test-base-1-identity_id",
			},
			wantErr: false,
		},
		{
			name: "should fail if compliance level is not provided",
			in: args{
				name: "test-root-1",
				args: &azure.BaseArgs{
					ComplianceLevel: nil,
					Customer:        pulumi.String("test-customer"),
					Environment:     pulumi.String("test"),
				},
			},
			wantErr: true,
		},
		{
			name: "should fail if customer is not provided",
			in: args{
				name: "test-root-1",
				args: &azure.BaseArgs{
					ComplianceLevel: pulumi.String("testing"),
					Customer:        nil,
					Environment:     pulumi.String("test"),
				},
			},
			wantErr: true,
		},
		{
			name: "should fail if environment is not provided",
			in: args{
				name: "test-root-1",
				args: &azure.BaseArgs{
					ComplianceLevel: pulumi.String("testing"),
					Customer:        pulumi.String("test-customer"),
					Environment:     nil,
				},
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := azure.NewBase(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.ResourceGroupName.ApplyT(func(rg string) string {
					assert.Equal(t, tt.want.resourceGroupName, rg)

					return rg
				})

				got.ManagedIdentityID.ApplyT(func(id string) string {
					assert.Equal(t, tt.want.managedIdentityID, id)

					return id
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestBaseArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *azure.BaseArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"customer": "customer-abc",
				"environment": "production",
				"complianceLevel": "high",
				"location": "usgovvirginia",
				"tags": {"env": "production", "tier": "gold"}
			}`,
			want: &azure.BaseArgs{
				Customer:        pulumi.String("customer-abc"),
				Environment:     pulumi.String("production"),
				ComplianceLevel: pulumi.String("high"),
				Location:        pulumi.String("usgovvirginia"),
				Tags:            pulumi.StringMap{"env": pulumi.String("production"), "tier": pulumi.String("gold")},
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"customer": "customer-xyz", "environment": "production", "complianceLevel": "high", "location": 123}`, // location should be a string
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"customer": "customer-xyz", "environment": "production", "complianceLevel": "high"`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args azure.BaseArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
