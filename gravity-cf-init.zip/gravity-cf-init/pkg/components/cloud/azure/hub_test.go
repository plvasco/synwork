package azure_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestNewHub(t *testing.T) {
	t.Parallel()

	type want struct {
		resourceGroupName string
		managedIdentityID string
	}

	type args struct {
		name string
		args *azure.HubArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create governance resource",
			in: args{
				name: "test-base-1",
				args: &azure.HubArgs{
					ComplianceLevel:             pulumi.String("testing"),
					Customer:                    pulumi.String("test-customer"),
					Environment:                 pulumi.String("test"),
					CustomPolicyDefinitionScope: pulumi.String("/subscriptions/12345678-90ab-cdef-1234-567890abcdef"),
					ResourceGroupName:           pulumi.String("hub"),
					Networking: &networking.VirtualNetworkArgs{
						AddressSpace: pulumi.String("10.10.0.0/24"),
						Subnets:      map[string]*networking.VirtualNetworkSubnetArgs{},
					},
					Firewall: &networking.FirewallArgs{
						Name:               pulumi.String("test-hub-azfw"),
						Sku:                pulumi.String("Standard"),
						SubnetAddressSpace: pulumi.String("10.10.0.0/26"),
					},
					Bastion: &networking.BastionArgs{
						Name:               pulumi.String("test-hub-bastion"),
						SubnetAddressSpace: pulumi.String("10.10.0.64/26"),
					},
				},
			},
			want: want{
				resourceGroupName: "rg-test-base-1",
				managedIdentityID: "test-base-1-identity_id",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := azure.NewHub(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
