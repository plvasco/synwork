package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const firewallComponentName = "gravity:azure:firewall"

var (
// ErrRequiredArgumentRootCIDRString = errors.New("required argument AddressSpace is missing")
)

type Firewall struct {
	pulumi.ResourceState
	ResourceGroupName pulumi.StringOutput `pulumi:"resourceGroupName"`
	AzureFirewallID   pulumi.IDOutput     `pulumi:"azurefirewallID"`
}

type FirewallPolicy struct {
	pulumi.ResourceState
}

type FirewallArgs struct {
	ResourceGroupName  pulumi.StringInput
	VirtualNetworkName pulumi.StringInput
	SubnetAddressSpace pulumi.StringInput `pulumi:"subnetAddressSpace"`
	Name               pulumi.StringInput `pulumi:"name"`
	NatGatewayID       pulumi.IDOutput
	Tags               pulumi.StringMap    `pulumi:"tags"`
	Policy             *FirewallPolicyArgs `pulumi:"policy"`
	Sku                pulumi.StringInput  `pulumi:"sku"`
	SupernetCidr       pulumi.StringInput  `pulumi:"supernetCidr" validate:"default=10.128.0.0/16"`
}

type FirewallPolicyArgs struct {
}

func NewFirewall(ctx *pulumi.Context, name string, args *FirewallArgs, opts ...pulumi.ResourceOption) (*Firewall, error) {
	if err := args.Validate(); err != nil {
		return nil, fmt.Errorf("unable to validate firewall args, %w", err)
	}

	component := &Firewall{}

	if err := ctx.RegisterComponentResource(firewallComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", firewallComponentName, name, err)
	}

	if err := component.createFirewall(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"azurefirewallID":   component.AzureFirewallID,
		"resourceGroupName": component.ResourceGroupName,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", firewallComponentName, name, err)
	}

	return component, nil
}

func (c *Firewall) createFirewall(ctx *pulumi.Context, name string, args *FirewallArgs) error {
	// Create the subnet resource
	firewallSubnet, err := network.NewSubnet(ctx, "azfwSubnet", &network.SubnetArgs{
		SubnetName:         pulumi.String("AzureFirewallSubnet"), // This is *required* to always be AzureFirewallSubnet
		AddressPrefix:      args.SubnetAddressSpace,
		VirtualNetworkName: args.VirtualNetworkName,
		ResourceGroupName:  args.ResourceGroupName,
		NatGateway: &network.SubResourceArgs{
			Id: args.NatGatewayID,
		},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	// Create the Public IP Address
	publicIP, err := network.NewPublicIPAddress(ctx, name+"-pip", &network.PublicIPAddressArgs{
		ResourceGroupName:        args.ResourceGroupName,
		PublicIpAddressName:      pulumi.String(name + "-pip"),
		PublicIPAllocationMethod: pulumi.String("Static"),
		Sku: &network.PublicIPAddressSkuArgs{
			Name: pulumi.String("Standard"),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	// Create the Firewall Policy
	firewallPolicy, err := network.NewFirewallPolicy(ctx, name+"-policy", &network.FirewallPolicyArgs{
		FirewallPolicyName: pulumi.String(name + "-policy"),
		ResourceGroupName:  args.ResourceGroupName,
		DnsSettings: &network.DnsSettingsArgs{
			EnableProxy: pulumi.Bool(true),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	// Create the Firewall Policy Rule Collection Groups
	defaultAKSRuleCollectionGroup, err := network.NewFirewallPolicyRuleCollectionGroup(ctx, "DefaultAKSRuleCollectionGroup", &network.FirewallPolicyRuleCollectionGroupArgs{
		ResourceGroupName:  args.ResourceGroupName,
		FirewallPolicyName: firewallPolicy.Name,
		Priority:           pulumi.Int(400),
		RuleCollections: pulumi.Array{
			&network.FirewallPolicyFilterRuleCollectionArgs{
				RuleCollectionType: pulumi.String("FirewallPolicyFilterRuleCollection"),
				Action: &network.FirewallPolicyFilterRuleCollectionActionArgs{
					Type: network.FirewallPolicyFilterRuleCollectionActionTypeAllow,
				},
				Rules: pulumi.Array{
					&network.ApplicationRuleArgs{
						RuleType: pulumi.String("ApplicationRule"),
						Name:     pulumi.String("AzureGlobalApplicationRules"),
						Protocols: network.FirewallPolicyRuleApplicationProtocolArray{
							&network.FirewallPolicyRuleApplicationProtocolArgs{
								ProtocolType: network.FirewallPolicyRuleApplicationProtocolTypeHttps,
								Port:         pulumi.Int(443),
							},
						},
						TargetFqdns: pulumi.StringArray{
							pulumi.String("*.azmk8s.io"),
							pulumi.String("*.cx.aks.containerservice.azure.us"),
							pulumi.String("mcr.microsoft.com"),
							pulumi.String("*.data.mcr.microsoft.com"),
							pulumi.String("management.usgovcloudapi.net"),
							pulumi.String("login.microsoftonline.us"),
							pulumi.String("packages.microsoft.com"),
							pulumi.String("acs-mirror.azureedge.net"),
							pulumi.String("data.policy.azure.us"),
							pulumi.String("store.policy.azure.us"),
							pulumi.String("*.dp.kubernetesconfiguration.azure.us"),
						},
						SourceAddresses: pulumi.StringArray{
							pulumi.String("*"),
						},
					},
					&network.ApplicationRuleArgs{
						RuleType: pulumi.String("ApplicationRule"),
						Name:     pulumi.String("OsUpdates"),
						Protocols: network.FirewallPolicyRuleApplicationProtocolArray{
							&network.FirewallPolicyRuleApplicationProtocolArgs{
								ProtocolType: network.FirewallPolicyRuleApplicationProtocolTypeHttp,
								Port:         pulumi.Int(80),
							},
							&network.FirewallPolicyRuleApplicationProtocolArgs{
								ProtocolType: network.FirewallPolicyRuleApplicationProtocolTypeHttps,
								Port:         pulumi.Int(443),
							},
						},
						TargetFqdns: pulumi.StringArray{
							pulumi.String("security.ubuntu.com"),
							pulumi.String("azure.archive.ubuntu.com"),
							pulumi.String("changelogs.ubuntu.com"),
						},
						SourceAddresses: pulumi.StringArray{
							pulumi.String("*"),
						},
					},
					&network.ApplicationRuleArgs{
						RuleType: pulumi.String("ApplicationRule"),
						Name:     pulumi.String("GitOps"),
						Protocols: network.FirewallPolicyRuleApplicationProtocolArray{
							&network.FirewallPolicyRuleApplicationProtocolArgs{
								ProtocolType: network.FirewallPolicyRuleApplicationProtocolTypeHttps,
								Port:         pulumi.Int(443),
							},
						},
						TargetFqdns: pulumi.StringArray{
							pulumi.String("dc.services.visualstudio.com"),
							pulumi.String("cloudfitsoftware.visualstudio.com"),
						},
						SourceAddresses: pulumi.StringArray{
							pulumi.String("*"),
						},
					},
				},
				Name:     pulumi.String("Azure Global"),
				Priority: pulumi.Int(100),
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	defaultApplicationRuleCollectionGroup, err := network.NewFirewallPolicyRuleCollectionGroup(ctx, "DefaultApplicationRuleCollectionGroup", &network.FirewallPolicyRuleCollectionGroupArgs{
		ResourceGroupName:  args.ResourceGroupName,
		FirewallPolicyName: firewallPolicy.Name,
		Priority:           pulumi.Int(300),
		RuleCollections: pulumi.Array{
			&network.FirewallPolicyFilterRuleCollectionArgs{
				RuleCollectionType: pulumi.String("FirewallPolicyFilterRuleCollection"),
				Action: &network.FirewallPolicyFilterRuleCollectionActionArgs{
					Type: network.FirewallPolicyFilterRuleCollectionActionTypeAllow,
				},
				Rules: pulumi.Array{
					&network.ApplicationRuleArgs{
						RuleType: pulumi.String("ApplicationRule"),
						Name:     pulumi.String("msftauth"),
						Protocols: network.FirewallPolicyRuleApplicationProtocolArray{
							&network.FirewallPolicyRuleApplicationProtocolArgs{
								ProtocolType: network.FirewallPolicyRuleApplicationProtocolTypeHttps,
								Port:         pulumi.Int(443),
							},
						},
						TargetFqdns: pulumi.StringArray{
							pulumi.String("aadcdn.msftauth.net"),
							pulumi.String("aadcdn.msauth.net"),
						},
						SourceAddresses: pulumi.StringArray{
							pulumi.String("*"),
						},
					},
				},
				Name:     pulumi.String("AzureAuth"),
				Priority: pulumi.Int(110),
			},
		},
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{defaultAKSRuleCollectionGroup}))
	if err != nil {
		return err
	}

	defaultDnatRuleCollectionGroup, err := network.NewFirewallPolicyRuleCollectionGroup(ctx, "DefaultDnatRuleCollectionGroup", &network.FirewallPolicyRuleCollectionGroupArgs{
		ResourceGroupName:  args.ResourceGroupName,
		FirewallPolicyName: firewallPolicy.Name,
		Priority:           pulumi.Int(100),
		RuleCollections: pulumi.Array{
			&network.FirewallPolicyNatRuleCollectionArgs{
				RuleCollectionType: pulumi.String("FirewallPolicyNatRuleCollection"),
				Action: &network.FirewallPolicyNatRuleCollectionActionArgs{
					Type: network.FirewallPolicyNatRuleCollectionActionTypeDNAT,
				},
				Rules:    pulumi.Array{},
				Name:     pulumi.String("DNAT_Rules"),
				Priority: pulumi.Int(200),
			},
		},
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{defaultApplicationRuleCollectionGroup}))
	if err != nil {
		return err
	}

	_, err = network.NewFirewallPolicyRuleCollectionGroup(ctx, "DefaultNetworkRuleCollectionGroup", &network.FirewallPolicyRuleCollectionGroupArgs{
		ResourceGroupName:  args.ResourceGroupName,
		FirewallPolicyName: firewallPolicy.Name,
		Priority:           pulumi.Int(200),
		RuleCollections: pulumi.Array{
			&network.FirewallPolicyFilterRuleCollectionArgs{
				RuleCollectionType: pulumi.String("FirewallPolicyFilterRuleCollection"),
				Action: &network.FirewallPolicyFilterRuleCollectionActionArgs{
					Type: network.FirewallPolicyFilterRuleCollectionActionTypeAllow,
				},
				Rules: pulumi.Array{
					&network.NetworkRuleArgs{
						RuleType: pulumi.String("NetworkRule"),
						Name:     pulumi.String("AzureCloud"),
						IpProtocols: pulumi.StringArray{
							network.FirewallPolicyRuleNetworkProtocolAny,
						},
						SourceAddresses: pulumi.StringArray{
							pulumi.String("*"),
						},
						DestinationAddresses: pulumi.StringArray{
							pulumi.String("AzureCloud"),
						},
						DestinationPorts: pulumi.StringArray{
							pulumi.String("*"),
						},
					},
				},
				Name:     pulumi.String("AllowAzureCloud"),
				Priority: pulumi.Int(100),
			},
			&network.FirewallPolicyFilterRuleCollectionArgs{
				RuleCollectionType: pulumi.String("FirewallPolicyFilterRuleCollection"),
				Action: &network.FirewallPolicyFilterRuleCollectionActionArgs{
					Type: network.FirewallPolicyFilterRuleCollectionActionTypeAllow,
				},
				Rules: pulumi.Array{
					&network.NetworkRuleArgs{
						RuleType: pulumi.String("NetworkRule"),
						Name:     pulumi.String("AllSpokeTraffic"),
						IpProtocols: pulumi.StringArray{
							network.FirewallPolicyRuleNetworkProtocolAny,
						},
						SourceAddresses: pulumi.StringArray{
							args.SupernetCidr,
						},
						SourceIpGroups: pulumi.StringArray{},
						DestinationAddresses: pulumi.StringArray{
							pulumi.String("*"),
						},
						DestinationIpGroups: pulumi.StringArray{},
						DestinationFqdns:    pulumi.StringArray{},
						DestinationPorts: pulumi.StringArray{
							pulumi.String("*"),
						},
					},
				},
				Name:     pulumi.String("AllowTrafficBetweenSpokes"),
				Priority: pulumi.Int(200),
			},
		},
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{defaultDnatRuleCollectionGroup}))
	if err != nil {
		return err
	}

	// Create the Firewall
	firewall, err := network.NewAzureFirewall(ctx, name, &network.AzureFirewallArgs{
		AzureFirewallName: args.Name,
		ResourceGroupName: args.ResourceGroupName,
		Sku: &network.AzureFirewallSkuArgs{
			Name: pulumi.String("AZFW_VNet"),
			Tier: args.Sku,
		},
		ThreatIntelMode: pulumi.String("Alert"),
		IpConfigurations: network.AzureFirewallIPConfigurationArray{
			&network.AzureFirewallIPConfigurationArgs{
				Name: pulumi.String(name + "-pip"),

				Subnet: &network.SubResourceArgs{
					Id: firewallSubnet.ID(),
				},
				PublicIPAddress: &network.SubResourceArgs{
					Id: publicIP.ID(),
				},
			},
		},
		FirewallPolicy: &network.SubResourceArgs{
			Id: firewallPolicy.ID(),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create firewall %s, %w", name, err)
	}

	c.AzureFirewallID = firewall.ID()

	return nil
}

// validate checks that all required args are set and sets defaults for any optional args.
func (args *FirewallArgs) Validate() error {
	if args == nil {
		args = &FirewallArgs{}
	}

	return nil
}

func (args *FirewallArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal network args, %w", err)
	}

	return nil
}
