package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const bastionComponentName = "gravity:azure:bastion"

type Bastion struct {
	pulumi.ResourceState
	BastionID pulumi.IDOutput `pulumi:"bastionID"`
}

type BastionArgs struct {
	ResourceGroupName  pulumi.StringInput
	SubnetAddressSpace pulumi.StringInput
	VirtualNetworkName pulumi.StringInput
	Name               pulumi.StringInput `pulumi:"name"`
}

func NewBastion(ctx *pulumi.Context, name string, args *BastionArgs, opts ...pulumi.ResourceOption) (*Bastion, error) {
	if err := args.validate(); err != nil {
		return nil, fmt.Errorf("unable to validate network args, %w", err)
	}

	component := &Bastion{}

	if err := ctx.RegisterComponentResource(bastionComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", networkComponentName, name, err)
	}

	if err := component.createBastion(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"bastionID": component.BastionID,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", bastionComponentName, name, err)
	}

	return component, nil

}

func (c *Bastion) createBastion(ctx *pulumi.Context, name string, args *BastionArgs) error {
	// Create a Network Security Group
	nsg, err := network.NewNetworkSecurityGroup(ctx, "bastionNSG", &network.NetworkSecurityGroupArgs{
		ResourceGroupName:        args.ResourceGroupName,
		NetworkSecurityGroupName: pulumi.Sprintf("%s-nsg", args.Name),
		SecurityRules: network.SecurityRuleTypeArray{
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowWebExperienceInbound"),
				Description:              pulumi.String("Allow our users in. Update this to be as restrictive as possible."),
				Protocol:                 pulumi.String("Tcp"),
				SourcePortRange:          pulumi.String("*"),
				DestinationPortRange:     pulumi.String("443"),
				SourceAddressPrefix:      pulumi.String("Internet"),
				DestinationAddressPrefix: pulumi.String("*"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(100),
				Direction:                pulumi.String("Inbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowControlPlaneInbound"),
				Description:              pulumi.String("Service Requirement. Allow control plane access. Regional Tag not yet supported."),
				Protocol:                 pulumi.String("Tcp"),
				SourcePortRange:          pulumi.String("*"),
				DestinationPortRange:     pulumi.String("443"),
				SourceAddressPrefix:      pulumi.String("GatewayManager"),
				DestinationAddressPrefix: pulumi.String("*"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(110),
				Direction:                pulumi.String("Inbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowHealthProbesInbound"),
				Description:              pulumi.String("Service Requirement. Allow Health Probes."),
				Protocol:                 pulumi.String("Tcp"),
				SourcePortRange:          pulumi.String("*"),
				DestinationPortRange:     pulumi.String("443"),
				SourceAddressPrefix:      pulumi.String("AzureLoadBalancer"),
				DestinationAddressPrefix: pulumi.String("*"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(120),
				Direction:                pulumi.String("Inbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowBastionHostToHostInbound"),
				Description:              pulumi.String("Service Requirement. Allow Required Host to Host Communication."),
				Protocol:                 pulumi.String("*"),
				SourcePortRange:          pulumi.String("*"),
				DestinationPortRanges:    pulumi.StringArray([]pulumi.StringInput{pulumi.String("8080"), pulumi.String("5701")}),
				SourceAddressPrefix:      pulumi.String("VirtualNetwork"),
				DestinationAddressPrefix: pulumi.String("VirtualNetwork"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(130),
				Direction:                pulumi.String("Inbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("DenyAllInbound"),
				Description:              pulumi.String("No further inbound traffic allowed."),
				Protocol:                 pulumi.String("*"),
				SourcePortRange:          pulumi.String("*"),
				DestinationPortRange:     pulumi.String("*"),
				SourceAddressPrefix:      pulumi.String("*"),
				DestinationAddressPrefix: pulumi.String("*"),
				Access:                   pulumi.String("Deny"),
				Priority:                 pulumi.Int(1000),
				Direction:                pulumi.String("Inbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowSshToVnetOutbound"),
				Description:              pulumi.String("Allow SSH out to the virtual network"),
				Protocol:                 pulumi.String("Tcp"),
				SourcePortRange:          pulumi.String("*"),
				SourceAddressPrefix:      pulumi.String("*"),
				DestinationPortRange:     pulumi.String("22"),
				DestinationAddressPrefix: pulumi.String("VirtualNetwork"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(100),
				Direction:                pulumi.String("Outbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowRdpToVnetOutbound"),
				Description:              pulumi.String("Allow RDP out to the virtual network"),
				Protocol:                 pulumi.String("Tcp"),
				SourcePortRange:          pulumi.String("*"),
				SourceAddressPrefix:      pulumi.String("*"),
				DestinationPortRange:     pulumi.String("3389"),
				DestinationAddressPrefix: pulumi.String("VirtualNetwork"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(110),
				Direction:                pulumi.String("Outbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowControlPlaneOutbound"),
				Description:              pulumi.String("Required for control plane outbound. Regional prefix not yet supported"),
				Protocol:                 pulumi.String("Tcp"),
				SourcePortRange:          pulumi.String("*"),
				SourceAddressPrefix:      pulumi.String("*"),
				DestinationPortRange:     pulumi.String("443"),
				DestinationAddressPrefix: pulumi.String("AzureCloud"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(120),
				Direction:                pulumi.String("Outbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowBastionHostToHostOutbound"),
				Description:              pulumi.String("Service Requirement. Allow Required Host to Host Communication."),
				Protocol:                 pulumi.String("*"),
				SourcePortRange:          pulumi.String("*"),
				SourceAddressPrefix:      pulumi.String("VirtualNetwork"),
				DestinationPortRanges:    pulumi.StringArray([]pulumi.StringInput{pulumi.String("8080"), pulumi.String("5701")}),
				DestinationAddressPrefix: pulumi.String("VirtualNetwork"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(130),
				Direction:                pulumi.String("Outbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("AllowBastionCertificateValidationOutbound"),
				Description:              pulumi.String("Service Requirement. Allow Required Session and Certificate Validation."),
				Protocol:                 pulumi.String("*"),
				SourcePortRange:          pulumi.String("*"),
				SourceAddressPrefix:      pulumi.String("*"),
				DestinationPortRange:     pulumi.String("80"),
				DestinationAddressPrefix: pulumi.String("Internet"),
				Access:                   pulumi.String("Allow"),
				Priority:                 pulumi.Int(140),
				Direction:                pulumi.String("Outbound"),
			},
			&network.SecurityRuleTypeArgs{
				Name:                     pulumi.String("DenyAllOutbound"),
				Description:              pulumi.String("No further outbound traffic allowed."),
				Protocol:                 pulumi.String("*"),
				SourcePortRange:          pulumi.String("*"),
				DestinationPortRange:     pulumi.String("*"),
				SourceAddressPrefix:      pulumi.String("*"),
				DestinationAddressPrefix: pulumi.String("*"),
				Access:                   pulumi.String("Deny"),
				Priority:                 pulumi.Int(1000),
				Direction:                pulumi.String("Outbound"),
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	// Create the subnet resource
	bastionSubnet, err := network.NewSubnet(ctx, "bastionSubnet", &network.SubnetArgs{
		SubnetName:         pulumi.String("AzureBastionSubnet"), // This is *required* to always be AzureBastionSubnet
		ResourceGroupName:  args.ResourceGroupName,
		AddressPrefix:      args.SubnetAddressSpace,
		VirtualNetworkName: args.VirtualNetworkName,
		NetworkSecurityGroup: &network.NetworkSecurityGroupTypeArgs{
			Id: nsg.ID(),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	// Create a public IP address for the Bastion Host
	publicIP, err := network.NewPublicIPAddress(ctx, name+"-pip", &network.PublicIPAddressArgs{
		ResourceGroupName:        args.ResourceGroupName,
		PublicIpAddressName:      pulumi.Sprintf("%s-pip", args.Name),
		PublicIPAllocationMethod: pulumi.String("Static"),
		Sku: &network.PublicIPAddressSkuArgs{
			Name: pulumi.String("Standard"),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	// Create the Bastion Host
	bastion, err := network.NewBastionHost(ctx, "bastionHost", &network.BastionHostArgs{
		ResourceGroupName: args.ResourceGroupName,
		BastionHostName:   args.Name,
		IpConfigurations: network.BastionHostIPConfigurationArray{
			&network.BastionHostIPConfigurationArgs{
				Name: pulumi.String("bastionHostIpConfiguration"),
				PublicIPAddress: &network.SubResourceArgs{
					Id: publicIP.ID(),
				},
				Subnet: &network.SubResourceArgs{
					Id: bastionSubnet.ID(),
				},
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	c.BastionID = bastion.ID()

	return nil
}

// validate checks that all required args are set and sets defaults for any optional args.
func (args *BastionArgs) validate() error {
	if args == nil {
		args = &BastionArgs{}
	}

	return nil
}

func (args *BastionArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal network args, %w", err)
	}

	return nil
}
