package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewSubnet(t *testing.T) {
	t.Parallel()

	type want struct {
		ID           string
		RouteTableID string
	}

	type args struct {
		name string
		args *networking.SubnetArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test creates subnet",
			in: args{
				name: "test-subnet",
				args: &networking.SubnetArgs{
					CIDRBlock:          pulumi.String("10.0.0.0/24"),
					SubnetPrefixSize:   pulumi.Int(26),
					Tags:               map[string]pulumi.StringInput{},
					ResourceGroupName:  pulumi.String("resourcegroup"),
					VirtualNetworkName: pulumi.String("vnet-1234"),
				},
			},
			want: want{
				ID:           "test-subnet-subnet_id",
				RouteTableID: "",
			},
			wantErr: false,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewSubnet(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.ID.ApplyT(func(id string) string {
					assert.Equal(t, tc.want.ID, id)

					return id
				})

				got.RouteTableID.ApplyT(func(routeTableID string) string {
					assert.Equal(t, tc.want.RouteTableID, routeTableID)
					require.NotNil(t, routeTableID)

					return routeTableID
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewSubnet() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestSubnetArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.SubnetArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"cidrBlock": "10.0.1.0/24",
				"subnetPrefixSize": 28,
				"tags": {
					"env": "production",
					"team": "networking"
				},
				"resourceGroupName": "rg-example",
				"virtualNetworkName": "vnet-example"
			}`,
			want: &networking.SubnetArgs{
				CIDRBlock:        pulumi.String("10.0.1.0/24"),
				SubnetPrefixSize: pulumi.Int(28),
				Tags: pulumi.StringMap{
					"env":  pulumi.String("production"),
					"team": pulumi.String("networking"),
				},
				ResourceGroupName:  pulumi.String("rg-example"),
				VirtualNetworkName: pulumi.String("vnet-example"),
			},
			wantErr: false,
		},
		{
			name: "malformed JSON",
			input: `{
				"cidrBlock": "10.0.1.0/24",
				"subnetPrefixSize": "28",
				"tags": {
					"env": "production",
					"team": "networking"
				},
				"resourceGroupName": "rg-example",
				"virtualNetworkName": "vnet-example"
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.SubnetArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
