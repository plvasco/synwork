package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const subnetsComponentName = "gravity:azure:network:subnets"

type Subnet struct {
	pulumi.ResourceState
	PublicIPPrefixID pulumi.IDOutput     `pulumi:"publicIPPrefixID"`
	NatGatewayID     pulumi.IDOutput     `pulumi:"natGatewayID"`
	ID               pulumi.StringOutput `pulumi:"id"`
	RouteTableID     pulumi.StringOutput `pulumi:"routeTableID"`
}

type SubnetArgs struct {
	// The CIDR address to build subnet on.
	CIDRBlock pulumi.StringInput `pulumi:"cidrBlock"`
	// The Size of the subnet prefix to use when generating subnets per AZ (default is 28).
	SubnetPrefixSize pulumi.IntInput `pulumi:"subnetPrefixSize" validate:"default=26"`
	// Tags to apply to all child objects of the subnet component resource.
	Tags pulumi.StringMap `pulumi:"tags"`
	// Resource Group to build subnet in
	ResourceGroupName pulumi.StringInput `pulumi:"resourceGroupName"`
	// VNet to build subnet in
	VirtualNetworkName pulumi.StringInput `pulumi:"virtualNetworkName"`
}

func NewSubnet(ctx *pulumi.Context, name string, args *SubnetArgs, opts ...pulumi.ResourceOption) (*Subnet, error) {
	component := &Subnet{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(subnetsComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", subnetsComponentName, name, err)
	}

	if err := component.createSubnet(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"id": component.ID,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", subnetsComponentName, name, err)
	}

	return component, nil
}

func (c *Subnet) createSubnet(ctx *pulumi.Context, name string, args *SubnetArgs) error {
	subnet, err := network.NewSubnet(ctx, name, &network.SubnetArgs{
		AddressPrefix:      args.CIDRBlock,
		ResourceGroupName:  args.ResourceGroupName,
		VirtualNetworkName: args.VirtualNetworkName,
		ServiceEndpoints: network.ServiceEndpointPropertiesFormatArray{
			&network.ServiceEndpointPropertiesFormatArgs{
				Service: pulumi.String("Microsoft.KeyVault"),
			},
			&network.ServiceEndpointPropertiesFormatArgs{
				Service: pulumi.String("Microsoft.Storage"),
			},
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create subnet %s, %w", name, err)
	}

	c.ID = subnet.ID().ToStringOutput()
	c.RouteTableID = subnet.RouteTable.Id().Elem().ToStringOutput()

	return nil
}

func (args *SubnetArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *SubnetArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal cluster args, %w", err)
	}

	return nil
}
