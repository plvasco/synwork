package networking

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const natGatewayComponentName = "gravity:azure:natgateway"

var (
	ErrRequiredArgumentResourceGroupName = errors.New("required argument ResourceGroupName is missing")
)

type NatGateway struct {
	pulumi.ResourceState
	Name         pulumi.StringInput `pulumi:"name"`
	NatGatewayID pulumi.IDOutput    `pulumi:"natGatewayID"`
}

type NatGatewayArgs struct {
	ResourceGroupName pulumi.StringInput `pulumi:"resourceGroupName"`
}

func NewNatGateway(ctx *pulumi.Context, name string, args *NatGatewayArgs, opts ...pulumi.ResourceOption) (*NatGateway, error) {
	if err := args.validate(); err != nil {
		return nil, fmt.Errorf("unable to validate nat gateway args, %w", err)
	}

	component := &NatGateway{}

	if err := ctx.RegisterComponentResource(natGatewayComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", natGatewayComponentName, name, err)
	}

	publicIP, err := component.createPublicIPAddress(ctx, name, args)
	if err != nil {
		return nil, fmt.Errorf("unable to create public ip address for nat gateway, %w", err)
	}

	if err := component.createNatGateway(ctx, name, publicIP, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"natGatewayID": component.NatGatewayID,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", natGatewayComponentName, name, err)
	}

	return component, nil
}

func (c *NatGateway) createPublicIPAddress(ctx *pulumi.Context, name string, args *NatGatewayArgs) (*network.PublicIPAddress, error) {

	ipAddressName := fmt.Sprintf("%s-pip", name)

	publicIP, err := network.NewPublicIPAddress(ctx, ipAddressName, &network.PublicIPAddressArgs{
		ResourceGroupName:        args.ResourceGroupName,
		PublicIpAddressName:      pulumi.String(ipAddressName),
		PublicIPAllocationMethod: pulumi.String("Static"),
		Sku: &network.PublicIPAddressSkuArgs{
			Name: pulumi.String("Standard"),
		},
	}, pulumi.Parent(c))
	if err != nil {
		return nil, err
	}

	return publicIP, nil
}

func (c *NatGateway) createNatGateway(ctx *pulumi.Context, name string, publicIP *network.PublicIPAddress, args *NatGatewayArgs) error {

	if args.ResourceGroupName == nil {
		return ErrRequiredArgumentResourceGroupName
	}

	natGateway, err := network.NewNatGateway(ctx, name, &network.NatGatewayArgs{
		ResourceGroupName: args.ResourceGroupName,
		PublicIpAddresses: network.SubResourceArray{
			&network.SubResourceArgs{
				Id: publicIP.ID(),
			},
		},
		Sku: &network.NatGatewaySkuArgs{
			Name: network.NatGatewaySkuNameStandard,
		},
	}, pulumi.Parent(publicIP))
	if err != nil {
		return err
	}

	c.NatGatewayID = natGateway.ID()

	return nil
}

func (args *NatGatewayArgs) validate() error {
	if args == nil {
		args = &NatGatewayArgs{}
	}

	return nil
}

func (args *NatGatewayArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal network args, %w", err)
	}

	return nil
}
