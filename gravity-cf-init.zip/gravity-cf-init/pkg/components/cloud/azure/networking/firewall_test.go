package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestNewFirewall(t *testing.T) {
	t.Parallel()

	type want struct {
		name string
	}

	type args struct {
		name string
		args *networking.FirewallArgs
	}

	tests := []struct {
		name    string
		input   args
		want    want
		wantErr bool
	}{
		{
			name: "should create a new firewall",
			input: args{
				name: "test-firewall",
				args: &networking.FirewallArgs{
					ResourceGroupName:  pulumi.String("resourcegroup").ToStringOutput(),
					VirtualNetworkName: pulumi.String("vnet").ToStringOutput(),
					SubnetAddressSpace: pulumi.String("10.0.0.0/16").ToStringOutput(),
					NatGatewayID:       pulumi.IDOutput(pulumi.String("nat-67890").ToStringOutput()),
				},
			},
			want: want{
				name: "test-firewall",
			},
			wantErr: false,
		},
		{
			name: "should return error for nil resource group name",
			input: args{
				name: "test-firewall",
				args: &networking.FirewallArgs{
					ResourceGroupName:  nil,
					VirtualNetworkName: pulumi.String("vnet").ToStringOutput(),
				},
			},
			want: want{
				name: "test-firewall",
			},
			wantErr: true,
		},
		{
			name: "should return error for nil virtual network name",
			input: args{
				name: "test-firewall",
				args: &networking.FirewallArgs{
					ResourceGroupName:  pulumi.String("resourcegroup").ToStringOutput(),
					VirtualNetworkName: nil,
				},
			},
			want: want{
				name: "test-firewall",
			},
			wantErr: true,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewFirewall(ctx, test.input.name, test.input.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != test.wantErr {
				t.Errorf("error = %v, wantErr %v", err, test.wantErr)
			}
		})
	}
}

func TestNewFirewallArgs(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.FirewallArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"resourceGroupName":"rg-example"
			}`,
			want: &networking.FirewallArgs{
				ResourceGroupName: pulumi.String("rg-example"),
			},
			wantErr: false,
		},
		{
			name: "invalid input",
			input: `{
				"resourceGroupName": 42
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			var args networking.FirewallArgs

			b := []byte(test.input)
			err := json.Unmarshal(b, &args)

			if test.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(test.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *test.want)
			}
		})
	}
}
