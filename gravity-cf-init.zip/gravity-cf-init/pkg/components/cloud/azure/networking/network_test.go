package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewNetwork(t *testing.T) {
	t.Parallel()

	type want struct {
		vnetName string
		subnetID pulumi.ID
	}

	type args struct {
		name string
		args *networking.NetworkArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create network resources",
			in: args{
				name: "test-net",
				args: &networking.NetworkArgs{
					ResourceGroupName: pulumi.String("resourcegroup"),
					SupernetCidr:      pulumi.String("10.0.0.0/16"),
					NetworkCidr:       pulumi.String("10.0.0.0/24"),
					SubnetPrefixSize:  pulumi.Int(26),
					Tags:              pulumi.StringMap{},
				},
			},
			want: want{
				vnetName: "test-net-vnet",
				subnetID: "test-net-subnet_id",
			},
			wantErr: false,
		},
		{
			name: "should create network with default values",
			in: args{
				name: "test-default",
				args: &networking.NetworkArgs{
					ResourceGroupName: pulumi.String("resourcegroup"),
					Tags:              pulumi.ToStringMap(map[string]string{"test": "test"}),
				},
			},
			want: want{
				vnetName: "test-default-vnet",
				subnetID: "test-default-subnet_id",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewNetwork(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				vnetName := got.VirtualNetworkName.ApplyT(func(vnetName string) string {
					assert.Equal(t, tt.want.vnetName, vnetName)

					return vnetName
				})
				require.NotNil(t, vnetName)

				got.Subnet.ID.ApplyT(func(subnetID pulumi.ID) pulumi.ID {
					assert.Equal(t, tt.want.subnetID, subnetID)

					return subnetID
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestNetworkArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.NetworkArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"location": "us-east-1",
				"resourceGroupName": "rg-network",
				"tags": {
					"env": "production",
					"team": "networking"
				},
				"supernetCidr": "10.0.0.0/16",
				"networkCidr": "10.0.10.0/24",
				"networkPrefixSize": 23,
				"subnetPrefixSize": 27
			}`,
			want: &networking.NetworkArgs{
				Location:          pulumi.String("us-east-1"),
				ResourceGroupName: pulumi.String("rg-network"),
				Tags: pulumi.StringMap{
					"env":  pulumi.String("production"),
					"team": pulumi.String("networking"),
				},
				SupernetCidr:      pulumi.String("10.0.0.0/16"),
				NetworkCidr:       pulumi.String("10.0.10.0/24"),
				NetworkPrefixSize: pulumi.Int(23),
				SubnetPrefixSize:  pulumi.Int(27),
			},
			wantErr: false,
		},
		{
			name: "malformed JSON with incorrect type",
			input: `{
				"location": 123,
				"resourceGroupName": true,
				"supernetCidr": false,
				"networkCidr": 12345,
				"networkPrefixSize": "invalid",
				"subnetPrefixSize": "wrong"
			}`, // Incorrect types for all fields
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.NetworkArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
