package hub

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/multi_cloud"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const hubComponentName = "gravity:azure:networking:hub"

type Hub struct {
	pulumi.ResourceState
	VNnetID   pulumi.StringOutput `pulumi:"vNnetID"`
	VNetName  pulumi.StringOutput `pulumi:"vNetName"`
	GatewayID pulumi.StringOutput `pulumi:"gatewayID"`
}

type HubArgs struct {
	Location          pulumi.StringInput `pulumi:"location"          validate:"required"`
	ResourceGroupName pulumi.StringInput `pulumi:"resourceGroupName" validate:"required"`
	Tags              pulumi.StringMap   `pulumi:"tags"`
	// optionally override ipam allocation for vpc network, required if not using transit gateway
	NetworkCidr pulumi.StringInput `pulumi:"networkCidr" validate:"default=10.128.0.0/24"`
	// The size of each subnet created per az inside vpc network (default is 26)
	AwsGatewayConfig *AwsGatewayConfigArgs `pulumi:"awsGatewayConfig"`
	FirewallCidr   pulumi.StringInput             `pulumi:"firewallCidr" validate:"default=10.128.0.64/26"`
	// RouterASN      pulumi.Float64Input            `pulumi:"routerASN"`
	ComplianceLevel pulumi.StringInput `pulumi:"complianceLevel"   validate:"required"`
	Customer        pulumi.StringInput `pulumi:"customer"          validate:"required"`
	Environment     pulumi.StringInput `pulumi:"environment"       validate:"required"`
}

type AwsGatewayConfigArgs struct {
	CidrBlock        pulumi.StringInput `pulumi:"cidrBlock"        validate:"default=10.128.0.0/26"`
	TransitGatewayID pulumi.StringInput `pulumi:"transitGatewayID" validate:"required"`
	
}

func NewHub(ctx *pulumi.Context, name string, args *HubArgs, opts ...pulumi.ResourceOption) (*Hub, error) {
	component := &Hub{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(hubComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", hubComponentName, name, err)
	}

	if err := component.createVirtualNetwork(ctx, name+"-network", args); err != nil {
		return nil, err
	}

	if args.AwsGatewayConfig != nil {
		if err := component.createAWSVPNConnection(ctx, name+"-aws", args); err != nil {
			return nil, err
		}
	}

	// if err := component.createFirewall(ctx, name+"-firewall", args); err != nil {
	// 	return nil, err
	// }

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"gatewayID": component.GatewayID,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", hubComponentName, name, err)
	}

	return component, nil
}

func (c *Hub) createVirtualNetwork(ctx *pulumi.Context, name string, args *HubArgs) error {
	vNet, err := network.NewVirtualNetwork(ctx, name, &network.VirtualNetworkArgs{
		AddressSpace: &network.AddressSpaceArgs{
			AddressPrefixes: pulumi.StringArray{
				args.NetworkCidr,
			},
		},
		Location:          args.Location,
		ResourceGroupName: args.ResourceGroupName,
		Tags:              utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create virtual network %s, %w", name, err)
	}

	c.VNetName = vNet.Name
	c.VNnetID = vNet.ID().ToStringOutput()

	return nil
}

func (c *Hub) createAWSVPNConnection(ctx *pulumi.Context, name string, args *HubArgs) error {
	gtwSubnet, err := network.NewSubnet(ctx, name, &network.SubnetArgs{
		AddressPrefix:                      args.AwsGatewayConfig.CidrBlock,
		ResourceGroupName:                  args.ResourceGroupName,
		ServiceEndpoints:                   network.ServiceEndpointPropertiesFormatArray{&network.ServiceEndpointPropertiesFormatArgs{Service: pulumi.String("Microsoft.KeyVault")}},
		SubnetName:                         pulumi.String("GatewaySubnet"),
		VirtualNetworkName:                 c.VNetName,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create Gtw subnet %s, %w", name, err)
	}

	_, err = multicloud.NewAzureAwsTunnel(ctx, name, &multicloud.AzureAwsTunnelArgs{
		GatewaySubnetID:   gtwSubnet.ID(),
		GatewayCidr:       args.AwsGatewayConfig.CidrBlock,
		VNetName:          c.VNetName,
		VNetID:            c.VNnetID,
		Location:          args.Location,
		ResourceGroupName: args.ResourceGroupName,
		TransitGatewayID:  args.AwsGatewayConfig.TransitGatewayID,
		Tags:              args.Tags,
	})
	if err != nil {
		return fmt.Errorf("unable to create Azure virtual gateway, %w", err)
	}

	return nil
}

// func (c *Hub) createFirewall(ctx *pulumi.Context, name string, args *HubArgs) error {
// 	firewallSubnet, err := network.NewSubnet(ctx, name, &network.SubnetArgs{
// 		Name:               pulumi.String("AzureFirewallSubnet"),
// 		AddressPrefix:      args.FirewallCidr,
// 		ResourceGroupName:  args.ResourceGroupName,
// 		VirtualNetworkName: vNet.Name,
// 		ServiceEndpoints: network.ServiceEndpointPropertiesFormatArray{
// 			&network.ServiceEndpointPropertiesFormatArgs{
// 				Service: pulumi.String("Microsoft.KeyVault"),
// 			},
// 			&network.ServiceEndpointPropertiesFormatArgs{
// 				Service: pulumi.String("Microsoft.Storage"),
// 			},
// 		},
// 	}, pulumi.Parent(c))
// 	if err != nil {
// 		return fmt.Errorf("unable to create firewall subnet %s, %w", name, err)
// 	}
// 	return nil
// }

func (args *HubArgs) validate() error {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["customer"]; !ok {
		args.Tags["customer"] = args.Customer
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["complianceLevel"] = args.ComplianceLevel
	}

	if _, ok := args.Tags["environment"]; !ok {
		args.Tags["environment"] = args.Environment
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}
	
	if args.AwsGatewayConfig != nil {
		if err := args.AwsGatewayConfig.validate(); err != nil {
			return err
		}
	}

	return nil
}

func (args *HubArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal hub args, %w", err)
	}

	return nil
}

func (args *AwsGatewayConfigArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}
	
	return nil
}

func (args *AwsGatewayConfigArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal hub args, %w", err)
	}

	return nil
}