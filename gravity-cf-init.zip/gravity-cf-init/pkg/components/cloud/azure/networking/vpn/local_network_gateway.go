package vpn

import (
	"fmt"
	"strconv"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const localNetworkGatewayComponentName = "gravity:azure:vpn:localNetworkGateway"

type LocalNetworkGateway struct {
	pulumi.ResourceState
}

type LocalNetworkGatewayArgs struct {
	GatewayIP         pulumi.StringInput `pulumi:"gatewayIP"  validate:"required"`
	PeeringIP         pulumi.StringInput `pulumi:"peeringIPs" validate:"required"`
	SharedKey         pulumi.StringInput `pulumi:"sharedKey"  validate:"required"`
	Location          pulumi.StringInput `pulumi:"location"   validate:"required"`
	ResourceGroupName pulumi.StringInput `pulumi:"resourceGroupName" validate:"required"`
	RouterASN         pulumi.StringInput `pulumi:"routerASN" validate:"default=64515"`
	Tags              pulumi.StringMap   `pulumi:"tags"`
}

func NewLocalNetworkGateway(ctx *pulumi.Context, name string, args *LocalNetworkGatewayArgs, opts ...pulumi.ResourceOption) (*LocalNetworkGateway, error) {
	component := &LocalNetworkGateway{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(localNetworkGatewayComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", localNetworkGatewayComponentName, name, err)
	}

	if err := component.createLocalNetworkGateway(ctx, "lng-"+name, args); err != nil {
		return nil, err
	}

	if err := component.createVirtualNetworkConnections(ctx, "vnc-"+name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", localNetworkGatewayComponentName, name, err)
	}

	return component, nil
}

func (c *LocalNetworkGateway) createLocalNetworkGateway(ctx *pulumi.Context, name string, args *LocalNetworkGatewayArgs) error {
	if _, err := network.NewLocalNetworkGateway(ctx, name, &network.LocalNetworkGatewayArgs{
		BgpSettings: &network.BgpSettingsArgs{
			Asn: pulumi.Float64Output(pulumix.Cast[pulumi.IntOutput](pulumix.ApplyErr(args.RouterASN.ToStringOutput(), strconv.Atoi))),
			// BgpPeeringAddresses: network.IPConfigurationBgpPeeringAddressArray{
			// 	&network.IPConfigurationBgpPeeringAddressArgs{
			// 		CustomBgpIpAddresses: args.PeeringIPs,
			// 	}},
			BgpPeeringAddress: args.PeeringIP,
		},
		GatewayIpAddress:  args.GatewayIP,
		Location:          args.Location,
		ResourceGroupName: args.ResourceGroupName,
		Tags:              args.Tags,
	}, pulumi.Parent(c)); err != nil {
		return fmt.Errorf("unable to create Azure local network gateway, %w", err)
	}

	return nil
}

func (c *LocalNetworkGateway) createVirtualNetworkConnections(ctx *pulumi.Context, name string, args *LocalNetworkGatewayArgs) error {
	if _, err := network.NewVirtualNetworkGatewayConnection(ctx, name, &network.VirtualNetworkGatewayConnectionArgs{
		ConnectionMode:                      network.VirtualNetworkGatewayConnectionModeDefault,
		ConnectionProtocol:                  network.VirtualNetworkGatewayConnectionProtocolIKEv2,
		ConnectionType:                      network.VirtualNetworkGatewayConnectionTypeIPsec,
		DpdTimeoutSeconds:                   nil,
		EgressNatRules:                      nil,
		EnableBgp:                           nil,
		EnablePrivateLinkFastPath:           nil,
		ExpressRouteGatewayBypass:           nil,
		GatewayCustomBgpIpAddresses:         nil,
		Id:                                  nil,
		IngressNatRules:                     nil,
		IpsecPolicies:                       nil,
		LocalNetworkGateway2:                nil,
		Location:                            nil,
		Peer:                                nil,
		ResourceGroupName:                   args.ResourceGroupName,
		RoutingWeight:                       nil,
		SharedKey:                           args.SharedKey,
		Tags:                                args.Tags,
		TrafficSelectorPolicies:             nil,
		UseLocalAzureIpAddress:              nil,
		UsePolicyBasedTrafficSelectors:      nil,
		VirtualNetworkGateway1:              nil,
		VirtualNetworkGateway2:              nil,
		VirtualNetworkGatewayConnectionName: nil,
	}); err != nil {
		return fmt.Errorf("unable to create Azure virtual network gateway connection, %w", err)
	}

	return nil
}

func (args *LocalNetworkGatewayArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *LocalNetworkGatewayArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal cluster args, %w", err)
	}

	return nil
}
