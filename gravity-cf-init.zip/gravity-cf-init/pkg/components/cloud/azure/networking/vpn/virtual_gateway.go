package vpn

import (
	"fmt"
	// "strings"
	// "strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure/sdk/v6/go/azure/network"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	// "github.com/pulumi/pulumi/sdk/v3/go/pulumix"
	// "github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

const virtualGatewayComponentName = "gravity:azure:vpn:virtualGateway"

type VirtualGateway struct {
	pulumi.ResourceState
	RouterASN          pulumi.IntOutput
	SubnetID           pulumi.StringOutput `pulumi:"subnetID"`
	PublicInterfaceIDs pulumi.StringArray  `pulumi:"publicInterfaceIDs"`
	PublicInterfaceIPs pulumi.StringArray  `pulumi:"publicInterfaceIPs"`
}

type VirtualGatewayArgs struct {
	SubnetID          pulumi.StringInput `pulumi:"subnetID"          validate:"required"`
	VNetName          pulumi.StringInput `pulumi:"vNetName"          validate:"required"`
	VNetID            pulumi.StringInput `pulumi:"vNetID"            validate:"required"`
	Location          pulumi.StringInput `pulumi:"location"          validate:"required"`
	ResourceGroupName pulumi.StringInput `pulumi:"resourceGroupName" validate:"required"`
	RouterASN         pulumi.IntInput    `pulumi:"routerASN"         validate:"default=65515"`
	TunnelCount       pulumi.Int         `pulumi:"tunnelCount"       validate:"default=2"`
	Tags              pulumi.StringMap   `pulumi:"tags"`
}

func NewVirtualGateway(ctx *pulumi.Context, name string, args *VirtualGatewayArgs, opts ...pulumi.ResourceOption) (*VirtualGateway, error) {
	component := &VirtualGateway{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(virtualGatewayComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", virtualGatewayComponentName, name, err)
	}

	if err := component.createPublicInterfaces(ctx, "pip-"+name, args); err != nil {
		return nil, err
	}

	if err := component.createVirtualGateway(ctx, "vng-"+name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"publicInterfaceIDs": component.PublicInterfaceIDs,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", virtualGatewayComponentName, name, err)
	}

	return component, nil
}

func (c *VirtualGateway) createPublicInterfaces(ctx *pulumi.Context, name string, args *VirtualGatewayArgs) error {
	c.PublicInterfaceIDs = pulumi.StringArray{}

	for i := range args.TunnelCount {
		if err := c.createPublicInterface(ctx, fmt.Sprintf("%s-%d", name, i), args); err != nil {
			return err
		}
	}

	return nil
}

func (c *VirtualGateway) createPublicInterface(ctx *pulumi.Context, name string, args *VirtualGatewayArgs) error {
	pubInterface, err := network.NewPublicIp(ctx, name, &network.PublicIpArgs{
		Location:          args.Location,
		ResourceGroupName: args.ResourceGroupName,
		AllocationMethod:  pulumi.String("Static"),
		Zones:             pulumi.ToStringArray([]string{"1", "2", "3"}),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create Azure vpn gateway public IP, %w", err)
	}

	c.PublicInterfaceIDs = append(c.PublicInterfaceIDs, pubInterface.ID())
	c.PublicInterfaceIPs = append(c.PublicInterfaceIPs, pubInterface.IpAddress)

	return nil
}

func (c *VirtualGateway) createVirtualGateway(ctx *pulumi.Context, name string, args *VirtualGatewayArgs) error {
	_, err := network.NewVirtualNetworkGateway(ctx, name, &network.VirtualNetworkGatewayArgs{
		ActiveActive: pulumi.Bool(true),
		BgpSettings: &network.VirtualNetworkGatewayBgpSettingsArgs{
			Asn: args.RouterASN,
			PeeringAddresses: func() network.VirtualNetworkGatewayBgpSettingsPeeringAddressArray {
				bgpPeers := network.VirtualNetworkGatewayBgpSettingsPeeringAddressArray{}

				for idx := range c.PublicInterfaceIDs {
					bgpPeer := &network.VirtualNetworkGatewayBgpSettingsPeeringAddressArgs{
						ApipaAddresses: pulumi.StringArray{
							pulumi.Sprintf("169.254.21.%d", idx*4+2),
							pulumi.Sprintf("169.254.22.%d", idx*4+2),
						},
						IpConfigurationName: pulumi.Sprintf("%sGWpip%d", args.VNetName, idx),
					}

					bgpPeers = append(bgpPeers, bgpPeer)
				}

				return bgpPeers
			}(),
		},
		Name:      pulumi.String(name),
		EnableBgp: pulumi.Bool(true),
		Type:      pulumi.String("Vpn"),
		IpConfigurations: func() *network.VirtualNetworkGatewayIpConfigurationArray {
			ipConfigs := network.VirtualNetworkGatewayIpConfigurationArray{}

			for idx, id := range c.PublicInterfaceIDs {
				ipConfigs = append(ipConfigs, &network.VirtualNetworkGatewayIpConfigurationArgs{
					PublicIpAddressId: id,
					Name:              pulumi.Sprintf("%sGWpip%d", args.VNetName, idx),
					SubnetId:          args.SubnetID,
				})
			}

			return &ipConfigs
		}(),
		Location:          args.Location,
		ResourceGroupName: args.ResourceGroupName,
		Sku:               pulumi.String("VpnGw2AZ"),
		Tags:              args.Tags,
		Generation:        pulumi.String("Generation2"),
		VpnType:           pulumi.String("RouteBased"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create Azure vpn gateway, %w", err)
	}

	c.RouterASN = args.RouterASN.ToIntOutput()

	return nil
}

func (args *VirtualGatewayArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *VirtualGatewayArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
