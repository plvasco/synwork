package networking_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewVirtualNetwork(t *testing.T) {
	t.Parallel()

	type want struct {
		vnetName  string
		snetNames map[string]pulumi.ID
		peerings  map[string]pulumi.ID
	}

	type args struct {
		name string
		args *networking.VirtualNetworkArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "should create network resources",
			in: args{
				name: "test-net",
				args: &networking.VirtualNetworkArgs{
					ResourceGroupName: pulumi.String("resourcegroup"),
					AddressSpace:      pulumi.String("10.0.0.0/16"),
					Subnets: map[string]*networking.VirtualNetworkSubnetArgs{
						"subnet-one": {
							AddressSpace: pulumi.String("10.0.0.0/24"),
						},
						"subnet-two": {
							AddressSpace: pulumi.String("10.0.1.0/24"),
						},
					},
					Tags: pulumi.StringMap{},
				},
			},
			want: want{
				vnetName: "test-net-vnet",
				snetNames: map[string]pulumi.ID{
					"subnet-one": "subnet-one-snet_id",
					"subnet-two": "subnet-two-snet_id",
				},
			},
			wantErr: false,
		},
		{
			name: "should create peerings",
			in: args{
				name: "test-net",
				args: &networking.VirtualNetworkArgs{
					ResourceGroupName: pulumi.String("resourcegroup"),
					AddressSpace:      pulumi.String("10.0.0.0/16"),
					Subnets: map[string]*networking.VirtualNetworkSubnetArgs{
						"subnet-one": {
							AddressSpace: pulumi.String("10.0.0.0/24"),
						},
						"subnet-two": {
							AddressSpace: pulumi.String("10.0.1.0/24"),
						},
					},
					Peerings: map[string]string{
						"peer-one": "/subscriptions/123e4567-e89b-12d3-a456-426614174000/resourceGroups/test1/providers/Microsoft.Network/virtualNetworks/2f-test-vnet-1",
						"peer-two": "/subscriptions/123e4567-e89b-12d3-a456-426614174000/resourceGroups/test1/providers/Microsoft.Network/virtualNetworks/2f-test-vnet-2",
					},
					Tags: pulumi.StringMap{},
				},
			},
			want: want{
				vnetName: "test-net-vnet",
				snetNames: map[string]pulumi.ID{
					"subnet-one": "subnet-one-snet_id",
					"subnet-two": "subnet-two-snet_id",
				},
				peerings: map[string]pulumi.ID{
					"peer-one": "peer-one-peering_id",
					"peer-two": "peer-two-peering_id",
				},
			},
			wantErr: false,
		},
		// {
		// 	name: "should create network with default values",
		// 	in: args{
		// 		name: "test-default",
		// 		args: &networking.NetworkArgs{
		// 			ResourceGroupName: pulumi.String("resourcegroup"),
		// 			Tags:              pulumi.ToStringMap(map[string]string{"test": "test"}),
		// 		},
		// 	},
		// 	want: want{
		// 		vnetName:        "test-default-vnet",
		// 		privateSubnetID: "test-default-private-subnet_id",
		// 		publicSubnetID:  "test-default-public-subnet_id",
		// 	},
		// 	wantErr: false,
		// },
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewVirtualNetwork(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				vnetName := got.VNetName.ApplyT(func(vnetName string) string {
					assert.Equal(t, tt.want.vnetName, vnetName)

					return vnetName
				})
				require.NotNil(t, vnetName)

				for name, gotID := range got.Subnets {
					gotID.ApplyT(func(subnetID pulumi.ID) pulumi.ID {
						assert.Equal(t, tt.want.snetNames[name], subnetID)

						return subnetID
					})
				}

				for name, gotID := range got.Peerings {
					gotID.ApplyT(func(peeringID pulumi.ID) pulumi.ID {
						assert.Equal(t, tt.want.peerings[name], peeringID)

						return peeringID
					})
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestVirtualNetworkArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *networking.VirtualNetworkArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"location": "usgovvirginia",
				"resourceGroupName": "rg-example",
				"tags": {
					"env": "production"
				},
				"addressSpace": "10.0.0.0/16",
				"subnets": {
					"subnet-one": {
						"addressSpace": "10.0.0.0/24"
					},
					"subnet-two": {
						"addressSpace": "10.0.1.0/24"
					}
				}
			}`,
			want: &networking.VirtualNetworkArgs{
				Location:          pulumi.String("usgovvirginia"),
				ResourceGroupName: pulumi.String("rg-example"),
				Tags: pulumi.StringMap{
					"env": pulumi.String("production"),
				},
				AddressSpace: pulumi.String("10.0.0.0/16"),
				Subnets: map[string]*networking.VirtualNetworkSubnetArgs{
					"subnet-one": {
						AddressSpace: pulumi.String("10.0.0.0/24"),
					},
					"subnet-two": {
						AddressSpace: pulumi.String("10.0.1.0/24"),
					},
				},
			},
			wantErr: false,
		},
		{
			name: "malformed vnet address space",
			input: `{
				"location": "usgovvirginia",
				"resourceGroupName": "rg-example",
				"tags": {
					"env": "production"
				},
				"addressSpace": 42
				"subnets": {
					"subnet-one": {
						"addressSpace": "10.0.0.0/24"
					},
					"subnet-two": {
						"addressSpace": "10.0.1.0/24"
					}
				}
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name: "malformed subnet JSON",
			input: `{
				"location": "usgovvirginia",
				"resourceGroupName": "rg-example",
				"tags": {
					"env": "production"
				},
				"addressSpace": "10.0.0.0/16"
				"subnets": {
					"subnet-one": {
						"addressSpace": "10.0.0.0/24"
					},
					"subnet-two": {
						"addressSpace": 42
					}
				}
			}`,
			want:    nil,
			wantErr: true,
		},
		{
			name: "malformed network args JSON",
			input: `{
				"location": "usgovvirginia",
				"resourceGroupName": 1000,
				"tags": {
					"env": "production"
				},
				"addressSpace": "10.0.0.0/16"
				"subnets": {
					"subnet-one": {
						"addressSpace": "10.0.0.0/24"
					},
					"subnet-two": {
						"addressSpace": "10.0.1.0/24"
					}
				}
			}`,
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args networking.VirtualNetworkArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
