package networking

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const virtualNetworkComponentName = "gravity:azure:virtualnetwork"

var (
	ErrRequiredArgumentRootCIDRString = errors.New("required argument AddressSpace is missing")
)

// VirtualNetwork is a struct representation of the AWS Network component Resource.
type VirtualNetwork struct {
	pulumi.ResourceState
	ResourceGroupName pulumi.StringOutput        `pulumi:"resourceGroupName"`
	AddressSpace      pulumi.StringOutput        `pulumi:"addressSpace"`
	VNetID            pulumi.IDOutput            `pulumi:"vnetID"`
	VNetName          pulumi.StringOutput        `pulumi:"vnetName"`
	Subnets           map[string]pulumi.IDOutput `pulumi:"subnets"`
	Peerings          map[string]pulumi.IDOutput `pulumi:"peerings"`
}

// NetworkArgs contains arguments required to create a Root componentResource (can be unmarshalled from stack config).
type VirtualNetworkArgs struct {
	ResourceGroupName pulumi.StringInput                   `pulumi:"resourceGroupName" validate:"required"`
	Location          pulumi.StringInput                   `pulumi:"location"`
	AddressSpace      pulumi.StringInput                   `pulumi:"addressSpace"`
	Subnets           map[string]*VirtualNetworkSubnetArgs `pulumi:"subnets"           validate:"dig"`
	Peerings          map[string]string                    `pulumi:"peerings"`
	Tags              pulumi.StringMap                     `pulumi:"tags"`
}

type VirtualNetworkSubnetArgs struct {
	AddressSpace pulumi.StringInput `pulumi:"addressSpace"`
}

// NewNetwork creates a new component resource containing a account, vpc, and subnets needed to stand up a new org.
func NewVirtualNetwork(ctx *pulumi.Context, name string, args *VirtualNetworkArgs, opts ...pulumi.ResourceOption) (*VirtualNetwork, error) {
	if err := args.validate(); err != nil {
		return nil, fmt.Errorf("unable to validate network args, %w", err)
	}

	component := &VirtualNetwork{
		Subnets:  make(map[string]pulumi.IDOutput),
		Peerings: make(map[string]pulumi.IDOutput),
	}

	if err := ctx.RegisterComponentResource(virtualNetworkComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", virtualNetworkComponentName, name, err)
	}

	if err := component.createVNet(ctx, name+"-vnet", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"vnetID":   component.VNetID,
		"vnetName": component.VNetName,
		"subnets":  pulumi.ToIDMapOutput(component.Subnets),
		"peerings": pulumi.ToIDMapOutput(component.Peerings),
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", virtualNetworkComponentName, name, err)
	}

	return component, nil
}

// createVNet creates a vnet
func (c *VirtualNetwork) createVNet(ctx *pulumi.Context, name string, args *VirtualNetworkArgs) error {
	vnet, err := network.NewVirtualNetwork(ctx, name, &network.VirtualNetworkArgs{
		VirtualNetworkName: pulumi.String(name),
		Location:           args.Location,
		AddressSpace: &network.AddressSpaceArgs{
			AddressPrefixes: pulumi.StringArray{
				args.AddressSpace,
			},
		},
		ResourceGroupName: args.ResourceGroupName,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create vnet %s, %w", name, err)
	}

	for subnetName, subnet := range args.Subnets {
		sn, err := network.NewSubnet(ctx, subnetName+"-snet", &network.SubnetArgs{
			SubnetName:         pulumi.String(subnetName + "-snet"),
			AddressPrefix:      subnet.AddressSpace,
			VirtualNetworkName: vnet.Name,
			ResourceGroupName:  args.ResourceGroupName,
		}, pulumi.Parent(vnet))
		if err != nil {
			return fmt.Errorf("unable to create subnet %s, %w", subnetName, err)
		}

		c.Subnets[subnetName] = sn.ID()
	}

	for peeringName, remoteNetworkID := range args.Peerings {
		peering, err := network.NewVirtualNetworkPeering(ctx, peeringName+"-peering", &network.VirtualNetworkPeeringArgs{
			ResourceGroupName:  args.ResourceGroupName,
			VirtualNetworkName: vnet.Name,
			Name:               pulumi.String(peeringName),
			RemoteVirtualNetwork: &network.SubResourceArgs{
				Id: pulumi.String(remoteNetworkID),
			},
		}, pulumi.Parent(vnet))
		if err != nil {
			return fmt.Errorf("unable to create peering %s, %w", peeringName, err)
		}

		c.Peerings[peeringName] = peering.ID()
	}

	c.VNetID = vnet.ID()
	c.VNetName = vnet.Name
	c.AddressSpace = pulumi.StringOutput(vnet.AddressSpace)

	return nil
}

// validate checks that all required args are set and sets defaults for any optional args.
func (args *VirtualNetworkArgs) validate() error {
	if args == nil {
		args = &VirtualNetworkArgs{}
	}

	if args.AddressSpace == nil {
		return ErrRequiredArgumentRootCIDRString
	}

	return nil
}

func (args *VirtualNetworkArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal network args, %w", err)
	}

	return nil
}

func (args *VirtualNetworkSubnetArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal network args, %w", err)
	}

	return nil
}
