package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const networkComponentName = "gravity:azure:network"

type Network struct {
	pulumi.ResourceState
	VirtualNetworkName pulumi.StringOutput `pulumi:"virtualNetworkName"`
	// A map of avaliablility zones and their associated subnet configurations for the created network.
	Subnet *Subnet `pulumi:"subnet"`
}

type NetworkArgs struct {
	Location          pulumi.StringInput `pulumi:"location"`
	ResourceGroupName pulumi.StringInput `pulumi:"resourceGroupName" validate:"required"`
	Tags              pulumi.StringMap   `pulumi:"tags"`
	// overarching cloud supernet that the ipam will use to find free ranges.
	SupernetCidr pulumi.StringInput `pulumi:"supernetCidr" validate:"default=10.128.0.0/16"`
	// optionally override ipam allocation for vpc network, required if not using transit gateway
	NetworkCidr pulumi.StringInput `pulumi:"networkCidr" validate:"default=10.128.10.0/24"`
	// The size of the network prefix to assign to the VPC (default is 24)
	NetworkPrefixSize pulumi.IntInput `pulumi:"networkPrefixSize" validate:"default=24"`
	// The size of each subnet created per az inside vpc network (default is 26)
	SubnetPrefixSize pulumi.IntInput `pulumi:"subnetPrefixSize" validate:"default=26"`
}

func NewNetwork(ctx *pulumi.Context, name string, args *NetworkArgs, opts ...pulumi.ResourceOption) (*Network, error) {
	component := &Network{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(networkComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", networkComponentName, name, err)
	}

	if err := component.createVirtualNetwork(ctx, "vnet-"+name+"-", args); err != nil {
		return nil, err
	}

	if err := component.createSubnet(ctx, "sn-"+name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"virtualNetworkName": component.VirtualNetworkName,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", networkComponentName, name, err)
	}

	return component, nil
}

func (c *Network) createVirtualNetwork(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	vNet, err := network.NewVirtualNetwork(ctx, name, &network.VirtualNetworkArgs{
		AddressSpace: &network.AddressSpaceArgs{
			AddressPrefixes: pulumi.StringArray{
				args.NetworkCidr,
			},
		},
		Location:          args.Location,
		ResourceGroupName: args.ResourceGroupName,
		Tags:              utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create virtual network %s, %w", name, err)
	}

	c.VirtualNetworkName = vNet.Name

	return nil
}

func (c *Network) createSubnet(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	subnet, err := NewSubnet(ctx, name, &SubnetArgs{
		CIDRBlock:          args.NetworkCidr,
		SubnetPrefixSize:   args.SubnetPrefixSize,
		ResourceGroupName:  args.ResourceGroupName,
		VirtualNetworkName: c.VirtualNetworkName,
		Tags:               utils.GenerateTags(args.Tags, name),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create subnet, %w", err)
	}

	c.Subnet = subnet

	return nil
}

func (args *NetworkArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *NetworkArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
