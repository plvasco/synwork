package azure_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/cluster/aks"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewInfrastructure(t *testing.T) {
	t.Parallel()

	type want struct {
		vnetName string
		subnets  []string
	}

	type args struct {
		name string
		args *azure.InfrastructureArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should create azure infra stack with existing network",
			in: args{
				name: "test-infra",
				args: &azure.InfrastructureArgs{
					Cluster: &aks.ClusterArgs{
						KubernetesVersion: pulumi.String("1.30"),
						AgentPools:        map[string]*aks.AgentPoolArgs{},
						ResourceGroupName: pulumi.String("testrg"),
					},
					ExistingNetwork: &azure.ExistingNetworkArgs{
						VirtualNetworkName: pulumi.String("testvnet"),
						SubnetName:         pulumi.String("subnet"),
					},
					ResourceGroupName: pulumi.String("testrg"),
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test"),
					Environment:       pulumi.String("testing"),
				},
			},
			want: want{
				vnetName: "testvnet",
				subnets: []string{
					"",
					"",
				},
			},
			wantErr: false,
		},
		{
			name: "test should create azure infra stack with network build",
			in: args{
				name: "test-infra",
				args: &azure.InfrastructureArgs{
					Cluster: &aks.ClusterArgs{
						KubernetesVersion: pulumi.String("1.30"),
						AgentPools:        map[string]*aks.AgentPoolArgs{},
						ResourceGroupName: pulumi.String("testrg"),
					},
					Networking:        &networking.NetworkArgs{},
					ResourceGroupName: pulumi.String("testrg"),
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test"),
					Environment:       pulumi.String("testing"),
				},
			},
			want: want{
				vnetName: "test-infra-network-vnet",
				subnets: []string{
					"test-infra-network-subnet_id",
				},
			},
			wantErr: false,
		},
		{
			name: "test should fail with missing required ResourceGroupName",
			in: args{
				name: "test-infra",
				args: &azure.InfrastructureArgs{
					Cluster: &aks.ClusterArgs{
						KubernetesVersion: pulumi.String("1.30"),
						AgentPools:        map[string]*aks.AgentPoolArgs{},
						ResourceGroupName: pulumi.String("testrg"),
					},
					Networking:      &networking.NetworkArgs{},
					ComplianceLevel: pulumi.String("testing"),
					Customer:        pulumi.String("test"),
					Environment:     pulumi.String("testing"),
				},
			},
			wantErr: true,
		},
		{
			name: "test should fail with missing required ComplianceLevel",
			in: args{
				name: "test-infra",
				args: &azure.InfrastructureArgs{
					Cluster: &aks.ClusterArgs{
						KubernetesVersion: pulumi.String("1.30"),
						AgentPools:        map[string]*aks.AgentPoolArgs{},
						ResourceGroupName: pulumi.String("testrg"),
					},
					Networking:        &networking.NetworkArgs{},
					ComplianceLevel:   pulumi.String("testing"),
					ResourceGroupName: pulumi.String("testrg"),
					Environment:       pulumi.String("testing"),
				},
			},
			wantErr: true,
		},
		{
			name: "test should fail with missing required Customer",
			in: args{
				name: "test-infra",
				args: &azure.InfrastructureArgs{
					Cluster: &aks.ClusterArgs{
						KubernetesVersion: pulumi.String("1.30"),
						AgentPools:        map[string]*aks.AgentPoolArgs{},
						ResourceGroupName: pulumi.String("testrg"),
					},
					Networking:        &networking.NetworkArgs{},
					ComplianceLevel:   pulumi.String("testing"),
					ResourceGroupName: pulumi.String("testrg"),
					Environment:       pulumi.String("testing"),
				},
			},
			wantErr: true,
		},
		{
			name: "test should fail with missing required Environment",
			in: args{
				name: "test-infra",
				args: &azure.InfrastructureArgs{
					Cluster: &aks.ClusterArgs{
						KubernetesVersion: pulumi.String("1.30"),
						AgentPools:        map[string]*aks.AgentPoolArgs{},
						ResourceGroupName: pulumi.String("testrg"),
					},
					Networking:        &networking.NetworkArgs{},
					ComplianceLevel:   pulumi.String("testing"),
					ResourceGroupName: pulumi.String("testrg"),
					Customer:          pulumi.String("test"),
				},
			},
			wantErr: true,
		},
		{
			name: "test should fail with both network types defined",
			in: args{
				name: "test-infra",
				args: &azure.InfrastructureArgs{
					Cluster: &aks.ClusterArgs{
						KubernetesVersion: pulumi.String("1.30"),
						AgentPools:        map[string]*aks.AgentPoolArgs{},
						ResourceGroupName: pulumi.String("testrg"),
					},
					ExistingNetwork: &azure.ExistingNetworkArgs{
						VirtualNetworkName: pulumi.String("testvnet"),
						SubnetName:         pulumi.String("subnet"),
					},
					Networking:        &networking.NetworkArgs{},
					ResourceGroupName: pulumi.String("testrg"),
					ComplianceLevel:   pulumi.String("testing"),
					Customer:          pulumi.String("test"),
					Environment:       pulumi.String("testing"),
				},
			},
			wantErr: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := azure.NewInfrastructure(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				vnetName := got.VirtualNetworkName.ApplyT(func(vnetName string) string {
					assert.Equal(t, tc.want.vnetName, vnetName)

					return vnetName
				})
				require.NotNil(t, vnetName)

				if tc.in.args.ExistingNetwork == nil {
					got.Subnet.ID.ApplyT(func(subnetID string) string {
						assert.Contains(t, tc.want.subnets, subnetID)

						return subnetID
					})
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AzureMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewInfrastructure() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestInfrastructureArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *azure.InfrastructureArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"tags": {
					"team": "infra",
					"project": "azure"
				},
				"cluster": {
					"kubernetesVersion": "1.23",
					"complianceLevel": "high",
					"tier": "Premium",
					"location": "usgovvirginia",
					"environment": "production",
					"customer": "gov-cloud",
					"subnetID": "subnet-12345",
					"resourceGroupName": "rg-cluster"
				},
				"location": "us-east-1",
				"networking": {
					"location": "us-east-1",
					"resourceGroupName": "rg-network",
					"tags": {
						"env": "production"
					},
					"supernetCidr": "10.0.0.0/16",
					"networkCidr": "10.0.10.0/24",
					"networkPrefixSize": 23,
					"subnetPrefixSize": 27
				},
				"existingNetwork": {
					"virtualNetworkName": "vnet-12345",
					"subnetName": "subnet-existing"
				},
				"resourceGroupName": "rg-infra",
				"complianceLevel": "high",
				"customer": "gov-cloud",
				"environment": "production"
			}`,
			want: &azure.InfrastructureArgs{
				Tags: pulumi.StringMap{
					"team":    pulumi.String("infra"),
					"project": pulumi.String("azure"),
				},
				Cluster: &aks.ClusterArgs{
					KubernetesVersion: pulumi.String("1.23"),
					ComplianceLevel:   pulumi.String("high"),
					Tier:              pulumi.String("Premium"),
					Location:          pulumi.String("usgovvirginia"),
					Environment:       pulumi.String("production"),
					Customer:          pulumi.String("gov-cloud"),
					SubnetID:          pulumi.String("subnet-12345"),
					ResourceGroupName: pulumi.String("rg-cluster"),
				},
				Location: pulumi.String("us-east-1"),
				Networking: &networking.NetworkArgs{
					Location:          pulumi.String("us-east-1"),
					ResourceGroupName: pulumi.String("rg-network"),
					Tags: pulumi.StringMap{
						"env": pulumi.String("production"),
					},
					SupernetCidr:      pulumi.String("10.0.0.0/16"),
					NetworkCidr:       pulumi.String("10.0.10.0/24"),
					NetworkPrefixSize: pulumi.Int(23),
					SubnetPrefixSize:  pulumi.Int(27),
				},
				ExistingNetwork: &azure.ExistingNetworkArgs{
					VirtualNetworkName: pulumi.String("vnet-12345"),
					SubnetName:         pulumi.String("subnet-existing"),
				},
				ResourceGroupName: pulumi.String("rg-infra"),
				ComplianceLevel:   pulumi.String("high"),
				Customer:          pulumi.String("gov-cloud"),
				Environment:       pulumi.String("production"),
			},
			wantErr: false,
		},
		{
			name: "malformed JSON with incorrect types",
			input: `{
				"tags": "invalid",
				"cluster": 123,
				"location": true,
				"networking": false,
				"existingNetwork": {
					"virtualNetworkName": 456,
					"subnetName": null
				},
				"resourceGroupName": [],
				"complianceLevel": {},
				"customer": 123,
				"environment": null
			}`, // Incorrect types for all fields
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args azure.InfrastructureArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
