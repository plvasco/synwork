package azure

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/cluster/aks"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/azure/networking"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const infrastructureComponentName = "gravity:azure:infrastructure"

var (
	ErrArgumentNetworkingDupe = errors.New("can not provide both `networking` and `existingNetwork` only one can be defined")
)

type Infrastructure struct {
	pulumi.ResourceState
	Cluster            *aks.Cluster        `pulumi:"cluster"`
	Subnet             *networking.Subnet  `pulumi:"subnet"`
	VirtualNetworkName pulumi.StringOutput `pulumi:"virtualNetworkName"`
}

type InfrastructureArgs struct {
	Tags              pulumi.StringMap        `pulumi:"tags"`
	Cluster           *aks.ClusterArgs        `pulumi:"cluster"`
	Location          pulumi.StringInput      `pulumi:"location"          validate:"default=usgovvirginia"`
	Networking        *networking.NetworkArgs `pulumi:"networking"`
	ExistingNetwork   *ExistingNetworkArgs    `pulumi:"existingNetwork"`
	ResourceGroupName pulumi.StringInput      `pulumi:"resourceGroupName" validate:"required"`
	ComplianceLevel   pulumi.StringInput      `pulumi:"complianceLevel"   validate:"required"`
	Customer          pulumi.StringInput      `pulumi:"customer"          validate:"required"`
	Environment       pulumi.StringInput      `pulumi:"environment"       validate:"required"`
}

type ExistingNetworkArgs struct {
	VirtualNetworkName pulumi.StringInput `pulumi:"virtualNetworkName" validate:"required"`
	SubnetName         pulumi.StringInput `pulumi:"subnetName"         validate:"required"`
}

func NewInfrastructure(ctx *pulumi.Context, name string, args *InfrastructureArgs, opts ...pulumi.ResourceOption) (*Infrastructure, error) {
	component := &Infrastructure{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(infrastructureComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", infrastructureComponentName, name, err)
	}

	if args.ExistingNetwork == nil {
		if err := component.createNetwork(ctx, name, args); err != nil {
			return nil, err
		}
	} else {
		component.getExistingNetwork(ctx, args)
	}

	if err := component.createAksClusters(ctx, "aks-"+name+"-", args); err != nil {
			return nil, err
		}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", infrastructureComponentName, name, err)
	}

	return component, nil
}

func (c *Infrastructure) createNetwork(ctx *pulumi.Context, name string, args *InfrastructureArgs) error {
	// Create Networking for AWS stack
	if args.Networking == nil {
		args.Networking = &networking.NetworkArgs{}
	}

	args.Networking.Location = args.Location
	args.Networking.Tags = utils.CombineTags(args.Tags, args.Networking.Tags)
	args.Networking.ResourceGroupName = args.ResourceGroupName

	vnet, err := networking.NewNetwork(ctx, name, args.Networking, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("error building networking %w", err)
	}

	c.Subnet = vnet.Subnet

	c.VirtualNetworkName = vnet.VirtualNetworkName

	return nil
}

func (c *Infrastructure) getExistingNetwork(ctx *pulumi.Context, args *InfrastructureArgs) {
	// Get info from existing network
	subnet := network.LookupSubnetOutput(ctx, network.LookupSubnetOutputArgs{
		SubnetName:         args.ExistingNetwork.SubnetName,
		ResourceGroupName:  args.ResourceGroupName,
		VirtualNetworkName: args.ExistingNetwork.VirtualNetworkName,
	}, pulumi.Parent(c))

	c.Subnet = &networking.Subnet{
		ID:           subnet.Id().Elem(),
		RouteTableID: subnet.RouteTable().Id().Elem(),
	}

	c.VirtualNetworkName = args.ExistingNetwork.VirtualNetworkName.ToStringOutput()
}

func (c *Infrastructure) createAksClusters(ctx *pulumi.Context, name string, args *InfrastructureArgs) error {
	args.Cluster.ResourceGroupName = args.ResourceGroupName
	args.Cluster.SubnetID = c.Subnet.ID
	args.Cluster.Tags = utils.CombineTags(args.Tags, args.Cluster.Tags)
	args.Cluster.ComplianceLevel = args.ComplianceLevel
	args.Cluster.Customer = args.Customer
	args.Cluster.Environment = args.Environment
	args.Cluster.Location = args.Location

	cluster, err := aks.NewCluster(ctx, name, args.Cluster, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create aks clusters, %w", err)
	}

	c.Cluster = cluster

	return nil
}

func (args *InfrastructureArgs) validate() error {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["customer"]; !ok {
		args.Tags["customer"] = args.Customer
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["complianceLevel"] = args.ComplianceLevel
	}

	if _, ok := args.Tags["environment"]; !ok {
		args.Tags["environment"] = args.Environment
	}

	if args.ExistingNetwork != nil && args.Networking != nil {
		return ErrArgumentNetworkingDupe
	}

	if args.ExistingNetwork != nil {
		if err := args.ExistingNetwork.validate(); err != nil {
			return err
		}
	}

	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *ExistingNetworkArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	

	return nil
}

func (args *InfrastructureArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal infra args, %w", err)
	}

	return nil
}

func (args *ExistingNetworkArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
