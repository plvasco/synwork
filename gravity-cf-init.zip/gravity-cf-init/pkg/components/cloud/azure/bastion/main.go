package main

import (
	"fmt"

	network "github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi/config"
)

// Define a custom struct for the Bastion Host configuration
type BastionHostConfig struct {
	BastionHostName   pulumi.StringInput
	IpConfigurations  network.BastionHostIPConfigurationArray
	ResourceGroupName pulumi.StringInput
	Region            pulumi.StringInput
}

// DefaultTags to be applied to all resources
var DefaultTags = pulumi.StringMap{
	"Type":    pulumi.String("Testing"),
	"Purpose": pulumi.String("testing"),
}

// Function to create a new Bastion Host configuration
func NewBastionHostConfig(resourceGroupName, subnetID, region pulumi.String, publicIPID pulumi.IDOutput) *BastionHostConfig {
	return &BastionHostConfig{
		BastionHostName: pulumi.String("bastionhosttenant"),
		IpConfigurations: network.BastionHostIPConfigurationArray{
			&network.BastionHostIPConfigurationArgs{
				Name: pulumi.String("bastionHostIpConfiguration"),
				PublicIPAddress: &network.SubResourceArgs{
					Id: publicIPID,
				},
				Subnet: &network.SubResourceArgs{
					Id: subnetID,
				},
			},
		},
		ResourceGroupName: pulumi.String(resourceGroupName),
		Region:            pulumi.String(region),
	}
}

// Function to look up a subnet
func GetAzureSubnet(ctx *pulumi.Context, resourceGroupName, virtualNetworkName, subnetName string) (*network.LookupSubnetResult, error) {
	// Call LookupSubnet
	subnet, err := network.LookupSubnet(ctx, &network.LookupSubnetArgs{
		ResourceGroupName:  resourceGroupName,
		VirtualNetworkName: virtualNetworkName,
		SubnetName:         subnetName,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to lookup subnet: %w", err)
	}

	return subnet, nil
}

func createBastionServer(ctx *pulumi.Context, rgName, subnetID, region pulumi.String, publicIPID pulumi.IDOutput) (*network.BastionHost, error) {
	// Create the Bastion Host configuration
	bastionConfig := NewBastionHostConfig(rgName, subnetID, region, publicIPID)

	customTags := pulumi.StringMap{
		"Name": pulumi.String("E2gbastion"),
	}

	// Merge the default tags with the custom tags.
	mergedTags := mergeTags(DefaultTags, customTags)

	// Use the custom struct to create the Bastion Host
	bastionHost, err := network.NewBastionHost(ctx, "bastionHostTenant", &network.BastionHostArgs{
		BastionHostName:   bastionConfig.BastionHostName,
		IpConfigurations:  bastionConfig.IpConfigurations,
		ResourceGroupName: bastionConfig.ResourceGroupName,
		Location:          bastionConfig.Region,
		Tags:              mergedTags,
	})
	if err != nil {
		return nil, err
	}
	return bastionHost, nil
}

func main() {
	pulumi.Run(func(ctx *pulumi.Context) error {
		c := config.New(ctx, "")
		resourceGroupName := c.Require("resourceGroupName")
		region := c.Require("azLocation")
		vnetName := c.Require("vnetName")
		subnetName := c.Require("subnetName")

		subnet, err := GetAzureSubnet(ctx, resourceGroupName, vnetName, subnetName)
		if err != nil {
			return err
		}

		// Create the Public IP Address
		publicIP, err := publicIPAddress(ctx, resourceGroupName, region)
		if err != nil {
			return err
		}

		bastionHost, err := createBastionServer(ctx, pulumi.String(resourceGroupName), pulumi.String(*subnet.Id), pulumi.String(region), publicIP.ID())
		if err != nil {
			return err
		}
		ctx.Export("publicIP", publicIP.ID())
		ctx.Export("Subnet", pulumi.String(*subnet.Id))
		ctx.Export("BastionData", bastionHost.ID())

		return nil
	})
}
