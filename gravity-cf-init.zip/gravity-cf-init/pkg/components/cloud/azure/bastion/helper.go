package main

import "github.com/pulumi/pulumi/sdk/v3/go/pulumi"

// mergeTags merges the default tags with any custom tags
func mergeTags(defaultTags, customTags pulumi.StringMap) pulumi.StringMap {
	// Create a new map to hold the merged tags
	mergedTags := pulumi.StringMap{}

	// Add the default tags
	for key, value := range defaultTags {
		mergedTags[key] = value
	}

	// Add the custom tags, which will overwrite any default tags with the same key
	for key, value := range customTags {
		mergedTags[key] = value
	}

	return mergedTags
}
