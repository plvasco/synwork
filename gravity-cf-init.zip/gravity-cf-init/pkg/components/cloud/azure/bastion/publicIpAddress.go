package main

import (
	"fmt"

	network "github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

// Resource struct for Public IP address.
type PublicIpAddressArgs struct {
	Location            pulumi.StringInput
	PublicIpAddressName pulumi.StringInput
	ResourceGroupName   pulumi.StringInput
}

// Args for new Public IP Address.
func NewPublicIPAddress(Location, PublicIpAddressName, ResourceGroup pulumi.String) *PublicIpAddressArgs {
	return &PublicIpAddressArgs{
		Location:            Location,
		PublicIpAddressName: PublicIpAddressName,
		ResourceGroupName:   ResourceGroup,
	}
}

// Function to create a Public IP Address and return it.
func publicIPAddress(ctx *pulumi.Context, resourceGroupName, location string) (*network.PublicIPAddress, error) {
	publicIPAddressName := pulumi.String(fmt.Sprintf("pip-az-%s-%s", ctx.Organization(), ctx.Stack()))
	publicIpAddressArgs := NewPublicIPAddress(pulumi.String(location), publicIPAddressName, pulumi.String(resourceGroupName))

	customTags := pulumi.StringMap{
		"Name": pulumi.String("E2gbastionPublicIp"),
	}

	// Merge the default tags with the custom tags.
	mergedTags := mergeTags(DefaultTags, customTags)

	publicIP, err := network.NewPublicIPAddress(ctx, "publicIPAddress", &network.PublicIPAddressArgs{
		Location:                 publicIpAddressArgs.Location,
		PublicIpAddressName:      publicIpAddressArgs.PublicIpAddressName,
		ResourceGroupName:        publicIpAddressArgs.ResourceGroupName,
		PublicIPAllocationMethod: pulumi.String("Static"),
		Sku: &network.PublicIPAddressSkuArgs{
			Name: pulumi.String("Standard"),
		},
		Tags: mergedTags,
	})
	if err != nil {
		return nil, err
	}

	return publicIP, nil
}
