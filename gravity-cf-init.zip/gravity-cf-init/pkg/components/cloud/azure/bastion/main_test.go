package main

import (
	"testing"

	network "github.com/pulumi/pulumi-azure-native-sdk/network/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

type mocks int

func (mocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	return args.Name + "_id", args.Inputs, nil
}

func (mocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	return args.Args, nil
}

func TestInfrastructure(t *testing.T) {
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		resourceGroupName := "test-resource-group"
		region := "eastus"

		// Create Public IP Address
		publicIP, err := publicIPAddress(ctx, resourceGroupName, region)
		assert.NoError(t, err)

		// Create Bastion Host
		subnetID := "/subscriptions/test-sub/resourceGroups/rg/providers/Microsoft.Network/virtualNetworks/vnet/subnets/subnet"
		publicIPID := publicIP.ID()
		bastionHost, err := createBastionServer(ctx, pulumi.String(resourceGroupName), pulumi.String(subnetID), pulumi.String(region), publicIPID)
		assert.NoError(t, err)

		// Test 1: Public IP Allocation Method is Static
		pulumi.All(publicIP.URN(), publicIP.PublicIPAllocationMethod).ApplyT(func(all []interface{}) error {
			urn := all[0].(pulumi.URN)
			allocationMethod := *all[1].(*string)

			assert.Equal(t, "Static", allocationMethod, "Public IP allocation method should be Static for %v", urn)
			return nil
		})

		// Test 2: Bastion Host has a Name tag
		pulumi.All(bastionHost.URN(), bastionHost.Tags).ApplyT(func(all []interface{}) error {
			urn := all[0].(pulumi.URN)
			tags := all[1].(map[string]string)

			assert.Containsf(t, tags, "Name", "Bastion Host is missing a Name tag on %v", urn)
			return nil
		})

		// Test 3: Public IP SKU is Standard
		pulumi.All(publicIP.URN(), publicIP.Sku).ApplyT(func(all []interface{}) error {
			urn := all[0].(pulumi.URN)
			sku := *all[1].(*network.PublicIPAddressSkuResponse)

			assert.Equal(t, "Standard", *sku.Name, "Public IP SKU should be Standard for %v", urn)
			return nil
		})

		// Test 4: Public Ip address has a Name tag
		pulumi.All(publicIP.URN(), publicIP.Tags).ApplyT(func(all []interface{}) error {
			urn := all[0].(pulumi.URN)
			tags := all[1].(map[string]string)

			assert.Containsf(t, tags, "Name", "PublicIPAddress resource is missing a Name tag on %v", urn)
			return nil
		})

		return nil
	}, pulumi.WithMocks("project", "stack", mocks(0)))
	assert.NoError(t, err)
}
