package cloud

import (
	"errors"
	"fmt"
	"net"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
)

var (
	ErrNoFreeSubnets    = errors.New("no free subnets available in range")
	ErrSubnetOutofRange = errors.New("requested subnet is not contained within network")
)

type SubnetManager struct {
	RootNetwork   *net.IPNet
	Subnets       []*net.IPNet
	NewSubnetMask net.IPMask
}

func NewSubnetManager(rootNetwork *net.IPNet, existingSubnets []*net.IPNet, newSubnetMaskSize int) *SubnetManager {
	return &SubnetManager{
		RootNetwork:   rootNetwork,
		Subnets:       existingSubnets,
		NewSubnetMask: net.CIDRMask(newSubnetMaskSize, 32),
	}
}

func (s *SubnetManager) deduplicateSubnets() {
	cidrMap := map[string]int{}
	dedupedSubnets := []*net.IPNet{}

	for _, cidr := range s.Subnets {
		superNet := &net.IPNet{IP: cidr.IP, Mask: s.NewSubnetMask}
		if _, ok := cidrMap[superNet.String()]; !ok {
			cidrMap[superNet.String()]++
			dedupedSubnets = append(dedupedSubnets, superNet)
		}
	}

	s.Subnets = dedupedSubnets
}

func (s *SubnetManager) getFirstSubnet() *net.IPNet {
	return &net.IPNet{
		IP:   s.RootNetwork.IP,
		Mask: s.NewSubnetMask,
	}
}

func (s *SubnetManager) walk(subnet *net.IPNet) (*net.IPNet, error) {
	if !s.RootNetwork.Contains(subnet.IP) {
		return nil, ErrNoFreeSubnets
	}

	for i := range len(s.Subnets) {
		if inUse := subnet.Contains(s.Subnets[i].IP); inUse {
			return s.walk(s.nextSubnet(subnet))
		}
	}

	return subnet, nil
}

// nextSubnet uses bitwise operations to increase to the next subnet of a given length.
// lets assume that we have a starting ip address of 10.0.1.4 and want to convert this to a UInt32
// 1. first we split each octet into its own byte which will convert it to binary (00001010, 00000000, 00000001, 00000100)
// 2. now lets take the first byte (10) 00001010 and add it to our empty uint32,
// this would look something like this 00000000000000000000000000001010
// 3. next we can "bit shift left" over 8 places which moves each bit to the left 8 times resulting in 00000000000000000000101000000000
// (notice how we have 8 zeros at the end of the number, its because the 8 digits at the beginning we "moved left and wrapped around")
// we can now repeat step 2 and 3 for the second digit (0) which results in 00000000000010100000000000000000
// we repeat this for each digit and in the end we get 00001010000000000000000100000100
// when converted to base 10 this would be 167772420
// now we can take the size of our subnet and add it to this number i.e. we want a /28 so lets add 16 to the number = 167772436
// now we can convert back to ip by reversing the process above and it results in 10.0.1.20
// once we apply the subnet mask this leaves us with 10.0.1.16 and now we have our new subnet!
func (s *SubnetManager) nextSubnet(subnet *net.IPNet) *net.IPNet {
	ipv4 := subnet.IP.To4()

	var ipv4UInt uint32
	for i := range 4 {
		ipv4UInt = ipv4UInt<<8 + uint32(ipv4[i])
	}

	networkBits, hostBits := s.NewSubnetMask.Size()
	subnetSize := 1 << (hostBits - networkBits)

	ipv4UInt += uint32(subnetSize)

	newIPAddress := make(net.IP, 4)
	for i := 3; i >= 0; i-- {
		newIPAddress[i] = byte(ipv4UInt & 0xFF)
		ipv4UInt >>= 8
	}

	return &net.IPNet{IP: newIPAddress, Mask: s.NewSubnetMask}
}

func (s *SubnetManager) nextNSubnets(subnet *net.IPNet, count int) ([]*net.IPNet, error) {
	var newSubnets []*net.IPNet

	firstSubnet := &net.IPNet{IP: subnet.IP, Mask: s.NewSubnetMask}

	for newSubnet := firstSubnet; s.RootNetwork.Contains(newSubnet.IP) && len(newSubnets) < count; newSubnet = s.nextSubnet(newSubnet) {
		newSubnets = append(newSubnets, newSubnet)
	}

	if len(newSubnets) != count {
		return newSubnets, ErrSubnetOutofRange
	}

	return newSubnets, nil
}

func GetNextFreeSubnet(rootCIDR string, existingCIDRs []string, subnetMaskSize int) (*net.IPNet, error) {
	networks := []*net.IPNet{}

	for _, existingCIDRs := range existingCIDRs {
		_, network, err := net.ParseCIDR(existingCIDRs)
		if err != nil {
			return nil, fmt.Errorf("unable to parse existing cidrs, %w", err)
		}

		networks = append(networks, network)
	}

	_, rootNetwork, err := net.ParseCIDR(rootCIDR)
	if err != nil {
		return nil, fmt.Errorf("unable to parse rootCIDR, %w", err)
	}

	ipam := &SubnetManager{
		RootNetwork:   rootNetwork,
		Subnets:       networks,
		NewSubnetMask: net.CIDRMask(subnetMaskSize, 32),
	}

	ipam.deduplicateSubnets()

	freeSubnet, err := ipam.walk(ipam.getFirstSubnet())
	if err != nil {
		return nil, err
	}

	return freeSubnet, nil
}

func SplitSubnet(cidr string, newMaskSize, count int) ([]string, error) {
	_, superNet, err := net.ParseCIDR(cidr)
	if err != nil {
		return nil, fmt.Errorf("unable to parse cidr, %w", err)
	}

	ipam := &SubnetManager{
		RootNetwork:   superNet,
		NewSubnetMask: net.CIDRMask(newMaskSize, 32),
	}

	newSubnets, err := ipam.nextNSubnets(ipam.getFirstSubnet(), count)
	if err != nil {
		return nil, err
	}

	cidrStrings := make([]string, len(newSubnets))
	for i := range newSubnets {
		cidrStrings[i] = newSubnets[i].String()
	}

	return cidrStrings, nil
}

func PulumiGetNextFreeSubnet(rootCIDR pulumi.StringInput, existingCIDRs pulumi.StringArrayInput, subnetMaskSize pulumi.IntInput) pulumi.StringOutput {
	freeSubnet := pulumix.Apply3Err(
		rootCIDR.ToStringOutput(),
		subnetMaskSize.ToIntOutput(),
		existingCIDRs.ToStringArrayOutput(),
		func(root string, size int, existing []string) (string, error) {
			freeSubnet, err := GetNextFreeSubnet(root, existing, size)
			if err != nil {
				return "", err
			}

			return freeSubnet.String(), nil
		},
	)

	return pulumix.Cast[pulumi.StringOutput](freeSubnet)
}

func PulumiSplitSubnet(cidr pulumi.StringInput, newMaskSize, count pulumi.IntInput) pulumi.StringArrayOutput {
	subnets, ok := pulumi.All(cidr, newMaskSize, count).ApplyT(func(all []any) ([]string, error) {
		cidr := all[0].(string)
		newMaskSize := all[1].(int)
		count := all[2].(int)

		s, err := SplitSubnet(cidr, newMaskSize, count)
		if err != nil {
			return nil, err
		}

		return s, nil
	}).(pulumi.StringArrayOutput)
	if !ok {
		panic("unable to convert subnets to array output")
	}

	return subnets
}
