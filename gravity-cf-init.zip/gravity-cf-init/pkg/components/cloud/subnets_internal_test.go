package cloud

import (
	"net"
	"reflect"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSubnetManager_walk(t *testing.T) {
	t.Parallel()

	type fields struct {
		RootNetwork   *net.IPNet
		Subnets       []*net.IPNet
		NewSubnetMask net.IPMask
	}

	type args struct {
		subnet *net.IPNet
	}

	type want struct {
		subnet *net.IPNet
		err    error
	}

	tests := []struct {
		name    string
		fields  fields
		args    args
		want    want
		wantErr bool
		focus   bool
	}{
		{
			name: "correctly grabs the right supernet when only one is used",
			fields: fields{
				RootNetwork: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(16, 32),
				},
				Subnets: []*net.IPNet{
					{
						IP:   net.ParseIP("10.0.0.0"),
						Mask: net.CIDRMask(26, 32),
					},
					{
						IP:   net.ParseIP("10.0.0.64"),
						Mask: net.CIDRMask(26, 32),
					},
					{
						IP:   net.ParseIP("10.0.0.128"),
						Mask: net.CIDRMask(26, 32),
					},
				},
				NewSubnetMask: net.CIDRMask(24, 32),
			},
			args: args{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			want: want{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.1.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			wantErr: false,
		},
		{
			name: "correctly grabs the right supernet when several are used",
			fields: fields{
				RootNetwork: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(16, 32),
				},
				Subnets: []*net.IPNet{
					{
						IP:   net.ParseIP("10.0.0.0"),
						Mask: net.CIDRMask(26, 32),
					},
					{
						IP:   net.ParseIP("10.0.1.64"),
						Mask: net.CIDRMask(26, 32),
					},
					{
						IP:   net.ParseIP("10.0.2.128"),
						Mask: net.CIDRMask(26, 32),
					},
				},
				NewSubnetMask: net.CIDRMask(24, 32),
			},
			args: args{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			want: want{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.3.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			wantErr: false,
		},
		{
			name: "correctly grabs the right supernet when a gap exists",
			fields: fields{
				RootNetwork: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(16, 32),
				},
				Subnets: []*net.IPNet{
					{
						IP:   net.ParseIP("10.0.0.0"),
						Mask: net.CIDRMask(26, 32),
					},
					{
						IP:   net.ParseIP("10.0.1.64"),
						Mask: net.CIDRMask(26, 32),
					},
					{
						IP:   net.ParseIP("10.0.4.128"),
						Mask: net.CIDRMask(26, 32),
					},
				},
				NewSubnetMask: net.CIDRMask(24, 32),
			},
			args: args{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			want: want{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.2.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			wantErr: false,
		},
		{
			name: "correctly rolls 3rd octet",
			fields: fields{
				RootNetwork: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(16, 32),
				},
				Subnets: []*net.IPNet{
					{
						IP:   net.ParseIP("10.0.0.0"),
						Mask: net.CIDRMask(25, 32),
					},
					{
						IP:   net.ParseIP("10.0.0.128"),
						Mask: net.CIDRMask(25, 32),
					},
					{
						IP:   net.ParseIP("10.0.1.0"),
						Mask: net.CIDRMask(25, 32),
					},
				},
				NewSubnetMask: net.CIDRMask(24, 32),
			},
			args: args{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			want: want{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.2.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			wantErr: false,
		},
		{
			name: "Breaks when Root CIDR is full",
			fields: fields{
				RootNetwork: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(23, 32),
				},
				Subnets: []*net.IPNet{
					{
						IP:   net.ParseIP("10.0.0.0"),
						Mask: net.CIDRMask(25, 32),
					},
					{
						IP:   net.ParseIP("10.0.0.128"),
						Mask: net.CIDRMask(25, 32),
					},
					{
						IP:   net.ParseIP("10.0.1.0"),
						Mask: net.CIDRMask(25, 32),
					},
				},
				NewSubnetMask: net.CIDRMask(24, 32),
			},
			want: want{
				err: ErrNoFreeSubnets,
			},
			args: args{
				subnet: &net.IPNet{
					IP:   net.ParseIP("10.0.0.0"),
					Mask: net.CIDRMask(24, 32),
				},
			},
			wantErr: true,
		},
	}

	focused := false

	for _, tt := range tests {
		if tt.focus {
			focused = true

			break
		}
	}

	for _, tt := range tests {
		if focused && !tt.focus {
			continue
		}

		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			s := &SubnetManager{
				RootNetwork:   tt.fields.RootNetwork,
				Subnets:       tt.fields.Subnets,
				NewSubnetMask: tt.fields.NewSubnetMask,
			}

			got, err := s.walk(tt.args.subnet)
			if (err != nil) != tt.wantErr {
				t.Errorf("IPAM.walk wantedError: %t, gotError: %s", tt.wantErr, err)

				return
			}

			if tt.wantErr {
				require.EqualError(t, err, tt.want.err.Error())
			}

			assert.Equal(t, tt.want.subnet.String(), got.String())
		})
	}
}

func TestSplitSubnet(t *testing.T) {
	t.Parallel()

	type args struct {
		cidr        string
		newMaskSize int
		count       int
	}

	tests := []struct {
		name string
		args args
		want []string
	}{
		{
			name: "given a /24 and want 3 /28s",
			args: args{
				cidr:        "10.0.0.10/24",
				newMaskSize: 28,
				count:       3,
			},
			want: []string{
				"10.0.0.0/28",
				"10.0.0.16/28",
				"10.0.0.32/28",
			},
		},
		{
			name: "given a /24 and want 3 /26s",
			args: args{
				cidr:        "10.0.0.0/24",
				newMaskSize: 26,
				count:       3,
			},
			want: []string{
				"10.0.0.0/26",
				"10.0.0.64/26",
				"10.0.0.128/26",
			},
		},
		{
			name: "given a /16 and want 3 /24s",
			args: args{
				cidr:        "10.0.0.0/16",
				newMaskSize: 24,
				count:       3,
			},
			want: []string{
				"10.0.0.0/24",
				"10.0.1.0/24",
				"10.0.2.0/24",
			},
		},
	}

	for _, tt := range tests {
		testCase := tt

		t.Run(testCase.name, func(t *testing.T) {
			t.Parallel()

			got, err := SplitSubnet(testCase.args.cidr, testCase.args.newMaskSize, testCase.args.count)
			require.NoError(t, err)

			if !reflect.DeepEqual(got, testCase.want) {
				t.Errorf("CarveSubnets() = %v, want %v", got, testCase.want)
			}
		})
	}
}
