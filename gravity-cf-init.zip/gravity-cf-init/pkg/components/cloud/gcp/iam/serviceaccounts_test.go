package iam_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/iam"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

func TestNewServiceAccount(t *testing.T) {
	t.Parallel()

	type want struct {
		SAProject  string
		IAMProject string
		Role       string
	}

	type args struct {
		args *iam.ServiceAccountArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should create service account and bind to a project",
			in: args{
				args: &iam.ServiceAccountArgs{
					AccountID:   "goodest-boy",
					Description: "the goodest boy that's ever lived",
					DisplayName: "Goodest Boy",
					Project:     "gcp-doggo-project",
					Role:        "admin",
				},
			},
			want: want{
				IAMProject: "gcp-doggo-project",
				SAProject:  "gcp-doggo-project",
				Role:       "admin",
			},
			wantErr: false,
		},
		{
			name: "test should create service account and bind to a project",
			in: args{
				args: &iam.ServiceAccountArgs{
					AccountID:   "pulumi-operator",
					Description: "service account for gitops",
					DisplayName: "Pulumi Operator",
					Project:     "il2-dev",
					Role:        "storageAdministrator",
				},
			},
			want: want{
				IAMProject: "il2-dev",
				SAProject:  "il2-dev",
				Role:       "storageAdministrator",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := iam.NewServiceAccount(ctx, "test", tt.in.args)
				if err != nil {
					return err
				}

				wanted := tt.want

				pulumi.All(got.Account.Project, got.IAMMember.Role, got.IAMMember.Project).ApplyT(func(all []interface{}) bool {
					saProject := all[0].(string)
					saRole := all[1].(string)
					saIAMProject := all[2].(string)

					assert.Equal(t, wanted.Role, saRole)
					assert.Equal(t, wanted.SAProject, saProject)
					assert.Equal(t, wanted.IAMProject, saIAMProject)
					assert.Nil(t, got.OrgBinding)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, testutils.GCPMocks(0)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestNewOrgServiceAccount(t *testing.T) {
	t.Parallel()

	type want struct {
		SAProject  string
		IAMProject string
		Role       string
	}

	type args struct {
		args *iam.ServiceAccountArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should create service account and bind to a project and org",
			in: args{
				args: &iam.ServiceAccountArgs{
					AccountID:   "goodest-boy",
					Description: "the goodest boy that's ever lived",
					DisplayName: "Goodest Boy",
					Project:     "gcp-doggo-project",
					Role:        "admin",
					OrgSA:       true,
				},
			},
			want: want{
				IAMProject: "gcp-doggo-project",
				SAProject:  "gcp-doggo-project",
				Role:       "admin",
			},
			wantErr: false,
		},
		{
			name: "test should create service account and bind to a project and org",
			in: args{
				args: &iam.ServiceAccountArgs{
					AccountID:   "pulumi-operator",
					Description: "service account for gitops",
					DisplayName: "Pulumi Operator",
					Project:     "il2-dev",
					Role:        "storageAdministrator",
					OrgSA:       true,
				},
			},
			want: want{
				IAMProject: "il2-dev",
				SAProject:  "il2-dev",
				Role:       "storageAdministrator",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := iam.NewServiceAccount(ctx, "test", tt.in.args)
				if err != nil {
					return err
				}

				wanted := &tt.want

				pulumi.All(got.Account.Project, got.IAMMember.Role, got.IAMMember.Project).ApplyT(func(all []interface{}) bool {
					saProject := all[0].(string)
					saRole := all[1].(string)
					saIAMProject := all[2].(string)

					assert.Equal(t, wanted.Role, saRole)
					assert.Equal(t, wanted.SAProject, saProject)
					assert.Equal(t, wanted.IAMProject, saIAMProject)
					assert.NotNil(t, got.OrgBinding)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, testutils.GCPMocks(0)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
