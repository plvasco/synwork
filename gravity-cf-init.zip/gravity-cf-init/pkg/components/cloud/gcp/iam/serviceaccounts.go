package iam

import (
	"fmt"

	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/organizations"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/projects"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/serviceaccount"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const serviceAccountComponentName = "gravity:gcp:serviceaccount"

type ServiceAccount struct {
	pulumi.ResourceState
	Account    *serviceaccount.Account
	IAMMember  *projects.IAMMember
	OrgBinding *organizations.IAMMember
}
type ServiceAccountArgs struct {
	AccountID   string
	Description string
	DisplayName string
	Project     string
	Role        string
	OrgSA       bool
	OrgID       string
}

func NewServiceAccount(ctx *pulumi.Context, name string, args *ServiceAccountArgs, opts ...pulumi.ResourceOption) (*ServiceAccount, error) {
	component := &ServiceAccount{}

	var err error

	if err := ctx.RegisterComponentResource(serviceAccountComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource %s, %w", name, err)
	}

	component.Account, err = component.createServiceAccount(ctx, name+"-sa", args)
	if err != nil {
		return nil, fmt.Errorf("unable to create service account, %w", err)
	}

	if err := component.createServiceAccountKey(ctx, name+"-key"); err != nil {
		return nil, fmt.Errorf("unable to create service account key, %w", err)
	}

	component.IAMMember, err = component.bindServiceAccountRoleToProject(ctx, name+"-binding", args)
	if err != nil {
		return nil, fmt.Errorf("unable to bind service account to project, %w", err)
	}

	if args.OrgSA {
		component.OrgBinding, err = component.bindServiceAccountToOrg(ctx, name+"-org-binding", args, component.Account)
		if err != nil {
			return nil, fmt.Errorf("unable to bind service account to organization, %w", err)
		}
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", serviceAccountComponentName, name, err)
	}

	return component, nil
}

func (c *ServiceAccount) createServiceAccount(ctx *pulumi.Context, name string, args *ServiceAccountArgs) (*serviceaccount.Account, error) {
	account, err := serviceaccount.NewAccount(ctx, name, &serviceaccount.AccountArgs{
		AccountId:   pulumi.String(args.AccountID),
		Description: pulumi.StringPtr(args.Description),
		DisplayName: pulumi.StringPtr(args.DisplayName),
		Project:     pulumi.StringPtr(args.Project),
	}, pulumi.Parent(c))
	if err != nil {
		return nil, fmt.Errorf("unable to create new service account %s, %w", name, err)
	}

	return account, nil
}

func (c *ServiceAccount) bindServiceAccountRoleToProject(ctx *pulumi.Context, name string, args *ServiceAccountArgs) (*projects.IAMMember, error) {
	member, err := projects.NewIAMMember(ctx, name, &projects.IAMMemberArgs{
		Member:  c.Account.Member,
		Project: pulumi.String(args.Project),
		Role:    pulumi.String(args.Role),
	}, pulumi.Parent(c))
	if err != nil {
		return nil, fmt.Errorf("unable to create IAM member '%s' for project '%s' with role '%s', %w", args.DisplayName, args.Project, args.Role, err)
	}

	return member, nil
}

func (c *ServiceAccount) bindServiceAccountToOrg(ctx *pulumi.Context, name string, args *ServiceAccountArgs, account *serviceaccount.Account) (*organizations.IAMMember, error) {
	binding, err := organizations.NewIAMMember(ctx, name, &organizations.IAMMemberArgs{
		Member: pulumi.Sprintf("serviceAccount:%s", account.Email),
		OrgId:  pulumi.String(args.OrgID),
		Role:   pulumi.String(args.Role),
	}, pulumi.Parent(c))
	if err != nil {
		return nil, fmt.Errorf("unable to create IAM member '%s' for org '%s' with role '%s', %w", args.DisplayName, args.OrgID, args.Role, err)
	}

	return binding, nil
}

func (c *ServiceAccount) createServiceAccountKey(ctx *pulumi.Context, name string) error {
	key, err := serviceaccount.NewKey(ctx, name, &serviceaccount.KeyArgs{
		ServiceAccountId: c.Account.Name,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create service account key, %w", err)
	}

	ctx.Export("serviceAccountKey", pulumi.ToSecret(key.PrivateKey))

	return nil
}
