package rbac_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/rbac"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewWorkforce(t *testing.T) {
	t.Parallel()

	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		workforce, err := rbac.NewWorkforce(ctx, "test", &rbac.WorkforceArgs{
			OrgID:        "123456789",
			ClientID:     "test_clientID",
			ClientSecret: "supersecrettestsecret",
			IssuerURI:    "https://test-issuer.mil/auth/realms/testrealm",
		})
		require.NoError(t, err)

		workforce.Pool.Location.ApplyT(func(location string) error {
			assert.Equal(t, "global", location)

			return nil
		})

		workforce.Pool.WorkforcePoolId.ApplyT(func(id string) error {
			assert.Equal(t, "test-pool", id)

			return nil
		})

		workforce.Provider.ProviderId.ApplyT(func(id string) error {
			assert.Equal(t, "test-pool-provider", id)

			return nil
		})

		workforce.Provider.Location.ApplyT(func(location string) error {
			assert.Equal(t, "global", location)

			return nil
		})

		workforce.Provider.Oidc.Elem().IssuerUri().ApplyT(func(issuer string) error {
			assert.Equal(t, "https://test-issuer.mil/auth/realms/testrealm", issuer)

			return nil
		})

		workforce.Provider.Oidc.Elem().ClientId().ApplyT(func(id string) error {
			assert.Equal(t, "test_clientID", id)

			return nil
		})

		return nil
	}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))

	require.NoError(t, err)
}
