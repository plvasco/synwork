package rbac_test

import (
	"sync"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/rbac"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

func TestNewFolderRoleBinding(t *testing.T) {
	t.Parallel()

	type want struct {
		ResultName string
		Folder     string
		Members    []string
		Role       string
	}

	type args struct {
		args *rbac.RoleBindingsArgs
	}

	tests := []struct {
		name    string
		in      args
		want    []want
		wantErr bool
	}{
		{
			name: "test should map folder roles",
			in: args{
				args: &rbac.RoleBindingsArgs{
					FolderRoleMapping: []rbac.FolderRoleMap{
						{
							Folder: "test1",
							Groups: []string{
								"Admin1",
								"ReadOnly1",
							}},
						{
							Folder: "test2",
							Groups: []string{
								"Admin2",
								"ReadOnly2",
							}},
						{
							Folder: "test3",
							Groups: []string{
								"Admin3",
								"ReadOnly3",
							}},
					},
					UserRoleMap: []rbac.UserRoleMap{
						{
							Email: "goodest.boy@test.com",
							CustomGroups: []string{
								"Admin1",
								"Admin2",
								"Admin3",
							},
						},
						{
							Email: "air.power@test.com",
							CustomGroups: []string{
								"Admin1",
								"ReadOnly2",
							},
						},
						{
							Email: "johnny.begood@test.com",
							CustomGroups: []string{
								"ReadOnly1",
								"ReadOnly2",
							},
						},
					},
					OrgID: "123456789",
				},
			},
			want: []want{
				{
					ResultName: "test1-Admin1",
					Folder:     "test1",
					Members: []string{
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/goodest.boy",
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/air.power",
					},
					Role: "organizations/123456789/roles/Admin1",
				},
				{
					ResultName: "test1-ReadOnly1",
					Folder:     "test1",
					Members: []string{
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/johnny.begood",
					},
					Role: "organizations/123456789/roles/ReadOnly1",
				},
				{
					ResultName: "test2-Admin2",
					Folder:     "test2",
					Members: []string{
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/goodest.boy",
					},
					Role: "organizations/123456789/roles/Admin2",
				},
				{
					ResultName: "test2-ReadOnly2",
					Folder:     "test2",
					Members: []string{
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/air.power",
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/johnny.begood",
					},
					Role: "organizations/123456789/roles/ReadOnly2",
				},
				{
					ResultName: "test3-Admin3",
					Folder:     "test3",
					Members: []string{
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/goodest.boy",
					},
					Role: "organizations/123456789/roles/Admin3",
				},
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				var wg sync.WaitGroup

				got, err := rbac.NewRoleBindings(ctx, "test", tt.in.args)
				if err != nil {
					return err
				}

				for _, want := range tt.want {
					wanted := want //capture current want inside goroutine

					wg.Add(1)

					folderBindings := got.FolderBindings[want.ResultName]

					pulumi.All(folderBindings.Role, folderBindings.Members, folderBindings.Folder).ApplyT(func(all []interface{}) bool {
						role := all[0].(string)
						members := all[1].([]string)
						folder := all[2].(string)

						assert.Equal(t, wanted.Role, role, "ResultName: %s", wanted.ResultName)
						assert.Equal(t, wanted.Members, members, "ResultName: %s", wanted.ResultName)
						assert.Equal(t, wanted.Folder, folder, "ResultName: %s", wanted.ResultName)
						wg.Done()

						return true
					})
				}

				wg.Wait()

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, testutils.GCPMocks(0)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestNewOrgRoleBinding(t *testing.T) {
	t.Parallel()

	type want struct {
		Members []string
		Role    string
	}

	type args struct {
		args *rbac.RoleBindingsArgs
	}

	tests := []struct {
		name    string
		in      args
		want    []want
		wantErr bool
	}{
		{
			name: "test should map org roles",
			in: args{
				args: &rbac.RoleBindingsArgs{
					UserRoleMap: []rbac.UserRoleMap{
						{
							Email: "goodest.boy@test.com",
							CustomGroups: []string{
								"Admin1",
								"Admin2",
								"Admin3",
							},
							OrgGroups: []string{
								"Viewer",
							},
						},
						{
							Email: "air.power@test.com",
							CustomGroups: []string{
								"Admin1",
								"ReadOnly2",
							},
							OrgGroups: []string{
								"Viewer",
							},
						},
						{
							Email: "johnny.begood@test.com",
							CustomGroups: []string{
								"ReadOnly1",
								"ReadOnly2",
							},
							OrgGroups: []string{
								"Owner",
							},
						},
					},
					OrgID: "123456789",
				},
			},
			want: []want{
				{
					Members: []string{
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/goodest.boy",
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/air.power",
					},
					Role: "roles/Viewer",
				},
				{
					Members: []string{
						"principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/johnny.begood",
					},
					Role: "roles/Owner",
				},
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				var wg sync.WaitGroup

				got, err := rbac.NewRoleBindings(ctx, "test", tt.in.args)
				if err != nil {
					return err
				}

				for _, want := range tt.want {
					wanted := want //capture current want inside goroutine

					wg.Add(1)

					orgBindings := got.OrgBindings[want.Role]

					pulumi.All(orgBindings.Role, orgBindings.Members).ApplyT(func(all []interface{}) bool {
						role := all[0].(string)
						members := all[1].([]string)

						assert.Equal(t, wanted.Role, role)
						assert.Equal(t, wanted.Members, members)
						wg.Done()

						return true
					})
				}

				wg.Wait()

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, testutils.GCPMocks(0)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
