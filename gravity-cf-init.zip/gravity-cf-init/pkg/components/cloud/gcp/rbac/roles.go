package rbac

import (
	"fmt"

	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/organizations"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const rolesComponentName = "gravity:gcp:roles"

type Roles struct {
	pulumi.ResourceState
	Roles []*organizations.IAMCustomRole
}

type RolesArgs struct {
	OrgID            string
	ComplianceLevels []string
}

func NewCustomRoles(ctx *pulumi.Context, name string, args *RolesArgs, opts ...pulumi.ResourceOption) (*Roles, error) {
	component := &Roles{}

	if err := ctx.RegisterComponentResource(rolesComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource %s, %w", name, err)
	}

	if err := component.createAdminRoles(ctx, name, args); err != nil {
		return nil, fmt.Errorf("unable to create adminRoles, %w", err)
	}

	if err := component.createReadOnlyRoles(ctx, name, args); err != nil {
		return nil, fmt.Errorf("unable to create readOnlyRoles, %w", err)
	}

	if err := component.createCustomRole(ctx, "pulumiOperator", "Pulumi Operator", getOperatorPermissions(), args); err != nil {
		return nil, fmt.Errorf("unable to create pulumi operator role, %w", err)
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", rolesComponentName, name, err)
	}

	return component, nil
}

func (c *Roles) createAdminRoles(ctx *pulumi.Context, name string, args *RolesArgs) error {
	var roleName = "AssuredWorkloadAdministrator"

	adminRoles, err := c.createAWRole(ctx, name+"-admin", &roleArgs{
		Name:             roleName,
		Permissions:      getAwAdminPermissions(),
		ComplianceLevels: args.ComplianceLevels,
		OrgID:            args.OrgID,
	})
	if err != nil {
		return fmt.Errorf("unable to create and assign custom roles, %w", err)
	}

	c.Roles = append(c.Roles, adminRoles...)

	return nil
}

func (c *Roles) createReadOnlyRoles(ctx *pulumi.Context, name string, args *RolesArgs) error {
	roleName := "AssuredWorkloadReadOnly"

	readOnlyRoles, err := c.createAWRole(ctx, name+"-readonly", &roleArgs{
		Name:             roleName,
		Permissions:      getAwRoPermissions(),
		ComplianceLevels: args.ComplianceLevels,
		OrgID:            args.OrgID,
	})
	if err != nil {
		return fmt.Errorf("unable to create and assign custom roles, %w", err)
	}

	c.Roles = append(c.Roles, readOnlyRoles...)

	return nil
}

func (c *Roles) createCustomRole(ctx *pulumi.Context, name, title string, permissions []string, args *RolesArgs) error {
	_, err := organizations.NewIAMCustomRole(ctx, name, &organizations.IAMCustomRoleArgs{
		OrgId:       pulumi.String(args.OrgID),
		Permissions: pulumi.ToStringArray(permissions),
		RoleId:      pulumi.String(name),
		Title:       pulumi.String(title),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create custom role '%s', %w", name, err)
	}

	return nil
}

type roleArgs struct {
	Name             string
	Permissions      []string
	ComplianceLevels []string
	OrgID            string
}

func (c *Roles) createAWRole(ctx *pulumi.Context, name string, args *roleArgs) ([]*organizations.IAMCustomRole, error) {
	roles := []*organizations.IAMCustomRole{}

	for _, level := range args.ComplianceLevels {
		role, err := organizations.NewIAMCustomRole(ctx, fmt.Sprintf("%s-%s", name, level), &organizations.IAMCustomRoleArgs{
			OrgId:       pulumi.String(args.OrgID),
			Permissions: pulumi.ToStringArray(args.Permissions),
			RoleId:      pulumi.String(level + args.Name),
			Title:       pulumi.String(level + args.Name),
		}, pulumi.Parent(c))
		if err != nil {
			return nil, fmt.Errorf("unable to create %s custom role, %w", level, err)
		}

		roles = append(roles, role)
	}

	return roles, nil
}
