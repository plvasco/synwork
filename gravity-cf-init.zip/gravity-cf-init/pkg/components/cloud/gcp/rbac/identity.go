package rbac

import (
	"fmt"

	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/iam"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const workforceComponentName = "gravity:gcp:workforce"

type Workforce struct {
	pulumi.ResourceState
	Pool     *iam.WorkforcePool
	Provider *iam.WorkforcePoolProvider
}
type WorkforceArgs struct {
	OrgID        string
	ClientID     string
	ClientSecret string
	IssuerURI    string
}

func NewWorkforce(ctx *pulumi.Context, name string, args *WorkforceArgs, opts ...pulumi.ResourceOption) (*Workforce, error) {
	component := &Workforce{}

	if err := ctx.RegisterComponentResource(workforceComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource %s, %w", name, err)
	}

	if err := component.createWorkforcePool(ctx, name+"-pool", args); err != nil {
		return nil, err
	}

	if err := component.createWorkforcePoolProvider(ctx, name+"-pool-provider", args); err != nil {
		return nil, err
	}

	return component, nil
}

func (c *Workforce) createWorkforcePool(ctx *pulumi.Context, name string, args *WorkforceArgs) error {
	pool, err := iam.NewWorkforcePool(ctx, name, &iam.WorkforcePoolArgs{
		Location:        pulumi.String("global"),
		Parent:          pulumi.Sprintf("organizations/%s", args.OrgID),
		SessionDuration: pulumi.String("7200s"), // 2 hours
		WorkforcePoolId: pulumi.String(name),
		Disabled:        pulumi.Bool(false),
		DisplayName:     pulumi.String(name),
	}, pulumi.Parent(c))

	if err != nil {
		return fmt.Errorf("unable to create workforce pool, %w", err)
	}

	c.Pool = pool

	return nil
}

func (c *Workforce) createWorkforcePoolProvider(ctx *pulumi.Context, name string, args *WorkforceArgs) error {
	poolProvider, err := iam.NewWorkforcePoolProvider(ctx, name, &iam.WorkforcePoolProviderArgs{
		AttributeMapping: pulumi.StringMap{
			"google.subject":         pulumi.String("assertion.email.split('@')[0]"),
			"google.display_name":    pulumi.String("assertion.email"),
			"attribute.keycloak_sub": pulumi.String("assertion.sub"),
		},
		AttributeCondition: pulumi.String("assertion.groups.exists(g, matches(g, r'.*/Gamewarden/employee.*'))"),
		Disabled:           c.Pool.Disabled,
		DisplayName:        pulumi.String(name),
		Location:           c.Pool.Location,
		Oidc: &iam.WorkforcePoolProviderOidcArgs{
			ClientId: pulumi.String(args.ClientID),
			ClientSecret: &iam.WorkforcePoolProviderOidcClientSecretArgs{
				Value: &iam.WorkforcePoolProviderOidcClientSecretValueArgs{
					PlainText: pulumi.String(args.ClientSecret),
				},
			},
			IssuerUri: pulumi.String(args.IssuerURI),
			WebSsoConfig: &iam.WorkforcePoolProviderOidcWebSsoConfigArgs{
				AssertionClaimsBehavior: pulumi.String("ONLY_ID_TOKEN_CLAIMS"),
				ResponseType:            pulumi.String("CODE"),
			},
		},
		ProviderId:      pulumi.String(name),
		WorkforcePoolId: c.Pool.WorkforcePoolId,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create workforce pool provider, %w", err)
	}

	c.Provider = poolProvider

	return nil
}
