package rbac_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/rbac"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewCustomRoles(t *testing.T) {
	t.Parallel()

	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		roles, err := rbac.NewCustomRoles(ctx, "test", &rbac.RolesArgs{
			OrgID: "123456789",
			ComplianceLevels: []string{
				"IL2",
				"IL4",
				"IL5",
			},
		})
		require.NoError(t, err)

		var testRole = roles.Roles

		testRole[0].Title.ApplyT(func(title string) error {
			assert.Equal(t, "IL2AssuredWorkloadAdministrator", title)

			return nil
		})

		testRole[1].Title.ApplyT(func(title string) error {
			assert.Equal(t, "IL4AssuredWorkloadAdministrator", title)

			return nil
		})

		testRole[2].Title.ApplyT(func(title string) error {
			assert.Equal(t, "IL5AssuredWorkloadAdministrator", title)

			return nil
		})

		testRole[2].Permissions.ApplyT(func(perms []string) error {
			assert.Contains(t, perms, "assuredworkloads.workload.create")

			return nil
		})

		testRole[3].Title.ApplyT(func(title string) error {
			assert.Equal(t, "IL2AssuredWorkloadReadOnly", title)

			return nil
		})

		testRole[4].Title.ApplyT(func(title string) error {
			assert.Equal(t, "IL4AssuredWorkloadReadOnly", title)

			return nil
		})

		testRole[5].Title.ApplyT(func(title string) error {
			assert.Equal(t, "IL5AssuredWorkloadReadOnly", title)

			return nil
		})

		testRole[4].Permissions.ApplyT(func(perms []string) error {
			assert.NotContains(t, perms, "assuredworkloads.workload.create")

			return nil
		})

		return nil
	}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))

	require.NoError(t, err)
}
