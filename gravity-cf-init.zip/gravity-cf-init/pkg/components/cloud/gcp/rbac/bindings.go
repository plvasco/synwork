package rbac

import (
	"fmt"
	"strings"

	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/folder"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/organizations"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const (
	bindingsComponentName = "gravity:gcp:rolebindings"
	providerPrefix        = "principal://iam.googleapis.com/locations/global/workforcePools/secondfront-pool/subject/"
)

type RoleBindings struct {
	pulumi.ResourceState
	FolderBindings map[string]*folder.IAMBinding
	OrgBindings    map[string]*organizations.IAMBinding
}

type RoleBindingsArgs struct {
	UserRoleMap       []UserRoleMap
	FolderRoleMapping []FolderRoleMap
	OrgID             string
}

type UserRoleMap struct {
	Email        string
	CustomGroups []string
	OrgGroups    []string
}

type FolderRoleMap struct {
	Folder string
	Groups []string
}

func NewRoleBindings(ctx *pulumi.Context, name string, args *RoleBindingsArgs, opts ...pulumi.ResourceOption) (*RoleBindings, error) {
	component := &RoleBindings{}

	if err := ctx.RegisterComponentResource(bindingsComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource %s, %w", name, err)
	}

	if err := component.createIAMBindings(ctx, name+"-bindings", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", bindingsComponentName, name, err)
	}

	return component, nil
}

func (c *RoleBindings) createIAMBindings(ctx *pulumi.Context, name string, args *RoleBindingsArgs) error {
	customRoleMappings := c.getCustomRoleMappings(args)
	orgRoleMappings := c.getOrgRoleMappings(args)
	folderMappings := c.getFolderMappings(args)

	folderBindings := map[string]*folder.IAMBinding{}
	orgBindings := map[string]*organizations.IAMBinding{}

	for role, users := range customRoleMappings {
		for _, folderName := range folderMappings[role] {
			parentOrg := "organizations/" + args.OrgID

			folderResult, err := organizations.GetActiveFolder(ctx, &organizations.GetActiveFolderArgs{
				DisplayName: folderName,
				Parent:      parentOrg,
			})

			if err != nil {
				return fmt.Errorf("folder %s not found, %w", folderName, err)
			}

			roleParts := strings.Split(role, "/")
			bindingName := fmt.Sprintf("%s-%s", folderResult.DisplayName, roleParts[len(roleParts)-1])

			binding, err := folder.NewIAMBinding(ctx, fmt.Sprintf("%s-%s", name, bindingName), &folder.IAMBindingArgs{
				Folder:  pulumi.String(folderResult.Id),
				Members: pulumi.ToStringArray(users),
				Role:    pulumi.String(role),
			}, pulumi.Parent(c))
			if err != nil {
				return fmt.Errorf("unable to create IAM binding for %s on folder %s, %w", role, folderResult.DisplayName, err)
			}

			folderBindings[bindingName] = binding
		}
	}

	for role, users := range orgRoleMappings {
		binding, err := organizations.NewIAMBinding(ctx, fmt.Sprintf("%s-%s", name, role), &organizations.IAMBindingArgs{
			Members: pulumi.ToStringArray(users),
			OrgId:   pulumi.String(args.OrgID),
			Role:    pulumi.String(role),
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create org IAM binding for %s, %w", role, err)
		}

		orgBindings[role] = binding
	}

	c.FolderBindings = folderBindings
	c.OrgBindings = orgBindings

	return nil
}

func (c *RoleBindings) getCustomRoleMappings(args *RoleBindingsArgs) map[string][]string {
	roleMappings := map[string][]string{}

	for _, userMap := range args.UserRoleMap {
		for _, role := range userMap.CustomGroups {
			subjectName := strings.Split(userMap.Email, "@")[0]
			roleID := fmt.Sprintf("organizations/%s/roles/%s", args.OrgID, role)
			principal := providerPrefix + subjectName
			roleMappings[roleID] = append(roleMappings[roleID], principal)
		}
	}

	return roleMappings
}

func (c *RoleBindings) getOrgRoleMappings(args *RoleBindingsArgs) map[string][]string {
	roleMappings := map[string][]string{}

	for _, userMap := range args.UserRoleMap {
		for _, role := range userMap.OrgGroups {
			subjectName := strings.Split(userMap.Email, "@")[0]
			roleID := "roles/" + role
			principal := providerPrefix + subjectName
			roleMappings[roleID] = append(roleMappings[roleID], principal)
		}
	}

	return roleMappings
}

func (c *RoleBindings) getFolderMappings(args *RoleBindingsArgs) map[string][]string {
	folderMappings := map[string][]string{}

	for _, folderMap := range args.FolderRoleMapping {
		for _, role := range folderMap.Groups {
			roleID := fmt.Sprintf("organizations/%s/roles/%s", args.OrgID, role)
			folderMappings[roleID] = append(folderMappings[roleID], folderMap.Folder)
		}
	}

	return folderMappings
}
