package base_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/base"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewAPIServices(t *testing.T) {
	t.Parallel()

	type want struct {
		services []string
	}

	type args struct {
		name string
		args *base.APIServicesArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test api enable services",
			in: args{
				name: "test-api",
				args: &base.APIServicesArgs{
					ProjectID: pulumi.String("test-proj"),
					Services: []pulumi.StringInput{
						pulumi.String("x10d"),
						pulumi.String("mynamajeff"),
					},
				},
			},
			want: want{
				services: []string{
					"mynamajeff",
					"x10d",
				},
			},
			wantErr: false,
		},
		{
			name: "test should fail no projectID",
			in: args{
				name: "test-api",
				args: &base.APIServicesArgs{
					Services: []pulumi.StringInput{
						pulumi.String("x10d"),
						pulumi.String("mynamajeff"),
					},
				},
			},
			wantErr: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := base.NewAPIServices(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				for _, service := range got.Services {
					service.ToServiceOutput().Service().ApplyT(func(serviceStr string) bool {
						assert.Contains(t, tc.want.services, serviceStr)

						return true
					})
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.GCPMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewAPIServices() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestAPIServicesArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *base.APIServicesArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"projectID": "project-123",
				"services": ["service-1", "service-2"]
			}`,
			want: &base.APIServicesArgs{
				ProjectID: pulumi.String("project-123"),
				Services: pulumi.StringArray{
					pulumi.String("service-1"),
					pulumi.String("service-2"),
				},
			},
			wantErr: false,
		},
		{
			name:    "malformed JSON with incorrect type",
			input:   `{"projectID": 123, "services": "service-1"}`, // projectID should be a string, and services should be an array
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args base.APIServicesArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
