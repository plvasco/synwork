package base

import (
	"fmt"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"

	"github.com/pulumi/pulumi-gcp/sdk/v7/go/gcp/compute"
	"github.com/pulumi/pulumi-gcp/sdk/v7/go/gcp/organizations"
	"github.com/pulumi/pulumi-gcp/sdk/v7/go/gcp/projects"
	"github.com/pulumi/pulumi-gcp/sdk/v7/go/gcp/storage"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const baseComponentName = "gravity:gcp:base"

type Base struct {
	pulumi.ResourceState
	APIServices      *APIServices           `pulumi:"apiServices"`
	BucketName       pulumi.StringOutput    `pulumi:"bucketName"`
	DefaultKeyID     pulumi.IDOutput        `pulumi:"defaultKeyID"`
	DefaultKeyRingID pulumi.IDOutput        `pulumi:"defaultKeyRingID"`
	KMS              *KMS                   `pulumi:"kms"`
	Logging          *Logging               `pulumi:"logging"`
	HostProjectID    pulumi.StringOutput    `pulumi:"hostProjectID"`
	Project          *organizations.Project `pulumi:"project"`
	ProjectID        pulumi.StringOutput    `pulumi:"projectID"`
	RootCIDR         pulumi.StringPtrOutput `pulumi:"rootCIDR"`
	Subnets          pulumi.MapOutput       `pulumi:"subnets"`
}

//nolint:revive // using common naming convention
type BaseArgs struct {
	Customer        pulumi.StringInput `pulumi:"customer"        validate:"required"`
	ComplianceLevel pulumi.StringInput `pulumi:"complianceLevel" validate:"required"`
	Environment     pulumi.StringInput `pulumi:"environment"     validate:"required"`
	Location        pulumi.StringInput `pulumi:"location"        validate:"required"`
	BillingAccount  pulumi.StringInput `pulumi:"billingAccount"  validate:"required"`
	AdditionalAPIs  pulumi.StringArray `pulumi:"additionalAPIs"`
	IsHostProject   pulumi.Bool        `pulumi:"isHostProject"`
	LoggingConfig   *LoggingArgs       `pulumi:"loggingConfig"`
	SlackAuthToken  pulumi.StringInput `pulumi:"slackAuthToken"`
	Tags            pulumi.StringMap   `pulumi:"tags"`
	Workload        pulumi.StringInput `pulumi:"workload"`
}

func NewBase(ctx *pulumi.Context, args *BaseArgs, opts ...pulumi.ResourceOption) (*Base, error) {
	if err := args.validate(); err != nil {
		return nil, err
	}

	component := &Base{}

	name := fmt.Sprintf("%s-%s-%s", args.ComplianceLevel, args.Environment, args.Customer)

	if err := ctx.RegisterComponentResource(baseComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", baseComponentName, name, err)
	}

	if err := component.createNewProject(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createAPIServices(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createSharedVPCProject(ctx, name, args); err != nil {
		return nil, err
	}

	// if err := component.createLogging(ctx, name, args); err != nil {
	// 	return nil, err
	// }

	if err := component.createKMS(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createStorageBucket(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"defaultKeyRingID": component.DefaultKeyRingID,
		"defaultKeyID":     component.DefaultKeyID,
		"bucketName":       component.BucketName,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", baseComponentName, name, err)
	}

	return component, nil
}

func (c *Base) createNewProject(ctx *pulumi.Context, name string, args *BaseArgs) error {
	folder := organizations.GetActiveFolderOutput(ctx, organizations.GetActiveFolderOutputArgs{
		DisplayName: args.Workload,
		Parent:      pulumi.String("organizations/903018176368"),
	}, pulumi.Parent(c))

	project, err := organizations.NewProject(ctx, name, &organizations.ProjectArgs{
		FolderId:          folder.Id(),
		Labels:            args.Tags,
		AutoCreateNetwork: pulumi.Bool(false),
		BillingAccount:    args.BillingAccount,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to get create new gcp project, %w", err)
	}

	c.Project = project
	c.ProjectID = project.ProjectId

	return nil
}

func (c *Base) createAPIServices(ctx *pulumi.Context, name string, args *BaseArgs) error {
	services := pulumi.ToStringArray([]string{
		"container.googleapis.com",
		"compute.googleapis.com",
		"cloudkms.googleapis.com",
		"storage.googleapis.com",
		"networkconnectivity.googleapis.com",
		"servicenetworking.googleapis.com",
		"containersecurity.googleapis.com",
	})

	services = append(services, args.AdditionalAPIs...)

	apiServices, err := NewAPIServices(ctx, name, &APIServicesArgs{
		ProjectID: c.ProjectID,
		Services:  services,
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	c.APIServices = apiServices

	return nil
}

func (c *Base) createSharedVPCProject(ctx *pulumi.Context, name string, args *BaseArgs) error {
	if args.IsHostProject {
		if err := c.createSharedVPCHost(ctx, name); err != nil {
			return err
		}

		return nil
	}

	if err := c.createSharedVPCService(ctx, name, args); err != nil {
		return err
	}

	return nil
}

func (c *Base) createSharedVPCHost(ctx *pulumi.Context, name string) error {
	_, err := compute.NewSharedVPCHostProject(ctx, name, &compute.SharedVPCHostProjectArgs{
		Project: c.Project.ProjectId,
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{c.APIServices}))
	if err != nil {
		return fmt.Errorf("unable to create sharedHostProject, %w", err)
	}

	return nil
}

func (c *Base) createSharedVPCService(ctx *pulumi.Context, name string, args *BaseArgs) error {
	projectID := projects.GetProjectOutput(ctx, projects.GetProjectOutputArgs{
		Filter: pulumi.Sprintf("name:%s-prd-networking", args.ComplianceLevel),
	}, pulumi.Parent(c))

	sharedVPC, err := compute.NewSharedVPCServiceProject(ctx, name, &compute.SharedVPCServiceProjectArgs{
		HostProject:    projectID.Projects().Index(pulumi.Int(0)).ProjectId(),
		ServiceProject: c.Project.ProjectId,
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{c.APIServices}))
	if err != nil {
		return fmt.Errorf("unable to create sharedVPCServiceProject, %w", err)
	}

	c.HostProjectID = sharedVPC.HostProject

	return nil
}

func (c *Base) createKMS(ctx *pulumi.Context, name string, args *BaseArgs) error {
	kms, err := NewKMS(ctx, name, &KMSArgs{
		ProjectNumber: c.Project.Number,
		ProjectName:   c.Project.ProjectId,
		Location:      args.Location,
		Tags:          args.Tags,
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{c.APIServices}))

	if err != nil {
		return err
	}

	c.DefaultKeyRingID = kms.DefaultKeyRingID
	c.DefaultKeyID = kms.DefaultKeyID
	c.KMS = kms

	return nil
}

func (c *Base) createStorageBucket(ctx *pulumi.Context, name string, args *BaseArgs) error {
	bucket, err := storage.NewBucket(ctx, name+"-state", &storage.BucketArgs{
		Encryption:               &storage.BucketEncryptionArgs{DefaultKmsKeyName: c.DefaultKeyID},
		Location:                 args.Location,
		Name:                     pulumi.Sprintf("gamewarden-infrastructure-state-%s", name),
		Project:                  c.Project.ProjectId,
		UniformBucketLevelAccess: pulumi.Bool(true),
		ForceDestroy:             pulumi.Bool(true),
		Versioning:               &storage.BucketVersioningArgs{Enabled: pulumi.Bool(true)},
		Labels:                   args.Tags,
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{c.KMS}))
	if err != nil {
		return fmt.Errorf("error creating base infra bucket %s, %w", name, err)
	}

	c.BucketName = bucket.Name

	return nil
}

func (c *Base) createLogging(ctx *pulumi.Context, name string, args *BaseArgs) error {
	logging, err := NewLogging(ctx, name, &LoggingArgs{
		ProjectID:      c.ProjectID,
		SlackAuthToken: args.SlackAuthToken,
	}, pulumi.Parent(c))
	if err != nil {
		return err
	}

	c.Logging = logging

	return nil
}

func (args *BaseArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	args.setDefaultTags()

	return nil
}

func (args *BaseArgs) setDefaultTags() {
	if args.Tags == nil {
		args.Tags = pulumi.StringMap{}
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["compliancelevel"] = args.ComplianceLevel
	}

	if _, ok := args.Tags["environment"]; !ok {
		args.Tags["environment"] = args.Environment
	}

	if _, ok := args.Tags["customer"]; !ok {
		args.Tags["customer"] = args.Customer
	}

	for k, v := range args.Tags {
		args.Tags[strings.ToLower(k)] = v
	}
}

func (args *BaseArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
