package base

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-gcp/sdk/v7/go/gcp/logging"
	"github.com/pulumi/pulumi-gcp/sdk/v7/go/gcp/monitoring"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const loggingComponentName = "gravity:gcp:logging"

var (
	ErrNoMetricResourceMappingFound = errors.New("no resource type mapping found for metric")
)

type Logging struct {
	pulumi.ResourceState
	Metrics               map[string]*logging.Metric
	BucketConfig          *logging.ProjectBucketConfig
	AlertPolicies         map[string]*monitoring.AlertPolicy
	NotificationChannelID pulumi.StringOutput
}

type LoggingArgs struct {
	ProjectID        pulumi.StringInput `pulumi:"projectID"        validate:"required"`
	SlackAuthToken   pulumi.StringInput `pulumi:"slackAuthToken"`
	SlackChannelName pulumi.StringInput `pulumi:"slackChannelName" validate:"default=#soc"`
	SlackChannelTeam pulumi.StringInput `pulumi:"slackChannelTeam" validate:"default=Second Front Systems"`
}

func NewLogging(ctx *pulumi.Context, name string, args *LoggingArgs, opts ...pulumi.ResourceOption) (*Logging, error) {
	if err := args.validate(); err != nil {
		return nil, err
	}

	component := &Logging{}

	if err := ctx.RegisterComponentResource(loggingComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", loggingComponentName, name, err)
	}

	if err := component.createLoggingMetrics(ctx, name+"-metric", args); err != nil {
		return nil, err
	}

	if err := component.createLogRetention(ctx, name+"-retention", args); err != nil {
		return nil, err
	}

	if err := component.createAlertPolicy(ctx, name+"-alert-policy", args); err != nil {
		return nil, err
	}

	if args.SlackAuthToken != nil {
		if err := component.createNotificationChannel(ctx, name+"-notify", args); err != nil {
			return nil, err
		}
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", loggingComponentName, name, err)
	}

	return component, nil
}

func (c *Logging) createLoggingMetrics(ctx *pulumi.Context, name string, args *LoggingArgs) error {
	metrics := map[string]*logging.Metric{}

	metricArgs := map[string]struct {
		Filter      pulumi.String
		DisplayName pulumi.String
	}{
		"sql_instance_configuration_changes": {
			Filter: pulumi.String(`resource.type="cloudsql_database"
			AND protoPayload.methodName="cloudsql.instances.update"`),
			DisplayName: pulumi.String("SQL Instance Configuration Changes"),
		},
		"cloud_storage_iam_permission_changes": {
			Filter: pulumi.String(`resource.type=gcs_bucket
			AND protoPayload.methodName="storage.setIamPermissions"`),
			DisplayName: pulumi.String("Cloud Storage IAM Permission Changes"),
		},
		"vpc_network_changes": {
			Filter: pulumi.String(`resource.type="gce_network"
			AND protoPayload.methodName:"compute.networks.insert"
			OR protoPayload.methodName:"compute.networks.patch"
			OR protoPayload.methodName:"compute.networks.delete"
			OR protoPayload.methodName:"compute.networks.addPeering"
			OR protoPayload.methodName:"compute.networks.removePeering"`),
			DisplayName: pulumi.String("VPC Network Changes"),
		},
		"vpc_network_route_changes": {
			Filter: pulumi.String(`resource.type="gce_network"
			AND (protoPayload.methodName:"compute.networks.insert"
			OR protoPayload.methodName:"compute.networks.patch"
			OR protoPayload.methodName:"compute.networks.delete"
			OR protoPayload.methodName:"compute.networks.removePeering"
			OR protoPayload.methodName:"compute.networks.addPeering")`),
			DisplayName: pulumi.String("VPC Network Route Changes"),
		},
		"vpc_network_firewall_rule_changes": {
			Filter: pulumi.String(`resource.type="gce_firewall"
			AND (protoPayload.methodName="compute.firewalls.patch"
			OR protoPayload.methodName="compute.firewalls.insert"
			OR protoPayload.methodName="compute.firewalls.delete")`),
			DisplayName: pulumi.String("VPC Network Firewall Rule Changes"),
		},
		"custom_role_changes": {
			Filter: pulumi.String(`resource.type="iam_role"
			AND (protoPayload.methodName="google.iam.admin.v1.CreateRole"
			OR protoPayload.methodName="google.iam.admin.v1.DeleteRole"
			OR protoPayload.methodName="google.iam.admin.v1.UpdateRole")`),
			DisplayName: pulumi.String("Custom Role Changes"),
		},
		"audit_configuration_changes": {
			Filter: pulumi.String(`resource.type="project"
			AND protoPayload.methodName="SetIamPolicy"
			AND protoPayload.serviceData.policyDelta.auditConfigDeltas:*`),
			DisplayName: pulumi.String("Audit Configuration Changes"),
		},
		"project_ownership_changes": {
			Filter: pulumi.String(`resource.type="project"
			AND (protoPayload.serviceName="cloudresourcemanager.googleapis.com")
			AND (ProjectOwnership OR projectOwnerInvitee)
			OR (protoPayload.serviceData.policyDelta.bindingDeltas.action="REMOVE"
			AND protoPayload.serviceData.policyDelta.bindingDeltas.role="roles/owner")
			OR (protoPayload.serviceData.policyDelta.bindingDeltas.action="ADD"
			AND protoPayload.serviceData.policyDelta.bindingDeltas.role="roles/owner")`),
			DisplayName: pulumi.String("Project Ownership Changes"),
		},
	}

	for metricName, metricArg := range metricArgs {
		metric, err := logging.NewMetric(ctx, name+"-"+metricName, &logging.MetricArgs{
			Name:    pulumi.String(metricName),
			Project: args.ProjectID,
			Filter:  metricArg.Filter,
			MetricDescriptor: &logging.MetricMetricDescriptorArgs{
				MetricKind:  pulumi.String("DELTA"),
				ValueType:   pulumi.String("INT64"),
				Unit:        pulumi.String("1"),
				DisplayName: metricArg.DisplayName,
			},
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create logging metric %s, %w", metricName, err)
		}

		metrics[metricName] = metric
	}

	c.Metrics = metrics

	return nil
}

func (c *Logging) createLogRetention(ctx *pulumi.Context, name string, args *LoggingArgs) error {
	bucketConfigArgs := &logging.ProjectBucketConfigArgs{
		Project:       args.ProjectID,
		Location:      pulumi.String("us-central1"),
		RetentionDays: pulumi.Int(365),
		BucketId:      pulumi.String("_Default"),
	}

	bucketConfig, err := logging.NewProjectBucketConfig(ctx, name, bucketConfigArgs, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create logging bucket config %s, %w", name, err)
	}

	c.BucketConfig = bucketConfig

	return nil
}

func (c *Logging) createAlertPolicy(ctx *pulumi.Context, name string, args *LoggingArgs) error {
	metricToResourceMap := map[string]string{
		"sql_instance_configuration_changes":   "cloudsql_database",
		"custom_role_changes":                  "global",
		"vpc_network_firewall_rule_changes":    "global",
		"audit_configuration_changes":          "global",
		"cloud_storage_iam_permission_changes": "gcs_bucket",
		"project_ownership_changes":            "global",
		"vpc_network_changes":                  "gce_network",
		"vpc_network_route_changes":            "gce_network",
	}

	alertPolicies := map[string]*monitoring.AlertPolicy{}

	for metricName := range c.Metrics {
		resourceType, ok := metricToResourceMap[metricName]
		if !ok {
			return fmt.Errorf("%w: %s", ErrNoMetricResourceMappingFound, metricName)
		}

		alertPolicyArgs := &monitoring.AlertPolicyArgs{
			DisplayName: pulumi.Sprintf("Alert for %s", metricName),
			Conditions: monitoring.AlertPolicyConditionArray{
				&monitoring.AlertPolicyConditionArgs{
					DisplayName: pulumi.String(metricName + " threshold condition"),
					ConditionThreshold: &monitoring.AlertPolicyConditionConditionThresholdArgs{
						Comparison:     pulumi.String("COMPARISON_GT"),
						ThresholdValue: pulumi.Float64(0),
						Duration:       pulumi.String("60s"),
						Filter:         pulumi.Sprintf(`metric.type="logging.googleapis.com/user/%s" AND resource.type="%s"`, metricName, resourceType),
						Aggregations: monitoring.AlertPolicyConditionConditionThresholdAggregationArray{
							&monitoring.AlertPolicyConditionConditionThresholdAggregationArgs{
								AlignmentPeriod:  pulumi.String("60s"),
								PerSeriesAligner: pulumi.String("ALIGN_RATE"),
							},
						},
					},
				},
			},
			NotificationChannels: pulumi.StringArray{
				c.NotificationChannelID,
			},
			Combiner: pulumi.String("AND"),
			Enabled:  pulumi.Bool(true),
			Project:  args.ProjectID,
		}

		nameStr := name + "-" + metricName

		alertPolicy, err := monitoring.NewAlertPolicy(ctx, nameStr, alertPolicyArgs, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create logging alert policy %s, %w", nameStr, err)
		}

		alertPolicies[metricName] = alertPolicy
	}

	c.AlertPolicies = alertPolicies

	return nil
}

func (c *Logging) createNotificationChannel(ctx *pulumi.Context, name string, args *LoggingArgs) error {
	notificationChannel, err := monitoring.NewNotificationChannel(ctx, name, &monitoring.NotificationChannelArgs{
		Type: pulumi.String("slack"),
		Labels: pulumi.StringMap{
			"channel_name": args.SlackChannelName,
			"team":         args.SlackChannelTeam,
		},
		SensitiveLabels: &monitoring.NotificationChannelSensitiveLabelsArgs{
			AuthToken: args.SlackAuthToken,
		},
		Enabled: pulumi.Bool(true),
		Project: args.ProjectID,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create notification error, %w", err)
	}

	c.NotificationChannelID = notificationChannel.ID().ToStringOutput()

	return nil
}

func (args *LoggingArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *LoggingArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal cluster args, %w", err)
	}

	return nil
}
