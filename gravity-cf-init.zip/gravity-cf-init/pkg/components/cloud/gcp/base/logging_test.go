package base_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/base"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

func TestNewLogging(t *testing.T) {
	t.Parallel()

	type want struct {
	}

	tests := []struct {
		name    string
		args    *base.LoggingArgs
		want    want
		wantErr bool
	}{
		{
			name: "using standard inputs",
			args: &base.LoggingArgs{
				ProjectID:      pulumi.String("test"),
				SlackAuthToken: pulumi.String("test"),
			},
			want:    want{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := base.NewLogging(ctx, "test", tt.args)
				if err != nil {
					return err
				}

				got.NotificationChannelID.ApplyT(func(id string) string {
					assert.Equal(t, "test-notify_id", id)

					return id
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.GCPMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
