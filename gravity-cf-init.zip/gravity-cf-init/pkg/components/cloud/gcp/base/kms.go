package base

import (
	"fmt"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/kms"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const kmsComponentName = "gravity:gcp:root:kms"

type KMS struct {
	pulumi.ResourceState
	DefaultKeyRingID pulumi.IDOutput `pulumi:"defaultKeyRingID"`
	DefaultKeyID     pulumi.IDOutput `pulumi:"defaultKeyID"`
}

type KMSArgs struct {
	ProjectName   pulumi.StringInput `pulumi:"projectName"   validate:"required"`
	ProjectNumber pulumi.StringInput `pulumi:"projectNumber"`
	Location      pulumi.StringInput `pulumi:"location"      validate:"required"`
	Tags          pulumi.StringMap   `pulumi:"tags"`
}

func NewKMS(ctx *pulumi.Context, name string, args *KMSArgs, opts ...pulumi.ResourceOption) (*KMS, error) {
	if err := args.validate(); err != nil {
		return nil, err
	}

	component := &KMS{}

	if err := ctx.RegisterComponentResource(baseComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", kmsComponentName, name, err)
	}

	if err := component.createDefaultKMSKeyRing(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createDefaultKMSKey(ctx, name, args); err != nil {
		return nil, err
	}

	component.createKMSPolicyBindings(ctx, args)

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"defaultKeyRingID": component.DefaultKeyRingID,
		"defaultKeyID":     component.DefaultKeyID,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", kmsComponentName, name, err)
	}

	return component, nil
}

func (c *KMS) createDefaultKMSKeyRing(ctx *pulumi.Context, name string, args *KMSArgs) error {
	keyRing, err := kms.NewKeyRing(ctx, name, &kms.KeyRingArgs{
		Location: args.Location,
		Project:  args.ProjectName,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("error creating base infra keyRing %s, %w", name, err)
	}

	c.DefaultKeyRingID = keyRing.ID()

	return nil
}

func (c *KMS) createDefaultKMSKey(ctx *pulumi.Context, name string, args *KMSArgs) error {
	key, err := kms.NewCryptoKey(ctx, name, &kms.CryptoKeyArgs{
		KeyRing:        c.DefaultKeyRingID,
		Labels:         args.Tags,
		Name:           pulumi.String("encryption-key"),
		RotationPeriod: pulumi.String("7614000s"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("error creating base infra Kms Key %s, %w", name, err)
	}

	c.DefaultKeyID = key.ID()

	return nil
}

func (c *KMS) createKMSPolicyBindings(ctx *pulumi.Context, args *KMSArgs) {
	args.ProjectNumber.ToStringOutput().ApplyT(func(projectNumber string) error {
		members := [4]string{}

		members[0] = fmt.Sprintf("serviceAccount:service-%s@container-engine-robot.iam.gserviceaccount.com", projectNumber)
		members[1] = fmt.Sprintf("serviceAccount:%s-compute@developer.gserviceaccount.com", projectNumber)
		members[2] = fmt.Sprintf("serviceAccount:service-%s@gs-project-accounts.iam.gserviceaccount.com", projectNumber)
		members[3] = fmt.Sprintf("serviceAccount:service-%s@compute-system.iam.gserviceaccount.com", projectNumber)

		for _, member := range members {
			resourceName := strings.Split(strings.Split(member, "@")[1], ".")

			if _, err := kms.NewCryptoKeyIAMMember(ctx, resourceName[0]+"-kms-member-binding", &kms.CryptoKeyIAMMemberArgs{
				CryptoKeyId: c.DefaultKeyID,
				Member:      pulumi.String(member),
				Role:        pulumi.String("roles/cloudkms.cryptoKeyEncrypterDecrypter"),
			}, pulumi.Parent(c)); err != nil {
				return fmt.Errorf("error creating IAM Member binding for %s, %w", member, err)
			}
		}

		return nil
	})
}

func (args *KMSArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *KMSArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
