package base

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-gcp/sdk/v7/go/gcp/projects"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const apiServicesComponentName = "gravity:gcp:apiServices"

var ErrRequiredArgumentNetworkID = errors.New("required argument NetworkID is missing")

type APIServices struct {
	pulumi.ResourceState
	Services projects.ServiceArray
}

type APIServicesArgs struct {
	ProjectID pulumi.StringInput `pulumi:"projectID" validate:"required"`
	Services  pulumi.StringArray `pulumi:"services"`
}

func NewAPIServices(ctx *pulumi.Context, name string, args *APIServicesArgs, opts ...pulumi.ResourceOption) (*APIServices, error) {
	component := &APIServices{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(apiServicesComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", apiServicesComponentName, name, err)
	}

	if err := component.createAPIServices(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"services": component.Services.ToServiceArrayOutput(),
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", apiServicesComponentName, name, err)
	}

	return component, nil
}

func (c *APIServices) createAPIServices(ctx *pulumi.Context, name string, args *APIServicesArgs) error {
	services := projects.ServiceArray{}

	for _, service := range args.Services {
		apiService, err := projects.NewService(ctx, fmt.Sprintf("%s-%s", name, service), &projects.ServiceArgs{
			Project:                  args.ProjectID,
			Service:                  service,
			DisableDependentServices: pulumi.Bool(true),
		}, pulumi.Parent(c), pulumi.DeleteBeforeReplace(true))
		if err != nil {
			return fmt.Errorf("unable to enable new gcp service %s, %w", service, err)
		}

		services = append(services, apiService)
	}

	c.Services = services

	return nil
}

func (args *APIServicesArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *APIServicesArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
