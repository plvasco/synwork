package base_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/base"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

func TestNewBase(t *testing.T) {
	t.Parallel()

	type want struct {
		ProjectID     string
		BucketName    string
		KeyID         string
		HostProjectID string
	}

	type args struct {
		args *base.BaseArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "Testing base host project deployment",
			in: args{
				args: &base.BaseArgs{
					Customer:        pulumi.String("testCust"),
					ComplianceLevel: pulumi.String("testIL"),
					Environment:     pulumi.String("test"),
					Location:        pulumi.String("testAZ-1"),
					BillingAccount:  pulumi.String("testBilling"),
					LoggingConfig: &base.LoggingArgs{
						SlackAuthToken:   pulumi.String("potato"),
						SlackChannelName: pulumi.String("potatosrus"),
						SlackChannelTeam: pulumi.String("jefesx10ders"),
					},
					IsHostProject:  pulumi.Bool(true),
					AdditionalAPIs: pulumi.ToStringArray([]string{}),
					Workload:       pulumi.String("testAZ-1-Workload"),
				},
			},
			want: want{
				ProjectID:     "mock-gcp-project",
				BucketName:    "testIL-test-testCust-state",
				KeyID:         "testIL-test-testCust_id",
				HostProjectID: "",
			},
			wantErr: false,
		},
		{
			name: "Testing base service project deployment",
			in: args{
				args: &base.BaseArgs{
					Customer:        pulumi.String("testCust"),
					ComplianceLevel: pulumi.String("testIL"),
					Environment:     pulumi.String("test"),
					Location:        pulumi.String("testAZ-1"),
					BillingAccount:  pulumi.String("testBilling"),
					LoggingConfig: &base.LoggingArgs{
						SlackAuthToken:   pulumi.String("potato"),
						SlackChannelName: pulumi.String("potatosrus"),
						SlackChannelTeam: pulumi.String("jefesx10ders"),
					},
					AdditionalAPIs: pulumi.ToStringArray([]string{}),
					Workload:       pulumi.String("testAZ-1-Workload"),
				},
			},
			want: want{
				ProjectID:     "mock-gcp-project",
				BucketName:    "testIL-test-testCust-state",
				KeyID:         "testIL-test-testCust_id",
				HostProjectID: "testIL-prd-networking",
			},
			wantErr: false,
		},
		{
			name: "Testing that customer is required",
			in: args{
				args: &base.BaseArgs{
					ComplianceLevel: pulumi.String("testIL"),
					Environment:     pulumi.String("test"),
					Location:        pulumi.String("testAZ-1"),
					BillingAccount:  pulumi.String("testBilling"),
					LoggingConfig: &base.LoggingArgs{
						SlackAuthToken: pulumi.String("potato"),
					},
					AdditionalAPIs: pulumi.ToStringArray([]string{}),
					Workload:       pulumi.String("testAZ-1-Workload"),
				},
			},
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := base.NewBase(ctx, tc.in.args)
				if err != nil {
					return err
				}

				got.ProjectID.ApplyT(func(id string) bool {
					assert.Equal(t, tc.want.ProjectID, id)

					return true
				})

				got.BucketName.ApplyT(func(name string) bool {
					assert.Equal(t, tc.want.BucketName, name)

					return true
				})

				got.DefaultKeyID.ApplyT(func(id string) bool {
					assert.Equal(t, tc.want.KeyID, id)

					return true
				})

				got.HostProjectID.ApplyT(func(id string) bool {
					assert.Equal(t, tc.want.HostProjectID, id)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.GCPMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tc.wantErr)
			}
		})
	}
}
