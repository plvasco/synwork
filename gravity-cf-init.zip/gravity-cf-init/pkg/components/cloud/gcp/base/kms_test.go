package base_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/base"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"

	"github.com/stretchr/testify/assert"
)

func TestNewKMS(t *testing.T) {
	t.Parallel()

	type want struct {
		*base.KMS
	}

	type args struct {
		name string
		args *base.KMSArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should create new KMS key and keyring",
			in: args{
				name: "test",
				args: &base.KMSArgs{
					ProjectName:   pulumi.String("fakeproject"),
					Location:      pulumi.String("us-east4"),
					ProjectNumber: pulumi.String("123456789"),
				},
			},
			want:    want{},
			wantErr: false,
		},
		{
			name: "test should fail to create keys due to missing arguments",
			in: args{
				name: "test",
				args: &base.KMSArgs{
					ProjectName: nil,
					Location:    nil,
				},
			},
			want:    want{},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := base.NewKMS(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				pulumi.All(got.DefaultKeyID.ToStringOutput(), got.DefaultKeyRingID.ToStringOutput()).ApplyT(func(all []interface{}) error {
					keyID := all[0].(string)
					keyRingID := all[1].(string)

					assert.Equal(t, "test_id", keyID)
					assert.Equal(t, "test_id", keyRingID)

					return nil
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.GCPMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
