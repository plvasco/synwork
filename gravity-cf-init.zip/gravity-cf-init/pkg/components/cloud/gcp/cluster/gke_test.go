package gke_test

import (
	"testing"

	gke "code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/cluster"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"

	"github.com/stretchr/testify/assert"
)

func TestNewCluster(t *testing.T) {
	t.Parallel()

	defaultTestConfig := map[string]any{
		"gcp:region":  "us-east4",
		"gcp:project": "mock-test-project",
	}

	type want struct {
		clusterName          string
		defaultKeyID         string
		hostNetworkURI       string
		hostProjectID        string
		hostVPC              map[string]any
		serviceProjectNumber string
		network              string
		privCidr             string
		defaultCidr          string
	}

	type args struct {
		ctx  *pulumi.Context
		name string
		args *gke.ClusterArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "Test should create GCP GKE cluster",
			in: args{
				ctx:  &pulumi.Context{},
				name: "gcp-gke-cluster-test",
				args: &gke.ClusterArgs{
					KubernetesVersion: pulumi.String("137.27"),
					ComplianceLevel:   string("il0"),
					NodePools: map[string]gke.NodePoolArgs{
						"test-node-pool": {
							InstanceType:     pulumi.String("test-instance-type"),
							MaxSize:          pulumi.Int(3),
							MinSize:          pulumi.Int(1),
							StorageSize:      pulumi.Int(100),
							LocationPolicy:   pulumi.String("test-location-policy"),
							Preemptible:      pulumi.Bool(true),
							Spot:             pulumi.Bool(false),
							KubeletExtraArgs: pulumi.String("test-extra-args"),
							Taints:           []gke.Taint{},
						},
					},
					Subnets: map[string]gke.SubnetArgs{
						"default": {
							CIDR:        "10.0.0.0/24",
							PodNet:      "10.1.1.0/22",
							ServicesNet: "10.1.2.0/22",
						},
						"privEndpoint": {
							CIDR: "10.0.1.1/28",
						},
					},
					Customer:                "my-test-customer",
					Environment:             "test",
					ExtraAuthorizedNetworks: []string{"172.1.1.1/18"},
				},
			},
			want: want{
				clusterName:    "gcp-gke-cluster-test",
				defaultKeyID:   "encryption-key-12345",
				hostNetworkURI: "host-network-self-link/mock-network",
				hostProjectID:  "il0-prd-networking",
				hostVPC: map[string]any{
					"project":  "mock-project",
					"selfLink": "host-network-self-link",
				},
				serviceProjectNumber: "service-project-number",
				network:              "mock-network",
				privCidr:             "10.0.1.1/28",
				defaultCidr:          "10.0.0.0/24",
			},
			wantErr: false,
		},
		{
			name: "Test should fail due to missing required args",
			in: args{
				ctx:  &pulumi.Context{},
				name: "gcp-gke-cluster-test",
				args: &gke.ClusterArgs{
					KubernetesVersion: pulumi.String("137.27"),
					ComplianceLevel:   string("il0"),
					NodePools: map[string]gke.NodePoolArgs{
						"test-node-pool": {
							InstanceType:     pulumi.String("test-instance-type"),
							MaxSize:          pulumi.Int(3),
							MinSize:          pulumi.Int(1),
							StorageSize:      pulumi.Int(100),
							LocationPolicy:   pulumi.String("test-location-policy"),
							Preemptible:      pulumi.Bool(true),
							Spot:             pulumi.Bool(false),
							KubeletExtraArgs: pulumi.String("test-extra-args"),
							Taints:           []gke.Taint{},
						},
					},
					Subnets: map[string]gke.SubnetArgs{
						"default": {
							CIDR:        "10.0.0.0/24",
							PodNet:      "10.1.1.0/22",
							ServicesNet: "10.1.2.0/22",
						},
					},
					Customer:                "my-test-customer",
					Environment:             "test",
					ExtraAuthorizedNetworks: []string{"172.1.1.1/18"},
				},
			},
			want:    want{},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := gke.NewCluster(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				pulumi.All(got.ClusterName, got.DefaultKeyID, got.HostNetworkURI, got.HostProjectID,
					got.Subnets["default"].Network, got.Subnets["privEndpoint"].IpCidrRange, got.Subnets["default"].IpCidrRange).ApplyT(func(all []interface{}) error {
					clusterName := all[0].(string)
					assert.Equal(t, tt.want.clusterName, clusterName)

					defaultKeyID := all[1].(string)
					assert.Equal(t, tt.want.defaultKeyID, defaultKeyID)

					hostNetworkURI := all[2].(string)
					assert.Equal(t, tt.want.hostNetworkURI, hostNetworkURI)

					HostProjectID := all[3].(string)
					assert.Equal(t, tt.want.hostProjectID, HostProjectID)

					assert.Equal(t, tt.want.hostVPC["selfLink"], got.HostVPC.SelfLink)
					assert.Equal(t, tt.want.hostVPC["project"], *got.HostVPC.Project)

					assert.Equal(t, tt.want.serviceProjectNumber, got.ServiceProjectNumber)

					network := all[4]
					assert.Equal(t, tt.want.network, network)

					privCidr := all[5]
					assert.Equal(t, tt.want.privCidr, privCidr)

					defaultCidr := all[6]
					assert.Equal(t, tt.want.defaultCidr, defaultCidr)

					return nil
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", defaultTestConfig, new(testutils.GCPMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
