package gke

import (
	"errors"
	"fmt"
	"strings"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/whitelist"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/compute"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/container"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/kms"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/projects"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/serviceaccount"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi/config"
)

const gkeComponentName = "gravity:gcp:cluster:gke"

var (
	ErrRequiredArgumentComplianceLevel    = errors.New("required argument `complianceLevel` is missing")
	ErrRequiredArgumentAMI                = errors.New("required argument `ami` is missing")
	ErrRequiredArgumentNodePools          = errors.New("required argument `nodePools` are missing")
	ErrRequiredArgumentkKubernetesVersion = errors.New("required argument `kubernetesVersion` is missing")
	ErrRequiredArgumentPrivEndpoint       = errors.New("required subnet `privEndpoint` is missing")
	ErrRequiredArgumentDefaultSubnet      = errors.New("required subnet `default` is missing")
)

type Cluster struct {
	pulumi.ResourceState
	ClusterName          pulumi.StringOutput
	HostProjectID        pulumi.StringOutput
	ServiceProjectNumber string
	DefaultKeyID         pulumi.StringOutput
	HostVPC              *compute.GetNetworksResult
	Subnets              map[string]*compute.Subnetwork
	HostNetworkURI       pulumi.StringOutput
	PrivateClusterConfig container.ClusterPrivateClusterConfigOutput
	NodeSvcAccount       pulumi.StringOutput
}

type ClusterArgs struct {
	NodePools               map[string]NodePoolArgs `pulumi:"nodePools"`
	KubernetesVersion       pulumi.String           `pulumi:"kubernetesVersion"`
	Subnets                 map[string]SubnetArgs   `pulumi:"subnets"`
	ComplianceLevel         string                  `pulumi:"complianceLevel"`
	Customer                string                  `pulumi:"customer"`
	Environment             string                  `pulumi:"environment"`
	Tags                    map[string]string       `pulumi:"tags"`
	ExtraAuthorizedNetworks []string                `pulumi:"extraAuthorizedNetworks"`
}

type SubnetArgs struct {
	CIDR        string `pulumi:"cidr"`
	PodNet      string `pulumi:"podNet"`
	ServicesNet string `pulumi:"servicesNet"`
}

type NodePoolArgs struct {
	InstanceType     pulumi.String `pulumi:"instanceTypes"`
	MaxSize          pulumi.Int    `pulumi:"maxSize"`
	MinSize          pulumi.Int    `pulumi:"minSize"`
	StorageSize      pulumi.Int    `pulumi:"storageSize"`
	LocationPolicy   pulumi.String `pulumi:"locationPolicy"`
	Preemptible      pulumi.Bool   `pulumi:"preemtible"`
	Spot             pulumi.Bool   `pulumi:"spot"`
	KubeletExtraArgs pulumi.String `pulumi:"kubeletExtraArgs"`
	Taints           []Taint       `pulumi:"taints"`
}

type Taint struct {
	Effect pulumi.String
	Key    pulumi.String
	Value  pulumi.String
}

func NewCluster(ctx *pulumi.Context, name string, args *ClusterArgs, opts ...pulumi.ResourceOption) (*Cluster, error) {
	component := &Cluster{}

	var err error

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(gkeComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", gkeComponentName, name, err)
	}

	component.DefaultKeyID, err = component.getKeyID(ctx, "encryption-key")

	if err != nil {
		return nil, fmt.Errorf("unable to get default key ID, %w", err)
	}

	if err := component.getHostNetwork(ctx, args); err != nil {
		return nil, err
	}

	if err := component.createSubnets(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createIAMBindings(ctx); err != nil {
		return nil, err
	}

	if err := component.createCluster(ctx, name, args); err != nil {
		return nil, err
	}

	if err := component.createControlPlaneFirewallRules(ctx, name); err != nil {
		return nil, err
	}

	if err := component.createNodePools(ctx, name, args); err != nil {
		return nil, err
	}

	return component, nil
}

func (args *ClusterArgs) validate() error {
	if args == nil {
		args = &ClusterArgs{}
	}

	if args.KubernetesVersion == "" {
		return ErrRequiredArgumentkKubernetesVersion
	}

	if args.ComplianceLevel == "" {
		return ErrRequiredArgumentComplianceLevel
	}

	if len(args.NodePools) == 0 {
		return ErrRequiredArgumentNodePools
	}

	if _, ok := args.Subnets["privEndpoint"]; !ok {
		return ErrRequiredArgumentPrivEndpoint
	}

	if _, ok := args.Subnets["default"]; !ok {
		return ErrRequiredArgumentDefaultSubnet
	}

	if args.Tags == nil {
		args.Tags = map[string]string{}
	}

	if _, ok := args.Tags["customer"]; !ok {
		args.Tags["customer"] = args.Customer
	}

	if _, ok := args.Tags["complianceLevel"]; !ok {
		args.Tags["complianceLevel"] = args.ComplianceLevel
	}

	if _, ok := args.Tags["environment"]; !ok {
		args.Tags["environment"] = args.Environment
	}

	return nil
}

func (c *Cluster) getHostNetwork(ctx *pulumi.Context, args *ClusterArgs) error {
	hostNetworkOutput, err := projects.GetProject(ctx, &projects.GetProjectArgs{
		Filter: fmt.Sprintf("name:%s-prd-networking", args.ComplianceLevel),
	})
	if err != nil {
		return fmt.Errorf("error getting host projectID, %w", err)
	}

	hostVPC, err := compute.GetNetworks(ctx, &compute.GetNetworksArgs{
		Project: &hostNetworkOutput.Projects[0].ProjectId,
	})
	if err != nil {
		return fmt.Errorf("unable to get hostVPC for %w", err)
	}

	c.HostProjectID = pulumi.String(hostNetworkOutput.Projects[0].ProjectId).ToStringOutput()
	c.HostVPC = hostVPC
	c.HostNetworkURI = pulumi.Sprintf("%s/%s", c.HostVPC.SelfLink, c.HostVPC.Networks[0])

	return nil
}

func (c *Cluster) createSubnets(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	subnets := map[string]*compute.Subnetwork{}

	for subnetName, subnetConf := range args.Subnets {
		args := &compute.SubnetworkArgs{
			Project:               c.HostProjectID,
			Network:               pulumi.String(c.HostVPC.Networks[0]),
			IpCidrRange:           pulumi.String(subnetConf.CIDR),
			PrivateIpGoogleAccess: pulumi.Bool(true),
			StackType:             pulumi.String("IPV4_ONLY"),
			SecondaryIpRanges: compute.SubnetworkSecondaryIpRangeArray{
				&compute.SubnetworkSecondaryIpRangeArgs{
					RangeName:   pulumi.String("pods"),
					IpCidrRange: pulumi.String(subnetConf.PodNet),
				},
				&compute.SubnetworkSecondaryIpRangeArgs{
					RangeName:   pulumi.String("services"),
					IpCidrRange: pulumi.String(subnetConf.ServicesNet),
				},
			},
			LogConfig: &compute.SubnetworkLogConfigArgs{
				AggregationInterval: pulumi.String("INTERVAL_10_MIN"),
				FlowSampling:        pulumi.Float64(0.5),
				Metadata:            pulumi.String("INCLUDE_ALL_METADATA"),
			},
		}

		if subnetName == "privEndpoint" {
			args.SecondaryIpRanges = nil
		}

		subnet, err := compute.NewSubnetwork(ctx, name+"-"+subnetName, args, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create subnet for %s, %w", name, err)
		}

		subnets[subnetName] = subnet
	}

	c.Subnets = subnets

	return nil
}

func (c *Cluster) createIAMBindings(ctx *pulumi.Context) error {
	var err error

	cfg := config.New(ctx, "gcp")

	serviceProject, err := projects.GetProject(ctx, &projects.GetProjectArgs{Filter: "id:" + cfg.Require("project")})
	if err != nil {
		return fmt.Errorf("unable to get service project, %w", err)
	}

	c.ServiceProjectNumber = serviceProject.Projects[0].Number

	containerEngineAcc := pulumi.Sprintf("serviceAccount:service-%s@container-engine-robot.iam.gserviceaccount.com", serviceProject.Projects[0].Number)
	cloudServicesAcc := pulumi.Sprintf("serviceAccount:%s@cloudservices.gserviceaccount.com", serviceProject.Projects[0].Number)
	computeEngineAcc := pulumi.Sprintf("serviceAccount:%s-compute@developer.gserviceaccount.com", serviceProject.Projects[0].Number)
	defaultNodeAcc := pulumi.Sprintf("serviceAccount:cluster-node@%s.iam.gserviceaccount.com", serviceProject.Projects[0].ProjectId)

	networkUserRole := pulumi.String("roles/compute.networkUser")
	securityAdminRole := pulumi.String("roles/compute.securityAdmin")
	hostServiceAgentRole := pulumi.String("roles/container.hostServiceAgentUser")

	nodeRoles := []string{
		"roles/container.defaultNodeServiceAccount",
	}

	nodeServiceAccount, err := serviceaccount.NewAccount(ctx, "cluster-node", &serviceaccount.AccountArgs{
		AccountId:   pulumi.String("cluster-node"),
		DisplayName: pulumi.String("Cluster Node Service Account"),
	})
	if err != nil {
		return fmt.Errorf("unable to create iam policy binding on host project for network user, %w", err)
	}

	for _, role := range nodeRoles {
		_, err = projects.NewIAMMember(ctx, "cluster-node-"+role, &projects.IAMMemberArgs{
			Project: pulumi.String(serviceProject.Projects[0].ProjectId),
			Member:  defaultNodeAcc,
			Role:    pulumi.String(role),
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create iam policy binding on host project for network user, %w", err)
		}
	}

	defaultSubnet := c.Subnets["default"]

	_, err = compute.NewSubnetworkIAMMember(ctx, "default-containerSA", &compute.SubnetworkIAMMemberArgs{
		Project:    c.HostProjectID,
		Subnetwork: defaultSubnet.Name,
		Member:     containerEngineAcc,
		Role:       networkUserRole,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create iam policy binding, %w", err)
	}

	_, err = compute.NewSubnetworkIAMMember(ctx, "default-cloudSA", &compute.SubnetworkIAMMemberArgs{
		Project:    c.HostProjectID,
		Subnetwork: defaultSubnet.Name,
		Member:     cloudServicesAcc,
		Role:       networkUserRole,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create iam policy binding, %w", err)
	}

	_, err = projects.NewIAMMember(ctx, "project-compute-user-bind", &projects.IAMMemberArgs{
		Project: c.HostProjectID,
		Member:  computeEngineAcc,
		Role:    networkUserRole,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create iam policy binding on host project for network user, %w", err)
	}

	_, err = projects.NewIAMMember(ctx, "container-robot-security-bind", &projects.IAMMemberArgs{
		Project: c.HostProjectID,
		Member:  containerEngineAcc,
		Role:    securityAdminRole,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create iam policy binding on host project for security admin, %w", err)
	}

	_, err = projects.NewIAMMember(ctx, "container-robot-net-admin-bind", &projects.IAMMemberArgs{
		Project: c.HostProjectID,
		Member:  containerEngineAcc,
		Role:    hostServiceAgentRole,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create iam policy binding on host project for k8s, %w", err)
	}

	c.NodeSvcAccount = nodeServiceAccount.Email

	return nil
}

func (c *Cluster) getKeyID(ctx *pulumi.Context, keyName string) (pulumi.StringOutput, error) {
	cfg := config.New(ctx, "gcp")

	keyRing, err := kms.GetKeyRings(ctx, &kms.GetKeyRingsArgs{
		Location: cfg.Require("region"),
	}, pulumi.Parent(c))
	if err != nil {
		return pulumi.StringOutput{}, fmt.Errorf("unable to lookup keyrings in the project, %w", err)
	}

	key, err := kms.GetKMSCryptoKey(ctx, &kms.GetKMSCryptoKeyArgs{
		KeyRing: keyRing.KeyRings[0].Id,
		Name:    keyName,
	})
	if err != nil {
		return pulumi.StringOutput{}, fmt.Errorf("unable to get kms key name, %w", err)
	}

	return pulumi.String(key.Id).ToStringOutput(), nil
}

func (c *Cluster) createCluster(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	cfg := config.New(ctx, "gcp")

	lowerCaseTags := make(map[string]string)
	for k, v := range args.Tags {
		lowerCaseTags[strings.ToLower(k)] = v
	}

	cluster, err := container.NewCluster(ctx, name, &container.ClusterArgs{
		Location:              pulumi.String(cfg.Require("region")),
		Network:               c.HostNetworkURI,
		Subnetwork:            c.Subnets["default"].SelfLink,
		RemoveDefaultNodePool: pulumi.Bool(true),
		DatabaseEncryption: &container.ClusterDatabaseEncryptionArgs{
			KeyName: c.DefaultKeyID,
			State:   pulumi.String("ENCRYPTED"),
		},
		NodeConfig: &container.ClusterNodeConfigArgs{
			BootDiskKmsKey: c.DefaultKeyID,
		},
		InitialNodeCount: pulumi.Int(1),
		ResourceLabels:   pulumi.ToStringMap(lowerCaseTags),
		MinMasterVersion: args.KubernetesVersion,
		DatapathProvider: pulumi.String("ADVANCED_DATAPATH"),
		PrivateClusterConfig: &container.ClusterPrivateClusterConfigArgs{
			EnablePrivateEndpoint:     pulumi.Bool(false),
			EnablePrivateNodes:        pulumi.Bool(true),
			PrivateEndpointSubnetwork: c.Subnets["privEndpoint"].ID(),
		},
		NetworkingMode: pulumi.String("VPC_NATIVE"),
		IpAllocationPolicy: &container.ClusterIpAllocationPolicyArgs{
			ClusterSecondaryRangeName:  pulumi.String("pods"),
			ServicesSecondaryRangeName: pulumi.String("services"),
		},
		MasterAuthorizedNetworksConfig: &container.ClusterMasterAuthorizedNetworksConfigArgs{
			CidrBlocks:                  makeAllowCidrArray(args.ComplianceLevel, args.ExtraAuthorizedNetworks),
			GcpPublicCidrsAccessEnabled: pulumi.Bool(false),
		},
		DeletionProtection: pulumi.Bool(false),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create gke cluster, %w", err)
	}

	c.ClusterName = cluster.Name
	c.PrivateClusterConfig = cluster.PrivateClusterConfig

	return nil
}

func (c *Cluster) createControlPlaneFirewallRules(ctx *pulumi.Context, name string) error {
	_, err := compute.NewFirewall(ctx, name, &compute.FirewallArgs{
		Project: c.HostProjectID,
		Network: c.HostNetworkURI,
		Allows: compute.FirewallAllowArray{
			&compute.FirewallAllowArgs{
				Protocol: pulumi.String("icmp"),
			},
			&compute.FirewallAllowArgs{
				Protocol: pulumi.String("esp"),
			},
			&compute.FirewallAllowArgs{
				Protocol: pulumi.String("ah"),
			},
			&compute.FirewallAllowArgs{
				Protocol: pulumi.String("sctp"),
			},
			&compute.FirewallAllowArgs{
				Protocol: pulumi.String("udp"),
				Ports: pulumi.StringArray{
					pulumi.String("0-65535"),
				},
			},
			&compute.FirewallAllowArgs{
				Protocol: pulumi.String("tcp"),
				Ports: pulumi.StringArray{
					pulumi.String("0-65535"),
				},
			},
		},
		SourceRanges: pulumi.StringArray{
			c.Subnets["privEndpoint"].IpCidrRange,
		},
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create new firewall, %w", err)
	}

	return nil
}

func (c *Cluster) createNodePools(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	for npName, nodePool := range args.NodePools {
		_, err := container.NewNodePool(ctx, name+"-"+npName, &container.NodePoolArgs{
			Autoscaling: &container.NodePoolAutoscalingArgs{
				LocationPolicy:    pulumi.String("BALANCED"),
				TotalMaxNodeCount: nodePool.MaxSize,
				TotalMinNodeCount: nodePool.MinSize,
			},
			Cluster:          c.ClusterName,
			InitialNodeCount: pulumi.Int(1),
			NetworkConfig: &container.NodePoolNetworkConfigArgs{
				CreatePodRange:     pulumi.Bool(false),
				EnablePrivateNodes: pulumi.Bool(true),
			},
			NodeConfig: &container.NodePoolNodeConfigArgs{
				ServiceAccount: c.NodeSvcAccount,
				Preemptible:    nodePool.Preemptible,
				BootDiskKmsKey: c.DefaultKeyID,
				MachineType:    nodePool.InstanceType,
				Spot:           nodePool.Spot,
				ShieldedInstanceConfig: &container.NodePoolNodeConfigShieldedInstanceConfigArgs{
					EnableSecureBoot: pulumi.Bool(true),
				},
				KubeletConfig: &container.NodePoolNodeConfigKubeletConfigArgs{
					InsecureKubeletReadonlyPortEnabled: pulumi.String("FALSE"),
					CpuManagerPolicy:                   pulumi.String("none"),
				},
				Taints: makeTaintArray(&nodePool),
				OauthScopes: pulumi.StringArray{
					pulumi.String("https://www.googleapis.com/auth/compute"),
					pulumi.String("https://www.googleapis.com/auth/devstorage.read_only"),
					pulumi.String("https://www.googleapis.com/auth/logging.write"),
					pulumi.String("https://www.googleapis.com/auth/monitoring"),
					pulumi.String("https://www.googleapis.com/auth/cloud-platform"),
				},
				DiskSizeGb: nodePool.StorageSize,
			},
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create node pool, %w", err)
		}
	}

	return nil
}

func makeAllowCidrArray(complianceLevel string, extraNetworks []string) *container.ClusterMasterAuthorizedNetworksConfigCidrBlockArray {
	var allowCidrs container.ClusterMasterAuthorizedNetworksConfigCidrBlockArray

	allowCidrArray, err := whitelist.GetStringArrayIPWhitelist(complianceLevel)
	if err != nil {
		panic("unable to get allowed cidr array")
	}

	for _, allowCidr := range allowCidrArray {
		allowCidrs = append(allowCidrs, &container.ClusterMasterAuthorizedNetworksConfigCidrBlockArgs{
			CidrBlock: pulumi.String(allowCidr),
		})
	}

	if len(extraNetworks) != 0 {
		for _, network := range extraNetworks {
			allowCidrs = append(allowCidrs, &container.ClusterMasterAuthorizedNetworksConfigCidrBlockArgs{
				CidrBlock: pulumi.String(network),
			})
		}
	}

	return &allowCidrs
}

func makeTaintArray(nodePool *NodePoolArgs) *container.NodePoolNodeConfigTaintArray {
	var taints container.NodePoolNodeConfigTaintArray

	if nodePool.Taints == nil {
		return nil
	}

	for _, taint := range nodePool.Taints {
		taints = append(taints, &container.NodePoolNodeConfigTaintArgs{
			Effect: taint.Effect,
			Key:    taint.Key,
			Value:  taint.Value,
		})
	}

	return &taints
}

func (args *ClusterArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal cluster args, %w", err)
	}

	return nil
}
