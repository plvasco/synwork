package networking

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/compute"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const networkComponentName = "gravity:gcp:network"

type Network struct {
	pulumi.ResourceState
	VpcID       pulumi.StringOutput
	VpcSelfLink pulumi.StringOutput
}

type NetworkArgs struct {
	ProjectID   pulumi.StringInput
	Description pulumi.StringInput
	CidrBlock   pulumi.StringInput
}

func NewNetwork(ctx *pulumi.Context, name string, args *NetworkArgs, opts ...pulumi.ResourceOption) (*Network, error) {
	component := &Network{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(networkComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", networkComponentName, name, err)
	}

	if err := component.createVPC(ctx, name+"-vpc", args); err != nil {
		return nil, err
	}

	if err := component.createSubnet(ctx, name+"-subnet", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", networkComponentName, name, err)
	}

	return component, nil
}

func (c *Network) createVPC(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	vpc, err := compute.NewNetwork(ctx, name, &compute.NetworkArgs{
		AutoCreateSubnetworks: pulumi.Bool(false),
		Description:           args.Description,
		Project:               args.ProjectID,
		RoutingMode:           pulumi.String("REGIONAL"),
	}, pulumi.Parent(c), pulumi.Aliases([]pulumi.Alias{
		{Name: pulumi.String("networking-prd-gcp-vpc"), NoParent: pulumi.Bool(true)},
		{NoParent: pulumi.Bool(true)},
	}))
	if err != nil {
		return fmt.Errorf("unable to create network vpc, %w", err)
	}

	c.VpcID = vpc.ID().ToStringOutput()
	c.VpcSelfLink = vpc.SelfLink

	return nil
}

func (c *Network) createSubnet(ctx *pulumi.Context, name string, args *NetworkArgs) error {
	if _, err := compute.NewSubnetwork(ctx, name, &compute.SubnetworkArgs{
		IpCidrRange: args.CidrBlock,
		Description: args.Description,
		LogConfig: &compute.SubnetworkLogConfigArgs{
			AggregationInterval: pulumi.String("INTERVAL_10_MIN"),
			FlowSampling:        pulumi.Float64(0.5),
			Metadata:            pulumi.String("INCLUDE_ALL_METADATA"),
		},
		Network:               c.VpcID,
		PrivateIpGoogleAccess: pulumi.Bool(true),
		Project:               args.ProjectID,
		StackType:             pulumi.String("IPV4_ONLY"),
	}, pulumi.Parent(c), pulumi.Aliases([]pulumi.Alias{
		{Name: pulumi.String("networking-prd-gcp-private-subnet-0"), NoParent: pulumi.Bool(true)},
		{NoParent: pulumi.Bool(true)},
	})); err != nil {
		return fmt.Errorf("unable to create network subnet, %w", err)
	}

	return nil
}

func (args *NetworkArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *NetworkArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
