package vpn

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewConnection(t *testing.T) {
	t.Parallel()

	type want struct {
		peerIP        string
		interfaceName string
		tunnelName    string
	}

	type args struct {
		name string
		args *ConnectionArgs
	}

	testCases := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test new connection",
			in: args{
				name: "test1",
				args: &ConnectionArgs{
					ExternalInterfaceIP: pulumi.String("0.0.0.0"),
					Interface:           pulumi.Int(1),
					InternalInterfaceIP: pulumi.String("0.0.0.0"),
					InternalPeerIP:      pulumi.String("0.0.0.0"),
					InternalCIDR:        pulumi.String("0.0.0.0/16"),
					SharedKey:           pulumi.String("123456789"),
					RemoteASN:           pulumi.Int(123),
					routerName:          pulumi.String("test"),
				},
			},
			want: want{
				peerIP:        "0.0.0.0",
				interfaceName: "test1-ri",
				tunnelName:    "test1-tn",
			},
			wantErr: false,
		},
		{
			name: "test should fail on vailidation missing arg",
			in: args{
				name: "test1",
				args: &ConnectionArgs{
					Interface:           pulumi.Int(1),
					InternalInterfaceIP: pulumi.String("0.0.0.0"),
					InternalPeerIP:      pulumi.String("0.0.0.0"),
					InternalCIDR:        pulumi.String("0.0.0.0/16"),
					SharedKey:           pulumi.String("123456789"),
					RemoteASN:           pulumi.Int(123),
					routerName:          pulumi.String("test"),
				},
			},
			wantErr: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := newConnection(ctx, tc.in.name, tc.in.args)
				if err != nil {
					return err
				}

				require.NotNil(t, got)

				got.InternalPeerIP.ApplyT(func(peerIP string) bool {
					assert.Equal(t, tc.want.peerIP, peerIP)

					return true
				})

				got.RouterInterfaceName.ApplyT(func(name string) bool {
					assert.Equal(t, tc.want.interfaceName, name)

					return true
				})

				got.TunnelName.ApplyT(func(name string) bool {
					assert.Equal(t, tc.want.tunnelName, name)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.GCPMocks)))
			if (err != nil) != tc.wantErr {
				t.Errorf("NewConnection() error = %v, wantErr %v", err, tc.wantErr)

				return
			}
		})
	}
}

func TestConnectionArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *ConnectionArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"externalInterfaceIP": "203.0.113.1",
				"interface": 1,
				"internalInterfaceIP": "10.0.0.1",
				"internalPeerIP": "10.0.0.2",
				"internalCIDR": "10.0.0.0/24",
				"sharedKey": "test-shared-key",
				"remoteASN": 65000
			}`,
			want: &ConnectionArgs{
				ExternalInterfaceIP: pulumi.String("203.0.113.1"),
				Interface:           pulumi.Int(1),
				InternalInterfaceIP: pulumi.String("10.0.0.1"),
				InternalPeerIP:      pulumi.String("10.0.0.2"),
				InternalCIDR:        pulumi.String("10.0.0.0/24"),
				SharedKey:           pulumi.String("test-shared-key"),
				RemoteASN:           pulumi.Int(65000),
			},
			wantErr: false,
		},
		{
			name: "malformed JSON with incorrect type",
			input: `{
				"externalInterfaceIP": "203.0.113.1",
				"interface": true,
				"internalInterfaceIP": "10.0.0.1",
				"internalPeerIP": "10.0.0.2",
				"internalCIDR": "10.0.0.0/24",
				"sharedKey": true,
				"remoteASN": "65000"
			}`, // Incorrect types for all fields
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args ConnectionArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
