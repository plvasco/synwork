package vpn

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-gcp/sdk/v7/go/gcp/compute"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const externalVpnGatewayComponentName = "gravity:gcp:networking:vpn:externalGateway"

type ExternalGateway struct {
	pulumi.ResourceState
	Name        pulumi.StringOutput `pulumi:"name"`
	Connections []*Connection       `pulumi:"connections"`
}

type ExternalGatewayArgs struct {
	AwsConnections   []*ConnectionArgs  `pulumi:"awsConnections"   validate:"required,dig"`
	GcpVpnGatewayURL pulumi.StringInput `pulumi:"gcpVpnGatewayURL" validate:"required"`
	RouterName       pulumi.StringInput `pulumi:"routerName"       validate:"required"`
	RedundancyType   pulumi.StringInput `pulumi:"redundancyType"   validate:"default=FOUR_IPS_REDUNDANCY"`
}

func NewExternalGateway(ctx *pulumi.Context, name string, args *ExternalGatewayArgs, opts ...pulumi.ResourceOption) (*ExternalGateway, error) {
	component := &ExternalGateway{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(externalVpnGatewayComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", externalVpnGatewayComponentName, name, err)
	}

	if err := component.createExternalGateway(ctx, name+"-extgw", args); err != nil {
		return nil, err
	}

	if err := component.createConnections(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"name": component.Name,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", externalVpnGatewayComponentName, name, err)
	}

	return component, nil
}

func (c *ExternalGateway) createExternalGateway(ctx *pulumi.Context, name string, args *ExternalGatewayArgs) error {
	// Create a VPN Gateway in the GCP VPC
	interfaces := compute.ExternalVpnGatewayInterfaceArray{}
	for idx, vpnConf := range args.AwsConnections {
		interfaces = append(interfaces, &compute.ExternalVpnGatewayInterfaceArgs{
			Id:        pulumi.Int(idx),
			IpAddress: vpnConf.ExternalInterfaceIP,
		})
	}

	externalVpnGateway, err := compute.NewExternalVpnGateway(ctx, name, &compute.ExternalVpnGatewayArgs{
		Interfaces:     interfaces,
		RedundancyType: args.RedundancyType,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create ha vpn gateway, %w", err)
	}

	c.Name = externalVpnGateway.Name

	return nil
}

func (c *ExternalGateway) createConnections(ctx *pulumi.Context, name string, args *ExternalGatewayArgs) error {
	vpnConnections := []*Connection{}

	for index, connectionArgs := range args.AwsConnections {
		connectionArgs.externalVpnGatewayName = c.Name
		connectionArgs.peerGatewayInterfaceID = pulumi.Int(index)
		connectionArgs.routerName = args.RouterName
		connectionArgs.vpnGatewayURL = args.GcpVpnGatewayURL

		vpnConnection, err := newConnection(ctx, fmt.Sprintf("%s-%d", name, index), connectionArgs, pulumi.Parent(c))
		if err != nil {
			return err
		}

		vpnConnections = append(vpnConnections, vpnConnection)
	}

	c.Connections = vpnConnections

	return nil
}

func (args *ExternalGatewayArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *ExternalGatewayArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
