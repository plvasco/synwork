package vpn_test

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/networking/vpn"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewExternalGateway(t *testing.T) {
	t.Parallel()

	type want struct {
		Name                 string
		TunnelNames          []string
		RouterInterfaceNames []string
		RouterPeerNames      []string
	}

	type args struct {
		ctx  *pulumi.Context
		name string
		args *vpn.ExternalGatewayArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "Test should create a GCP external VPN connection and BGP interfaces",
			in: args{
				ctx:  &pulumi.Context{},
				name: "gcp-externalvpn-test",
				args: &vpn.ExternalGatewayArgs{
					AwsConnections: []*vpn.ConnectionArgs{
						{
							ExternalInterfaceIP: pulumi.String("10.0.0.1"),
							Interface:           pulumi.Int(0),
							InternalInterfaceIP: pulumi.String("10.0.0.1"),
							InternalPeerIP:      pulumi.String("172.16.0.1"),
							InternalCIDR:        pulumi.String("10.0.0.0/32"),
							SharedKey:           pulumi.String("fakesharedkey"),
							RemoteASN:           pulumi.Int(123456),
						},
						{
							ExternalInterfaceIP: pulumi.String("10.0.0.2"),
							Interface:           pulumi.Int(0),
							InternalInterfaceIP: pulumi.String("10.0.0.2"),
							InternalPeerIP:      pulumi.String("172.16.0.2"),
							InternalCIDR:        pulumi.String("10.0.0.0/32"),
							SharedKey:           pulumi.String("fakesharedkey"),
							RemoteASN:           pulumi.Int(123456),
						},
						{
							ExternalInterfaceIP: pulumi.String("10.0.0.1"),
							Interface:           pulumi.Int(1),
							InternalInterfaceIP: pulumi.String("10.0.0.1"),
							InternalPeerIP:      pulumi.String("172.16.0.1"),
							InternalCIDR:        pulumi.String("10.0.0.0/32"),
							SharedKey:           pulumi.String("fakesharedkey"),
							RemoteASN:           pulumi.Int(123456),
						},
						{
							ExternalInterfaceIP: pulumi.String("10.0.0.2"),
							Interface:           pulumi.Int(1),
							InternalInterfaceIP: pulumi.String("10.0.0.2"),
							InternalPeerIP:      pulumi.String("172.16.0.2"),
							InternalCIDR:        pulumi.String("10.0.0.0/32"),
							SharedKey:           pulumi.String("fakesharedkey"),
							RemoteASN:           pulumi.Int(123456),
						},
					},
					GcpVpnGatewayURL: pulumi.String("test-vpn-gateway"),
					RouterName:       pulumi.String("test-router"),
				},
			},
			want: want{
				Name: "test-extgw",
				TunnelNames: []string{
					"test-0-tn",
					"test-1-tn",
					"test-2-tn",
					"test-3-tn",
				},
				RouterInterfaceNames: []string{
					"test-0-ri",
					"test-1-ri",
					"test-2-ri",
					"test-3-ri",
				},
				RouterPeerNames: []string{
					"test-0-peer",
					"test-1-peer",
					"test-2-peer",
					"test-3-peer",
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := vpn.NewExternalGateway(ctx, "test", tt.in.args)
				if err != nil {
					return err
				}

				got.Name.ApplyT(func(name string) bool {
					assert.Equal(t, tt.want.Name, name)

					return true
				})

				for _, vpnConnection := range got.Connections {
					vpnConnection.TunnelName.ApplyT(func(name string) bool {
						assert.Contains(t, tt.want.TunnelNames, name)

						return true
					})

					vpnConnection.RouterInterfaceName.ApplyT(func(name string) bool {
						assert.Contains(t, tt.want.RouterInterfaceNames, name)

						return true
					})

					vpnConnection.RouterPeerName.ApplyT(func(name string) bool {
						assert.Contains(t, tt.want.RouterPeerNames, name)

						return true
					})
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.GCPMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestExternalGatewayArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *vpn.ExternalGatewayArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"awsConnections": [
					{
						"externalInterfaceIP": "203.0.113.1",
						"interface": 1,
						"internalInterfaceIP": "10.0.0.1",
						"internalPeerIP": "10.0.0.2",
						"internalCIDR": "10.0.0.0/24",
						"sharedKey": "test-shared-key",
						"remoteASN": 65000
					}
				],
				"gcpVpnGatewayURL": "https://gcp.example.com/vpn-gateway",
				"routerName": "my-router",
				"redundancyType": "TWO_IPS_REDUNDANCY"
			}`,
			want: &vpn.ExternalGatewayArgs{
				AwsConnections: []*vpn.ConnectionArgs{
					{
						ExternalInterfaceIP: pulumi.String("203.0.113.1"),
						Interface:           pulumi.Int(1),
						InternalInterfaceIP: pulumi.String("10.0.0.1"),
						InternalPeerIP:      pulumi.String("10.0.0.2"),
						InternalCIDR:        pulumi.String("10.0.0.0/24"),
						SharedKey:           pulumi.String("test-shared-key"),
						RemoteASN:           pulumi.Int(65000),
					},
				},
				GcpVpnGatewayURL: pulumi.String("https://gcp.example.com/vpn-gateway"),
				RouterName:       pulumi.String("my-router"),
				RedundancyType:   pulumi.String("TWO_IPS_REDUNDANCY"),
			},
			wantErr: false,
		},
		{
			name: "malformed JSON with incorrect type",
			input: `{
				"awsConnections": "invalid",
				"gcpVpnGatewayURL": 123,
				"routerName": true,
				"redundancyType": 456
			}`, // Incorrect types for all fields
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args vpn.ExternalGatewayArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
