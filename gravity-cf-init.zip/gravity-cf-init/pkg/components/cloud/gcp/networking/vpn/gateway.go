package vpn

import (
	"errors"
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/compute"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const gatewayComponentName = "gravity:gcp:network:vpn:gateway"

var ErrRequiredArgumentNetworkID = errors.New("required argument NetworkID is missing")

type Gateway struct {
	pulumi.ResourceState
	HaVpnGatewayID     pulumi.StringOutput      `pulumi:"haVpnGatewayID"`
	HaVpnGatewayURL    pulumi.StringOutput      `pulumi:"haVpnGatewayURL"`
	RouterASN          pulumi.IntOutput         `pulumi:"routerASN"`
	RouterName         pulumi.StringOutput      `pulumi:"routerName"`
	RouterID           pulumi.StringOutput      `pulumi:"routerID"`
	RouterInterfaceIPs pulumi.StringArrayOutput `pulumi:"routerInterfaceIPs"`
}

type GatewayArgs struct {
	NetworkID pulumi.StringInput `pulumi:"networkID" validate:"required"`
	Region    pulumi.StringInput `pulumi:"region"`
	RouterASN pulumi.IntInput    `pulumi:"routerASN" validate:"default=65534"`
}

func NewGateway(ctx *pulumi.Context, name string, args *GatewayArgs, opts ...pulumi.ResourceOption) (*Gateway, error) {
	component := &Gateway{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(gatewayComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", gatewayComponentName, name, err)
	}

	if err := component.createGateway(ctx, name+"-gateway", args); err != nil {
		return nil, err
	}

	if err := component.createCloudRouter(ctx, name+"-cloud-router", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"routerASN":    component.RouterASN,
		"routerIntIPs": component.RouterInterfaceIPs,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", gatewayComponentName, name, err)
	}

	return component, nil
}

func (c *Gateway) createGateway(ctx *pulumi.Context, name string, args *GatewayArgs) error {
	// Create a VPN Gateway in the GCP VPC
	haVpnGateway, err := compute.NewHaVpnGateway(ctx, name, &compute.HaVpnGatewayArgs{
		Network:          args.NetworkID,
		Region:           args.Region,
		GatewayIpVersion: pulumi.String("IPV4"),
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create ha vpn gateway, %w", err)
	}

	ipAddresses, ok := haVpnGateway.VpnInterfaces.ApplyT(func(vpnInterfaces []compute.HaVpnGatewayVpnInterface) []string {
		results := []string{}

		for _, item := range vpnInterfaces {
			results = append(results, *item.IpAddress)
		}

		return results
	}).(pulumi.StringArrayOutput)
	if !ok {
		panic("unable to convert ipaddresses to string array")
	}

	c.RouterInterfaceIPs = ipAddresses
	c.HaVpnGatewayID = haVpnGateway.ID().ToStringOutput()
	c.HaVpnGatewayURL = haVpnGateway.SelfLink

	return nil
}

func (c *Gateway) createCloudRouter(ctx *pulumi.Context, name string, args *GatewayArgs) error {
	// Create a Cloud Router in the GCP VPC
	router, err := compute.NewRouter(ctx, name, &compute.RouterArgs{
		Bgp: &compute.RouterBgpArgs{
			AdvertiseMode:    pulumi.String("CUSTOM"),
			AdvertisedGroups: pulumi.ToStringArray([]string{"ALL_SUBNETS"}),
			Asn:              args.RouterASN,
		},
		Network: args.NetworkID,
		Region:  args.Region,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create vpn router, %w", err)
	}

	c.RouterASN = router.Bgp.Asn().Elem()
	c.RouterName = router.Name
	c.RouterID = router.ID().ToStringOutput()

	return nil
}

func (args *GatewayArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *GatewayArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
