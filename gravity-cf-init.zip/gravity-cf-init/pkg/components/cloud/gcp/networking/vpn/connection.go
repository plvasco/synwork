package vpn

import (
	"fmt"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi-gcp/sdk/v8/go/gcp/compute"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

const connectionComponentName = "gravity:gcp:networking:vpn:connection"

type Connection struct {
	pulumi.ResourceState
	TunnelName          pulumi.StringOutput `pulumi:"tunnelName"`
	TunnelSelfLink      pulumi.StringOutput `pulumi:"tunnelSelfLink"`
	InternalPeerIP      pulumi.StringOutput `pulumi:"internalPeerIP"`
	RouterInterfaceName pulumi.StringOutput `pulumi:"routerInterfaceName"`
	RouterPeerName      pulumi.StringOutput `pulumi:"routerPeerName"`
}

type ConnectionArgs struct {
	ExternalInterfaceIP pulumi.StringInput `pulumi:"externalInterfaceIP" validate:"required"`
	Interface           pulumi.IntInput    `pulumi:"interface"           validate:"required"`
	InternalInterfaceIP pulumi.StringInput `pulumi:"internalInterfaceIP" validate:"required"`
	InternalPeerIP      pulumi.StringInput `pulumi:"internalPeerIP"      validate:"required"`
	InternalCIDR        pulumi.StringInput `pulumi:"internalCIDR"        validate:"required"`
	SharedKey           pulumi.StringInput `pulumi:"sharedKey"           validate:"required"`
	RemoteASN           pulumi.IntInput    `pulumi:"remoteASN"           validate:"required"`
	// internal inputs
	peerGatewayInterfaceID pulumi.IntInput
	routerName             pulumi.StringInput
	vpnGatewayURL          pulumi.StringInput
	externalVpnGatewayName pulumi.StringInput
}

func newConnection(ctx *pulumi.Context, name string, args *ConnectionArgs, opts ...pulumi.ResourceOption) (*Connection, error) {
	component := &Connection{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(connectionComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", connectionComponentName, name, err)
	}

	if err := component.createVPNTunnel(ctx, name+"-tn", args); err != nil {
		return nil, err
	}

	if err := component.createRouterInterface(ctx, name+"-ri", args); err != nil {
		return nil, err
	}

	if err := component.createRouterBGPPeer(ctx, name+"-peer", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{
		"tunnelName":          component.TunnelName,
		"tunnelSelfLink":      component.TunnelSelfLink,
		"internalPeerIP":      component.InternalPeerIP,
		"routerInterfaceName": component.RouterInterfaceName,
	}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", connectionComponentName, name, err)
	}

	return component, nil
}

func (c *Connection) createVPNTunnel(ctx *pulumi.Context, name string, args *ConnectionArgs) error {
	vpnTunnel, err := compute.NewVPNTunnel(ctx, name, &compute.VPNTunnelArgs{
		PeerExternalGateway:          args.externalVpnGatewayName,
		PeerExternalGatewayInterface: args.peerGatewayInterfaceID,
		Router:                       args.routerName,
		SharedSecret:                 args.SharedKey,
		VpnGateway:                   args.vpnGatewayURL,
		VpnGatewayInterface:          args.Interface,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create VPN connection %s, %w", name, err)
	}

	c.TunnelName = vpnTunnel.Name
	c.TunnelSelfLink = vpnTunnel.SelfLink
	c.InternalPeerIP = vpnTunnel.PeerIp

	return nil
}

func (c *Connection) createRouterInterface(ctx *pulumi.Context, name string, args *ConnectionArgs) error {
	routerInterface, err := compute.NewRouterInterface(ctx, name, &compute.RouterInterfaceArgs{
		Router:    args.routerName,
		VpnTunnel: c.TunnelSelfLink,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create router interface %s, %w", name, err)
	}

	c.RouterInterfaceName = routerInterface.Name

	return nil
}

func (c *Connection) createRouterBGPPeer(ctx *pulumi.Context, name string, args *ConnectionArgs) error {
	routerPeer, err := compute.NewRouterPeer(ctx, name, &compute.RouterPeerArgs{
		Interface:     c.RouterInterfaceName,
		IpAddress:     args.InternalPeerIP,
		PeerAsn:       args.RemoteASN,
		PeerIpAddress: args.InternalInterfaceIP,
		Router:        args.routerName,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create router bgp peer %s, %w", name, err)
	}

	c.RouterPeerName = routerPeer.Name

	return nil
}

func (args *ConnectionArgs) validate() error {
	if err := utils.ValidateStruct(args); err != nil {
		return fmt.Errorf("%T validation failed: %w", args, err)
	}

	return nil
}

func (args *ConnectionArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, args); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", args, err)
	}

	return nil
}
