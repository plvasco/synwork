package vpn_test

import (
	"testing"

	networking "code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cloud/gcp/networking/vpn"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

func TestNewGateway(t *testing.T) {
	t.Parallel()

	type want struct {
		HaVPNGatewayID     string
		RouterASN          int
		RouterID           string
		RouterInterfaceIPs []string
	}

	type args struct {
		args *networking.GatewayArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should create a GCP VPN Gateway, Cloud Router and interfaces",
			in: args{
				args: &networking.GatewayArgs{
					RouterASN: pulumi.Int(65534),
					NetworkID: pulumi.String("vpc-id"),
					Region:    pulumi.String("region"),
				},
			},
			want: want{
				HaVPNGatewayID:     "test-gateway_id",
				RouterASN:          65534,
				RouterID:           "test-cloud-router_id",
				RouterInterfaceIPs: []string{},
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := networking.NewGateway(ctx, "test", tt.in.args)
				if err != nil {
					return err
				}

				wanted := tt.want

				pulumi.All(got.HaVpnGatewayID, got.RouterASN, got.RouterID, got.RouterInterfaceIPs).ApplyT(func(all []interface{}) bool {
					haVpnGatewayID := all[0].(string)
					routerAsn := all[1].(int)
					routerID := all[2].(string)
					routerIps := all[3].([]string)

					assert.Equal(t, wanted.HaVPNGatewayID, haVpnGatewayID)
					assert.Equal(t, wanted.RouterASN, routerAsn)
					assert.Equal(t, wanted.RouterID, routerID)
					assert.Equal(t, wanted.RouterInterfaceIPs, routerIps)

					return true
				})

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.GCPMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
