package configs_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cluster/configs"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSecrets_createSecrets(t *testing.T) {
	t.Parallel()

	type want struct {
		data map[string]any
		name map[string]string
	}

	type args struct {
		name string
		args configs.SecretsMapArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "test should create k8s secrets",
			in: args{
				name: "test_secret",
				args: configs.SecretsMapArgs{
					"test-regsecret": {
						Namespace: pulumi.String("kube-system"),
						Data: pulumi.ToStringMap(map[string]string{
							".dockerconfigjson": `eyJhdXRocyI6eyJyZWdpc3RyeS50ZXN0LmNvbSI6eyJ1c2VybmFtZSI6InJvYm90LXRlc3QiLCJwYXNzd29yZCI6InRlc3RwYXNzIn19fQo=`,
						}),
						Type: pulumi.String("kubernetes.io/dockerconfigjson"),
					},
					"test-secret2": {
						Namespace: pulumi.String("kube-system"),
						Data:      pulumi.ToStringMap(map[string]string{".dockerconfigjson": `{"auths":{"registry.test.com":{"username":"robot-test","password":"testpass"}}}`}),
						Type:      pulumi.String("Opaque"),
					},
				},
			},
			want: want{
				data: map[string]any{
					"test-regsecret-kube-system": map[string]string{
						".dockerconfigjson": `eyJhdXRocyI6eyJyZWdpc3RyeS50ZXN0LmNvbSI6eyJ1c2VybmFtZSI6InJvYm90LXRlc3QiLCJwYXNzd29yZCI6InRlc3RwYXNzIn19fQo=`,
					},
					"test-secret2-kube-system": map[string]string{
						".dockerconfigjson": `{"auths":{"registry.test.com":{"username":"robot-test","password":"testpass"}}}`,
					},
				},
				name: map[string]string{
					"test-regsecret-kube-system": "test-regsecret",
					"test-secret2-kube-system":   "test-secret2",
				},
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				got, err := configs.NewSecrets(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				for key, secret := range got.SecretOutputs {
					dataOut := secret.Data.ApplyT(func(data map[string]string) map[string]string {
						assert.Equal(t, tt.want.data[key], data)
						require.NotNil(t, data)

						return data
					})
					require.NotNil(t, dataOut)

					secret.Metadata.Name().Elem().ApplyT(func(name string) string {
						assert.Equal(t, tt.want.name[key], name)
						require.NotNil(t, name)

						return ""
					})
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}
