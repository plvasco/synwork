package configs

import (
	"errors"
	"fmt"

	coreV1 "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes/core/v1"
	metav1 "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes/meta/v1"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

//nolint:gosec // This is not a secret, just package name
const secretsComponentName = "gravity:configs:secrets"

var ErrRequiredArgumentSecrets = errors.New("required argument Secrets are missing")

type Secrets struct {
	pulumi.ResourceState
	SecretOutputs map[string]*coreV1.Secret
}
type SecretsMapArgs map[string]*SecretArgs

type SecretArgs struct {
	Namespace pulumi.String    `pulumi:"namespace"`
	Data      pulumi.StringMap `pulumi:"data"`
	Type      pulumi.String    `pulumi:"Type"`
}

func NewSecrets(ctx *pulumi.Context, name string, args SecretsMapArgs, opts ...pulumi.ResourceOption) (*Secrets, error) {
	component := &Secrets{}

	if err := args.validate(); err != nil {
		return nil, err
	}

	if err := ctx.RegisterComponentResource(secretsComponentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", secretsComponentName, name, err)
	}

	if err := component.createSecrets(ctx, name, args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", secretsComponentName, name, err)
	}

	return component, nil
}

func (args *SecretsMapArgs) validate() error {
	if args == nil {
		args = &SecretsMapArgs{}
	}

	if args == nil {
		return ErrRequiredArgumentSecrets
	}

	return nil
}

func (c *Secrets) createSecrets(ctx *pulumi.Context, name string, args SecretsMapArgs) error {
	// Loop through secret array and create all secrets defined
	secretOutputs := map[string]*coreV1.Secret{}

	for secretName, secret := range args {
		metadata := &metav1.ObjectMetaArgs{
			Name:      pulumi.String(secretName),
			Namespace: secret.Namespace,
		}

		secretOutput, err := coreV1.NewSecret(ctx, name+secretName, &coreV1.SecretArgs{
			Data:     secret.Data,
			Metadata: metadata,
			Type:     secret.Type,
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to create %v secret, %w", secretName, err)
		}

		keyName := fmt.Sprintf("%s-%s", secretName, secret.Namespace)

		secretOutputs[keyName] = secretOutput
	}

	c.SecretOutputs = secretOutputs

	return nil
}
