package talos

import (
	"encoding/json"
	"errors"
	"fmt"
	"slices"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	k8s "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes"
	helm "github.com/pulumi/pulumi-kubernetes/sdk/v4/go/kubernetes/helm/v3"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumix"
	"github.com/pulumiverse/pulumi-talos/sdk/go/talos/client"
	talosCluster "github.com/pulumiverse/pulumi-talos/sdk/go/talos/cluster"
	"github.com/pulumiverse/pulumi-talos/sdk/go/talos/machine"
)

const componentName = "gravity:talos:cluster"

var (
	ErrRequiredArgumentK8sVersion = errors.New("required argument KubernetesVersion is missing")
	ErrUnsupportedK8sVersion      = errors.New("unsupported k8s version specified")
)

type Cluster struct {
	pulumi.ResourceState
	TalosBoot           *machine.Bootstrap                `pulumi:"talosBoot"`
	TalosSecrets        *machine.Secrets                  `pulumi:"talosSecrets"`
	ClientConfiguration machine.ClientConfigurationOutput `pulumi:"clientConfiguration"`
	TalosConfig         pulumi.StringOutput               `pulumi:"talosConfig"`
	KubeconfigJSON      pulumi.StringOutput               `pulumi:"talosKubeconfig"`
	TalosClusterName    pulumi.StringOutput               `pulumi:"talosClusterName"`
	Endpoint            pulumi.StringOutput               `pulumi:"endpoint"`
}

type ClusterArgs struct {
	ControlPlane        *MachineArgs       `pulumi:"controlPlane"`
	Workers             *MachineArgs       `pulumi:"workers"`
	LoadBalancerDNS     pulumi.StringInput `pulumi:"loadBalancerDNS"`
	KubernetesVersion   pulumi.StringInput `pulumi:"kubernetesVersion"   validate:"required"`
	ImagePullSecretName pulumi.StringInput `pulumi:"imagePullSecretName" validate:"default=private-registry"`
	CiliumRegistry      pulumi.StringInput `pulumi:"ciliumRegistry"      validate:"default=quay.io/cilium"`
	CiliumVersion       pulumi.StringInput `pulumi:"ciliumVersion"       validate:"required"`
}

type MachineArgs struct {
	PublicIPs pulumi.StringArray `pulumi:"publicIPs"`
	NodeIPs   pulumi.StringArray `pulumi:"nodeIPs"`
	IDs       pulumi.StringArray `pulumi:"ids"`
	OSVersion pulumi.StringInput `pulumi:"osVersion"`
}

func NewCluster(ctx *pulumi.Context, name string, args *ClusterArgs, opts ...pulumi.ResourceOption) (*Cluster, error) {
	if err := args.validate(); err != nil {
		return nil, err
	}

	component := &Cluster{}

	if err := ctx.RegisterComponentResource(componentName, name, component, opts...); err != nil {
		return nil, fmt.Errorf("unable to register component resource [%s] %s, %w", componentName, name, err)
	}

	if err := component.createSecrets(ctx, name+"-secrets"); err != nil {
		return nil, err
	}

	if err := component.configureNodes(ctx, name+"-config", args); err != nil {
		return nil, err
	}

	component.getTalosConfig(ctx, args)

	if err := component.createKubeconfig(ctx, name+"-k8s", args); err != nil {
		return nil, err
	}

	if err := component.installCiliumChart(ctx, name+"-cilium", args); err != nil {
		return nil, err
	}

	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{}); err != nil {
		return nil, fmt.Errorf("unable to register [%s] %s resource outputs, %w", componentName, name, err)
	}

	ctx.Export("talosctlK8sCfg", component.KubeconfigJSON)

	return component, nil
}

func (c *Cluster) createSecrets(ctx *pulumi.Context, name string) error {
	talosSecrets, err := machine.NewSecrets(ctx, name, nil, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create talos secrets %s: %w", name, err)
	}

	c.TalosSecrets = talosSecrets

	return nil
}

func (c *Cluster) configureNodes(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	controlPlaneConfig := machine.GetConfigurationOutput(ctx, machine.GetConfigurationOutputArgs{
		ClusterEndpoint:   pulumi.Sprintf("https://%v:443", args.LoadBalancerDNS),
		ClusterName:       pulumi.String(name),
		Docs:              pulumi.BoolPtr(false),
		Examples:          pulumi.BoolPtr(false),
		KubernetesVersion: args.KubernetesVersion,
		MachineSecrets:    c.TalosSecrets.ToSecretsOutput().MachineSecrets(),
		MachineType:       pulumi.String("controlplane"),
		TalosVersion:      args.ControlPlane.OSVersion,
	}, pulumi.Parent(c))

	workerConfig := machine.GetConfigurationOutput(ctx, machine.GetConfigurationOutputArgs{
		ClusterEndpoint:   pulumi.Sprintf("https://%v:443", args.LoadBalancerDNS),
		ClusterName:       pulumi.String(name),
		Docs:              pulumi.BoolPtr(false),
		Examples:          pulumi.BoolPtr(false),
		KubernetesVersion: args.KubernetesVersion,
		MachineSecrets:    c.TalosSecrets.ToSecretsOutput().MachineSecrets(),
		MachineType:       pulumi.String("worker"),
		TalosVersion:      args.Workers.OSVersion,
	}, pulumi.Parent(c))

	c.TalosClusterName = controlPlaneConfig.ClusterName()

	cpConfigJSON := pulumix.ApplyErr(args.LoadBalancerDNS.ToStringOutput(), func(lbName string) (string, error) {
		tmpJSONcp, err := json.Marshal(map[string]interface{}{
			"machine": map[string]interface{}{
				"certSANs": []string{lbName},
				"kubelet": map[string]interface{}{
					"nodeIP": map[string]interface{}{
						"validSubnets": []string{"10.0.0.0/16"},
					},
				},
			},
			"cluster": map[string]interface{}{
				"etcd": map[string]interface{}{
					"advertisedSubnets": []string{"10.0.0.0/16"},
				},
				"network": map[string]interface{}{
					"cni": map[string]interface{}{
						"name": "none",
					},
				},
				"proxy": map[string]interface{}{
					"disabled": true,
				},
			},
		})
		if err != nil {
			return string(tmpJSONcp), fmt.Errorf("unable to create talos config json %s: %w", name, err)
		}

		return string(tmpJSONcp), nil
	})

	jsonCp := pulumix.Cast[pulumi.StringOutput](cpConfigJSON)

	wkConfigJSON := pulumix.ApplyErr(args.LoadBalancerDNS.ToStringOutput(), func(lbName string) (string, error) {
		tmpJSONcp, err := json.Marshal(map[string]interface{}{
			"machine": map[string]interface{}{
				"certSANs": []string{lbName},
				"kubelet": map[string]interface{}{
					"nodeIP": map[string]interface{}{
						"validSubnets": []string{"10.0.0.0/16"},
					},
				},
			},
			"cluster": map[string]interface{}{
				"network": map[string]interface{}{
					"cni": map[string]interface{}{
						"name": "none",
					},
				},
				"proxy": map[string]interface{}{
					"disabled": true,
				},
			},
		})
		if err != nil {
			return string(tmpJSONcp), fmt.Errorf("unable to create talos config json %s: %w", name, err)
		}

		return string(tmpJSONcp), nil
	})

	jsonWkr := pulumix.Cast[pulumi.StringOutput](wkConfigJSON)

	for index := range args.ControlPlane.PublicIPs {
		_, err := machine.NewConfigurationApply(ctx, fmt.Sprintf("%s-cp-0%d", name, index), &machine.ConfigurationApplyArgs{
			ClientConfiguration:       c.TalosSecrets.ClientConfiguration,
			MachineConfigurationInput: controlPlaneConfig.MachineConfiguration(),
			Node:                      args.ControlPlane.PublicIPs[index],
			ConfigPatches: pulumi.StringArray{
				jsonCp,
			},
		}, pulumi.Parent(c))
		if err != nil {
			return fmt.Errorf("unable to apply new configuration to node %v, %w",
				args.ControlPlane.IDs[index], err)
		}
	}

	for index := range args.Workers.PublicIPs {
		if _, err := machine.NewConfigurationApply(ctx, fmt.Sprintf("%s-worker-%d", name, index), &machine.ConfigurationApplyArgs{
			ClientConfiguration:       c.TalosSecrets.ClientConfiguration,
			MachineConfigurationInput: workerConfig.MachineConfiguration(),
			Node:                      args.Workers.PublicIPs[index],
			ConfigPatches: pulumi.StringArray{
				jsonWkr,
			},
		}, pulumi.Parent(c)); err != nil {
			return fmt.Errorf("unable to apply new configuration to node %v, %w",
				args.Workers.IDs[index], err)
		}
	}

	boot, err := machine.NewBootstrap(ctx, "control-plane-bootstrap", &machine.BootstrapArgs{
		ClientConfiguration: c.TalosSecrets.ClientConfiguration,
		Node:                args.ControlPlane.PublicIPs[0],
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("error bootstrapping first node, %w", err)
	}

	c.TalosBoot = boot

	return nil
}

func (c *Cluster) getTalosConfig(ctx *pulumi.Context, args *ClusterArgs) {
	talosClientConfig := client.GetConfigurationOutput(ctx, client.GetConfigurationOutputArgs{
		ClientConfiguration: client.GetConfigurationClientConfigurationArgs{
			CaCertificate:     c.TalosSecrets.ClientConfiguration.CaCertificate(),
			ClientCertificate: c.TalosSecrets.ClientConfiguration.ClientCertificate(),
			ClientKey:         c.TalosSecrets.ClientConfiguration.ClientKey(),
		},
		ClusterName: c.TalosClusterName,
		Endpoints: pulumi.StringArray{
			args.LoadBalancerDNS,
		},
		Nodes: pulumi.StringArray{
			args.LoadBalancerDNS,
		},
	}, pulumi.Parent(c))

	c.TalosConfig = talosClientConfig.TalosConfig()
	ctx.Export("talosConfig", c.TalosConfig)
}

func (c *Cluster) createKubeconfig(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	k8Conf, err := talosCluster.NewKubeconfig(ctx, name, &talosCluster.KubeconfigArgs{
		ClientConfiguration: talosCluster.KubeconfigClientConfigurationArgs{
			CaCertificate:     c.TalosSecrets.ClientConfiguration.CaCertificate(),
			ClientCertificate: c.TalosSecrets.ClientConfiguration.ClientCertificate(),
			ClientKey:         c.TalosSecrets.ClientConfiguration.ClientKey(),
		},
		Node: args.LoadBalancerDNS,
	}, pulumi.Parent(c), pulumi.DependsOn([]pulumi.Resource{c.TalosBoot}))
	if err != nil {
		return fmt.Errorf("error getting kubeconfig for privateIP, %w", err)
	}

	ctx.Export("talosctlK8sCfg", k8Conf.KubeconfigRaw)

	c.KubeconfigJSON = k8Conf.KubeconfigRaw

	return nil
}

func (c *Cluster) installCiliumChart(ctx *pulumi.Context, name string, args *ClusterArgs) error {
	provider, err := k8s.NewProvider(ctx, name, &k8s.ProviderArgs{
		EnableServerSideApply: pulumi.Bool(true),
		Kubeconfig:            c.KubeconfigJSON,
	}, pulumi.Parent(c))
	if err != nil {
		return fmt.Errorf("unable to create k8s provider, %w", err)
	}

	if _, err := helm.NewRelease(ctx, name, &helm.ReleaseArgs{
		Chart:   pulumi.String("cilium"),
		Version: args.CiliumVersion,
		RepositoryOpts: &helm.RepositoryOptsArgs{
			Repo: pulumi.String("https://helm.cilium.io/"),
		},
		Values: pulumi.Map{
			"image": pulumi.Map{
				"repository": pulumi.Sprintf("%s/cilium", args.CiliumRegistry),
				"useDigest":  pulumi.Bool(false),
			},

			"imagePullSecrets": pulumi.Array{
				pulumi.Map{
					"name": args.ImagePullSecretName,
				},
			},

			"agent":              pulumi.Bool(true),
			"preallocateBPFMaps": pulumi.Bool(false),
			"ipam": pulumi.Map{
				"operator": pulumi.Map{
					"clusterPoolIPv4PodCIDRList": pulumi.ToStringArray([]string{
						"192.168.0.0/24",
						"192.168.1.0/24",
						"192.168.2.0/24",
						"192.168.3.0/24",
						"192.168.4.0/24",
						"192.168.5.0/24",
					}),
					"clusterPoolIPv4MaskSize": pulumi.Int(24),
				},
			},

			"operator": pulumi.Map{
				"image": pulumi.Map{
					"repository": pulumi.Sprintf("%s/operator", args.CiliumRegistry),
					"useDigest":  pulumi.Bool(false),
				},
				"prometheus": pulumi.Map{
					"enabled": pulumi.Bool(true),
				},
				"serviceMonitor": pulumi.Map{
					"enabled": pulumi.Bool(false),
				},
			},

			"clustermesh": pulumi.Map{
				"apiserver": pulumi.Map{
					"image": pulumi.Map{
						"repository": pulumi.Sprintf("%s/clustermesh-apiserver", args.CiliumRegistry),
						"useDigest":  pulumi.Bool(false),
					},
					"metrics": pulumi.Map{
						"enabled": pulumi.Bool(true),
					},
					"serviceMonitor": pulumi.Map{
						"enabled": pulumi.Bool(false),
					},
					"tls": pulumi.Map{
						"auto": pulumi.Map{
							"method": pulumi.String("cronJob"),
						},
					},
				},
			},

			"kubeProxyReplacement": pulumi.Bool(true),
			"hubble": pulumi.Map{
				"ui": pulumi.Map{
					"enabled": pulumi.Bool(true),
				},
				"relay": pulumi.Map{
					"enabled": pulumi.Bool(true),
				},
			},
			"k8sServiceHost": pulumi.String("localhost"),
			"k8sServicePort": pulumi.Int(7445),
			"cgroup": pulumi.Map{
				"autoMount": pulumi.Map{
					"enabled": pulumi.Bool(true),
				},
				"hostRoot": pulumi.String("/sys/fs/cgroup"),
			},
			"securityContext": pulumi.Map{
				"capabilities": pulumi.Map{
					"ciliumAgent": pulumi.ToStringArray([]string{
						"CHOWN", "KILL", "NET_ADMIN", "NET_RAW", "IPC_LOCK", "SYS_ADMIN",
						"SYS_RESOURCE", "DAC_OVERRIDE", "FOWNER", "SETGID", "SETUID"}),
					"cleanCiliumState": pulumi.ToStringArray([]string{"NET_ADMIN", "SYS_ADMIN", "SYS_RESOURCE"}),
				},
			},
		},
		Namespace: pulumi.String("kube-system"),
	}, pulumi.Parent(c), pulumi.Provider(provider)); err != nil {
		return fmt.Errorf("unable to install cilium, %w", err)
	}

	return nil
}

func (a *ClusterArgs) validate() error {
	if err := utils.ValidateStruct(a); err != nil {
		return fmt.Errorf("%T validation failed: %w", a, err)
	}

	// required since the config will be applied but will fail on installing kubelet for talos if unsupported K8s version specified.
	var supportedK8sVersions = []string{
		"1.31.2",
		"1.30.0",
		"1.29.4",
		"1.28.9",
	}

	validatedVersion := pulumix.ApplyErr(a.KubernetesVersion.ToStringOutput(), func(version string) (string, error) {
		if !slices.Contains(supportedK8sVersions, version) {
			return "", ErrUnsupportedK8sVersion
		}

		return version, nil
	})

	a.KubernetesVersion = pulumix.Cast[pulumi.StringOutput](validatedVersion)

	return nil
}

func (a *ClusterArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", a, err)
	}

	return nil
}

func (a *MachineArgs) UnmarshalJSON(b []byte) error {
	if err := utils.UnmarshalPulumiArgs(b, a); err != nil {
		return fmt.Errorf("unable to unmarshal %T, %w", a, err)
	}

	return nil
}
