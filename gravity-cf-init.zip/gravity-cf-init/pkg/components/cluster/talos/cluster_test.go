package talos_test

import (
	"encoding/json"
	"reflect"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/cluster/talos"
	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/components/testutils"

	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/require"
)

func TestNewCluster(t *testing.T) {
	t.Parallel()

	type want struct {
		*talos.Cluster
	}

	type args struct {
		name string
		args *talos.ClusterArgs
	}

	tests := []struct {
		name    string
		in      args
		want    want
		wantErr bool
	}{
		{
			name: "Should create talos cluster",
			in: args{
				name: "test-cluster",
				args: &talos.ClusterArgs{
					ControlPlane: &talos.MachineArgs{
						PublicIPs: []pulumi.StringInput{pulumi.String("10.0.0.1/32"), pulumi.String("10.0.0.2/32"), pulumi.String("10.0.0.3/32")},
						NodeIPs:   []pulumi.StringInput{pulumi.String("10.0.1.1/32"), pulumi.String("10.0.1.2/32"), pulumi.String("10.0.1.3/32")},
						IDs:       []pulumi.StringInput{pulumi.String("1234567"), pulumi.String("567890"), pulumi.String("098765")},
						OSVersion: pulumi.String("v1.7.4"),
					},
					Workers: &talos.MachineArgs{
						PublicIPs: []pulumi.StringInput{pulumi.String("10.0.0.4/32"), pulumi.String("10.0.0.5/32"), pulumi.String("10.0.0.6/32")},
						NodeIPs:   []pulumi.StringInput{pulumi.String("10.0.1.4/32"), pulumi.String("10.0.1.5/32"), pulumi.String("10.0.1.6/32")},
						IDs:       []pulumi.StringInput{pulumi.String("3454245"), pulumi.String("966789"), pulumi.String("6896875")},
						OSVersion: pulumi.String("v1.7.4"),
					},
					CiliumVersion:     pulumi.String("v1.14.5"),
					LoadBalancerDNS:   pulumi.String("test-elb"),
					KubernetesVersion: pulumi.String("1.30.0"),
				},
			},
			want: want{
				Cluster: &talos.Cluster{
					ResourceState: pulumi.ResourceState{},
					TalosConfig:   pulumi.StringOutput{},
				},
			},
			wantErr: false,
		},
		{
			name: "cluster-should-fail-no-k8s-version-argument",
			in: args{
				name: "test-cluster2",
				args: &talos.ClusterArgs{
					ControlPlane: &talos.MachineArgs{
						PublicIPs: []pulumi.StringInput{pulumi.String("10.0.0.1/32"), pulumi.String("10.0.0.2/32"), pulumi.String("10.0.0.3/32")},
						NodeIPs:   []pulumi.StringInput{pulumi.String("10.0.1.1/32"), pulumi.String("10.0.1.2/32"), pulumi.String("10.0.1.3/32")},
						IDs:       []pulumi.StringInput{pulumi.String("1234567"), pulumi.String("567890"), pulumi.String("098765")},
						OSVersion: pulumi.String("v1.7.4"),
					},
					Workers: &talos.MachineArgs{
						PublicIPs: []pulumi.StringInput{pulumi.String("10.0.0.4/32"), pulumi.String("10.0.0.5/32"), pulumi.String("10.0.0.6/32")},
						NodeIPs:   []pulumi.StringInput{pulumi.String("10.0.1.4/32"), pulumi.String("10.0.1.5/32"), pulumi.String("10.0.1.6/32")},
						IDs:       []pulumi.StringInput{pulumi.String("3454245"), pulumi.String("966789"), pulumi.String("6896875")},
						OSVersion: pulumi.String("v1.7.4"),
					},
					LoadBalancerDNS: pulumi.String("test-elb"),
					CiliumVersion:   pulumi.String("v1.14.5"),
				},
			},
			want: want{
				Cluster: &talos.Cluster{
					ResourceState: pulumi.ResourceState{},
					TalosConfig:   pulumi.StringOutput{},
				},
			},
			wantErr: true,
		},
		{
			name: "cluster-should-fail-unsupported-k8s-version",
			in: args{
				name: "cluster2-fail",
				args: &talos.ClusterArgs{
					ControlPlane: &talos.MachineArgs{
						PublicIPs: []pulumi.StringInput{pulumi.String("168.10.12.1/32"), pulumi.String("168.10.12.2/32"), pulumi.String("168.10.12.3/32")},
						NodeIPs:   []pulumi.StringInput{pulumi.String("168.10.13.1/32"), pulumi.String("168.10.13.2/32"), pulumi.String("168.10.13.3/32")},
						IDs:       []pulumi.StringInput{pulumi.String("1234567"), pulumi.String("567890"), pulumi.String("098765")},
						OSVersion: pulumi.String("v1.7.4"),
					},
					Workers: &talos.MachineArgs{
						PublicIPs: []pulumi.StringInput{pulumi.String("168.10.12.4/32"), pulumi.String("168.10.12.5/32"), pulumi.String("168.10.12.6/32")},
						NodeIPs:   []pulumi.StringInput{pulumi.String("168.10.13.4/32"), pulumi.String("168.10.13.5/32"), pulumi.String("168.10.13.6/32")},
						IDs:       []pulumi.StringInput{pulumi.String("3454245"), pulumi.String("966789"), pulumi.String("6896875")},
						OSVersion: pulumi.String("v1.7.4"),
					},
					LoadBalancerDNS:   pulumi.String("test-elb"),
					KubernetesVersion: pulumi.String("1.19.0"),
				},
			},
			want:    want{},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				_, err := talos.NewCluster(ctx, tt.in.name, tt.in.args)
				if err != nil {
					return err
				}

				return nil
			}, testutils.WithMocksAndConfig("project", "stack", nil, new(testutils.AWSMocks)))
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestClusterArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *talos.ClusterArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"controlPlane": {
					"publicIPs": ["192.168.1.1"],
					"nodeIPs": ["10.0.0.1"],
					"ids": ["id-123"],
					"osVersion": "v1.2.3"
				},
				"workers": {
					"publicIPs": ["192.168.1.2", "192.168.1.3"],
					"nodeIPs": ["10.0.0.2", "10.0.0.3"],
					"ids": ["id-456", "id-789"],
					"osVersion": "v1.2.4"
				},
				"loadBalancerDNS": "lb.example.com",
				"kubernetesVersion": "1.21",
				"imagePullSecretName": "custom-registry",
				"ciliumRegistry": "quay.io/cilium",
				"ciliumVersion": "1.11"
			}`,
			want: &talos.ClusterArgs{
				ControlPlane: &talos.MachineArgs{
					PublicIPs: pulumi.StringArray{pulumi.String("192.168.1.1")},
					NodeIPs:   pulumi.StringArray{pulumi.String("10.0.0.1")},
					IDs:       pulumi.StringArray{pulumi.String("id-123")},
					OSVersion: pulumi.String("v1.2.3"),
				},
				Workers: &talos.MachineArgs{
					PublicIPs: pulumi.StringArray{pulumi.String("192.168.1.2"), pulumi.String("192.168.1.3")},
					NodeIPs:   pulumi.StringArray{pulumi.String("10.0.0.2"), pulumi.String("10.0.0.3")},
					IDs:       pulumi.StringArray{pulumi.String("id-456"), pulumi.String("id-789")},
					OSVersion: pulumi.String("v1.2.4"),
				},
				LoadBalancerDNS:     pulumi.String("lb.example.com"),
				KubernetesVersion:   pulumi.String("1.21"),
				ImagePullSecretName: pulumi.String("custom-registry"),
				CiliumRegistry:      pulumi.String("quay.io/cilium"),
				CiliumVersion:       pulumi.String("1.11"),
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"controlPlane": "invalid-control-plane", "kubernetesVersion": "1.21", "ciliumVersion": "1.11"}`, // controlPlane should be a struct, not a string
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"controlPlane": {"publicIPs": ["192.168.1.1"], "nodeIPs": ["10.0.0.1"]`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args talos.ClusterArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}

func TestMachineArgs_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   string
		want    *talos.MachineArgs
		wantErr bool
	}{
		{
			name: "valid input",
			input: `{
				"publicIPs": ["192.168.1.1", "192.168.1.2"],
				"nodeIPs": ["10.0.0.1", "10.0.0.2"],
				"ids": ["id-123", "id-456"],
				"osVersion": "v1.2.3"
			}`,
			want: &talos.MachineArgs{
				PublicIPs: pulumi.StringArray{pulumi.String("192.168.1.1"), pulumi.String("192.168.1.2")},
				NodeIPs:   pulumi.StringArray{pulumi.String("10.0.0.1"), pulumi.String("10.0.0.2")},
				IDs:       pulumi.StringArray{pulumi.String("id-123"), pulumi.String("id-456")},
				OSVersion: pulumi.String("v1.2.3"),
			},
			wantErr: false,
		},
		{
			name:    "invalid field type",
			input:   `{"publicIPs": "192.168.1.1", "nodeIPs": ["10.0.0.1"]}`, // publicIPs should be an array
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed JSON",
			input:   `{"publicIPs": ["192.168.1.1"], "nodeIPs": ["10.0.0.1"]`, // Missing closing bracket
			want:    nil,
			wantErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			var args talos.MachineArgs

			b := []byte(tc.input)
			err := json.Unmarshal(b, &args)

			if tc.wantErr {
				require.Error(t, err)

				return
			}

			require.NoError(t, err)

			if !reflect.DeepEqual(tc.want, &args) {
				t.Errorf("unexpected result: got %+v, want %+v", args, *tc.want)
			}
		})
	}
}
