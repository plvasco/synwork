# Gravity
* Question: should Core be renamed to Cloud? will core get confused with root?
you could have a structure like this with it:
```
Hitlist:
    Figure out how to set the provider to the IAM user getting created so that you can up from scratch, root accounts can not assume roles
    Only enable account in the region that we have declared - if possible
    Fix account name for org accounts - add in infra so it's not just org-account-randomstring
    Figure out why the cilium install isn't graceful, needs to be upped twice - service accounts hang even though they get created

components:
    cloud:
        aws:
            cluster:
                infrastructure.go
            networking:
                network.go
            root:
                root.go
                infrastructure.go

        azure:
        gcp:
        metal:
        vsphere:
        cluster:
            infrastructure.go
    cluster:
        talos:
            cluster.go

or  maybe

components:
    cluster:
        talos:
            cluster.go
        cloud:
            infrastructure.go <-- interface, Struct and Args lives here
            aws:
                infrastructure.go <-- methods go here embed cloud.Infrastructure
            azure:
            gcp:
            metal:
            vsphere:
    cloud:
        aws:
            network.go
            root.go
            infrastructure.go
```


* add validation methods to each arg struct
* add required argument errors and defaults to each validate method
* centralize common errors into the core package
* add pulumi struct tags to each component and args struct
* register outputs for each component
* ensure parents are set on all child objects to include lookups/gets
* build out tests more.
* for root create a createBootstrapCluster() method and call talos.NewCluster feeding in the args, no stack reference needed.
* RoadMap Ideas:
    - create a Customer componentResource that includes
        - Account/Role (stack reference OU from Root inside Odessy)
        - Provider using account
        - Cluster
        - Cosmos?
# Odessy:
* create stack reference object for gravity root to be used for lookups (this should not live in gravity as it is unique to second front)
* use stack reference object to look up TransitGatewayID and RootCIDRString from root and feed into new cluster
