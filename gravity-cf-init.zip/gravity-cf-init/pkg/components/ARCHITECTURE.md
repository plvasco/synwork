```mermaid
flowchart TD
Root([Root]) --> Organization
Root --> OrganizationalUnits
Root --> ServiceControlPolicies
Root --> Infrastructure

Organization -.-> OrganizationalUnits


Infrastructure([Infrastructure]) --> Account
OrganizationalUnits -.-> Account
Infrastructure --> TransitGateway
Infrastructure --> BootstrapCluster

BootstrapCluster([BootStrapCluster]) --> ClusterNetwork
BootstrapCluster --> TalosCluster([TalosCluster])

ClusterNetwork([ClusterNetwork]) --> VPC

VPC --> Subnet
VPC --> TransitGatewayAttachment
```
