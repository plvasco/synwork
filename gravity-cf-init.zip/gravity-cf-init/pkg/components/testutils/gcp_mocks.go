package testutils

import (
	"fmt"
	"strings"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type GCPMocks int

func (GCPMocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	outputs := args.Inputs.Mappable()
	outputs["name"] = args.Name

	switch args.TypeToken {
	case "gcp:organizations/project:Project":
		outputs["projectId"] = "mock-gcp-project"
	// case "gravity:gcp:cluster:gke":
	// 	outputs["name"] = args.Name
	case "gcp:container/cluster:Cluster":
		outputs["name"] = args.Name
	case "gcp:compute/vPNTunnel:VPNTunnel":
		outputs["peerIp"] = "0.0.0.0"
	}

	return args.Name + "_id", resource.NewPropertyMapFromMap(outputs), nil
}

func (GCPMocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	outputs := args.Args.Mappable()

	switch args.Token {
	case "gcp:index:getRegion":
		outputs["region"] = "us-east1"
	case "gcp:organizations/getOrganization:getOrganization":
		outputs["orgId"] = "123456789"
	case "gcp:organizations/getActiveFolder:getActiveFolder":
		outputs["id"] = outputs["displayName"]
	case "gcp:projects/getProject:getProject":
		outputs["projects"] = []any{
			map[string]any{
				"parent": map[string]any{
					"mock": "me",
				},
				"name":      strings.Split(fmt.Sprintf("%s", outputs["filter"]), ":")[1],
				"projectId": strings.Split(fmt.Sprintf("%s", outputs["filter"]), ":")[1],
				"number":    "service-project-number",
				"labels": map[string]any{
					"mock": "me",
				},
			},
		}
	case "gcp:kms/getKeyRings:getKeyRings":
		outputs["location"] = "us-east4"
		outputs["keyRings"] = []any{
			map[string]any{
				"id":   "encryption-key-12345",
				"name": "encryption-key",
			},
		}
	case "gcp:kms/getKMSCryptoKey:getKMSCryptoKey":
		outputs["id"] = "encryption-key-12345"
	case "gcp:compute/getNetworks:getNetworks":
		outputs["networks"] = []string{"mock-network"}
		outputs["project"] = "mock-project"
		outputs["selfLink"] = "host-network-self-link"
	}

	return resource.NewPropertyMapFromMap(outputs), nil
}
