package testutils

import (
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type AWSMocks int

func (AWSMocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	outputs := args.Inputs.Mappable()
	outputs["name"] = args.Name

	switch args.TypeToken {
	case "aws:organizations/organization:Organization":
		outputs["roots"] = []any{
			map[string]any{
				"id": "r-examplerootid",
			},
		}
	case "aws:ec2/vpc:Vpc":
		outputs["defaultRouteTableId"] = "defaultRTID"
		outputs["cidrBlock"] = "10.0.0.0/16"
	case "aws:ec2/customerGateway:CustomerGateway":
		outputs["arn"] = "superduper"
		outputs["ipAddress"] = "1.2.3.4"
	case "aws:ec2/internetGateway:InternetGateway":
		outputs["id"] = "test-igw-id"
	case "aws:ec2/natGateway:NatGateway":
		outputs["id"] = "test-ngw-id"
	case "aws:ec2transitgateway/vpcAttachment:VpcAttachment":
		outputs["id"] = "test-tgw-attachment-id"
	case "aws:ec2transitgateway/peeringAttachment:PeeringAttachment":
		outputs["id"] = "test-tgw-peering-attachment-id"
		outputs["peerTransitGatewayId"] = "tgw-6769"
		outputs["transitGatewayId"] = "tgw-12345"
	case "aws:eks/nodeGroup:NodeGroup":
		outputs["nodeGroupName"] = "test-node-group"
	case "aws:eks/cluster:Cluster":
		test := `
-----BEGIN CERTIFICATE-----
MIIEozCCBEmgAwIBAgIQTij3hrZsGjuULNLEDrdCpTAKBggqhkjOPQQDAjCBjzEL
MAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3RlcjEQMA4GA1UE
BxMHU2FsZm9yZDEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMTcwNQYDVQQDEy5T
ZWN0aWdvIEVDQyBEb21haW4gVmFsaWRhdGlvbiBTZWN1cmUgU2VydmVyIENBMB4X
DTI0MDMwNzAwMDAwMFoXDTI1MDMwNzIzNTk1OVowFTETMBEGA1UEAxMKZ2l0aHVi
LmNvbTBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABARO/Ho9XdkY1qh9mAgjOUkW
mXTb05jgRulKciMVBuKB3ZHexvCdyoiCRHEMBfFXoZhWkQVMogNLo/lW215X3pGj
ggL+MIIC+jAfBgNVHSMEGDAWgBT2hQo7EYbhBH0Oqgss0u7MZHt7rjAdBgNVHQ4E
FgQUO2g/NDr1RzTK76ZOPZq9Xm56zJ8wDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB
/wQCMAAwHQYDVR0lBBYwFAYIKwYBBQUHAwEGCCsGAQUFBwMCMEkGA1UdIARCMEAw
NAYLKwYBBAGyMQECAgcwJTAjBggrBgEFBQcCARYXaHR0cHM6Ly9zZWN0aWdvLmNv
bS9DUFMwCAYGZ4EMAQIBMIGEBggrBgEFBQcBAQR4MHYwTwYIKwYBBQUHMAKGQ2h0
dHA6Ly9jcnQuc2VjdGlnby5jb20vU2VjdGlnb0VDQ0RvbWFpblZhbGlkYXRpb25T
ZWN1cmVTZXJ2ZXJDQS5jcnQwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3Rp
Z28uY29tMIIBgAYKKwYBBAHWeQIEAgSCAXAEggFsAWoAdwDPEVbu1S58r/OHW9lp
LpvpGnFnSrAX7KwB0lt3zsw7CAAAAY4WOvAZAAAEAwBIMEYCIQD7oNz/2oO8VGaW
WrqrsBQBzQH0hRhMLm11oeMpg1fNawIhAKWc0q7Z+mxDVYV/6ov7f/i0H/aAcHSC
Ii/QJcECraOpAHYAouMK5EXvva2bfjjtR2d3U9eCW4SU1yteGyzEuVCkR+cAAAGO
Fjrv+AAABAMARzBFAiEAyupEIVAMk0c8BVVpF0QbisfoEwy5xJQKQOe8EvMU4W8C
IGAIIuzjxBFlHpkqcsa7UZy24y/B6xZnktUw/Ne5q5hCAHcATnWjJ1yaEMM4W2zU
3z9S6x3w4I4bjWnAsfpksWKaOd8AAAGOFjrv9wAABAMASDBGAiEA+8OvQzpgRf31
uLBsCE8ktCUfvsiRT7zWSqeXliA09TUCIQDcB7Xn97aEDMBKXIbdm5KZ9GjvRyoF
9skD5/4GneoMWzAlBgNVHREEHjAcggpnaXRodWIuY29tgg53d3cuZ2l0aHViLmNv
bTAKBggqhkjOPQQDAgNIADBFAiEAru2McPr0eNwcWNuDEY0a/rGzXRfRrm+6XfZe
SzhYZewCIBq4TUEBCgapv7xvAtRKdVdi/b4m36Uyej1ggyJsiesA
-----END CERTIFICATE-----
`
		outputs["certificateAuthority"] = map[string]any{
			"data": &test,
		}
		outputs["name"] = args.Name
		outputs["endpoint"] = "https://fakeendpoint.com"
		outputs["identities"] = []any{
			map[string]any{
				"oidcs": []any{
					map[string]any{
						"issuers": &test,
					},
				},
			},
		}
	case "aws:lb/loadBalancer:LoadBalancer":
		outputs["arn"] = "fakeARN"
	case "aws:rds/cluster:Cluster":
		outputs["endpoint"] = "mockauraoracluster.db.x10d"
	case "aws:rds/instance:Instance":
		outputs["endpoint"] = "mockrdsinstance.db.x10d"
		outputs["dnsName"] = "loadbalancer.x10d.net"
	case "aws:lb/targetGroup:TargetGroup":
		outputs["arn"] = "testTGARN"
	case "aws:kms/key:Key":
		outputs["arn"] = "fakeARN"
	case "aws:ec2/subnet:Subnet":
		outputs["id"] = "test-subnet-id"
	case "random:index/randomPassword:RandomPassword":
		outputs["result"] = "mockPass"
	case "aws:s3/bucketV2:BucketV2":
		outputs["bucket"] = "test-bucket"
	case "aws:ec2/instance:Instance":
		outputs["publicIp"] = "10.0.0.1"
		outputs["privateIp"] = "10.0.0.0"
	case "tls:index/privateKey:PrivateKey":
		outputs["privateKeyPem"] = "testPrivKey"
	case "aws:iam/policy:Policy":
		outputs["policyId"] = "test-policy-id"
	}

	return args.Name + "_id", resource.NewPropertyMapFromMap(outputs), nil
}

func (AWSMocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	outputs := args.Args.Mappable()

	switch args.Token {
	case "aws:index/getPartition:getPartition":
		outputs["partition"] = "aws-us-gov"

	case "aws:index/getRegion:getRegion":
		outputs["name"] = "us-gov-east-1"

	case "aws:ec2/getAmi:getAmi":
		outputs["name"] = "ami-02c2cad49f9ef7c21"
		outputs["id"] = "ami-123456789"

	case "aws:index/getAvailabilityZones:getAvailabilityZones":
		outputs["zoneIds"] = []string{"us-gov-east-1a", "us-gov-east-1b", "us-gov-east-1c"}
		outputs["names"] = []string{"us-gov-east-1a", "us-gov-east-1b", "us-gov-east-1c"}

	case "aws:organizations/getOrganization:getOrganization":
		outputs["arn"] = `arn:aws-us-gov:organizations::123456789012:account/o-123456789/123456789`
		outputs["id"] = "o-123456789"
		outputs["roots"] = []any{
			map[string]any{
				"id": "r-examplerootid",
			},
		}

	case "aws:autoscaling/getAmiIds:getAmiIds":
		outputs["names"] = []string{"asg-123456789"}

	case "aws:ec2transitgateway/getTransitGateway:getTransitGateway":
		outputs["transitGatewayCidrBlocks"] = []string{"10.0.0.0/26", "10.0.0.64/26", "10.0.0.128/26", "10.0.2.0/26", "10.0.2.64/26", "10.0.2.128/26"}
		outputs["ownerId"] = "testOwner123"
		outputs["associationDefaultRouteTableId"] = "tgwRTTable"

	case "aws:ec2/getSubnet:getSubnet":
		outputs["arn"] = args.Args["name"].V

	case "aws:ec2/getSubnets:getSubnets":
		outputs["id"] = "test-id"
		outputs["ids"] = []string{"testSubnetID"}

	case "aws:ec2/getVpc:getVpc":
		outputs["cidrBlock"] = "10.0.0.0/24"

	case "aws:kms/getKey:getKey":
		outputs["arn"] = "arn:aws:kms:eu-west-2:123456789012:key/1234abcd-12ab-34cd-56ef-1234567890ab"

	case "aws:s3/bucket:Bucket":
		outputs["arn"] = "arn:aws:s3::417116289550:examplebucket"

	case "aws-native:index:getAccountId":
		outputs["accountId"] = "123456789012"

	case "aws:iam/getPolicyDocument:getPolicyDocument":
		outputs["json"] = "{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Action\":\"s3:GetObject\",\"Resource\":\"arn:aws:s3:::examplebucket/*\"}]}"

	case "aws:iam/user:User":
		outputs["arn"] = "arn:aws:iam::123456789012:user/example-user"

	case "aws:ec2/getVpcEndpointService:getVpcEndpointService":
		outputs["serviceName"] = "com.amazonaws.vpce.eu-west-2.vpce-svc-0a1b2c3d4e5f67890"

	case "aws:index/getCallerIdentity:getCallerIdentity":
		outputs["accountId"] = "123456789012"

	case "aws:ec2transitgateway/getAttachments:getAttachments":
		outputs["ids"] = []string{"123456", "654321"}

	case "aws:ec2transitgateway/getPeeringAttachment:getPeeringAttachment":
		outputs["peerTransitGatewayId"] = "tgw-12345"

	case "tls:index/getCertificate:getCertificate":
		outputs["certificates"] = []any{
			map[string]any{
				"sha1Fingerprint": "success",
			},
		}
	}

	return resource.NewPropertyMapFromMap(outputs), nil
}
