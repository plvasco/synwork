package testutils

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/service/ec2"
	"github.com/stretchr/testify/mock"
)

// MockEC2Client is a mock of the EC2 client.
type MockEC2Client struct {
	mock.Mock
}

func (m *MockEC2Client) DescribeTransitGatewayAttachments(ctx context.Context, input *ec2.DescribeTransitGatewayAttachmentsInput, _ ...func(*ec2.Options)) (*ec2.DescribeTransitGatewayAttachmentsOutput, error) {
	args := m.Called(ctx, input)

	return args.Get(0).(*ec2.DescribeTransitGatewayAttachmentsOutput), args.Error(1)
}

func (m *MockEC2Client) AcceptTransitGatewayPeeringAttachment(ctx context.Context, input *ec2.AcceptTransitGatewayPeeringAttachmentInput, _ ...func(*ec2.Options)) (*ec2.AcceptTransitGatewayPeeringAttachmentOutput, error) {
	args := m.Called(ctx, input)

	return args.Get(0).(*ec2.AcceptTransitGatewayPeeringAttachmentOutput), args.Error(1)
}
