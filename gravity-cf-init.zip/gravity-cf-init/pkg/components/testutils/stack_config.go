package testutils

import (
	"encoding/json"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type StackConfig map[string]any

func (s StackConfig) DefaultConfig() {
}

func (s StackConfig) Merge(overrides map[string]any) {
	for key, value := range overrides {
		s[key] = value
	}
}

func (s StackConfig) Build() map[string]string {
	serializedConfig := map[string]string{}

	for key, value := range s {
		b, err := json.Marshal(value)
		if err != nil {
			panic(err)
		}

		var serializedValue string
		if err := json.Unmarshal(b, &serializedValue); err != nil {
			panic(err)
		}

		serializedConfig[key] = serializedValue
	}

	return serializedConfig
}

func NewConfig() StackConfig {
	config := make(StackConfig)

	config.DefaultConfig()

	return config
}

func WithMocksAndConfig(project, stack string, overrides map[string]any, mocks pulumi.MockResourceMonitor) pulumi.RunOption {
	config := NewConfig()

	if overrides != nil {
		config.Merge(overrides)
	}

	serializedConfig := config.Build()

	return func(info *pulumi.RunInfo) {
		info.Project, info.Stack, info.Mocks, info.Config = project, stack, mocks, serializedConfig
	}
}
