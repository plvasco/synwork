package testutils

import (
	"github.com/pulumi/pulumi-azure-native-sdk/containerservice/v2"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type AzureMocks int

func (AzureMocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	outputs := args.Inputs.Mappable()
	outputs["name"] = args.Name

	switch args.TypeToken {
	case "azure-native:resources:ResourceGroup":
		outputs["name"] = args.Name
	case "azure-native:network:VirtualNetwork":
		outputs["name"] = args.Name
	case "azure-native:network:Subnet":
		outputs["name"] = args.Name
	}

	return args.Name + "_id", resource.NewPropertyMapFromMap(outputs), nil
}

func (AzureMocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	outputs := args.Args.Mappable()

	if args.Token == "azure-native:containerservice:listManagedClusterAdminCredentials" {
		outputs["kubeconfigs"] = []containerservice.CredentialResultResponse{{Name: "test-kube-config", Value: "dGVzdC1rdWJlLWNvbmZpZw=="}}
	}

	return resource.NewPropertyMapFromMap(outputs), nil
}
