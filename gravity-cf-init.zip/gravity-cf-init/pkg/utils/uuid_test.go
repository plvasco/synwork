package utils_test

import (
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
)

func TestGenerateUUIDFromString(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		inputs  []string
		wants   []string
		wantErr bool
	}{
		{
			name:    "input returns value",
			inputs:  []string{"foo"},
			wants:   []string{"02762cad-4823-5c71-9530-5cec0c34bbed"},
			wantErr: false,
		},
		{
			name:    "same input returns idempotent value",
			inputs:  []string{"foo", "foo"},
			wants:   []string{"02762cad-4823-5c71-9530-5cec0c34bbed", "02762cad-4823-5c71-9530-5cec0c34bbed"},
			wantErr: false,
		},
		{
			name:    "different input returns different value",
			inputs:  []string{"foo", "bar"},
			wants:   []string{"02762cad-4823-5c71-9530-5cec0c34bbed", "b42a8597-4f37-5a74-b74c-0c18bd98d7a9"},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			results := make([]string, len(tt.inputs))
			for i, str := range tt.inputs {
				results[i] = utils.GenerateUUIDFromString(str).String()
			}

			if !reflect.DeepEqual(results, tt.wants) {
				t.Errorf("GenerateUUIDFromString() = %+v, want %+v", tt.inputs, tt.wants)
			}
		})
	}
}
