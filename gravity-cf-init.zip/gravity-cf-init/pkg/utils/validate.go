package utils

import (
	"errors"
	"fmt"
	"log"
	"reflect"
	"strings"
)

type ValidateAction string

const (
	// Set field default value, this value is unmarshalled from json format into the field.
	ValidateActionDefault = "default"
	// recurse one level on field and run validation on the nested struct.
	ValidateActionDig = "dig"
	// Set field as required and error out if field is nil.
	ValidateActionRequired = "required"
)

var (
	ErrRequiredArgument      = errors.New("required argument is missing")
	ErrRequiredMustBeNilable = errors.New("`required` tag can only be used on objects that can be nil, did you mean to use a pointer?")
)

func ValidateStruct(ptr any) error {
	t := reflect.TypeOf(ptr)
	v := reflect.ValueOf(ptr)

	if t.Kind() == reflect.Ptr {
		t = t.Elem()
		v = v.Elem()
	}

	if t.Kind() != reflect.Struct {
		return nil
	}

	for i := range t.NumField() {
		field := t.Field(i)
		value := v.Field(i)

		if err := SetField(&field, value); err != nil {
			return err
		}
	}

	return nil
}

func SetField(field *reflect.StructField, value reflect.Value) error {
	tag, ok := field.Tag.Lookup("validate")
	if !ok {
		return nil
	}

	validationActions := strings.Split(tag, ",")
	for _, validationAction := range validationActions {
		if strings.HasPrefix(validationAction, ValidateActionRequired) {
			if err := checkRequired(value); err != nil {
				return fmt.Errorf("%w: `%s`", err, field.Name)
			}
		}

		if defaultValue, ok := strings.CutPrefix(validationAction, ValidateActionDefault+"="); ok {
			if err := setDefaults(defaultValue, value); err != nil {
				return err
			}
		}

		if validationAction == ValidateActionDig {
			if err := validateNestedStruct(value); err != nil {
				return err
			}
		}
	}

	return nil
}

func checkRequired(value reflect.Value) error {
	defer func() {
		if err := recover(); err != nil {
			log.Fatal(ErrRequiredMustBeNilable, err)
		}
	}()

	if value.IsNil() {
		return ErrRequiredArgument
	}

	return nil
}

func setDefaults(defaultValue string, value reflect.Value) error {
	if value.Kind() == reflect.Ptr {
		if value.IsNil() {
			value.Set(reflect.New(value.Type().Elem()))
		}

		value = value.Elem()
	}

	if !value.IsZero() {
		return nil
	}

	if strings.Contains(strings.ToLower(value.Type().Name()), "string") {
		defaultValue = fmt.Sprintf("%q", defaultValue)
	}

	if err := UnmarshalReflection([]byte(defaultValue), value, value.Type()); err != nil {
		return err
	}

	return nil
}

func validateNestedStruct(value reflect.Value) error {
	if value.Kind() == reflect.Ptr {
		if value.IsNil() {
			value.Set(reflect.New(value.Type().Elem()))
		}

		value = value.Elem()
	}

	if value.Kind() != reflect.Struct {
		return nil
	}

	if !value.CanSet() {
		return nil
	}

	// Recursively set fields for nested structs
	if err := ValidateStruct(value.Addr().Interface()); err != nil {
		return err
	}

	return nil
}
