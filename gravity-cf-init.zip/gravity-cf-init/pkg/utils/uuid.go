package utils

import (
	"crypto/sha1"

	"github.com/google/uuid"
)

func GenerateUUIDFromString(input string) uuid.UUID {
	hash := sha1.New()
	hash.Write([]byte(input))
	hashedBytes := hash.Sum(nil)
	return uuid.NewSHA1(uuid.NameSpaceOID, hashedBytes)
}
