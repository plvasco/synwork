package utils

import (
	"maps"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

func CombineTags(baseTags, newTags pulumi.StringMap) pulumi.StringMap {
	combinedTags := maps.Clone(baseTags)

	for k, v := range newTags {
		combinedTags[k] = v
	}

	return combinedTags
}

func GenerateTags(baseTags pulumi.StringMap, name string, extraTags ...pulumi.StringMap) pulumi.StringMap {
	generatedTags := pulumi.StringMap{}

	if baseTags != nil {
		generatedTags = maps.Clone(baseTags)
	}

	generatedTags["Name"] = pulumi.String(name)

	for _, extraTag := range extraTags {
		for k, v := range extraTag {
			generatedTags[k] = v
		}
	}

	return generatedTags
}
