package utils_test

import (
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

func TestCombineTags(t *testing.T) {
	t.Parallel()

	type args struct {
		baseTags pulumi.StringMap
		newTags  pulumi.StringMap
	}

	tests := []struct {
		name string
		args args
		want pulumi.StringMap
	}{
		{
			name: "test should return with no base tags",
			args: args{
				baseTags: map[string]pulumi.StringInput{},
				newTags: map[string]pulumi.StringInput{
					"new": pulumi.String("tag"),
				},
			},
			want: map[string]pulumi.StringInput{
				"new": pulumi.String("tag"),
			},
		},
		{
			name: "test should return with base tags",
			args: args{
				baseTags: map[string]pulumi.StringInput{
					"base": pulumi.String("tag"),
				},
				newTags: map[string]pulumi.StringInput{
					"new": pulumi.String("tag"),
				},
			},
			want: map[string]pulumi.StringInput{
				"base": pulumi.String("tag"),
				"new":  pulumi.String("tag"),
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			tags := utils.CombineTags(tt.args.baseTags, tt.args.newTags)

			if !reflect.DeepEqual(tags, tt.want) {
				t.Errorf("CombineTags() = %+v, want %+v", tags, tt.want)
			}
		})
	}
}

func TestGenerateTags(t *testing.T) {
	t.Parallel()

	type args struct {
		baseTags  pulumi.StringMap
		name      string
		extraTags pulumi.StringMap
	}

	tests := []struct {
		name string
		args args
		want pulumi.StringMap
	}{
		{
			name: "test should return with no base tags",
			args: args{
				baseTags: map[string]pulumi.StringInput{},
				name:     "test",
				extraTags: map[string]pulumi.StringInput{
					"new": pulumi.String("tag"),
				},
			},
			want: map[string]pulumi.StringInput{
				"new":  pulumi.String("tag"),
				"Name": pulumi.String("test"),
			},
		},
		{
			name: "test should return with base tags",
			args: args{
				baseTags: map[string]pulumi.StringInput{
					"base": pulumi.String("tag"),
				},
				name: "test",
				extraTags: map[string]pulumi.StringInput{
					"new": pulumi.String("tag"),
				},
			},
			want: map[string]pulumi.StringInput{
				"base": pulumi.String("tag"),
				"new":  pulumi.String("tag"),
				"Name": pulumi.String("test"),
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			tags := utils.GenerateTags(tt.args.baseTags, tt.args.name, tt.args.extraTags)

			if !reflect.DeepEqual(tags, tt.want) {
				t.Errorf("CombineTags() = %+v, want %+v", tags, tt.want)
			}
		})
	}
}
