package utils

import (
	"errors"
)

var (
	ErrUnableToTypeCast = errors.New("unable to type cast the value from ApplyT")
)
