package utils_test

import (
	"reflect"
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type Person struct {
	First pulumi.StringInput `validate:"default=John"`
	Last  pulumi.StringInput `validate:"default=Doe"`
}

type Address struct {
	City    pulumi.StringInput    `validate:"default=Charleston"`
	State   pulumi.StringPtrInput `validate:"default=South Carolina"`
	ZipCode pulumi.IntInput       `validate:"default=29483"`
}

type Dog struct {
	Name      pulumi.StringInput `validate:"required"`
	Age       pulumi.IntInput    `validate:"default=3"`
	IsGoodBoy pulumi.BoolInput   `validate:"default=true"`
	*Address  `validate:"dig"`
	Owner     Person `validate:"dig"`
}

func TestValidate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		input    any
		expected any
		wantErr  bool
	}{
		{
			name:  "basic struct with defaults",
			input: &Dog{Name: pulumi.String("Spot")},
			expected: &Dog{
				Name:      pulumi.String("Spot"),
				Age:       pulumi.Int(3),
				IsGoodBoy: pulumi.Bool(true),
				Address:   &Address{City: pulumi.String("Charleston"), State: pulumi.String("South Carolina"), ZipCode: pulumi.Int(29483)},
				Owner:     Person{First: pulumi.String("John"), Last: pulumi.String("Doe")},
			},
			wantErr: false,
		},
		{
			name:  "partially filled struct",
			input: &Dog{Name: pulumi.String("Daisy"), Address: &Address{City: pulumi.String("Potato")}},
			expected: &Dog{
				Name:      pulumi.String("Daisy"),
				Age:       pulumi.Int(3),
				IsGoodBoy: pulumi.Bool(true),
				Address:   &Address{City: pulumi.String("Potato"), State: pulumi.String("South Carolina"), ZipCode: pulumi.Int(29483)},
				Owner:     Person{First: pulumi.String("John"), Last: pulumi.String("Doe")},
			},
			wantErr: false,
		},
		{
			name:    "missing required field",
			input:   &Dog{},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := utils.ValidateStruct(tt.input)
			if (err != nil) != tt.wantErr {
				t.Errorf("setFieldFromDefaultTag() error = %v, wantErr %v", err, tt.wantErr)

				return
			}

			if tt.wantErr {
				return
			}

			if !reflect.DeepEqual(tt.input, tt.expected) {
				t.Errorf("setFieldFromDefaultTag() = %+v, want %+v", tt.input, tt.expected)
			}
		})
	}
}
