package utils_test

import (
	"testing"

	"code.il2.gamewarden.io/gamewarden/platform/gravity/pkg/utils"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/stretchr/testify/assert"
)

func TestUnmarshalPulumiArgs(t *testing.T) {
	t.Parallel()

	type testStruct struct {
		Test        pulumi.StringInput
		Hello       pulumi.StringPtrInput
		Int         pulumi.IntInput
		Bool        pulumi.BoolInput
		Map         pulumi.StringMap
		NumMap      pulumi.IntMap
		StringArray pulumi.StringArray
	}

	type want struct {
		result any
	}

	type args struct {
		b    []byte
		dest any
	}

	tests := []struct {
		name    string
		args    args
		want    want
		wantErr bool
	}{
		{
			name: "unmarshals string inputs",
			args: args{
				b: []byte(`
					{
						"test": "number1",
						"hello": "world",
						"int": 1,
						"bool": true,
						"map": {
							"test": "value"
						},
						"numMap": {
							"test": 1
						},
						"stringArray": [
							"Hello",
							"World"
						]
					}`),
				dest: &testStruct{},
			},
			want: want{
				result: &testStruct{
					Test:  pulumi.String("number1"),
					Hello: pulumi.String("world"),
					Int:   pulumi.Int(1),
					Bool:  pulumi.Bool(true),
					Map: map[string]pulumi.StringInput{
						"test": pulumi.String("value"),
					},
					NumMap: map[string]pulumi.IntInput{
						"test": pulumi.Int(1),
					},
					StringArray: pulumi.StringArray{
						pulumi.String("Hello"),
						pulumi.String("World"),
					},
				},
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			if err := utils.UnmarshalPulumiArgs(tt.args.b, tt.args.dest); (err != nil) != tt.wantErr {
				t.Errorf("UnmarshalPulumiArgs() error = %v, wantErr %v", err, tt.wantErr)
			}

			assert.Equal(t, tt.want.result, tt.args.dest)
		})
	}
}
