package utils

import (
	"encoding/json"
	"errors"
	"fmt"
	"reflect"
	"strings"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

var ErrOnlyStructs = errors.New("UmarshalPulumiArgs only works on structs")

func UnmarshalPulumiArgs(b []byte, dest any) error {
	var temp map[string]json.RawMessage

	if err := json.Unmarshal(b, &temp); err != nil {
		return fmt.Errorf("unable to unmarshal key names, %w", err)
	}

	argDefinitionPtr := reflect.ValueOf(dest)

	argDefinition := argDefinitionPtr.Elem()

	if argDefinition.Type().Kind() != reflect.Struct {
		return ErrOnlyStructs
	}

	for fieldIndex := range argDefinition.NumField() {
		field := argDefinition.Type().Field(fieldIndex)

		// a non empty PkgPath means that the field is private and we cannot set it
		if field.PkgPath != "" {
			continue
		}

		fieldName := field.Name
		fieldName = strings.ToLower(fieldName[:1]) + fieldName[1:]

		if name, ok := field.Tag.Lookup("pulumi"); ok {
			fieldName = name
		}

		if value, ok := temp[fieldName]; ok {
			if err := UnmarshalReflection(value, argDefinition.Field(fieldIndex), field.Type); err != nil {
				return err
			}
		}
	}

	return nil
}

func UnmarshalReflection(raw json.RawMessage, value reflect.Value, typ reflect.Type) error {
	if typ.Kind() == reflect.Map {
		if err := unmarshalMap(raw, value, typ); err != nil {
			return err
		}

		return nil
	}

	if typ.Kind() == reflect.Slice {
		if err := unmarshalSlice(raw, value, typ); err != nil {
			return err
		}

		return nil
	}

	switch typ.Name() {
	case "StringInput", "StringPtrInput":
		var v pulumi.String
		if err := json.Unmarshal(raw, &v); err != nil {
			return fmt.Errorf("unable to unmarshal pulumi string, %w", err)
		}

		value.Set(reflect.ValueOf(v))

		return nil
	case "IntInput", "IntPtrInput":
		var v pulumi.Int

		if err := json.Unmarshal(raw, &v); err != nil {
			return fmt.Errorf("unable to unmarshal pulumi int, %w", err)
		}

		value.Set(reflect.ValueOf(v))

		return nil
	case "BoolInput", "BoolPtrInput":
		var v pulumi.Bool

		if err := json.Unmarshal(raw, &v); err != nil {
			return fmt.Errorf("unable to unmarshal pulumi bool, %w", err)
		}

		value.Set(reflect.ValueOf(v))

		return nil
	case "StringArrayInput":
		var v []string

		if err := json.Unmarshal(raw, &v); err != nil {
			return err
		}

		value.Set(reflect.ValueOf(pulumi.ToStringArray(v)))

		return nil
	}

	vptr := reflect.New(typ)
	v := vptr.Interface()

	if err := json.Unmarshal(raw, &v); err != nil {
		return fmt.Errorf("unable to unmarshal pulumi value, %w", err)
	}

	value.Set(vptr.Elem())

	return nil
}

func unmarshalMap(raw json.RawMessage, value reflect.Value, typ reflect.Type) error {
	var temp map[string]json.RawMessage

	if err := json.Unmarshal(raw, &temp); err != nil {
		return fmt.Errorf("unable to unmarshal pulumi value from map, %w", err)
	}

	mapptr := reflect.MakeMap(typ)

	for k, v := range temp {
		kptr := reflect.New(typ.Key())
		vptr := reflect.New(typ.Elem())

		rawK, err := json.Marshal(k)
		if err != nil {
			return fmt.Errorf("unable to remarshal key for nested unmarshal,  %w", err)
		}

		if err := UnmarshalReflection(rawK, kptr.Elem(), typ.Key()); err != nil {
			return err
		}

		if err := UnmarshalReflection(v, vptr.Elem(), typ.Elem()); err != nil {
			return err
		}

		mapptr.SetMapIndex(kptr.Elem(), vptr.Elem())
	}

	value.Set(mapptr)

	return nil
}

func unmarshalSlice(raw json.RawMessage, value reflect.Value, typ reflect.Type) error {
	var temp []json.RawMessage

	if err := json.Unmarshal(raw, &temp); err != nil {
		return fmt.Errorf("unable to unmarshal pulumi value from array, %w", err)
	}

	arrptr := reflect.MakeSlice(typ, len(temp), len(temp))

	for k, v := range temp {
		vptr := reflect.New(typ.Elem())

		if err := UnmarshalReflection(v, vptr.Elem(), typ.Elem()); err != nil {
			return err
		}

		arrptr.Index(k).Set(vptr.Elem())
	}

	value.Set(arrptr)

	return nil
}
